# Run this migration if ChatSession table doesn't have is_starred column
# Save as: migration_add_session_starred.py

from flask import Flask
from database.model import db
from sqlalchemy import text
import os

from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()




def add_session_starred_column():
    """Add is_starred column to chat_session table"""
    
    app = Flask(__name__)
    
    # Configure database
    database_url = os.environ.get("DATABASE_URL")
    if database_url and database_url.startswith("postgres://"):
        database_url = database_url.replace("postgres://", "postgresql://", 1)
    elif not database_url:
        database_url = "sqlite:///ai_assistant.db"
    
    app.config["SQLALCHEMY_DATABASE_URI"] = database_url
    app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
    
    db.init_app(app)
    
    with app.app_context():
        try:
            # Add the column using new SQLAlchemy 2.x syntax
            if "sqlite" in database_url.lower():
                # SQLite syntax
                sql_command = text("ALTER TABLE chat_session ADD COLUMN is_starred BOOLEAN DEFAULT 0")
            else:
                # PostgreSQL syntax
                sql_command = text("ALTER TABLE chat_session ADD COLUMN is_starred BOOLEAN DEFAULT FALSE")
            
            # Execute using new syntax
            with db.engine.connect() as connection:
                connection.execute(sql_command)
                connection.commit()
            
            print("✅ Successfully added is_starred column to chat_session table")
            
        except Exception as e:
            error_msg = str(e).lower()
            if "already exists" in error_msg or "duplicate column" in error_msg or "duplicate" in error_msg:
                print("ℹ️  Column is_starred already exists in chat_session table")
            else:
                print(f"❌ Error adding column: {str(e)}")
                raise

if __name__ == "__main__":
    add_session_starred_column()