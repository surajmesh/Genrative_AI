# This file is a simple entry point to run our Flask application 
# All the actual Flask app configuration is in app.py

from app_init import app

# Run the application when main.py is executed directly
if __name__ == "__main__":
    app.run(host="0.0.0.0",port=2394, debug=True,use_reloader=False)