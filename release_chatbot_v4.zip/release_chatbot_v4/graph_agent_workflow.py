from typing import Dict, List, Any, TypedDict
from langgraph.graph import StateGraph, END
from langgraph.checkpoint.sqlite import SqliteSaver
from langchain_core.messages import SystemMessage, HumanMessage
from langchain_openai import ChatOpenAI
from langchain_core.pydantic_v1 import BaseModel
from langchain_core.tools import tool
import logging
import json
# Display the graph
from IPython.display import Image
import pygraphviz as pgv
print(pgv.__version__)

from dotenv import load_dotenv


# Load environment variables from .env file
load_dotenv()

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# ================================
# STATE DEFINITION
# ================================

class AgentState(TypedDict):
    user_message: str
    uploaded_content: str
    use_reasoning: bool
    
    # Agent outputs
    task_breakdown: Dict[str, str]
    decisions: Dict[str, Any]
    gathered_content: str
    improved_content: str
    enhanced_prompt: str

# ================================
# INITIALIZE COMPONENTS
# ================================

memory = SqliteSaver.from_conn_string(":memory:")
model = ChatOpenAI(model="gpt-3.5-turbo", temperature=0)

# ================================
# TOOLS
# ================================

@tool
def search_web(query: str) -> str:
    """Search the web for current information when you don't know the answer."""
    try:
        from integration.web_search_agent import WebSearchAgent
        web_agent = WebSearchAgent()
        result = web_agent.search_and_summarize(query)
        
        if result.get('results'):
            web_content = []
            for item in result['results'][:3]:
                web_content.append(f"Title: {item.get('title', 'N/A')}")
                web_content.append(f"Content: {item.get('content', 'N/A')}")
                web_content.append("---")
            return "\n".join(web_content)
        return "No relevant information found."
    except Exception as e:
        return f"Web search failed: {str(e)}"

tools = [search_web]

# ================================
# PYDANTIC MODELS
# ================================

class TaskBreakdown(BaseModel):
    tasks: Dict[str, str]

class Decisions(BaseModel):
    needs_web_search: bool
    needs_code_analysis: bool
    enable_quality_loop: bool
    reasoning: str

# ================================
# AGENT NODES
# ================================

def agent1_breakdown(state: AgentState):
    """Agent 1: Requirements Breakdown"""
    logger.info("🔍 Agent 1: Breaking down tasks...")
    
    prompt = f"""Break down this user request into specific tasks:
    
        User Message: {state['user_message']}
        Uploaded Content: {state.get('uploaded_content', '')}

        Return structured tasks."""
    
    try:
        response = model.with_structured_output(TaskBreakdown).invoke([
            SystemMessage(content="You are a task breakdown specialist."),
            HumanMessage(content=prompt)
        ])
        
        return {"task_breakdown": response.tasks}
    except:
        return {"task_breakdown": {"main_task": "Process user request"}}

def agent2_decision_engine(state: AgentState):
    """Agent 2: Decision Engine & Information Gatherer"""
    logger.info("🧠 Agent 2: Making decisions and gathering info...")
    
    # Bind tools to model
    model_with_tools = model.bind_tools(tools)
    
    prompt = f"""Analyze these tasks and make decisions:

            User Message: {state['user_message']}
            Tasks: {json.dumps(state['task_breakdown'], indent=2)}

            Use the tools at your disposal to perform tasks as needed:
            - search_web: whenever user asks for information on current events or if you don't know the answer.
            Only use the tools if you don't know the answer.

            Determine:
            1. needs_web_search: Does this require current info?
            2. needs_code_analysis: Is this coding-related?
            3. enable_quality_loop: Should we improve iteratively?
            4. reasoning: Explain decisions
            """
    
    try:
        # Get decisions
        decisions_response = model.with_structured_output(Decisions).invoke([
            SystemMessage(content="You are a decision engine with tools."),
            HumanMessage(content=prompt)
        ])
        
        decisions = {
            "needs_web_search": decisions_response.needs_web_search,
            "needs_code_analysis": decisions_response.needs_code_analysis,
            "enable_quality_loop": decisions_response.enable_quality_loop,
            "reasoning": decisions_response.reasoning
        }
        
        # Gather information if needed
        gathered_content = ""
        if decisions_response.needs_web_search:
            try:
                search_result = search_web.invoke({"query": state['user_message']})
                gathered_content = f"Web Search Results:\n{search_result}"
            except:
                gathered_content = "Web search failed"
        
        return {
            "decisions": decisions,
            "gathered_content": gathered_content
        }
    except:
        return {
            "decisions": {"reasoning": "Decision engine failed"},
            "gathered_content": ""
        }

def agent3_quality_improver(state: AgentState):
    """Agent 3: Quality Loop Improver"""
    logger.info("🔧 Agent 3: Improving quality...")
    
    prompt = f"""Improve this content for quality:

        Original Request: {state['user_message']}
        Current Content: {state.get('gathered_content', '')}

        Enhance for accuracy, completeness, and relevance."""
    
    try:
        response = model.invoke([
            SystemMessage(content="You are a quality improvement specialist."),
            HumanMessage(content=prompt)
        ])
        
        return {"improved_content": response.content}
    except:
        return {"improved_content": state.get('gathered_content', '')}

def prepare_final_output(state: AgentState):
    """Prepare final enhanced prompt"""
    logger.info("📝 Preparing final output...")
    
    final_content = state.get('improved_content') or state.get('gathered_content', '')
    
    if final_content.strip():
        enhanced_prompt = f"""Based on the analysis and gathered information, respond to: {state['user_message']}

        Task Analysis: {json.dumps(state['task_breakdown'], indent=2)}

        Information:
        {final_content}

        Provide a comprehensive response addressing all aspects."""
    else:
        enhanced_prompt = state['user_message']
    
    return {"enhanced_prompt": enhanced_prompt}

# ================================
# ROUTING LOGIC
# ================================

def should_use_quality_loop(state: AgentState):
    """Route to quality loop or final output"""
    if not state.get('use_reasoning', False):
        return "prepare_final"
    
    decisions = state.get('decisions', {})
    if decisions.get('enable_quality_loop', False):
        return "agent3_quality"
    
    return "prepare_final"

# ================================
# BUILD GRAPH
# ================================

def create_multi_agent_graph():
    """Create the multi-agent workflow graph"""
    
    builder = StateGraph(AgentState)
    
    # Add nodes
    builder.add_node("agent1_breakdown", agent1_breakdown)
    builder.add_node("agent2_decision_engine", agent2_decision_engine)
    builder.add_node("agent3_quality", agent3_quality_improver)
    builder.add_node("prepare_final", prepare_final_output)
    
    # Set entry point
    builder.set_entry_point("agent1_breakdown")
    
    # Add edges
    builder.add_edge("agent1_breakdown", "agent2_decision_engine")
    
    # Conditional edge for quality loop
    builder.add_conditional_edges(
        "agent2_decision_engine",
        should_use_quality_loop,
        {
            "agent3_quality": "agent3_quality",
            "prepare_final": "prepare_final"
        }
    )
    
    # Quality to final
    builder.add_edge("agent3_quality", "prepare_final")
    
    # End at final
    builder.add_edge("prepare_final", END)
    
    return builder.compile(checkpointer=memory)

# ================================
# USAGE
# ================================

# Initialize the graph
multi_agent_graph = create_multi_agent_graph()


Image(multi_agent_graph.get_graph().draw_png())

# Run the graph
def run_agents(user_message: str, use_reasoning: bool = False, uploaded_content: str = ""):
    """Run multi-agent system"""
    
    initial_state = {
        "user_message": user_message,
        "uploaded_content": uploaded_content,
        "use_reasoning": use_reasoning,
        "task_breakdown": {},
        "decisions": {},
        "gathered_content": "",
        "improved_content": "",
        "enhanced_prompt": ""
    }
    
    result = multi_agent_graph.invoke(initial_state)
    
    return {
        "enhanced_prompt": result.get("enhanced_prompt", user_message),
        "task_breakdown": result.get("task_breakdown", {}),
        "decisions": result.get("decisions", {}),
        "gathered_content": result.get("gathered_content", ""),
        "improved_content": result.get("improved_content", ""),
        "agent_success": True
    }