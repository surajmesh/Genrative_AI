from flask import Flask, request, jsonify, session
from flask_login import LoginManager, login_required, UserMixin, current_user, login_user
import os
import logging
import time
from werkzeug.utils import secure_filename

from config import UPLOAD_FOLDER

from integration.Settings_llm import get_system_prompt
from integration.LangChainConversationHandler import LangChainMemoryManager
from integration.Get_Completion_Function import get_completion_with_memory, generate_chat_title
from integration.Settings_llm import get_models_by_provider

# Configure logging
logging.basicConfig(level=logging.INFO)
# logging.basicConfig(level=logging.DEBUG) # to show the debug Mode is on 
logger = logging.getLogger(__name__)

app = Flask(__name__)
app.secret_key = 'your-secret-key-here'

# Initialize Flask-Login
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

# Simple User class for session management
class User(UserMixin):
    def __init__(self, id):
        self.id = id

@login_manager.user_loader
def load_user(user_id):
    # Load user from database in production
    return User(user_id)

def get_or_create_memory_manager():
    # Get or create session-based memory manager
    if 'memory_id' not in session:
        session['memory_id'] = f"user_{current_user.id}_{int(time.time())}"
    
    # Create new memory manager for session
    return LangChainMemoryManager("buffer")

def cleanup_uploaded_files(uploaded_files):
    # Remove uploaded files after processing
    for file_info in uploaded_files:
        try:
            if os.path.exists(file_info["filepath"]):
                os.remove(file_info["filepath"])
        except Exception as e:
            logger.error(f"Error cleaning up file {file_info['filepath']}: {e}")

def validate_file_type(filename):
    # Validate allowed file extensions
    allowed_extensions = {'.txt', '.pdf', '.docx', '.xlsx', '.csv', '.json', '.py', '.js', '.html', '.css', 
                         '.jpg', '.jpeg', '.png', '.gif', '.bmp', '.webp', '.mp3', '.wav', '.m4a', '.ogg'}
    return any(filename.lower().endswith(ext) for ext in allowed_extensions)

def process_uploaded_files(files):
    # Process and validate all uploaded files
    uploaded_files = []
    for file in files:
        if file.filename and validate_file_type(file.filename):
            filename = secure_filename(file.filename)
            filepath = os.path.join(UPLOAD_FOLDER, filename)
            file.save(filepath)
            
            # Determine file type for processing
            file_type = determine_file_type(filename)
            uploaded_files.append({
                "filename": filename,
                "filepath": filepath,
                "type": file_type,
                "size": os.path.getsize(filepath)
            })
    return uploaded_files

def determine_file_type(filename):
    # Determine file type based on extension
    extension = filename.lower().split('.')[-1]
    if extension in ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp']:
        return 'image'
    elif extension in ['mp3', 'wav', 'm4a', 'ogg']:
        return 'audio'
    elif extension in ['pdf', 'docx', 'txt']:
        return 'document'
    elif extension in ['xlsx', 'csv']:
        return 'data'
    elif extension in ['py', 'js', 'html', 'css', 'json']:
        return 'code'
    else:
        return 'unknown'

@app.route('/api/chat/messages', methods=['POST'])
@login_required
def api_send_message():
    uploaded_files = []
    user_message = ''
    use_reasoning = False
    provider = None
    has_uploads = False
    user_selection_model = None
    
    os.makedirs(UPLOAD_FOLDER, exist_ok=True)
    
    try:
        if request.files:
            user_message = request.form.get('message', '')
            use_reasoning = request.form.get('use_reasoning', 'false').lower() == 'true'
            provider = request.form.get('provider')
            user_selection_model = request.form.get('user_selection_model')
            has_uploads = True
            
            files = request.files.getlist('files')
            uploaded_files = process_uploaded_files(files)
            
        else:
            data = request.get_json()
            if not data:
                return jsonify({"error": "No data provided"}), 400
                
            user_message = data.get('message', '')
            use_reasoning = bool(data.get("use_reasoning", False))
            provider = data.get("provider")
            user_selection_model = data.get("user_selection_model")
            has_uploads = bool(data.get("has_uploads", False))
            
        if not user_message.strip():
            return jsonify({"error": "Message is required"}), 400
        
        session_title = generate_chat_title(user_message,user_selection_model)
        logger.info(f"Generated chat title: {session_title}")
        
        memory_manager = get_or_create_memory_manager()
        logger.info(f"Langchain Memory is Activated: {memory_manager}")
        
        system_prompt = get_system_prompt(
            use_reasoning=use_reasoning, 
            uploaded_files=uploaded_files,
            has_uploads=has_uploads
        )
        
        list_models = get_models_by_provider(provider)
        print("list_models:----------------",list_models)
        
        ai_response = get_completion_with_memory(
            prompt=user_message,
            user_selection_model=user_selection_model,
            memory_manager=memory_manager,
            use_reasoning=use_reasoning,
            system_prompt=system_prompt,
            provider=provider,
            has_uploads=len(uploaded_files) > 0,
            uploaded_files=uploaded_files
        )
        
        ai_response["session_title"] = session_title
        ai_response["models"] = list_models
        
        if uploaded_files:
            cleanup_uploaded_files(uploaded_files)
        
        return jsonify(ai_response)
        
    except Exception as e:
        logger.error(f"Error in api_send_message: {str(e)}")
        
        if uploaded_files:
            cleanup_uploaded_files(uploaded_files)
            
        return jsonify({
            "error": "Internal server error",
            "success": False,
            "text": "Sorry, there was an error processing your request."
        }), 500


@app.route('/login', methods=['POST'])
def login():
    # Handle user login with credentials
    data = request.get_json()
    username = data.get('username', 'test_user')
    
    # Validate credentials in production
    user = User(username)
    login_user(user)
    return jsonify({"message": "Logged in successfully"})

@app.route('/test-login', methods=['GET'])
def test_login():
    # Quick login for development testing
    user = User('test_user') 
    login_user(user)
    return "Logged in! Now you can test the API."

@app.route('/api/upload/validate', methods=['POST'])
@login_required
def validate_upload():
    # Validate uploaded files before processing
    if not request.files:
        return jsonify({"error": "No files provided"}), 400
    
    files = request.files.getlist('files')
    validation_results = []
    
    for file in files:
        is_valid = validate_file_type(file.filename) if file.filename else False
        validation_results.append({
            "filename": file.filename,
            "valid": is_valid,
            "type": determine_file_type(file.filename) if is_valid else "unsupported"
        })
    
    return jsonify({"files": validation_results})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8000, debug=True)