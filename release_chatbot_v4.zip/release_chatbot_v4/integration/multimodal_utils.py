import base64
import io
import logging
from typing import List, Dict, Any
from PIL import Image
from langchain.schema import HumanMessage, AIMessage
from langchain_core.messages import HumanMessage, SystemMessage

logger = logging.getLogger(__name__)

def process_multimodal_content(messages: List[Dict[str, str]], files: List[Dict[str, Any]], system_prompt: str, provider: str = "standard") -> List:
    """
    Process messages with multimodal content (text, images, documents)
    Shared function used by all providers
    """
    langchain_messages = []
    
    # Add system message if provided
    if system_prompt:
        langchain_messages.append(SystemMessage(content=system_prompt))
    
    # Process conversation messages
    for i, msg in enumerate(messages):
        if msg["role"] == "user":
            content_parts = []
            
            # Add text content
            if msg["content"]:
                content_parts.append({"type": "text", "text": msg["content"]})
            
            # Add files to the last user message
            if files and i == len(messages) - 1:
                for file_info in files:
                    try:
                        if file_info.get('type') == 'image':
                            # Process image files with provider-specific format
                            content_parts.extend(process_image_content(file_info, provider))
                        elif file_info.get('type') == 'document':
                            # Process document files
                            content_parts.extend(process_document_content(file_info, provider))
                        elif file_info.get('type') == 'audio':
                            # Process audio files
                            content_parts.extend(process_audio_content(file_info))
                        elif file_info.get('type') == 'error':
                            # Handle file processing errors
                            content_parts.append({
                                "type": "text",
                                "text": f"[Error loading file {file_info['name']}: {file_info['error']}]"
                            })
                    except Exception as e:
                        logger.error(f"Error processing file {file_info.get('name', 'unknown')}: {e}")
                        content_parts.append({
                            "type": "text",
                            "text": f"[Error processing file: {file_info.get('name', 'unknown')}]"
                        })
            
            # Create HumanMessage with appropriate content
            if len(content_parts) == 1 and content_parts[0]["type"] == "text":
                langchain_messages.append(HumanMessage(content=content_parts[0]["text"]))
            elif content_parts:
                langchain_messages.append(HumanMessage(content=content_parts))
            else:
                langchain_messages.append(HumanMessage(content=""))
                
        elif msg["role"] == "assistant":
            langchain_messages.append(AIMessage(content=msg["content"]))
    
    return langchain_messages

def process_image_content(file_info: Dict[str, Any], provider: str = "standard") -> List[Dict[str, Any]]:
    """Process image file for multimodal content with provider-specific format"""
    try:
        # Validate image data
        image_data = base64.b64decode(file_info['data'])
        with io.BytesIO(image_data) as img_buffer:
            img = Image.open(img_buffer)
            img.verify()
        
        # Determine image format and MIME type
        name = file_info.get('name', '').lower()
        if name.endswith(('.jpg', '.jpeg')):
            img_format = 'jpeg'
            mime_type = 'image/jpeg'
        elif name.endswith('.png'):
            img_format = 'png'
            mime_type = 'image/png'
        elif name.endswith('.gif'):
            img_format = 'gif'
            mime_type = 'image/gif'
        elif name.endswith('.webp'):
            img_format = 'webp'
            mime_type = 'image/webp'
        else:
            img_format = 'jpeg'
            mime_type = 'image/jpeg'
        
        # Return provider-specific format
        if provider == "anthropic":
            return [
                {
                    "type": "image",
                    "source": {
                        "type": "base64",
                        "media_type": mime_type,
                        "data": file_info['data']
                    }
                }
            ]
        else:
            # Standard format for OpenAI, Google, Groq
            return [
                {
                    "type": "image_url",
                    "image_url": {
                        "url": f"data:{mime_type};base64,{file_info['data']}"
                    }
                },
                {
                    "type": "text",
                    "text": f"[Image: {file_info.get('name', 'unnamed_image')}]"
                }
            ]
    except Exception as e:
        logger.error(f"Image processing error: {e}")
        return [{"type": "text", "text": f"[Error loading image: {file_info.get('name', 'unknown')}]"}]

def process_document_content(file_info: Dict[str, Any], provider: str = "standard") -> List[Dict[str, Any]]:
    """Process document file content for AI analysis"""
    try:
        content = file_info.get('content', '')
        file_type = file_info.get('file_type', 'document')
        name = file_info.get('name', 'document')
        
        # Truncate very long documents (Anthropic has stricter limits)
        max_length = 8000 if provider == "anthropic" else 10000
        if len(content) > max_length:
            content = content[:max_length] + "... [Content truncated]"
        
        return [{
            "type": "text",
            "text": f"[{file_type.title()} File: {name}]\n\nContent:\n{content}\n\n[End of {name}]"
        }]
    except Exception as e:
        logger.error(f"Document processing error: {e}")
        return [{"type": "text", "text": f"[Error loading document: {file_info.get('name', 'unknown')}]"}]

def process_audio_content(file_info: Dict[str, Any]) -> List[Dict[str, Any]]:
    """Process audio file for transcription"""
    try:
        name = file_info.get('name', 'audio_file')
        # Note: Audio transcription would require additional service integration
        return [{
            "type": "text",
            "text": f"[Audio File: {name}] - Audio transcription not yet implemented"
        }]
    except Exception as e:
        logger.error(f"Audio processing error: {e}")
        return [{"type": "text", "text": f"[Error loading audio: {file_info.get('name', 'unknown')}]"}]