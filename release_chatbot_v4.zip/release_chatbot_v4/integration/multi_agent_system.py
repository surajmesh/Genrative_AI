from typing import Dict, List, Any, TypedDict, Optional
from langgraph.graph import StateGraph, END
from langchain_core.messages import SystemMessage, HumanMessage, ToolMessage
from langchain_openai import ChatOpenAI
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain_anthropic import ChatAnthropic
from langchain_groq import ChatGroq
from pydantic import BaseModel, Field 
from langchain_core.tools import tool
import logging
import json
from datetime import datetime

logger = logging.getLogger(__name__)

# ================================
# STATE DEFINITION
# ================================

class AgentState(TypedDict):
    messages: List[Any]
    user_message: str
    uploaded_content: str
    use_reasoning: bool
    provider: Optional[str]
    model_name: Optional[str]
    user_id: Optional[str]  

    # NEW USER MODE FLAGS
    enable_web_search: bool
    enable_deep_research: bool
    enable_study_learn: bool
    
    # Agent outputs
    task_breakdown: Dict[str, str]
    decisions: Dict[str, Any]
    gathered_content: str
    improved_content: str
    enhanced_prompt: str
    enhanced_sources: List[Dict[str, Any]]
    
    # Routing flags
    should_skip_to_llm: bool
    needs_web_only: bool
    use_lightweight_agent2: bool
    execution_path: str

# ================================
# MODEL CONFIGURATION
# ================================

def get_tool_calling_model(provider):
    TOOL_CALLING_MODELS = {
        "google": "gemini-1.5-flash",
        "openai": "gpt-4o-mini", 
        "anthropic": "claude-3-5-sonnet-20241022",
        "groq": "llama-3.3-70b-versatile"
    }
    
    model_name = TOOL_CALLING_MODELS.get(provider)
    if model_name is None:
        raise ValueError(f"No model found for provider '{provider}'")
    
    return model_name, provider

def get_agent_from_provider(provider, model_name):
    """Get specific LLM provider with model name"""
    if isinstance(provider, tuple):
        provider = provider[0]

    if provider == "openai":
        from integration.Settings_llm import OPENAI_API_KEY
        return ChatOpenAI(api_key=OPENAI_API_KEY, model=model_name, temperature=0)
    elif provider == "google":
        from integration.Settings_llm import GEMINI_API_KEY
        return ChatGoogleGenerativeAI(google_api_key=GEMINI_API_KEY, model=model_name, temperature=0)
    elif provider == "anthropic":
        from integration.Settings_llm import ANTHROPIC_API_KEY
        return ChatAnthropic(anthropic_api_key=ANTHROPIC_API_KEY, model=model_name, temperature=0)
    elif provider == "groq":
        from integration.Settings_llm import GROQ_API_KEY
        return ChatGroq(groq_api_key=GROQ_API_KEY, model=model_name, temperature=0)
    else:
        raise ValueError(f"Unknown provider: {provider}")

def get_agent_model(provider, model_name):
    """Get agent model with fallback"""
    try:
        return get_agent_from_provider(provider=provider, model_name=model_name)
    except Exception as e:
        logger.warning(f"❌ Failed Provider: {provider}, Model: {model_name}: {e}")
        # Simple fallback to groq
        try:
            return get_agent_from_provider("groq", "llama-3.3-70b-versatile")
        except:
            logger.error("❌ All providers failed")
            return None

# ================================
# TOOLS
# ================================
@tool
def search_web(query: str) -> str:
    """Search the web for current information when you don't know the answer."""
    try:
        from integration.web_search_agent import WebSearchAgent
        web_agent = WebSearchAgent()
        result = web_agent.search_and_summarize(query)
        
        if result.get('results'):
            web_content = []
            for item in result['results'][:3]:
                web_content.append(f"Title: {item.get('title', 'N/A')}")
                web_content.append(f"Content: {item.get('content', 'N/A')}")
                web_content.append("---")
            return "\n".join(web_content)
        return "No relevant information found."
    except Exception as e:
        logger.error(f"Web search failed: {e}")
        return f"Web search failed: {str(e)}"

tools = [search_web]

# ================================
# PYDANTIC MODELS
# ================================

class TaskBreakdown(BaseModel):
    tasks: Dict[str, str] = Field(default_factory=dict, description="Dictionary of task names and descriptions")
    primary_intent: str = Field(default="general", description="Primary user intent")
    complexity_score: float = Field(default=0.5, description="Task complexity from 0.0 to 1.0")

class Decisions(BaseModel):
    needs_web_search: bool = Field(default=False, description="Whether web search is needed")
    needs_code_analysis: bool = Field(default=False, description="Whether code analysis is needed")
    enable_quality_loop: bool = Field(default=False, description="Whether to enable quality improvement")
    reasoning: str = Field(default="", description="Explanation of decisions")
    confidence_score: float = Field(default=0.0, description="Confidence in decision 0-1")
    
    # NEW USER MODE FEATURES
    force_web_search: bool = Field(default=False, description="Force web search when user enables web search mode")
    force_deep_research: bool = Field(default=False, description="Enable deep research mode with comprehensive analysis")
    force_study_mode: bool = Field(default=False, description="Enable educational study/learn mode")
    
    # Additional reasoning for new modes
    agent_thinking_reasoning_instruction: str = Field(default="", description="Detailed reasoning for user display")

# To provide a comprehensive and in-depth response to your query about World War II, I will analyze the key aspects such as its chronological sequence, causes, major events, key figures, and consequences, while also incorporating the latest historical scholarship and current perspectives to ensure a nuanced and detailed overview.

# ================================
# SIMPLIFIED PROMPTS
# ================================

DEEP_RESEARCH_PROMPT = """
You are an expert research analyst. When deep research mode is enabled:

1. **COMPREHENSIVE ANALYSIS**: Combine latest web information with your knowledge base
2. **MULTIPLE PERSPECTIVES**: Present different viewpoints and approaches
3. **SOURCE EVALUATION**: Assess credibility and relevance of information
4. **DEPTH OVER BREADTH**: Provide thorough analysis rather than surface-level answers
5. **RESEARCH METHODOLOGY**: Explain how you arrived at conclusions
6. **CURRENT CONTEXT**: Always prioritize recent developments and trends

Format your response as:
- **Executive Summary**: Key findings upfront
- **Detailed Analysis**: Comprehensive breakdown
- **Supporting Evidence**: Citations and sources
- **Implications**: What this means for the user
- **Further Research**: Suggested next steps

Be thorough, analytical, and evidence-based in your approach.
"""

STUDY_LEARN_PROMPT = """

You are an expert educator and professor. When study/learn mode is enabled:

1. **CONCEPT INTRODUCTION**: Start with fundamental concepts and definitions
2. **STEP-BY-STEP EXPLANATION**: Break down complex topics into digestible parts
3. **PRACTICAL EXAMPLES**: Use real-world examples and analogies
4. **INTERACTIVE LEARNING**: Include practice questions and exercises
5. **LEARNING OBJECTIVES**: Clearly state what the student will learn
6. **KNOWLEDGE CHECK**: End with questions to test understanding

Structure your response as:
- **Learning Objectives**: What you'll learn from this lesson
- **Core Concepts**: Key definitions and principles
- **Detailed Explanation**: Step-by-step breakdown with examples
- **Practice Exercise**: Hands-on questions or problems
- **Summary**: Key takeaways
- **Next Steps**: What to study next

Use encouraging, patient teacher tone. Make complex topics accessible.
Encourage critical thinking and curiosity.

"""

ENHANCED_WEB_SEARCH_PROMPT = """
You are a comprehensive information gatherer. When web search mode is enabled:

1. **CURRENT INFORMATION**: Always search for the latest, most up-to-date information
2. **MULTIPLE SOURCES**: Gather information from diverse, credible sources
3. **FACT VERIFICATION**: Cross-reference information across sources
4. **COMPREHENSIVE COVERAGE**: Ensure all aspects of the query are addressed
5. **SOURCE ATTRIBUTION**: Clearly cite where information comes from

Enhance every response with relevant, current web information even for topics you know well.
"""


AGENT1_PROMPT = """
You are a smart task analyzer. Analyze the user request and classify it:

PRIMARY INTENT Categories:
- GREETING: Simple social interaction 
- CODE_ANALYSIS: Questions about code, programming, debugging
- INFORMATION_SEEKING: User wants to know something
- TASK_REQUEST: User wants something done
- CURRENT_INFO: Asking for latest/recent/current information

COMPLEXITY SCORING (0.0 to 1.0):
- 0.0-0.2: Very simple (greetings, basic questions)
- 0.3-0.5: Medium complexity
- 0.6-1.0: Complex (multi-step, reasoning required)

Be accurate with complexity scoring. Simple questions should get low scores.
"""

AGENT2_PROMPT = """
You are a decision engine. Based on the user request, decide what processing is needed:

- needs_web_search: True only for current/recent/latest information requests
- needs_code_analysis: True if code files are present OR user is asking about programming
- enable_quality_loop: True only for very complex analysis tasks
- reasoning: Brief explanation of your decisions

Keep decisions minimal for simple requests.
"""

# ================================
# 4. UPDATED ROUTING LOGIC
# ================================

def determine_execution_path_enhanced(state: AgentState) -> Dict[str, Any]:
    """Enhanced routing logic that considers user modes as preferences"""
    task_breakdown = state.get('task_breakdown', {})
    user_message = state['user_message'].lower()
    use_reasoning = state.get('use_reasoning', False)
    uploaded_content = bool((state.get('uploaded_content') or '').strip())
    
    # NOTE: User mode flags are available but NOT forcing routes
    enable_web_search = state.get('enable_web_search', False)
    enable_deep_research = state.get('enable_deep_research', False)
    enable_study_learn = state.get('enable_study_learn', False)
    
    primary_intent = task_breakdown.get('primary_intent', 'general')
    complexity_score = task_breakdown.get('complexity_score', 0.5)
    
    # EXISTING LOGIC (unchanged) - no forced mode routing
    if primary_intent == 'greeting' or any(greeting in user_message for greeting in ['hello', 'hi', 'hey', 'good morning']):
        return {
            'use_lightweight_agent2': True,
            'execution_path': 'lightweight_agent2',
            'reason': 'Simple greeting'
        }
        
    if ('what is' in user_message and len(user_message.split()) <= 5 and 
        not any(current in user_message for current in ['current', 'latest', 'recent', 'today', '2025'])):
        return {
            'use_lightweight_agent2': True,
            'execution_path': 'lightweight_agent2', 
            'reason': 'Basic definition - no web search needed'
        }
    
    if uploaded_content or use_reasoning:
        return {
            'execution_path': 'full_pipeline',
            'reason': 'Uploaded content or reasoning requested'
        }
    
    if any(indicator in user_message for indicator in ['current', 'latest', 'recent', 'today', 'now', '2025', 'weather']):
        return {
            'needs_web_only': True,
            'execution_path': 'web_only',
            'reason': 'Current information needed'
        }
    
    if primary_intent == 'code_analysis' or any(word in user_message for word in ['code', 'function', 'debug', 'programming']):
        return {
            'execution_path': 'full_pipeline',
            'reason': 'Code analysis needed'
        }
    
    if complexity_score <= 0.3:
        return {
            'use_lightweight_agent2': True,
            'execution_path': 'lightweight_agent2',
            'reason': f'Simple query (complexity: {complexity_score})'
        }
    
    return {
        'execution_path': 'full_pipeline',
        'reason': f'Complex query (intent: {primary_intent}, complexity: {complexity_score})'
    }

# ================================
# AGENT IMPLEMENTATIONS
# ================================

def agent1_breakdown(state: AgentState):
    """Agent 1: Simple task breakdown"""
    logger.info("🔍 Agent 1: Task breakdown...")
    
    provider = state.get('provider', 'groq')
    model_name = state.get('model_name', 'llama-3.3-70b-versatile')
    
    # QUICK PATTERN MATCHING FIRST
    user_msg = state['user_message'].lower().strip()
    
    # Handle obvious cases without LLM
    if user_msg in ['hello', 'hi', 'hey', 'good morning', 'good evening']:
        task_dict = {
            "task": "greeting",
            "primary_intent": "greeting", 
            "complexity_score": 0.1
        }
    elif user_msg.startswith('what is ') and len(user_msg.split()) <= 4:
        task_dict = {
            "task": "basic_definition",
            "primary_intent": "information_seeking",
            "complexity_score": 0.2
        }
    else:
        # Use LLM for complex queries
        model = get_agent_model(provider, model_name)
        if not model:
            return _fallback_agent1_result(state)
        
        prompt = f"""Analyze: "{state['user_message']}"
        
        Length: {len(state['user_message'].split())} words
        Has uploads: {bool(state.get('uploaded_content', ''))}
        
        Classify the intent and complexity accurately."""
        
        try:
            response = model.with_structured_output(TaskBreakdown, method="function_calling").invoke([
                SystemMessage(content=AGENT1_PROMPT),
                HumanMessage(content=prompt)
            ])

            logger.info(f"✅ Agent:1 Using Provider: {provider}, Model: {model_name}")
            
            logger.info((f"✅ Agent:1 primery intent: {response.primary_intent}"))
            task_dict = {
                "task": "process_request",
                "primary_intent": response.primary_intent,
                "complexity_score": response.complexity_score
            }
            
        except Exception as e:
            logger.error(f"Agent 1 error: {e}")
            return _fallback_agent1_result(state)
    
    # Determine execution path
    routing = determine_execution_path_enhanced({**state, 'task_breakdown': task_dict})
    
    logger.info(f"🎯 Routing decision: {routing['execution_path']} - {routing.get('reason', '')}")
    
    return {
        "task_breakdown": task_dict,
        "should_skip_to_llm": routing.get('should_skip_to_llm', False),
        "needs_web_only": routing.get('needs_web_only', False),
        "use_lightweight_agent2": routing.get('use_lightweight_agent2', False),
        "execution_path": routing['execution_path'],
        "messages": state.get('messages', [])
    }

def _fallback_agent1_result(state: AgentState):
    """Fallback when agent1 fails"""
    return {
        "task_breakdown": {"task": "process_request", "primary_intent": "general", "complexity_score": 0.5},
        "should_skip_to_llm": False,
        "needs_web_only": False,
        "use_lightweight_agent2": False,
        "execution_path": "full_pipeline",
        "messages": state.get('messages', [])
    }

def agent2_lightweight(state: AgentState):
    """Lightweight Agent2: For simple queries"""
    logger.info("🔍 Agent 2: Lightweight processing...")
    
    # For simple queries, make minimal decisions without complex LLM calls
    user_message = state['user_message'].lower()
    
    # Simple decision logic
    decisions = {
        "needs_web_search": False,  # Lightweight never does web search
        "needs_code_analysis": bool(state.get('uploaded_content', '')),
        "enable_quality_loop": False,  # Never for lightweight
        "reasoning": "Lightweight processing for simple query",
        "confidence_score": 0.8
    }
    
    return {
        "decisions": decisions,
        "gathered_content": "",
        "enhanced_sources": [],
        "messages": state.get('messages', [])
    }

def web_search_only(state: AgentState):
    """Web search for current information queries"""
    logger.info("🔍 Web search only...")
    
    try:
        # Check plan limits
        user_id = state.get('user_id')
        if user_id:
            try:
                from services.plan_manager import PlanManager
                web_search_check = PlanManager.check_web_search_permission(user_id)
                if not web_search_check['allowed']:
                    logger.warning(f"Web search blocked: {web_search_check['reason']}")
                    return {
                        "gathered_content": f"Note: Web search unavailable - {web_search_check['reason']}",
                        "enhanced_sources": [],
                        "messages": state.get('messages', [])
                    }
            except Exception as plan_error:
                logger.error(f"Plan check failed: {plan_error}")
        
        # Perform web search
        from integration.web_search_agent import WebSearchAgent
        web_agent = WebSearchAgent()
        web_results = web_agent.search_and_summarize(state['user_message'])
        
        enhanced_sources = []
        gathered_content = ""
        
        if web_results.get('results'):
            enhanced_sources = web_results['results']
            
            content_parts = []
            for i, result in enumerate(web_results['results'], 1):
                content_parts.append(f"Source {i}: {result['title']}")
                content_parts.append(f"Content: {result['content']}")
                if result.get('url'):
                    content_parts.append(f"URL: {result['url']}")
                content_parts.append("")
            
            gathered_content = "\n".join(content_parts)
            logger.info(f"📌 Web search completed: {len(enhanced_sources)} sources")
        
        return {
            "gathered_content": gathered_content,
            "enhanced_sources": enhanced_sources,
            "messages": state.get('messages', [])
        }
        
    except Exception as e:
        logger.error(f"Web search failed: {e}")
        return {
            "gathered_content": "",
            "enhanced_sources": [],
            "messages": state.get('messages', [])
        }

# ================================
# 5. ENHANCED AGENT2 DECISION ENGINE
# ================================

def agent2_decision_engine_enhanced(state: AgentState):
    """Enhanced Agent 2 with smart user mode preferences"""
    logger.info("🔍 Agent 2: Enhanced decision engine...")
    
    provider = state.get('provider', 'groq')
    model_name = state.get('model_name', 'llama-3.3-70b-versatile')
    
    # Get user mode preferences (not overrides)
    enable_web_search = state.get('enable_web_search', False)
    enable_deep_research = state.get('enable_deep_research', False)
    enable_study_learn = state.get('enable_study_learn', False)
    
    model = get_agent_model(provider, model_name)
    if not model:
        return _fallback_agent2_result_enhanced(state)
    
    # Build context with mode preferences
    mode_context = ""
    if enable_web_search:
        mode_context += "\n🔍 USER PREFERS: Web search for comprehensive information when relevant"
    if enable_deep_research:
        mode_context += "\n🧠 USER PREFERS: Deep research analysis when topic warrants it"
    if enable_study_learn:
        mode_context += "\n📚 USER PREFERS: Educational explanations when learning is involved"
    
    context = f"""
    User Message: {state['user_message']}
    Task Analysis: {json.dumps(state['task_breakdown'], indent=2)}
    Has Uploads: {bool(state.get('uploaded_content', ''))}
    Current date: {datetime.now().strftime('%B %d, %Y')}
    
    USER MODE PREFERENCES:{mode_context}
    
    Decide based on the content what processing is needed. Consider user preferences but only activate them when the message content would benefit from it.
    
    For simple greetings or basic interactions, don't activate advanced modes even if user has preferences set.
    """
    
    # Enhanced system prompt with smart decision making
    system_prompt = f"""{AGENT2_PROMPT}
    
    IMPORTANT: User mode preferences should only be activated when the message content would genuinely benefit from them:
    - Web search: Only for current/recent information needs or when you lack knowledge
    - Deep research: Only for complex analysis topics that warrant comprehensive investigation  
    - Study/learn: Only when user is asking to learn/understand concepts
    
    For simple social interactions (greetings, thanks, etc.), use minimal processing regardless of user preferences.
    """
    
    try:
        decision_response = model.with_structured_output(
            Decisions, 
            method="function_calling"
        ).invoke([
            SystemMessage(content=system_prompt),
            HumanMessage(content=context)
        ])
        
        # Smart mode application based on LLM decision + user preferences
        needs_web_search = apply_web_search_preference(decision_response, enable_web_search, state)
        enable_quality_loop = apply_quality_preference(decision_response, enable_deep_research)
        
        decisions = {
            "needs_web_search": needs_web_search,
            "needs_code_analysis": decision_response.needs_code_analysis,
            "enable_quality_loop": enable_quality_loop,
            "reasoning": decision_response.reasoning,
            "confidence_score": decision_response.confidence_score,
            
            # Mode preferences (not forced activation)
            "user_web_search_preference": enable_web_search,
            "user_deep_research_preference": enable_deep_research,
            "user_study_preference": enable_study_learn,
            "mode_reasoning": generate_mode_reasoning(needs_web_search, enable_quality_loop, enable_study_learn)
        }
        
        logger.info(f"✅ Agent:2 Enhanced - Provider: {provider}, Model: {model_name}")
        logger.info(f"🎯 Smart Decisions - Web: {needs_web_search}, Quality: {enable_quality_loop}")
        
        gathered_content = ""
        enhanced_sources = []
        
        # Apply web search if decided
        if needs_web_search:
            web_result = web_search_enhanced(state)
            gathered_content += web_result.get('gathered_content', '')
            enhanced_sources.extend(web_result.get('enhanced_sources', []))
        
        # Apply code analysis if needed
        if decisions["needs_code_analysis"] and state.get('uploaded_content'):
            code_analysis = f"\n\nUploaded Code Content:\n{state['uploaded_content']}"
            gathered_content += code_analysis
        
        return {
            "decisions": decisions,
            "gathered_content": gathered_content,
            "enhanced_sources": enhanced_sources,
            "messages": state.get('messages', [])
        }
        
    except Exception as e:
        logger.error(f"Agent 2 enhanced error: {e}")
        return _fallback_agent2_result_enhanced(state)

def _generate_mode_reasoning(web_search, deep_research, study_learn):
    """Generate reasoning explanation for user modes"""
    modes = []
    if web_search: modes.append("Web Search for current information")
    if deep_research: modes.append("Deep Research for comprehensive analysis")
    if study_learn: modes.append("Study/Learn for educational explanation")
    
    if modes:
        return f"Enhanced response using: {', '.join(modes)}"
    return "Standard processing mode"

def _fallback_agent2_result_enhanced(state: AgentState):
    """Enhanced fallback with user mode support"""
    enable_web_search = state.get('enable_web_search', False)
    enable_deep_research = state.get('enable_deep_research', False)
    enable_study_learn = state.get('enable_study_learn', False)
    
    return {
        "decisions": {
            "needs_web_search": enable_web_search or enable_deep_research,
            "needs_code_analysis": bool(state.get('uploaded_content')),
            "enable_quality_loop": enable_deep_research,
            "reasoning": "Fallback decisions with user modes",
            "confidence_score": 0.0,
            "force_web_search": enable_web_search,
            "force_deep_research": enable_deep_research,
            "force_study_mode": enable_study_learn,
            "agent_thinking_reasoning_instruction": _generate_mode_reasoning(enable_web_search, enable_deep_research, enable_study_learn)
        },
        "gathered_content": "",
        "enhanced_sources": [],
        "messages": state.get('messages', [])
    }

def agent3_quality_improver(state: AgentState):
    """Agent 3: Quality improvement for complex queries only"""
    logger.info("🔍 Agent 3: Quality improvement...")
    
    provider = state.get('provider', 'groq')
    model_name = state.get('model_name', 'llama-3.3-70b-versatile')
    
    model = get_agent_model(provider, model_name)
    if not model:
        return {
            "improved_content": state.get('gathered_content', ''),
            "messages": state.get('messages', [])
        }
    
    prompt = f"""Enhance this content for better quality:

    Original Request: {state['user_message']}
    Current Content: {state.get('gathered_content', '')}

    Make it more comprehensive and accurate."""
            
    try:
        response = model.invoke([
            SystemMessage(content="You enhance content for accuracy and completeness."),
            HumanMessage(content=prompt)
        ])

        logger.info(f"✅ Agent:3 Using Provider: {provider}, Model: {model_name}")
        return {
            "improved_content": response.content,
            "messages": state.get('messages', [])
        }
    except Exception as e:
        logger.error(f"Agent 3 error: {e}")
        return {
            "improved_content": state.get('gathered_content', ''),
            "messages": state.get('messages', [])
        }

def prepare_final_output(state: AgentState):
    """Prepare final enhanced prompt"""
    
    final_content = state.get('improved_content') or state.get('gathered_content', '')
    
    # Keep prompts shorter to avoid token limits
    if final_content.strip():
        if len(final_content) > 2000:  # Truncate to prevent token overflow
            final_content = final_content[:2000] + "...[truncated]"
            
        enhanced_prompt = f"""Respond to: {state['user_message']}

    Context:
    {final_content}

    Provide a helpful response."""
    else:
        enhanced_prompt = state['user_message']
    
    return {
        "enhanced_prompt": enhanced_prompt,
        "messages": state.get('messages', [])
    }


# ================================
# Smart preference application functions
# ================================

def apply_web_search_preference(llm_decision, user_prefers_web_search, state):
    """Apply web search preference intelligently"""
    
    # If LLM says web search needed, always do it
    if llm_decision.needs_web_search:
        return True
    
    # If user prefers web search, only apply for medium+ confidence decisions
    if user_prefers_web_search and llm_decision.confidence_score >= 0.4:
        user_message = state['user_message'].lower()
        
        # Skip for obvious simple interactions
        if any(simple in user_message for simple in ['hello', 'hi', 'thanks', 'thank you', 'ok', 'yes', 'no']):
            return False
            
        # Apply for information-seeking queries
        if any(info_word in user_message for info_word in ['tell me', 'what', 'how', 'why', 'explain', 'about']):
            return True
    
    return False

def apply_quality_preference(llm_decision, user_prefers_deep_research):
    """Apply deep research preference intelligently"""
    
    # If LLM says quality loop needed, always do it
    if llm_decision.enable_quality_loop:
        return True
    
    # If user prefers deep research and it's a complex query
    if user_prefers_deep_research and llm_decision.confidence_score >= 0.6:
        return True
    
    return False

def generate_mode_reasoning(web_search_active, quality_active, study_preference):
    """Generate reasoning for mode decisions"""
    active_modes = []
    if web_search_active: active_modes.append("Web Search")
    if quality_active: active_modes.append("Deep Analysis")
    if study_preference: active_modes.append("Educational Focus")
    
    if active_modes:
        return f"Enhanced processing: {', '.join(active_modes)}"
    return "Standard processing"


# ================================
# 6. ENHANCED WEB SEARCH
# ================================

def web_search_enhanced(state: AgentState):
    """Enhanced web search with user mode support"""
    logger.info("🔍 Enhanced web search...")
    
    enable_deep_research = state.get('enable_deep_research', False)
    
    try:
        # Check plan limits
        user_id = state.get('user_id')
        if user_id:
            try:
                from services.plan_manager import PlanManager
                web_search_check = PlanManager.check_web_search_permission(user_id)
                if not web_search_check['allowed']:
                    logger.warning(f"Web search blocked: {web_search_check['reason']}")
                    return {
                        "gathered_content": f"Note: Web search unavailable - {web_search_check['reason']}",
                        "enhanced_sources": [],
                        "messages": state.get('messages', [])
                    }
            except Exception as plan_error:
                logger.error(f"Plan check failed: {plan_error}")
        
        # Enhanced search for deep research mode
        from integration.web_search_agent import WebSearchAgent
        web_agent = WebSearchAgent()
        
        # Multiple searches for deep research
        if enable_deep_research:
            # Primary search
            web_results = web_agent.search_and_summarize(state['user_message'])
            
            # Additional related searches for comprehensive coverage
            additional_queries = _generate_related_queries(state['user_message'])
            for query in additional_queries[:2]:  # Limit to avoid too many requests
                try:
                    additional_results = web_agent.search_and_summarize(query)
                    if additional_results.get('results'):
                        web_results['results'].extend(additional_results['results'][:2])
                except Exception as e:
                    logger.warning(f"Additional search failed: {e}")
        else:
            web_results = web_agent.search_and_summarize(state['user_message'])
        
        enhanced_sources = []
        gathered_content = ""
        
        if web_results.get('results'):
            enhanced_sources = web_results['results']
            
            content_parts = []
            for i, result in enumerate(web_results['results'], 1):
                content_parts.append(f"Source {i}: {result['title']}")
                content_parts.append(f"Content: {result['content']}")
                if result.get('url'):
                    content_parts.append(f"URL: {result['url']}")
                content_parts.append("")
            
            gathered_content = "\n".join(content_parts)
            logger.info(f"📌 Enhanced web search completed: {len(enhanced_sources)} sources")
        
        return {
            "gathered_content": gathered_content,
            "enhanced_sources": enhanced_sources,
            "messages": state.get('messages', [])
        }
        
    except Exception as e:
        logger.error(f"Enhanced web search failed: {e}")
        return {
            "gathered_content": "",
            "enhanced_sources": [],
            "messages": state.get('messages', [])
        }

def _generate_related_queries(original_query):
    """Generate related search queries for deep research"""
    # Simple related query generation
    base_terms = original_query.lower().split()
    related_queries = []
    
    if len(base_terms) > 1:
        related_queries.append(f"{original_query} latest trends 2025")
        related_queries.append(f"{original_query} expert analysis")
    
    return related_queries

# ================================
# 7. ENHANCED FINAL PROMPT PREPARATION
# ================================

def prepare_final_output_enhanced(state: AgentState):
    """Enhanced final output with smart mode application"""
    
    final_content = state.get('improved_content') or state.get('gathered_content', '')
    decisions = state.get('decisions', {})
    
    # Get actual applied modes (not just preferences)
    web_search_applied = decisions.get('needs_web_search', False)
    quality_applied = decisions.get('enable_quality_loop', False)
    study_preference = state.get('enable_study_learn', False)
    
    # Select appropriate prompt based on what was actually applied
    mode_prompt = ""
    if study_preference and (web_search_applied or quality_applied):
        mode_prompt = STUDY_LEARN_PROMPT
    elif quality_applied:
        mode_prompt = DEEP_RESEARCH_PROMPT
    elif web_search_applied:
        mode_prompt = ENHANCED_WEB_SEARCH_PROMPT
    
    # Build enhanced prompt
    if final_content.strip():
        if len(final_content) > 2000:
            final_content = final_content[:2000] + "...[truncated]"
        
        if mode_prompt:
            enhanced_prompt = f"""{mode_prompt}

            User Request: {state['user_message']}

            Context and Information:
            {final_content}

            Provide a response following the specified guidelines above."""
        else:
            enhanced_prompt = f"""Respond to: {state['user_message']}

            Context:
            {final_content}

            Provide a helpful response."""
    else:
        if mode_prompt:
            enhanced_prompt = f"""{mode_prompt}

            User Request: {state['user_message']}

            Provide a response following the specified guidelines."""
        else:
            enhanced_prompt = state['user_message']
    
    return {
        "enhanced_prompt": enhanced_prompt,
        "messages": state.get('messages', [])
    }


# ================================
# 8. UPDATED MAIN RUN FUNCTION
# ================================

def run_agents_enhanced(user_message: str, use_reasoning: bool = False, provider: Optional[str] = None,
                       uploaded_content: str = "", session_id: str = "default", 
                       user_id: str = None, enable_web_search: bool = False,
                       enable_deep_research: bool = False, enable_study_learn: bool = False):
    """Enhanced multi-agent runner with user modes"""
    
    # Use provided provider or default
    selected_provider = provider or "groq"
    selected_model_name, _ = get_tool_calling_model(selected_provider)
    
    initial_state = {
        "messages": [],
        "user_message": user_message,
        "uploaded_content": uploaded_content,
        "use_reasoning": use_reasoning,
        "provider": selected_provider,       
        "model_name": selected_model_name, 
        "user_id": user_id,
        
        # NEW: User mode flags
        "enable_web_search": enable_web_search,
        "enable_deep_research": enable_deep_research,
        "enable_study_learn": enable_study_learn,
        
        "task_breakdown": {},
        "decisions": {},
        "gathered_content": "",
        "improved_content": "",
        "enhanced_prompt": "",
        "enhanced_sources": [],
        "should_skip_to_llm": False,
        "needs_web_only": False,
        "use_lightweight_agent2": False,
        "execution_path": "unknown"
    }
    
    try:
        graph = create_enhanced_multi_agent_graph()
        result = graph.invoke(initial_state)
        
        execution_path = result.get("execution_path", "unknown")
        
        return {
            "enhanced_prompt": result.get("enhanced_prompt", user_message),
            "task_breakdown": result.get("task_breakdown", {}),
            "decisions": result.get("decisions", {}),
            "gathered_content": result.get("gathered_content", ""),
            "improved_content": result.get("improved_content", ""),
            "agent_success": True,
            "enhanced_sources": result.get("enhanced_sources", []),
            "execution_path": execution_path,
            "agent_enhanced_sources": result.get("enhanced_sources", []),
            
            # NEW: User mode information
            "user_modes": {
                "web_search_enabled": enable_web_search,
                "deep_research_enabled": enable_deep_research,
                "study_learn_enabled": enable_study_learn
            }
        }
        
    except Exception as e:
        logger.error(f"Error running enhanced agents: {e}")
        return {
            "enhanced_prompt": user_message,
            "task_breakdown": {},
            "decisions": {},
            "gathered_content": "",
            "improved_content": "",
            "agent_success": False,
            "enhanced_sources": [],
            "execution_path": "error",
            "error": str(e),
            "user_modes": {
                "web_search_enabled": enable_web_search,
                "deep_research_enabled": enable_deep_research,
                "study_learn_enabled": enable_study_learn
            }
        }

def create_enhanced_multi_agent_graph():
    """Create enhanced multi-agent workflow with user modes"""
    
    builder = StateGraph(AgentState)
    
    # Add nodes (using enhanced versions)
    builder.add_node("agent1_breakdown", agent1_breakdown)  # Uses enhanced routing
    builder.add_node("agent2_lightweight", agent2_lightweight)
    builder.add_node("web_search_only", web_search_enhanced)  # Enhanced
    builder.add_node("agent2_decision_engine", agent2_decision_engine_enhanced)  # Enhanced
    builder.add_node("agent3_quality", agent3_quality_improver)
    builder.add_node("prepare_final", prepare_final_output_enhanced)  # Enhanced
    
    # Set entry point
    builder.set_entry_point("agent1_breakdown")
    
    # Updated routing function to use enhanced logic
    def routing_decision_enhanced(state: AgentState):
        """Enhanced routing that lets agents decide mode application"""
        
        # Use existing routing logic - no forced mode overrides
        if state.get('use_lightweight_agent2', False):
            return "agent2_lightweight"
        elif state.get('needs_web_only', False):
            return "web_search_only"
        else:
            return "agent2_decision_engine"
    
    # Routing from Agent1
    builder.add_conditional_edges(
        "agent1_breakdown",
        routing_decision_enhanced,
        {
            "agent2_lightweight": "agent2_lightweight",
            "web_search_only": "web_search_only",
            "agent2_decision_engine": "agent2_decision_engine"
        }
    )
    
    # Lightweight Agent2 → final
    builder.add_edge("agent2_lightweight", "prepare_final")
    
    # Web search only → final
    builder.add_edge("web_search_only", "prepare_final")
    
    # Full Agent2 → quality loop decision
    def should_use_quality_loop_enhanced(state: AgentState):
        """Enhanced quality loop decision based on agent decisions"""
        
        # Use agent's decision, not forced mode activation
        decisions = state.get('decisions', {})
        if decisions.get('enable_quality_loop', False):
            return "agent3_quality"
        
        return "prepare_final"
    
    builder.add_conditional_edges(
        "agent2_decision_engine",
        should_use_quality_loop_enhanced,
        {
            "agent3_quality": "agent3_quality",
            "prepare_final": "prepare_final"
        }
    )
    
    # Quality → final
    builder.add_edge("agent3_quality", "prepare_final")
    
    # End at final
    builder.add_edge("prepare_final", END)
    
    return builder.compile()
# ================================
# 9. COMPATIBILITY WRAPPER
# ================================

def run_agents(user_message: str, use_reasoning: bool = False, uploaded_content: str = "", 
               session_id: str = "default", user_id: str = None, provider: str = None,
               enable_web_search: bool = False, enable_deep_research: bool = False, 
               enable_study_learn: bool = False):
    """Updated wrapper with new parameters"""
    return run_agents_enhanced(
        user_message=user_message,
        use_reasoning=use_reasoning,
        provider=provider,
        uploaded_content=uploaded_content,
        session_id=session_id,
        user_id=user_id,
        enable_web_search=enable_web_search,
        enable_deep_research=enable_deep_research,
        enable_study_learn=enable_study_learn
    )