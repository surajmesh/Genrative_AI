import time
import base64
import io
import traceback
import logging
from typing import List, Dict, Any
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain_anthropic import ChatAnthropic
from langchain_groq import ChatGroq

from integration.multimodal_utils import process_multimodal_content
from integration.OpenAI_llm import (regular_openai_llm , OSeries_llm)
from integration.Settings_llm import (
    GEMINI_API_KEY, ANTHROPIC_API_KEY, GROQ_API_KEY,
    get_token_limit, get_model_config , DEFAULT_MODELS
)

from services.plan_manager import PlanManager
# Remove duplicate import - keep only the line above

# Configure logging
logger = logging.getLogger(__name__)

def calculate_tokens_and_cost(provider, model, messages, response_text):
    """Calculate tokens and cost for billing"""
    try:
        # Simple token estimation (you can replace with actual tokenizer)
        input_text = " ".join([msg.get("content", "") for msg in messages])
        
        # Rough token calculation (1 token ≈ 0.75 words)
        input_tokens = int(len(input_text.split()) * 1.3)
        output_tokens = int(len(response_text.split()) * 1.3)
        
        # FIXED: Use PlanManager instead of DatabaseService
        estimated_cost = PlanManager.calculate_token_cost(
            provider, model, input_tokens, output_tokens
        )
        
        return {
            "input_tokens": input_tokens,
            "output_tokens": output_tokens,
            "total_tokens": input_tokens + output_tokens,
            "estimated_cost": estimated_cost
        }
    except Exception as e:
        logger.error(f"Error calculating tokens: {e}")
        return {
            "input_tokens": 0,
            "output_tokens": 0,
            "total_tokens": 0,
            "estimated_cost": 0.0
        }

def calculate_groq_cost(model: str, input_tokens: int, output_tokens: int) -> float:
    """Calculate estimated cost for Groq API usage"""
    try:
        # FIXED: Use PlanManager instead of DatabaseService
        return PlanManager.calculate_token_cost("groq", model, input_tokens, output_tokens)
    except Exception as e:
        logger.error(f"Error calculating Groq cost: {e}")
        # Fallback to manual calculation
        GROQ_PRICING = {
            "llama-3.1-8b-instant": {"input": 0.05, "output": 0.08},
            "llama-3.1-70b-versatile": {"input": 0.59, "output": 0.79},
            "llama-3.3-70b-versatile": {"input": 0.59, "output": 0.79},
            "deepseek-r1-distill-llama-70b": {"input": 0.59, "output": 0.79},
            "meta-llama/llama-4-scout-17b-16e-instruct": {"input": 0.20, "output": 0.30},
            "meta-llama/llama-4-maverick-17b-128e-instruct": {"input": 0.25, "output": 0.35},
        }
        
        model_pricing = GROQ_PRICING.get(model, {"input": 0.20, "output": 0.30})
        input_cost = (input_tokens / 1_000_000) * model_pricing["input"]
        output_cost = (output_tokens / 1_000_000) * model_pricing["output"]
        return input_cost + output_cost

def _try_groq(messages: List[Dict[str, str]], system_prompt: str, use_reasoning: bool, 
              files: List[Dict[str, Any]] = None, has_uploads: bool = False, 
              current_model: str = None) -> Dict[str, Any]:   
    """Try Groq provider with multimodal support, dynamic model selection, and token tracking"""
    
    # logger.info(f"Groq API receiving message: {messages[-1]['content'][:300]}...")
    
    # Use passed model or fall back to default
    model_to_use = current_model or DEFAULT_MODELS.get("groq", "llama-3.1-8b-instant")
    
    # logger.info(f"Groq using model: {model_to_use}")

    result = {
        "text": "",
        "success": True,
        "provider": "groq",
        "model": model_to_use,
        "elapsed_time": 0,
        "error": None,
        # Token tracking fields
        "input_tokens": 0,
        "output_tokens": 0,
        "total_tokens": 0,
        "estimated_cost": 0.0
    }
    
    try:
        start_time = time.time()
        # Check if there are images
        has_images = False
        if files:
            for file_data in files:
                if file_data.get('type') == 'image':
                    has_images = True
                    break
        
        if has_images:
            # Instead of error, send helpful message to user
            helpful_message = f"""I can see you've uploaded an image, but I'm currently using Groq's {model_to_use} model, which only supports text analysis.

                **To analyze your image, please:**
                1. Switch to a vision-capable provider (Google, OpenAI, or Anthropic)
                2. Or ask me about the text/code files you've uploaded instead

                **What I can help with using Groq:**
                - Code analysis and modifications
                - Text document analysis  
                - Programming questions
                - General text-based queries

                Would you like me to help with any text-based content, or would you prefer to switch providers for image analysis?"""

            result.update({
                "text": helpful_message,
                "success": True,  # ✅ Success, not error
                "elapsed_time": time.time() - start_time,
                "input_tokens": 50,  # Rough estimate
                "output_tokens": len(helpful_message.split()),
                "total_tokens": 50 + len(helpful_message.split()),
                "estimated_cost": 0.0
            })
            
            logger.info(f"ℹ️ Groq: Explained image limitation to user")

            return result
        
        # Initialize Groq LLM with selected model
        llm = ChatGroq(
            groq_api_key=GROQ_API_KEY,
            model=model_to_use,
            temperature=0.7,
            max_tokens=get_token_limit(bool(files)),
            timeout=60
        )

        # Process multimodal content
        langchain_messages = process_multimodal_content(messages, files or [], system_prompt)
        
        # Calculate input tokens before API call
        input_text = ""
        if system_prompt:
            input_text += f"System: {system_prompt}\n\n"
        
        for msg in messages:
            if msg.get("role") in ["user", "assistant"]:
                role = "Human" if msg["role"] == "user" else "Assistant"
                content = msg.get("content", "")
                input_text += f"{role}: {content}\n\n"
        
        # Add file content to input calculation
        if files:
            for file_data in files:
                input_text += f"File: {file_data.get('content', '')}\n\n"
        
        # Estimate input tokens (rough calculation: 1 token ≈ 0.75 words)
        input_tokens = int(len(input_text.split()) * 1.3)
        
        # Generate response
        response = llm.invoke(langchain_messages)
        
        response_text = response.content
        
        # Calculate output tokens
        output_tokens = int(len(response_text.split()) * 1.3)
        total_tokens = input_tokens + output_tokens
        
        # Calculate estimated cost
        estimated_cost = calculate_groq_cost(model_to_use, input_tokens, output_tokens)
        
        # Update result with token information
        result.update({
            "text": response_text,
            "success": True,
            "elapsed_time": time.time() - start_time,
            "input_tokens": input_tokens,
            "output_tokens": output_tokens,
            "total_tokens": total_tokens,
            "estimated_cost": estimated_cost
        })
        
        logger.info(f"✅ Groq success with {model_to_use}: {total_tokens} tokens, ${estimated_cost:.4f}")
        return result

    except Exception as e:
        result.update({
            "error": f"Groq error: {str(e)}",
            "elapsed_time": time.time() - start_time
        })
        logger.error(f"❌ Groq error with model {model_to_use}: {traceback.format_exc()}")
        return result

def _try_google(messages: List[Dict[str, str]], system_prompt: str, use_reasoning: bool, 
                files: List[Dict[str, Any]] = None, has_uploads: bool = False, 
                current_model: str = None) -> Dict[str, Any]:
    """Try Google provider with dynamic model selection and token tracking"""
    
    model_to_use = current_model or DEFAULT_MODELS.get("google", "models/gemini-2.0-flash")
    # logger.info(f"Google using model: {model_to_use}")

    result = {
        "text": "",
        "success": False,
        "provider": "google",
        "model": model_to_use,
        "elapsed_time": 0,
        "error": None,
        # Token tracking fields
        "input_tokens": 0,
        "output_tokens": 0,
        "total_tokens": 0,
        "estimated_cost": 0.0
    }

    try:
        start_time = time.time()
        
        # Initialize Google Gemini LLM
        llm = ChatGoogleGenerativeAI(
            google_api_key=GEMINI_API_KEY,
            model= model_to_use,
            temperature=0.7,
            max_output_tokens=get_token_limit(bool(files)),
            convert_system_message_to_human=True
        )

        # Process multimodal content
        langchain_messages = process_multimodal_content(messages, files or [], system_prompt)
        
        # Calculate input tokens
        input_text = ""
        if system_prompt:
            input_text += f"System: {system_prompt}\n\n"
        
        for msg in messages:
            if msg.get("role") in ["user", "assistant"]:
                role = "Human" if msg["role"] == "user" else "Assistant"
                content = msg.get("content", "")
                input_text += f"{role}: {content}\n\n"
        
        # Add file content to input calculation
        if files:
            for file_data in files:
                input_text += f"File: {file_data.get('content', '')}\n\n"
        
        input_tokens = int(len(input_text.split()) * 1.3)
        
        # Generate response
        response = llm.invoke(langchain_messages)
        
        response_text = response.content
        output_tokens = int(len(response_text.split()) * 1.3)
        total_tokens = input_tokens + output_tokens
        
        # Calculate cost using PlanManager
        estimated_cost = PlanManager.calculate_token_cost(
            "google", model_to_use, input_tokens, output_tokens
        )
        
        result.update({
            "text": response_text,
            "success": True,
            "elapsed_time": time.time() - start_time,
            "input_tokens": input_tokens,
            "output_tokens": output_tokens,
            "total_tokens": total_tokens,
            "estimated_cost": estimated_cost
        })

        logger.info(f"✅ Google success with {model_to_use}: {total_tokens} tokens, ${estimated_cost:.4f}")
        return result

    except Exception as e:
        result.update({
            "error": f"Google Gemini error: {str(e)}",
            "elapsed_time": time.time() - start_time
        })
        logger.error(f"Google Gemini error: {traceback.format_exc()}")
        return result

def _try_openai(messages: List[Dict[str, str]], system_prompt: str, use_reasoning: bool, 
                files: List[Dict[str, Any]] = None, has_uploads: bool = False, 
                current_model: str = None) -> Dict[str, Any]:
    """Try OpenAI provider with dynamic model selection"""
    
    model_to_use = current_model or DEFAULT_MODELS.get("openai", "gpt-4o-mini")

    # logger.info(f"OpenAI using model: {model_to_use}")

    # Define O-series models
    oseries_models = ["o4-mini-2025-04-16","o1-mini", "o3-mini","o3",'gpt-5','gpt-5-mini','gpt-5-nano']
    
    # Route to appropriate method based on model type
    if model_to_use in oseries_models:
        logger.info(f"Using O-series method for reasoning model: {model_to_use}")
        return OSeries_llm(messages, system_prompt, model_to_use, files or [], has_uploads)
    else:
        logger.info(f"Using LangChain method for regular model: {model_to_use}")
        return regular_openai_llm(messages, system_prompt, model_to_use, files or [], has_uploads)

def _try_anthropic(messages: List[Dict[str, str]], system_prompt: str, use_reasoning: bool, 
                   files: List[Dict[str, Any]] = None, has_uploads: bool = False, 
                   current_model: str = None) -> Dict[str, Any]:
    """Try Anthropic provider with dynamic model selection and token tracking"""
    
    model_to_use = current_model or DEFAULT_MODELS.get("anthropic", "claude-3-5-haiku-20241022")
    # logger.info(f"Anthropic using model: {model_to_use}")

    result = {
        "text": "",
        "success": False,
        "provider": "anthropic",
        "model": model_to_use,
        "elapsed_time": 0,
        "error": None,
        # Token tracking fields
        "input_tokens": 0,
        "output_tokens": 0,
        "total_tokens": 0,
        "estimated_cost": 0.0
    }

    try:
        start_time = time.time()

        # Initialize Anthropic Claude LLM
        llm = ChatAnthropic(
            anthropic_api_key=ANTHROPIC_API_KEY,
            model= model_to_use,
            temperature=0.7,
            max_tokens=get_token_limit(bool(files)),
            timeout=60,
            max_retries=2
        )

        # Process multimodal content with Anthropic-specific format
        langchain_messages = process_multimodal_content(
            messages, files or [], system_prompt, "anthropic"
        )

        # Calculate input tokens
        input_text = ""
        if system_prompt:
            input_text += f"System: {system_prompt}\n\n"
        
        for msg in messages:
            if msg.get("role") in ["user", "assistant"]:
                role = "Human" if msg["role"] == "user" else "Assistant"
                content = msg.get("content", "")
                input_text += f"{role}: {content}\n\n"
        
        # Add file content to input calculation
        if files:
            for file_data in files:
                input_text += f"File: {file_data.get('content', '')}\n\n"
        
        input_tokens = int(len(input_text.split()) * 1.3)

        # Generate response
        response = llm.invoke(langchain_messages)

        response_text = response.content
        output_tokens = int(len(response_text.split()) * 1.3)
        total_tokens = input_tokens + output_tokens
        
        # Calculate cost using PlanManager
        estimated_cost = PlanManager.calculate_token_cost(
            "anthropic", model_to_use, input_tokens, output_tokens
        )

        result.update({
            "text": response_text,
            "success": True,
            "elapsed_time": time.time() - start_time,
            "input_tokens": input_tokens,
            "output_tokens": output_tokens,
            "total_tokens": total_tokens,
            "estimated_cost": estimated_cost
        })

        logger.info(f"✅ Anthropic success with {model_to_use}: {total_tokens} tokens, ${estimated_cost:.4f}")
        return result

    except Exception as e:
        result.update({
            "error": f"Anthropic error: {str(e)}",
            "elapsed_time": time.time() - start_time
        })
        logger.error(f"Anthropic error: {traceback.format_exc()}")
        return result