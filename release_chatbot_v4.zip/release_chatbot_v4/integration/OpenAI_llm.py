from openai import OpenAI
import time
import base64
import io
import traceback
import logging
from typing import List, Dict, Any, Optional
from PIL import Image
from langchain_openai import ChatOpenAI  # ← Add this line
from langchain.schema import HumanMessage, AIMessage
from langchain_core.messages import HumanMessage, SystemMessage
from openai import OpenAI  # ← Add this for direct OpenAI client

from integration.multimodal_utils import process_multimodal_content

from integration.Settings_llm import (
    OPENAI_API_KEY,get_token_limit, get_model_config
   
)

from services.plan_manager import PlanManager

logger = logging.getLogger(__name__)
# Cache for validated images to avoid repeated processing
def regular_openai_llm(messages: List[Dict[str, str]], system_prompt: str, model_to_use: str, files: List[Dict[str, Any]], has_uploads: bool) -> Dict[str, Any]:
    """LangChain ChatOpenAI for regular models with token tracking"""
    result = {
        "text": "",
        "success": False,
        "provider": "openai",
        "model": model_to_use,
        "elapsed_time": 0,
        "error": None,
        # NEW: Token tracking fields
        "input_tokens": 0,
        "output_tokens": 0,
        "total_tokens": 0,
        "estimated_cost": 0.0
    }

    try:
        start_time = time.time()
        
        # logger.info(f"Using LangChain ChatOpenAI for regular model: {model_to_use}")
        
        # Initialize LangChain ChatOpenAI parameters
        llm_params = {
            "openai_api_key": OPENAI_API_KEY,
            "model": model_to_use,
            "temperature": 0.7,
            "max_tokens": get_token_limit(has_uploads, False),
            "timeout": 60,
            "max_retries": 2
        }
        
        llm = ChatOpenAI(**llm_params)

        # Process multimodal content using unified function
        langchain_messages = process_multimodal_content(messages, files or [], system_prompt)
        
        # NEW: Calculate input tokens before API call
        input_text = ""
        if system_prompt:
            input_text += f"System: {system_prompt}\n\n"
        
        for msg in messages:
            if msg.get("role") in ["user", "assistant"]:
                role = "Human" if msg["role"] == "user" else "Assistant"
                content = msg.get("content", "")
                input_text += f"{role}: {content}\n\n"
        
        # Add file content to input calculation
        if files:
            for file_data in files:
                input_text += f"File: {file_data.get('content', '')}\n\n"
        
        input_tokens = int(len(input_text.split()) * 1.3)
        
        # Generate response using LangChain
        logger.info("Sending request to OpenAI via LangChain...")
        response = llm.invoke(langchain_messages)
        
        response_text = response.content
        output_tokens = int(len(response_text.split()) * 1.3)
        total_tokens = input_tokens + output_tokens
        
        # Calculate cost using centralized function
        estimated_cost = PlanManager.calculate_token_cost(
            "openai", model_to_use, input_tokens, output_tokens
        )

        
        result.update({
            "text": response_text,
            "success": True,
            "elapsed_time": time.time() - start_time,
            "input_tokens": input_tokens,
            "output_tokens": output_tokens,
            "total_tokens": total_tokens,
            "estimated_cost": estimated_cost
        })
        
        logger.info(f"✅ Regular OpenAI success with {model_to_use}: {total_tokens} tokens, ${estimated_cost:.4f}")
        return result

    except Exception as e:
        result.update({
            "error": f"OpenAI regular error: {str(e)}",
            "elapsed_time": time.time() - start_time
        })
        logger.error(f"❌ OpenAI regular error: {str(e)}")
        return result

def OSeries_llm(messages: List[Dict[str, str]], system_prompt: str, model_to_use: str, files: List[Dict[str, Any]], has_uploads: bool) -> Dict[str, Any]:
    """Direct OpenAI client for O-series reasoning models with token tracking"""
    result = {
        "text": "",
        "success": False,
        "provider": "openai",
        "model": model_to_use,
        "elapsed_time": 0,
        "error": None,
        "input_tokens": 0,
        "output_tokens": 0,
        "total_tokens": 0,
        "estimated_cost": 0.0
    }

    try:
        start_time = time.time()
        
        # Initialize direct OpenAI client
        client = OpenAI(api_key=OPENAI_API_KEY)
        
        # Build messages for O-series API
        openai_messages = []
        input_text = ""
        
        # Add system prompt if provided
        if system_prompt and system_prompt.strip():
            openai_messages.append({
                "role": "system", 
                "content": system_prompt
            })
            input_text += f"System: {system_prompt}\n\n"
        
        # Process conversation messages
        for msg in messages:
            if msg.get("role") in ["user", "assistant"] and msg.get("content"):
                openai_messages.append({
                    "role": msg["role"],
                    "content": str(msg["content"])
                })
                input_text += f"{msg['role']}: {msg.get('content', '')}\n\n"
        
        # Ensure we have at least one message
        if not openai_messages:
            openai_messages.append({
                "role": "user",
                "content": "Hello"
            })
        
        # Add file content to last user message if files exist
        if files and openai_messages:
            file_content = ""
            for file_data in files:
                if file_data.get('content'):
                    file_content += f"\nFile content: {file_data.get('content', '')}"
                    input_text += f"File: {file_data.get('content', '')}\n\n"
            
            # Append to last user message
            for i in range(len(openai_messages) - 1, -1, -1):
                if openai_messages[i]["role"] == "user":
                    openai_messages[i]["content"] += file_content
                    break
        
        # Calculate input tokens
        input_tokens = int(len(input_text.split()) * 1.3)
        
        logger.info(f"Sending request to OpenAI O-series model: {model_to_use} with {len(openai_messages)} messages")
        
        # FIXED: Use max_completion_tokens instead of max_tokens for O-series models
        response = client.chat.completions.create(
            model=model_to_use,
            messages=openai_messages,
            max_completion_tokens=get_token_limit(has_uploads, False)  # Changed from max_tokens
        )
        
        # Extract response text
        if response.choices and len(response.choices) > 0:
            response_text = response.choices[0].message.content or ""
        else:
            raise Exception("No response choices returned from OpenAI")
        
        # Get actual token usage from response if available
        if hasattr(response, 'usage') and response.usage:
            input_tokens = response.usage.prompt_tokens or input_tokens
            output_tokens = response.usage.completion_tokens or 0
            total_tokens = response.usage.total_tokens or (input_tokens + output_tokens)
        else:
            # Fallback calculation
            output_tokens = int(len(response_text.split()) * 1.3)
            total_tokens = input_tokens + output_tokens
        
        # Calculate cost using centralized function
        estimated_cost = PlanManager.calculate_token_cost(
            "openai", model_to_use, input_tokens, output_tokens
        )
        
        result.update({
            "text": response_text,
            "success": True,
            "elapsed_time": time.time() - start_time,
            "input_tokens": input_tokens,
            "output_tokens": output_tokens,
            "total_tokens": total_tokens,
            "estimated_cost": estimated_cost
        })
        
        logger.info(f"✅ O-Series OpenAI success with {model_to_use}: {total_tokens} tokens, ${estimated_cost:.4f}")
        return result

    except Exception as e:
        result.update({
            "error": f"OpenAI O-series error: {str(e)}",
            "elapsed_time": time.time() - start_time
        })
        logger.error(f"❌ OpenAI O-series error: {str(e)}")
        return result