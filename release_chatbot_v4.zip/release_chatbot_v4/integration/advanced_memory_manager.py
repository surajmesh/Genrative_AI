# Updated advanced_memory_manager.py - Production Ready

import logging
import time
from typing import List, Dict, Any, Optional
from datetime import datetime
from integration.LangChainConversationHandler import LangChainMemoryManager
from integration.Settings_llm import provider_enabled, DEFAULT_MODELS
from integration.Chat_Completion_Function import _try_google, _try_anthropic, _try_openai, _try_groq

logger = logging.getLogger(__name__)

class HybridMemoryManager:
    """Advanced memory manager with buffer + summary capabilities"""
    
    def __init__(self, buffer_limit: int = 30, summary_threshold: float = 0.8):
        self.buffer_limit = buffer_limit
        self.summary_threshold = summary_threshold
        self.buffer = LangChainMemoryManager("window", k=buffer_limit)
        self.summary_memory = LangChainMemoryManager("buffer")
        self.conversation_summaries = []
        self.total_messages = 0
        
        # Session tracking properties for app.py integration
        self.session_id = None
        self.last_accessed = time.time()
        self.history_loaded = False
        self.last_message_id = None
        
    def add_user_message(self, message: str):
        """Add user message with automatic summarization"""
        self.total_messages += 1
        self.last_accessed = time.time()
        
        # Better duplicate prevention
        current_messages = self.buffer.get_messages()
        if current_messages:
            last_msg = current_messages[-1] if current_messages else None
            if (last_msg and 
                last_msg.get('role') == 'user' and 
                last_msg.get('content', '').strip() == message.strip()):
                logger.warning(f"⚠️ Duplicate user message detected in memory, skipping: {message[:50]}...")
                return
        
        # Check if buffer is near capacity BEFORE adding
        if self._should_summarize():
            self._summarize_and_compress()
        
        self.buffer.add_user_message(message)
        
    def add_ai_message(self, message: str):
        """Add AI message with automatic summarization"""
        self.total_messages += 1
        self.last_accessed = time.time()
        
        # Check if buffer is near capacity BEFORE adding
        current_messages = self.buffer.get_messages()
        if self._should_summarize():
            self._summarize_and_compress()
            
        self.buffer.add_ai_message(message)
    
    def _should_summarize(self) -> bool:
        """Check if buffer should be summarized"""
        current_messages = len(self.buffer.get_messages())
        threshold_reached = current_messages >= int(self.buffer_limit * self.summary_threshold)
        return threshold_reached
    
    def _summarize_and_compress(self):
        """Summarize buffer content and compress memory"""
        try:
            buffer_messages = self.buffer.get_messages()
            
            if len(buffer_messages) < 4:
                return
            
            # Create summary prompt
            conversation_text = "\n".join([
                f"{msg['role']}: {msg['content']}" for msg in buffer_messages
            ])
            
            summary_prompt = f"""
            Summarize this conversation segment concisely, preserving key context and decisions:
            
            {conversation_text}
            
            Focus on:
            - Main topics discussed
            - Key decisions or conclusions
            - Important context for future reference
            - User preferences or requirements mentioned
            - Personal information shared (name, role, preferences)
            """
            
            # Generate summary using available provider
            summary = self._generate_summary(summary_prompt)
            
            # Store summary with better structure
            summary_event = {
                "timestamp": datetime.now().isoformat(),
                "message_count": len(buffer_messages),
                "summary": summary,
                "session_id": self.session_id
            }
            
            self.conversation_summaries.append(summary_event)
            
            # Clear buffer 
            self.buffer = LangChainMemoryManager("window", k=self.buffer_limit)
            
            logger.info(f"Summarized {len(buffer_messages)} messages into summary memory for session {self.session_id}")
            
        except Exception as e:
            logger.error(f"Error during summarization: {str(e)}")

    def _generate_summary(self, prompt: str) -> str:
        """Generate summary using available LLM provider"""
        try:
            providers = ["google", "openai", "anthropic", "groq"]
            
            for provider in providers:
                if provider_enabled(provider):
                    try:
                        messages = [{"role": "user", "content": prompt}]
                        default_model = DEFAULT_MODELS.get(provider)
                        
                        if provider == "google":
                            result = _try_google(messages, "You are a helpful assistant that creates concise conversation summaries, preserving personal details and context.", False, None, False, default_model)
                        elif provider == "openai":
                            result = _try_openai(messages, "You are a helpful assistant that creates concise conversation summaries, preserving personal details and context.", False, None, False, default_model)
                        elif provider == "anthropic":
                            result = _try_anthropic(messages, "You are a helpful assistant that creates concise conversation summaries, preserving personal details and context.", False, None, False, default_model)
                        elif provider == "groq":
                            result = _try_groq(messages, "You are a helpful assistant that creates concise conversation summaries, preserving personal details and context.", False, None, False, default_model)
                        
                        if result.get("success"):
                            return result["text"][:800]  # Increased summary length for better context
                            
                    except Exception as provider_error:
                        logger.warning(f"Provider {provider} failed for summarization: {provider_error}")
                        continue
            
            return f"Conversation summary - {len(self.buffer.get_messages())} messages about user preferences and technical discussions"
        
        except Exception as e:
            logger.error(f"Error generating summary: {str(e)}")
            return "Conversation summary - content summarization failed"
    
    def get_messages(self) -> List[Dict[str, str]]:
        """Get all messages with improved context injection compatible with all LLM providers"""
        self.last_accessed = time.time()
        all_messages = []
        
        # FIXED: Better context injection compatible with Google Gemini and other providers
        if self.conversation_summaries:
            # Combine all summaries into comprehensive context
            all_summaries = []
            for summary_obj in self.conversation_summaries:
                summary_text = summary_obj['summary']
                timestamp = summary_obj.get('timestamp', 'Unknown time')
                all_summaries.append(f"[Previous conversation from {timestamp[:19]}]: {summary_text}")
            
            combined_context = "\n\n".join(all_summaries)
            
            # Use user/assistant pair for maximum compatibility across all providers
            context_user_msg = {
                "role": "user",
                "content": f"[CONTEXT] Here's a summary of our previous conversation to help you remember our discussion:\n\n{combined_context}\n\nPlease acknowledge that you understand this context, then I'll continue with my next question."
            }
            
            context_ai_msg = {
                "role": "assistant", 
                "content": "I understand and remember the context from our previous conversation. I'll keep this information in mind as we continue. Please go ahead with your question."
            }
            
            all_messages.extend([context_user_msg, context_ai_msg])
        
        # Add current buffer messages
        buffer_messages = self.buffer.get_messages()
        all_messages.extend(buffer_messages)
        
        return all_messages

    def get_memory_info(self) -> Dict[str, Any]:
        """Get memory usage information"""
        return {
            "session_id": self.session_id,
            "buffer_messages": len(self.buffer.get_messages()),
            "buffer_limit": self.buffer_limit,
            "summary_count": len(self.conversation_summaries),
            "total_messages": self.total_messages,
            "last_accessed": self.last_accessed,
            "history_loaded": self.history_loaded,
            "last_summary": self.conversation_summaries[-1] if self.conversation_summaries else None,
            "next_summarization_at": int(self.buffer_limit * self.summary_threshold)
        }
    
    def clear_memory(self):
        """Clear all memory"""
        self.buffer = LangChainMemoryManager("window", k=self.buffer_limit)
        self.summary_memory = LangChainMemoryManager("buffer")
        self.conversation_summaries = []
        self.total_messages = 0
        self.last_accessed = time.time()