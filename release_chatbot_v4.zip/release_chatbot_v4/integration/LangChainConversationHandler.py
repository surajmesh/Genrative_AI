"""
LangChain Memory Implementation for Chat History Management
Supports multiple memory types with proper error handling
"""
import time
import logging
from typing import List, Dict, Any
from langchain.memory import (
    ConversationBufferMemory,
    ConversationBufferWindowMemory,
    ConversationSummaryBufferMemory,
    ConversationTokenBufferMemory,
    ConversationSummaryMemory
)
from langchain.schema import HumanMessage, AIMessage
from langchain_core.messages import SystemMessage

# Configure logging
logger = logging.getLogger(__name__)

class LangChainMemoryManager:
    """
    Memory manager using LangChain components with error handling
    """
    
    def __init__(self, memory_type: str = "buffer", **kwargs):
        # Initialize memory manager with specified type
        self.memory_type = memory_type
        self.memory = self._create_memory(memory_type, **kwargs)
        self.created_at = time.time()
        self.session_id = kwargs.get('session_id', None)  # For tracking
        self.last_accessed = time.time()  # For cleanup (if you add it later)
        
    def _create_memory(self, memory_type: str, **kwargs) -> Any:
        # Create memory instance based on type
        try:
            if memory_type == "buffer":
                return ConversationBufferMemory(
                    memory_key="chat_history",
                    return_messages=True,
                    **kwargs
                )
            elif memory_type == "window":
                k = kwargs.get('k', 10)
                return ConversationBufferWindowMemory(
                    k=k,
                    memory_key="chat_history",
                    return_messages=True,
                    **{k: v for k, v in kwargs.items() if k != 'k'}
                )
            elif memory_type == "summary":
                llm = kwargs.get('llm') or self._get_default_llm()
                return ConversationSummaryMemory(
                    llm=llm,
                    memory_key="chat_history",
                    return_messages=True,
                    **{k: v for k, v in kwargs.items() if k != 'llm'}
                )
            elif memory_type == "summary_buffer":
                llm = kwargs.get('llm') or self._get_default_llm()
                max_token_limit = kwargs.get('max_token_limit', 2000)
                return ConversationSummaryBufferMemory(
                    llm=llm,
                    max_token_limit=max_token_limit,
                    memory_key="chat_history",
                    return_messages=True,
                    **{k: v for k, v in kwargs.items() if k not in ['llm', 'max_token_limit']}
                )
            elif memory_type == "token_buffer":
                llm = kwargs.get('llm') or self._get_default_llm()
                max_token_limit = kwargs.get('max_token_limit', 2000)
                return ConversationTokenBufferMemory(
                    llm=llm,
                    max_token_limit=max_token_limit,
                    memory_key="chat_history",
                    return_messages=True,
                    **{k: v for k, v in kwargs.items() if k not in ['llm', 'max_token_limit']}
                )
            else:
                raise ValueError(f"❌ Unknown memory type: {memory_type}")
                
        except Exception as e:
            logger.error(f"❌ Error creating memory: {str(e)}")
            # Fallback to buffer memory
            return ConversationBufferMemory(
                memory_key="chat_history",
                return_messages=True
            )
    
    def _get_default_llm(self):
        # Get default LLM for summary operations
        try:
            from integration.Settings_llm import GEMINI_API_KEY,GROQ_API_KEY
            from langchain_google_genai import ChatGoogleGenerativeAI
            from langchain_groq import ChatGroq
            

            if GEMINI_API_KEY:
                return ChatGoogleGenerativeAI(
                    api_key=GEMINI_API_KEY,
                    model="gemini-2.0-flash",
                    temperature=0
                )

            # if GROQ_API_KEY:
            #     return ChatGroq(
            #         groq_api_key=GROQ_API_KEY,
            #         model="llama-3.3-70b-versatile", 
            #         temperature=0
            #     )
                
        except Exception as e:
            logger.warning(f"❌ Could not create default LLM: {str(e)}")

        return None
    
    def add_user_message(self, message: str) -> None:
        # Add user message to conversation history
        try:
            self.memory.chat_memory.add_user_message(message)
        except Exception as e:
            logger.error(f"❌ Error adding user message: {str(e)}")
            raise
    
    def add_ai_message(self, message: str) -> None:
        # Add AI response to conversation history
        try:
            self.memory.chat_memory.add_ai_message(message)
        except Exception as e:
            logger.error(f"❌ Error adding AI message: {str(e)}")
            raise
    
    def add_system_message(self, message: str) -> None:
        # Add system message to conversation history
        try:
            system_msg = SystemMessage(content=message)
            self.memory.chat_memory.add_message(system_msg)
        except Exception as e:
            logger.error(f"❌ Error adding system message: {str(e)}")
            raise
    
    def get_memory_variables(self) -> Dict[str, Any]:
        # Get memory variables for LangChain chains
        try:
            return self.memory.load_memory_variables({})
        except Exception as e:
            logger.error(f"❌ Error loading memory variables: {str(e)}")
            return {"chat_history": []}
    
    def get_messages(self) -> List[Dict[str, str]]:
        # Get formatted messages for LLM consumption
        try:
            memory_vars = self.get_memory_variables()
            messages = memory_vars.get("chat_history", [])
            
            # Convert LangChain messages to standard format
            formatted_messages = []
            for msg in messages:
                if isinstance(msg, HumanMessage):
                    formatted_messages.append({"role": "user", "content": msg.content})
                elif isinstance(msg, AIMessage):
                    formatted_messages.append({"role": "assistant", "content": msg.content})
                elif isinstance(msg, SystemMessage):
                    formatted_messages.append({"role": "system", "content": msg.content})
                else:
                    # Handle string messages for backward compatibility
                    if isinstance(msg, str):
                        formatted_messages.append({"role": "user", "content": msg})
            
            return formatted_messages
            
        except Exception as e:
            logger.error(f"❌ Error getting messages: {str(e)}")
            return []
    
    def clear_memory(self) -> None:
        # Clear all conversation history
        try:
            self.memory.clear()
        except Exception as e:
            logger.error(f"❌ Error clearing memory: {str(e)}")
            raise
    
    def get_memory_info(self) -> Dict[str, Any]:
        # Get memory statistics and information
        try:
            messages = self.get_messages()
            return {
                "memory_type": self.memory_type,
                "message_count": len(messages),
                "created_at": self.created_at,
                "age_seconds": time.time() - self.created_at,
                "memory_key": getattr(self.memory, 'memory_key', 'chat_history')
            }
        except Exception as e:
            logger.error(f"❌ Error getting memory info: {str(e)}")
            return {"error": str(e)}
    
    def get_last_n_messages(self, n: int) -> List[Dict[str, str]]:
        # Get last N messages from conversation
        try:
            messages = self.get_messages()
            return messages[-n:] if len(messages) > n else messages
        except Exception as e:
            logger.error(f"Error getting last {n} messages: {str(e)}")
            return []
    
    def count_tokens_approximate(self) -> int:
        # Approximate token count for current conversation
        try:
            messages = self.get_messages()
            # Rough estimation: 4 characters per token
            total_chars = sum(len(msg["content"]) for msg in messages)
            return total_chars // 4
        except Exception as e:
            logger.error(f"Error counting tokens: {str(e)}")
            return 0