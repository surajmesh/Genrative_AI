"""
Enhanced LLM Settings - Multi-provider configuration with dynamic prompts
"""
import os
from typing import Dict, Optional, List 
import textwrap


# Provider switches
DEFAULT_PROVIDER   = os.getenv("LLM_PROVIDER", "groq").lower()
REASONING_PROVIDER = os.getenv("LLM_REASON_PROVIDER", "groq").lower()
VISION_PROVIDER    = os.getenv("LLM_VISION_PROVIDER", "groq").lower()  # NEW!


# API keys
GEMINI_API_KEY     = os.getenv("GEMINI_API_KEY", "")
OPENAI_API_KEY     = os.getenv("OPENAI_API_KEY", "")
ANTHROPIC_API_KEY  = os.getenv("ANTHROPIC_API_KEY", "")
GROQ_API_KEY = os.getenv("GROQ_API_KEY")


def provider_enabled(name: str) -> bool:
    # Check if provider has valid API key
    return ((name == "google"    and bool(GEMINI_API_KEY))   or
            (name == "openai"    and bool(OPENAI_API_KEY))   or
            (name == "anthropic" and bool(ANTHROPIC_API_KEY)) or
            (name == "groq" and bool(GROQ_API_KEY)))

# Model catalogue

# Normal Chat
DEFAULT_MODELS = {
    "google": "models/gemini-2.0-flash",
    "openai": "gpt-4o-mini", 
    "anthropic": "claude-3-5-haiku-20241022",
    "groq": "llama-3.1-8b-instant"
}

# Only models selections

MODEL_CATALOG = {
    "google": {
        "standard": [
            "models/gemini-2.0-flash"
        ],
        "premium": [
            "models/gemini-2.5-flash", 
            "models/gemini-2.0-flash-thinking-exp"
        ]
    },
    "openai": {
        "standard": [
            'gpt-5-nano',
            "gpt-4o-mini",
            "gpt-3.5-turbo"
        ],
        "premium":[
            'gpt-5',
            'gpt-5-mini',
            "o3",
            "gpt-4o",
            "gpt-4-turbo"
        ]
    },
    "anthropic": {
        "standard": [
            "claude-3-5-haiku-20241022"
        ],
        "premium": [
            "claude-opus-4-20250514",
            "claude-sonnet-4-20250514",
            "claude-3-5-sonnet-20241022", 
            "claude-3-7-sonnet-20250219"
        ]
    },
    "groq": {
        "standard": [
            "openai/gpt-oss-20b",
            "llama-3.1-8b-instant",
            "meta-llama/llama-4-scout-17b-16e-instruct"
        ],
        "premium": [
            "openai/gpt-oss-120b",
            "meta-llama/llama-4-maverick-17b-128e-instruct",
            "llama-3.3-70b-versatile",
            "deepseek-r1-distill-llama-70b"
        ]
    }
}


def get_model_config(provider: str, user_selection_model: str = None) -> Dict[str, any]:
    """Get model configuration with validation"""
    
    # Get available models for provider
    provider_models = MODEL_CATALOG.get(provider.lower(), {})
    all_models = provider_models.get("standard", []) + provider_models.get("premium", [])
    
    # Validate user selection
    if user_selection_model:
        if user_selection_model in all_models:
            model = user_selection_model
        else:
            # Invalid model for provider, fall back to default
            model = DEFAULT_MODELS.get(provider)
            print(f"⚠️ Model '{user_selection_model}' not available for {provider}, using default: {model}")
    else:
        model = DEFAULT_MODELS.get(provider)
    
    return {
        "model": model,
        "provider": provider
    } 


def validate_model_selection(provider: str, model: str) -> bool:
    """Validate if model is available for the provider"""
    provider_models = MODEL_CATALOG.get(provider.lower(), {})
    all_models = provider_models.get("standard", []) + provider_models.get("premium", [])
    return model in all_models

  
def get_models_by_provider(provider):

    # Convert to lowercase for case-insensitive matching
    provider_lower = provider.lower()
    
    if provider_lower not in MODEL_CATALOG:
        available_providers = list(MODEL_CATALOG.keys())
        raise ValueError(f"Provider '{provider}' not found. Available providers: {available_providers}")
    
    models = MODEL_CATALOG[provider_lower]
    
    return {
        "provider": provider_lower,
        "models": models
    }


# Token limits for different model categories
MAX_QUIKTHINK_TOKENS = int(os.getenv("MAX_DEFAULT_TOKENS", "4000"))
MAX_VISION_TOKENS = int(os.getenv("MAX_VISION_TOKENS", "2000"))
MAX_DEEPTHINK_TOKENS = int(os.getenv("MAX_REASONING_TOKENS", "4000"))

def get_token_limit(has_uploads: bool = False, use_reasoning: bool = False) -> int:
    # Get token limit based on model category for optimal performance
    if has_uploads:
        return MAX_VISION_TOKENS
    elif use_reasoning:
        return MAX_DEEPTHINK_TOKENS
    else:
        return MAX_QUIKTHINK_TOKENS


#-------------------------------------------------------------------------------------------------------------
# Prompts Settings ##
# In your other files, simply import:
from config import PROMPTS_FOLDER, BASE_PATH

# Generate the title for sessions
TITLE_SYSTEM_PROMPT = """
Act as a title generator for chat sessions.
Generate a short, clear title (4-7 words max) that summarizes the topic.
Do not include quotes or punctuation—just plain title text wihtout special character..
"""


# Updated system prompt for rich context

WELCOME_SYSTEM_PROMPT = """
You are an AI assistant greeting generator. Create brief, helpful welcome messages that invite users to share what they need.

Instructions:
- Generate 1 short sentence (Must be under 50 characters (hard limit) <Do NOT exceed 50 characters under any circumstances>)
- Focus on being ready to help, not just greeting
- Use the user's name naturally when appropriate
- Vary the approach - don't always use time greetings
- Be direct and inviting
- No quotation marks or extra punctuation
- Output only the welcome message

Message styles to use:
- Direct help offer: "How can I help, [name]?"
- Work focus: "What are you working on, [name]?"
- Open invitation: "What's on your mind today?"
- Casual check-in: "What should we dive into today?"
- Simple greeting: "Nice to see you, [name]. What's new?"
- Ready to assist: "What's on the agenda today?"

Examples:
- "What are you working on, Suraj?"
- "How can I help, Mike?"
- "What's on your mind today?"
- "What should we dive into today?"
- "Nice to see you, Sarah. What's new?"
- "What's on the agenda today?"
"""



# The paths will automatically work regardless of where you run the app from
prompt_dir = os.path.join(BASE_PATH,PROMPTS_FOLDER)


# Prompt filenames
quickTink_prompt_filename = 'Basic_Chat_Model_Prompt.txt'
deepThink_prompt_filename = 'Reasoning_Model_Prompt.txt'
vision_prompt_filename = 'Vision_Model_Prompt.txt'

# Construct full file paths for each prompt file
quickTink_chat_prompt_file = os.path.join(prompt_dir, quickTink_prompt_filename)
deepThink_prompt_file = os.path.join(prompt_dir, deepThink_prompt_filename)
vision_prompt_file = os.path.join(prompt_dir, vision_prompt_filename)

# Read prompt files with error handling and validation
def _read_prompt_file(file_path: str, default_content: str = "You are a helpful DotAI assistant.") -> str:
    # Read prompt file with fallback to default content if file doesn't exist
    try:
        if os.path.exists(file_path):
            with open(file_path, "r", encoding="utf-8") as file:
                content = textwrap.dedent(file.read()).strip()
                return content if content else default_content   
        else:
            print(f"❌ Warning: Prompt file not found: {file_path}")
            return default_content
    except Exception as e:
        print(f"❌ Error reading prompt file {file_path}: {e}")
        return default_content

# Read the Basic Chat Model prompt content
QUICKTHINK_SYSTEM_PROMPT = _read_prompt_file(
    quickTink_chat_prompt_file,
    "You are a helpful QuickThink AI assistant. Provide clear, accurate, and helpful responses."
)

# Read the Reasoning Model prompt content
DEEPTHINK_SYSTEM_PROMPT = _read_prompt_file(
    deepThink_prompt_file,
    "You are a DeepThink AI assistant. Think step by step and provide detailed explanations."
)

# Read the Vision Model prompt content
VISION_SYSTEM_PROMPT = _read_prompt_file(
    vision_prompt_file,
    "You are a vision AI assistant. Analyze images carefully and provide detailed descriptions."
)


def get_system_prompt(use_reasoning: bool = False, has_uploads: bool = False, uploaded_files: Optional[List] = None) -> str:
    # Get appropriate system prompt based on context with fixed parameter type
    if uploaded_files and has_uploads and len(uploaded_files) > 0:
        return VISION_SYSTEM_PROMPT
    elif use_reasoning:
        return DEEPTHINK_SYSTEM_PROMPT
    else:
        return QUICKTHINK_SYSTEM_PROMPT




