import os
import logging
import json
import pandas as pd
from typing import Dict, Any, List
import docx
import PyPDF2
from openpyxl import load_workbook
from langchain.schema import Document
from langchain.document_loaders.base import BaseLoader
import base64

# Configure logging
logger = logging.getLogger(__name__)

class CustomDocumentLoader(BaseLoader):
    """Custom LangChain document loader for various file types"""
    
    def __init__(self, file_paths: List[str]):
        self.file_paths = file_paths
    
    def load(self) -> List[Document]:
        """Load documents from file paths"""
        documents = []
        for file_path in self.file_paths:
            try:
                # Determine file type based on extension
                file_type = self._determine_file_type(file_path)
                
                # Process file content
                content = process_file_content(file_path, file_type)
                
                # Create LangChain Document
                metadata = get_file_info(file_path)
                metadata.update({
                    "source": file_path,
                    "file_type": file_type
                })
                
                doc = Document(page_content=content, metadata=metadata)
                documents.append(doc)
                
            except Exception as e:
                logger.error(f"Error loading document {file_path}: {str(e)}")
                # Create error document
                error_doc = Document(
                    page_content=f"Error loading file: {str(e)}",
                    metadata={"source": file_path, "error": True}
                )
                documents.append(error_doc)
        
        return documents
    
    def _determine_file_type(self, filepath: str) -> str:
        """Determine file type based on extension"""
        extension = filepath.lower().split('.')[-1]
        
        if extension in ['pdf', 'docx', 'txt']:
            return "document"
        elif extension in ['csv', 'xlsx', 'xls']:
            return "data"
        elif extension in ['py', 'js', 'html', 'css', 'java', 'cpp', 'c', 'cs', 'php', 'rb', 'go', 'rs']:
            return "code"
        elif extension in ['json']:
            return "json"
        else:
            return "text"

def process_file_content(filepath: str, file_type: str) -> str:
    """Process different file types and extract content"""
    try:
        if file_type == "document":
            return process_document_file(filepath)
        elif file_type == "data":
            return process_data_file(filepath)
        elif file_type == "code":
            return process_code_file(filepath)
        elif file_type == "json":  # Added JSON support
            return process_json_file(filepath)
        else:
            return process_text_file(filepath)
    except Exception as e:
        logger.error(f"Error processing file {filepath}: {str(e)}")
        return f"Error reading file: {str(e)}"

def process_document_file(filepath: str) -> str:
    """Process document files (PDF, DOCX, TXT)"""
    extension = filepath.lower().split('.')[-1]
    
    try:
        if extension == 'pdf':
            return extract_pdf_content(filepath)
        elif extension == 'docx':
            return extract_docx_content(filepath)
        elif extension == 'txt':
            return extract_text_content(filepath)
        else:
            return extract_text_content(filepath)
    except Exception as e:
        logger.error(f"Error processing document {filepath}: {str(e)}")
        return f"Error reading document: {str(e)}"

def extract_pdf_content(filepath: str) -> str:
    """Extract text content from PDF files"""
    try:
        with open(filepath, 'rb') as file:
            pdf_reader = PyPDF2.PdfReader(file)
            content = ""
            
            for page_num in range(len(pdf_reader.pages)):
                page = pdf_reader.pages[page_num]
                page_text = page.extract_text()
                if page_text.strip():  # Only add non-empty pages
                    content += f"--- Page {page_num + 1} ---\n{page_text}\n\n"
            
            return content.strip() if content.strip() else "No extractable text found in PDF"
    except Exception as e:
        logger.error(f"Error extracting PDF content: {str(e)}")
        return f"Error reading PDF: {str(e)}"

def extract_docx_content(filepath: str) -> str:
    """Extract text content from DOCX files"""
    try:
        doc = docx.Document(filepath)
        content = ""
        
        for paragraph in doc.paragraphs:
            if paragraph.text.strip():  # Only add non-empty paragraphs
                content += paragraph.text + "\n"
        
        # Also extract text from tables if present
        for table in doc.tables:
            for row in table.rows:
                row_text = []
                for cell in row.cells:
                    if cell.text.strip():
                        row_text.append(cell.text.strip())
                if row_text:
                    content += " | ".join(row_text) + "\n"
        
        return content.strip() if content.strip() else "No extractable text found in DOCX"
    except Exception as e:
        logger.error(f"Error extracting DOCX content: {str(e)}")
        return f"Error reading DOCX: {str(e)}"

def extract_text_content(filepath: str) -> str:
    """Extract content from plain text files"""
    try:
        # Try different encodings
        encodings = ['utf-8', 'utf-16', 'latin-1', 'cp1252']
        
        for encoding in encodings:
            try:
                with open(filepath, 'r', encoding=encoding) as file:
                    content = file.read()
                    return content if content.strip() else "File is empty"
            except UnicodeDecodeError:
                continue
        
        # If all encodings fail, try with error handling
        with open(filepath, 'r', encoding='utf-8', errors='replace') as file:
            content = file.read()
            return content if content.strip() else "File is empty"
            
    except Exception as e:
        logger.error(f"Error extracting text content: {str(e)}")
        return f"Error reading text file: {str(e)}"

def process_text_file(filepath: str) -> str:
    """Process plain text files - alias for extract_text_content"""
    return extract_text_content(filepath)

def process_data_file(filepath: str) -> str:
    """Process data files (CSV, XLSX)"""
    extension = filepath.lower().split('.')[-1]
    
    try:
        if extension == 'csv':
            return process_csv_file(filepath)
        elif extension in ['xlsx', 'xls']:
            return process_excel_file(filepath)
        else:
            return extract_text_content(filepath)
    except Exception as e:
        logger.error(f"Error processing data file {filepath}: {str(e)}")
        return f"Error reading data file: {str(e)}"

def process_csv_file(filepath: str) -> str:
    """Process CSV files and return structured content for LangChain"""
    try:
        # Try different separators and encodings
        separators = [',', ';', '\t', '|']
        encodings = ['utf-8', 'latin-1', 'cp1252']
        
        df = None
        for encoding in encodings:
            for sep in separators:
                try:
                    df = pd.read_csv(filepath, encoding=encoding, sep=sep)
                    if len(df.columns) > 1:  # Valid separation found
                        break
                except:
                    continue
            if df is not None and len(df.columns) > 1:
                break
        
        if df is None:
            df = pd.read_csv(filepath, encoding='utf-8', errors='replace')
        
        # Create structured content for better LangChain processing
        content = f"CSV Dataset Summary:\n"
        content += f"Total Records: {len(df)}\n"
        content += f"Columns: {', '.join(df.columns.tolist())}\n\n"
        
        # Add column descriptions with data types and sample values
        content += "Column Information:\n"
        for col in df.columns:
            content += f"- {col}: {df[col].dtype}"
            if not df[col].isna().all():
                sample_values = df[col].dropna().head(3).tolist()
                content += f" (Examples: {', '.join(map(str, sample_values))})"
            content += "\n"
        
        content += "\nData Sample (First 10 rows):\n"
        content += df.head(10).to_string(index=False, max_cols=10)
        
        # Add summary statistics for numeric columns
        numeric_cols = df.select_dtypes(include=['number']).columns
        if len(numeric_cols) > 0:
            content += f"\n\nNumeric Summary:\n"
            content += df[numeric_cols].describe().to_string()
        
        # Add value counts for categorical columns (top 5 values)
        categorical_cols = df.select_dtypes(include=['object']).columns
        if len(categorical_cols) > 0:
            content += f"\n\nCategorical Data Summary:\n"
            for col in categorical_cols[:5]:  # Limit to first 5 categorical columns
                content += f"\n{col} - Top 5 values:\n"
                content += df[col].value_counts().head().to_string()
        
        return content
    except Exception as e:
        logger.error(f"Error processing CSV: {str(e)}")
        return f"Error reading CSV: {str(e)}"

def process_excel_file(filepath: str) -> str:
    """Process Excel files and return structured content for LangChain"""
    try:
        # Get all sheet names
        excel_file = pd.ExcelFile(filepath)
        sheet_names = excel_file.sheet_names
        
        content = f"Excel Workbook Summary:\n"
        content += f"Total Sheets: {len(sheet_names)}\n"
        content += f"Sheet Names: {', '.join(sheet_names)}\n\n"
        
        # Process each sheet
        for i, sheet_name in enumerate(sheet_names):
            try:
                df = pd.read_excel(filepath, sheet_name=sheet_name)
                
                content += f"{'='*60}\n"
                content += f"SHEET: {sheet_name}\n"
                content += f"{'='*60}\n"
                content += f"Rows: {len(df)}, Columns: {len(df.columns)}\n"
                content += f"Columns: {', '.join(df.columns.tolist())}\n\n"
                
                if len(df) > 0:
                    content += "Sample Data (First 5 rows):\n"
                    content += df.head().to_string(index=False, max_cols=10)
                    content += "\n\n"
                    
                    # Add data types
                    content += "Data Types:\n"
                    for col in df.columns:
                        content += f"- {col}: {df[col].dtype}\n"
                    
                    # Add basic statistics for numeric columns
                    numeric_cols = df.select_dtypes(include=['number']).columns
                    if len(numeric_cols) > 0:
                        content += f"\nNumeric Summary:\n"
                        content += df[numeric_cols].describe().to_string()
                else:
                    content += "Sheet is empty\n"
                
                content += "\n\n"
                
                # Limit to first 3 sheets to avoid overly long content
                if i >= 2:
                    remaining_sheets = len(sheet_names) - 3
                    if remaining_sheets > 0:
                        content += f"... and {remaining_sheets} more sheets\n"
                    break
                    
            except Exception as sheet_error:
                content += f"Error reading sheet '{sheet_name}': {str(sheet_error)}\n\n"
        
        return content
    except Exception as e:
        logger.error(f"Error processing Excel: {str(e)}")
        return f"Error reading Excel: {str(e)}"

def process_code_file(filepath: str) -> str:
    """Process code files and extract content with metadata for LangChain"""
    try:
        extension = filepath.lower().split('.')[-1]
        content = extract_text_content(filepath)
        
        if "Error reading" in content:
            return content
        
        # Add metadata for code files
        lines = content.split('\n')
        lines_count = len(lines)
        char_count = len(content)
        
        # Extract basic code structure information
        functions = []
        classes = []
        imports = []
        
        for line_num, line in enumerate(lines, 1):
            line_stripped = line.strip()
            if line_stripped.startswith('def '):
                functions.append(f"Line {line_num}: {line_stripped}")
            elif line_stripped.startswith('class '):
                classes.append(f"Line {line_num}: {line_stripped}")
            elif line_stripped.startswith(('import ', 'from ')):
                imports.append(line_stripped)
        
        # Create structured summary
        summary = f"Code File Analysis ({extension.upper()}):\n"
        summary += f"File: {os.path.basename(filepath)}\n"
        summary += f"Lines: {lines_count}\n"
        summary += f"Characters: {char_count}\n"
        summary += f"Size: {os.path.getsize(filepath)} bytes\n\n"
        
        if imports:
            summary += "Imports/Dependencies:\n"
            summary += '\n'.join(f"- {imp}" for imp in imports[:10])  # Limit to first 10
            if len(imports) > 10:
                summary += f"\n... and {len(imports) - 10} more imports\n"
            summary += "\n\n"
        
        if functions:
            summary += "Functions:\n"
            summary += '\n'.join(f"- {func}" for func in functions[:10])  # Limit to first 10
            if len(functions) > 10:
                summary += f"\n... and {len(functions) - 10} more functions\n"
            summary += "\n\n"
        
        if classes:
            summary += "Classes:\n"
            summary += '\n'.join(f"- {cls}" for cls in classes[:5])  # Limit to first 5
            if len(classes) > 5:
                summary += f"\n... and {len(classes) - 5} more classes\n"
            summary += "\n\n"
        
        summary += "Full Code Content:\n"
        summary += "=" * 50 + "\n"
        summary += content
        
        return summary
    except Exception as e:
        logger.error(f"Error processing code file: {str(e)}")
        return f"Error reading code file: {str(e)}"

def process_json_file(filepath: str) -> str:
    """Process JSON files and return formatted content for LangChain"""
    try:
        with open(filepath, 'r', encoding='utf-8') as file:
            data = json.load(file)
        
        # Create structured summary
        summary = f"JSON File Analysis:\n"
        summary += f"File: {os.path.basename(filepath)}\n"
        summary += f"Root Type: {type(data).__name__}\n"
        
        if isinstance(data, dict):
            summary += f"Top-level Keys: {', '.join(list(data.keys())[:20])}\n"  # Limit keys display
            if len(data.keys()) > 20:
                summary += f"... and {len(data.keys()) - 20} more keys\n"
        elif isinstance(data, list):
            summary += f"Array Length: {len(data)}\n"
            if len(data) > 0:
                summary += f"First Item Type: {type(data[0]).__name__}\n"
        
        summary += f"File Size: {os.path.getsize(filepath)} bytes\n\n"
        
        # Add structured content representation
        summary += "Content Structure:\n"
        summary += "=" * 50 + "\n"
        
        # For better LangChain processing, include formatted JSON with size limit
        json_str = json.dumps(data, indent=2, ensure_ascii=False)
        
        # Limit content size for better processing
        max_content_length = 10000  # 10KB limit
        if len(json_str) > max_content_length:
            summary += json_str[:max_content_length]
            summary += f"\n\n... [Content truncated - Total size: {len(json_str)} characters]"
        else:
            summary += json_str
        
        return summary
    except Exception as e:
        logger.error(f"Error processing JSON: {str(e)}")
        return f"Error reading JSON: {str(e)}"

def get_file_info(filepath: str) -> Dict[str, Any]:
    """Get basic file information"""
    try:
        stat = os.stat(filepath)
        extension = filepath.lower().split('.')[-1] if '.' in filepath else ""
        
        return {
            "size": stat.st_size,
            "modified": stat.st_mtime,
            "extension": extension,
            "name": os.path.basename(filepath),
            "full_path": filepath,
            "size_mb": round(stat.st_size / (1024 * 1024), 2)
        }
    except Exception as e:
        logger.error(f"Error getting file info: {str(e)}")
        return {"error": str(e)}