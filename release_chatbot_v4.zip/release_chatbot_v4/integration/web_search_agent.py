import logging
import os
from typing import List, Dict, Any, Optional
from urllib.parse import urlparse
import re
from langchain_tavily import TavilySearch
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

logger = logging.getLogger(__name__)

class WebSearchAgent:
    """Simple web search agent using Langchain Tavily API"""
    
    def __init__(self, max_urls: int = 5):
        self.max_urls = max_urls
        
        # Load API key from environment
        self.tavily_api_key = os.getenv('TAVILY_API_KEY')
        if not self.tavily_api_key:
            raise ValueError("TAVILY_API_KEY not found in environment variables")
        
        # Initialize with default topic (will be updated dynamically)
        self.tavily_search_tool = None
        self._current_topic = None
    
    def _get_search_topic(self, query: str) -> str:
        """Determine the appropriate search topic based on query content"""
        query_lower = query.lower()
        
        # Finance keywords
        finance_keywords = [
            'dollar', 'rupee', 'currency', 'exchange rate', 'stock', 'market', 'bitcoin',
            'cryptocurrency', 'investment', 'trading', 'price', 'economic', 'finance',
            'bank', 'loan', 'mortgage', 'interest rate', 'inflation', 'gdp', 'revenue',
            'profit', 'earnings', 'dividend', 'portfolio', 'bond', 'commodity', 'gold',
            'silver', 'oil price', 'forex', 'financial', 'money', 'wealth', 'budget'
        ]
        
        # News keywords
        news_keywords = [
            'news', 'breaking', 'latest', 'update', 'current events', 'happening',
            'today', 'recent', 'trending', 'headline', 'report', 'announcement',
            'election', 'politics', 'government', 'policy', 'scandal', 'crisis',
            'disaster', 'accident', 'weather', 'storm', 'earthquake', 'fire',
            'sports', 'match', 'game', 'tournament', 'celebrity', 'entertainment',
            'movie', 'music', 'technology news', 'science news', 'health news'
        ]
        
        # Check for finance keywords
        if any(keyword in query_lower for keyword in finance_keywords):
            return 'finance'
        
        # Check for news keywords
        if any(keyword in query_lower for keyword in news_keywords):
            return 'news'
        
        # Default to general
        return 'general'
    
    def _initialize_tavily_tool(self, topic: str):
        """Initialize or reinitialize Tavily tool with specific topic"""
        if self._current_topic != topic or self.tavily_search_tool is None:
            logger.info(f"Initializing Tavily with topic: {topic}")
            self.tavily_search_tool = TavilySearch(
                tavily_api_key=self.tavily_api_key,
                max_results=self.max_urls,
                topic=topic
                # include_images=True
            )
            self._current_topic = topic

    def search_and_summarize(self, query: str) -> Dict[str, Any]:
        """Main method to search web and return simplified results"""
        try:
            logger.info(f"Starting Tavily search for: {query}")
            
            # Step 1: Determine topic and initialize Tavily tool
            topic = self._get_search_topic(query)
            self._initialize_tavily_tool(topic)
            logger.info(f"Using topic: {topic}")
            
            # Step 2: Search with Tavily
            search_results = self._search_tavily(query)
            
            if not search_results:
                return {
                    "images": [],
                    "results": [],
                    "High_relevance_urls": [],
                    "High_relevance_Title": [],
                    "High_relevance_Domain": []
                }
            
            logger.info(f"Found {len(search_results)} search results")
            
            # Step 3: Format results
            formatted_results = self._format_simple_results(search_results)
            
            return formatted_results
            
        except Exception as e:
            logger.error(f"❌ Error in Tavily search: {str(e)}")
            return {
                "images": [],
                "results": [],
                "High_relevance_urls": [],
                "High_relevance_Title": [],
                "High_relevance_Domain": []
            }
    
    def _search_tavily(self, query: str) -> List[Dict[str, Any]]:
        """Search using Langchain Tavily API"""
        try:
            # Use Langchain Tavily invoke method
            response = self.tavily_search_tool.invoke(query)
            
            # Handle different response formats
            if isinstance(response, list):
                results = response
            elif isinstance(response, dict):
                # Extract results and images from response
                results = response.get('results', [])
                images = response.get('images', [])
                
                # Store images for later use
                self._images = images
                
                return results
            else:
                results = [{'content': str(response), 'url': '', 'title': 'Search Result'}]
            
            # Set empty images if not found in response
            self._images = []
            
            logger.info(f"✅ Tavily returned {len(results)} results")
            return results
            
        except Exception as e:
            logger.error(f"Tavily search error: {str(e)}")
            raise
    
    def _get_favicon_url(self, domain: str) -> str:
        """Generate favicon URL for domain"""
        if not domain:
            return ""
        return f"https://www.google.com/s2/favicons?domain={domain}&sz=32"

    def _format_simple_results(self, tavily_results: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Format Tavily results with enhanced data structure including favicons"""
        formatted_results = []
        high_relevance_urls = []
        high_relevance_titles = []
        high_relevance_domains = []
        high_relevance_enhanced = []  # Enhanced high relevance data
        images = getattr(self, '_images', [])
        
        for result in tavily_results:
            if isinstance(result, str):
                # If result is just a string
                formatted_result = {
                    'url': '',
                    'title': 'Search Result',
                    'content': result,
                    'domain': '',
                    'favicon': '',
                    'score': 0.0
                }
            else:
                # If result is a dictionary
                url = result.get('url', '')
                title = result.get('title', 'Search Result')
                domain = self._get_domain(url)
                score = result.get('score', 0.0)
                favicon_url = self._get_favicon_url(domain)
                
                formatted_result = {
                    'url': url,
                    'title': title,
                    'content': result.get('content', ''),
                    'domain': domain,
                    'favicon': favicon_url,
                    'score': score
                }
                
                # Add to high relevance if score >= 0.5
                if score >= 0.5 and url:
                    high_relevance_urls.append(url)
                    high_relevance_titles.append(title)
                    high_relevance_domains.append(domain)
                    
                    # Enhanced high relevance data with metadata
                    high_relevance_enhanced.append({
                        'url': url,
                        'title': title,
                        'domain': domain,
                        'favicon': favicon_url,
                        'score': score
                    })
            
            formatted_results.append(formatted_result)
        
        # Filter images - only include if we have them
        filtered_images = images if images else []
        
        return {
            "images": filtered_images,
            "results": formatted_results,
            "High_relevance_urls": high_relevance_urls,
            "High_relevance_Title": high_relevance_titles,
            "High_relevance_Domain": high_relevance_domains,
            "High_relevance_Enhanced": high_relevance_enhanced
        }
    
    def _get_domain(self, url: str) -> str:
        """Extract domain from URL"""
        try:
            parsed = urlparse(url)
            return parsed.netloc
        except:
            return ""
    
  