from openai import OpenAI
import time
import base64
import io
import traceback
import logging
from typing import List, Dict, Any, Optional
from PIL import Image
from langchain_openai import ChatOpenAI  # ← Add this line
from langchain.schema import HumanMessage, AIMessage
from langchain_core.messages import HumanMessage, SystemMessage
from openai import OpenAI  # ← Add this for direct OpenAI client

from integration.multimodal_utils import process_multimodal_content

from integration.Settings_llm import (
    OPENAI_API_KEY,get_token_limit, get_model_config
   
)

from services.plan_manager import PlanManager

logger = logging.getLogger(__name__)
# Cache for validated images to avoid repeated processing
def regular_openai_llm(messages: List[Dict[str, str]], system_prompt: str, model_to_use: str, files: List[Dict[str, Any]], has_uploads: bool) -> Dict[str, Any]:
    """LangChain ChatOpenAI for regular models with token tracking"""
    result = {
        "text": "",
        "success": False,
        "provider": "openai",
        "model": model_to_use,
        "elapsed_time": 0,
        "error": None,
        # NEW: Token tracking fields
        "input_tokens": 0,
        "output_tokens": 0,
        "total_tokens": 0,
        "estimated_cost": 0.0
    }

    try:
        start_time = time.time()
        
        # logger.info(f"Using LangChain ChatOpenAI for regular model: {model_to_use}")
        
        # Initialize LangChain ChatOpenAI parameters
        llm_params = {
            "openai_api_key": OPENAI_API_KEY,
            "model": model_to_use,
            "temperature": 0.7,
            "max_tokens": get_token_limit(has_uploads, False),
            "timeout": 60,
            "max_retries": 2
        }
        
        llm = ChatOpenAI(**llm_params)

        # Process multimodal content using unified function
        langchain_messages = process_multimodal_content(messages, files or [], system_prompt)
        
        # NEW: Calculate input tokens before API call
        input_text = ""
        if system_prompt:
            input_text += f"System: {system_prompt}\n\n"
        
        for msg in messages:
            if msg.get("role") in ["user", "assistant"]:
                role = "Human" if msg["role"] == "user" else "Assistant"
                content = msg.get("content", "")
                input_text += f"{role}: {content}\n\n"
        
        # Add file content to input calculation
        if files:
            for file_data in files:
                input_text += f"File: {file_data.get('content', '')}\n\n"
        
        input_tokens = int(len(input_text.split()) * 1.3)
        
        # Generate response using LangChain
        logger.info("Sending request to OpenAI via LangChain...")
        response = llm.invoke(langchain_messages)
        
        response_text = response.content
        output_tokens = int(len(response_text.split()) * 1.3)
        total_tokens = input_tokens + output_tokens
        
        # Calculate cost using centralized function
        estimated_cost = PlanManager.calculate_token_cost(
            "openai", model_to_use, input_tokens, output_tokens
        )

        
        result.update({
            "text": response_text,
            "success": True,
            "elapsed_time": time.time() - start_time,
            "input_tokens": input_tokens,
            "output_tokens": output_tokens,
            "total_tokens": total_tokens,
            "estimated_cost": estimated_cost
        })
        
        logger.info(f"✅ Regular OpenAI success with {model_to_use}: {total_tokens} tokens, ${estimated_cost:.4f}")
        return result

    except Exception as e:
        result.update({
            "error": f"OpenAI regular error: {str(e)}",
            "elapsed_time": time.time() - start_time
        })
        logger.error(f"❌ OpenAI regular error: {str(e)}")
        return result

# REPLACE your existing OSeries_llm function with this:

def OSeries_llm(messages: List[Dict[str, str]], system_prompt: str, model_to_use: str, files: List[Dict[str, Any]], has_uploads: bool) -> Dict[str, Any]:
    """Direct OpenAI client for O-series reasoning models with token tracking"""
    result = {
        "text": "",
        "success": False,
        "provider": "openai",
        "model": model_to_use,
        "elapsed_time": 0,
        "error": None,
        # NEW: Token tracking fields
        "input_tokens": 0,
        "output_tokens": 0,
        "total_tokens": 0,
        "estimated_cost": 0.0
    }

    try:
        start_time = time.time()
        # logger.info(f"Using direct OpenAI client for O-series model: {model_to_use}")
        
        # Initialize direct OpenAI client
        client = OpenAI(api_key=OPENAI_API_KEY)
        
        # Process multimodal content using unified function
        langchain_messages = process_multimodal_content(messages, files or [], system_prompt)
        
        # Convert LangChain messages to OpenAI format for O-series API
        openai_messages = []
        input_text = ""  # For token calculation
        
        for msg in langchain_messages:
            if isinstance(msg, SystemMessage):
                openai_messages.append({
                    "role": "system",
                    "content": msg.content
                })
                input_text += f"System: {msg.content}\n\n"
            elif isinstance(msg, HumanMessage):
                openai_messages.append({
                    "role": "user",
                    "content": msg.content
                })
                input_text += f"Human: {msg.content}\n\n"
            elif isinstance(msg, AIMessage):
                openai_messages.append({
                    "role": "assistant",
                    "content": msg.content
                })
                input_text += f"Assistant: {msg.content}\n\n"
        
        # Add file content to input calculation
        if files:
            for file_data in files:
                input_text += f"File: {file_data.get('content', '')}\n\n"
        
        # Calculate input tokens
        input_tokens = int(len(input_text.split()) * 1.3)
        
        # Make request to OpenAI O-series API
        # logger.info("Sending request to OpenAI O-series...")
        
        # Use responses.create for O-series models
        response = client.responses.create(
            model=model_to_use,
            reasoning={"effort": "low"},
            input=openai_messages
        )
        
        response_text = response.output_text
        output_tokens = int(len(response_text.split()) * 1.3)
        total_tokens = input_tokens + output_tokens
        
        # Calculate cost using centralized function
        estimated_cost = PlanManager.calculate_token_cost(
            "openai", model_to_use, input_tokens, output_tokens
        )
        
        result.update({
            "text": response_text,
            "success": True,
            "elapsed_time": time.time() - start_time,
            "input_tokens": input_tokens,
            "output_tokens": output_tokens,
            "total_tokens": total_tokens,
            "estimated_cost": estimated_cost
        })
        
        logger.info(f"✅ O-Series OpenAI success with {model_to_use}: {total_tokens} tokens, ${estimated_cost:.4f}")
        return result

    except Exception as e:
        result.update({
            "error": f"OpenAI O-series error: {str(e)}",
            "elapsed_time": time.time() - start_time
        })
        logger.error(f"❌ OpenAI O-series error: {str(e)}")
        return result