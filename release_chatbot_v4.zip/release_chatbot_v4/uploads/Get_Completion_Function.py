import base64
import time
from datetime import datetime
import time
from typing import Dict, List, Any, Optional
import logging
import random

from integration.Settings_llm import (
    DEFAULT_PROVIDER, provider_enabled, TITLE_SYSTEM_PROMPT ,WELCOME_SYSTEM_PROMPT
)


from integration.Chat_Completion_Function import (_try_google, _try_anthropic, _try_openai, _try_groq)
from integration.Settings_llm import provider_enabled , get_model_config
from integration.File_Processor import process_file_content


from integration.advanced_memory_manager import HybridMemoryManager
from integration.multi_agent_system import run_agents 

from database.service import LLMContextBuilder
from database.service import ContentFilter


import json
from integration.web_search_agent import WebSearchAgent
from langchain_core.messages import HumanMessage

logger = logging.getLogger(__name__)

#-----------    new -------------------------
# Configuration
DEFAULT_PROVIDER = "groq"

# ================================
# CODE EXTRACTION AND PROCESSING
# ================================

def extract_and_combine_code_content(uploaded_files):
    """Extract actual code content and combine for database storage"""
    if not uploaded_files:
        return ""
    
    combined_content = []
    
    for file_info in uploaded_files:
        try:
            filename = file_info.get("name", "unknown_file")
            content = file_info.get("content", "")
            file_type = file_info.get("file_type", "unknown")
            
            if file_type == "code" and content:
                combined_content.append(f"\n=== UPLOADED FILE: {filename} ===")
                combined_content.append(content)
                combined_content.append("=== END FILE ===\n")
                
        except Exception as e:
            logger.error(f"Error extracting content from {filename}: {e}")
            
    return "\n".join(combined_content)

def prepare_files_for_ai_enhanced(uploaded_files):
    """Simple version that handles all file types correctly"""
    processed_files = []
    
    if not uploaded_files:
        return processed_files
    
    for file_info in uploaded_files:
        try:
            filename = file_info.get("name", "unknown_file")
            file_type = file_info.get("type", "unknown")
            
            logger.info(f"Processing {filename} (type: {file_type})")
            
            # Handle each file type simply
            if file_type == "image":
                # Images use "data" field
                if "data" in file_info:
                    processed_files.append({
                        "type": "image",
                        "name": filename,
                        "data": file_info["data"]
                    })
                    logger.info(f"✅ Image processed: {filename}")
                else:
                    logger.error(f"❌ No image data found for: {filename}")
                    
            elif file_type == "audio":
                # Audio uses "data" field
                if "data" in file_info:
                    processed_files.append({
                        "type": "audio", 
                        "name": filename,
                        "data": file_info["data"]
                    })
                    logger.info(f"✅ Audio processed: {filename}")
                else:
                    logger.error(f"❌ No audio data found for: {filename}")
                    
            else:
                # Text files (code, document, etc.) use "content" field
                if "content" in file_info:
                    processed_files.append({
                        "type": "document",
                        "name": filename,
                        "content": file_info["content"],
                        "file_type": file_info.get("file_type", file_type)
                    })
                    logger.info(f"✅ Text file processed: {filename}")
                else:
                    logger.error(f"❌ No content found for: {filename}")
                    
        except Exception as e:
            logger.error(f"❌ Error processing {filename}: {e}")
            
    return processed_files

# ================================
# SIMPLE PATTERN MATCHING
# ================================

def is_simple_greeting(message: str) -> bool:
    """Check if message is a simple greeting"""
    greetings = [
        'hello', 'hi', 'hey', 'good morning', 'good evening', 'good afternoon',
        'howdy', 'greetings', 'good day', 'hiya', 'sup'
    ]
    message_lower = message.lower().strip()
    return message_lower in greetings and len(message.split()) <= 2

def is_thank_you(message: str) -> bool:
    """Check if message is a thank you"""
    thanks = [
        'thank you', 'thanks', 'appreciate it', 'thx', 'ty', 
        'much appreciated', 'cheers', 'grateful'
    ]
    message_lower = message.lower().strip()
    return any(thank in message_lower for thank in thanks)

def is_simple_farewell(message: str) -> bool:
    """Check if message is a simple goodbye"""
    farewells = [
        'bye', 'goodbye', 'see you', 'see ya', 'later', 
        'take care', 'farewell', 'good night', 'goodnight'
    ]
    message_lower = message.lower().strip()
    return any(farewell in message_lower for farewell in farewells)

def is_simple_acknowledgment(message: str) -> bool:
    acknowledgments = ['ok', 'okay', 'alright', 'got it', 'understood', 'yes', 'yep', 'sure']
    message_lower = message.lower().strip()
    
    # Only trigger for exact matches or very short messages
    if len(message.split()) > 3:  # If more than 3 words, not a simple acknowledgment
        return False
        
    return message_lower in acknowledgments

def get_instant_response(message: str) -> Optional[str]:
    """Get instant response with random variety"""
    
    #Skip instant responses for long messages
    if len(message.split()) > 5 :
        return None

    if is_simple_greeting(message):
        greeting_responses = [
            "Hello! How can I help you today?",
            "Hi there! What can I assist you with?",
            "Hey! What would you like to work on?",
            "Hello! I'm here to help. What do you need?",
            "Hi! Ready to tackle any questions you have.",
            "Greetings! How can I be of assistance?",
            "Hello! What brings you here today?",
            "Hi! Looking forward to helping you out."
        ]
        return random.choice(greeting_responses)
    
    elif is_thank_you(message):
        thank_you_responses = [
            "You're welcome! Is there anything else I can help with?",
            "Happy to help! What else can I do for you?",
            "Glad I could assist! Need help with anything else?",
            "You're very welcome! Feel free to ask more questions.",
            "My pleasure! Is there something else you'd like to explore?",
            "Anytime! What would you like to work on next?",
            "You bet! How else can I help you today?",
            "No problem at all! What's next on your mind?"
        ]
        return random.choice(thank_you_responses)
    
    elif is_simple_farewell(message):
        farewell_responses = [
            "Goodbye! Feel free to come back anytime if you need help.",
            "See you later! Don't hesitate to return if you have questions.",
            "Take care! I'll be here whenever you need assistance.",
            "Farewell! Looking forward to helping you again soon.",
            "Bye for now! Come back anytime you need help.",
            "Until next time! Happy to assist whenever you return.",
            "See you! Remember, I'm always here to help.",
            "Good luck! Feel free to reach out anytime."
        ]
        return random.choice(farewell_responses)
    
    elif is_simple_acknowledgment(message):
        acknowledgment_responses = [
            "Great! What would you like to work on next?",
            "Perfect! How can I help you further?",
            "Excellent! What's the next step?",
            "Awesome! What else can I assist with?",
            "Wonderful! What should we tackle next?",
            "Fantastic! How else can I help?",
            "Sounds good! What would you like to explore?",
            "Nice! What's on your mind next?"
        ]
        return random.choice(acknowledgment_responses)
    
    return None

# ================================
# SMART ROUTING LOGIC
# ================================

def determine_processing_path(message: str, has_uploads: bool, session_has_code: bool, use_reasoning: bool, 
                            enable_web_search: bool = False, enable_deep_research: bool = False, 
                            enable_study_learn: bool = False) -> str:
    """Enhanced routing logic with user modes - MINIMAL CHANGES"""
    
    # NEW: Priority check for user modes (override everything else)
    if enable_study_learn:
        return "study_learn_mode"
    elif enable_deep_research:
        return "deep_research_mode"  
    elif enable_web_search:
        return "web_search_mode"
    
    # EXISTING LOGIC (unchanged)
    if get_instant_response(message):
        return "instant"
    
    if use_reasoning or has_uploads:
        return "full_pipeline"
    
    if session_has_code or any(keyword in message.lower() for keyword in ['code', 'function', 'class', 'variable', 'debug', 'error', 'modify', 'change']):
        return "code_focused"
    
    web_search_keywords = ['current', 'latest', 'recent', 'update', 'today', 'news', 'weather', 'price',
                              'now', 'currently', '2024', '2025', 'this year', 'trending', 'happening now',
                              'what\'s new', 'search for', 'current events', 'find information', 'look up',
                              'stock price', 'breaking news', 'latest news', 'recent developments', 
                              'what\'s happening', 'live', 'real-time', 'up to date', 'fresh', 'new']

    if any(keyword in message.lower() for keyword in web_search_keywords):
        return "web_search"

    if len(message.split()) <= 10 and any(starter in message.lower() for starter in ['what is', 'define', 'explain', 'how to']):
        return "lightweight"
    
    return "standard"

def determine_context_type(user_message: str) -> str:
    """Determine what type of context to build"""
    
    crud_keywords = ['modify', 'change', 'update', 'fix', 'add', 'remove', 'refactor', 'debug']
    analysis_keywords = ['analyze', 'compare', 'review', 'explain', 'understand', 'relationship']
    specific_file_keywords = ['in', 'file', '.py', '.js', '.java']
    
    message_lower = user_message.lower()
    
    if any(keyword in message_lower for keyword in crud_keywords):
        return "crud"
    elif any(keyword in message_lower for keyword in analysis_keywords):
        return "analysis" 
    elif any(keyword in message_lower for keyword in specific_file_keywords):
        return "specific_file"
    else:
        return "general"

# ================================
# ENHANCED MEMORY INTEGRATION
# ================================

def get_code_context_from_memory(memory_manager) -> Dict[str, str]:
    """Extract ONLY code files for CRUD operations"""
    code_files = {}
    
    try:
        messages = memory_manager.get_messages()
        
        for message in messages:
            content = message.get('content', '')
            
            # Use ContentFilter to extract only code files
            all_files = ContentFilter.extract_all_files_from_content(content)
            code_only = ContentFilter.filter_by_file_type(all_files, ['code'])
            
            # Update with latest versions
            for filename, file_info in code_only.items():
                code_files[filename] = file_info['content']
        
        logger.info(f"🔧 Found {len(code_files)} code files for CRUD operations")
        
    except Exception as e:
        logger.error(f"Error extracting code context: {e}")
    
    return code_files

def prepare_enhanced_context(prompt, memory_manager, processing_path, 
                           enable_web_search=False, enable_deep_research=False, enable_study_learn=False):
    """Enhanced context preparation with user modes - MINIMAL CHANGES"""
    
    # NEW: Add mode-specific instructions for user modes
    if enable_web_search or enable_deep_research or enable_study_learn:
        try:
            # Use existing logic first
            context_type = determine_context_type(prompt)
            session_id = getattr(memory_manager, 'session_id', None)
            
            # Get base enhanced prompt using existing logic
            if context_type == "crud" and session_id:
                base_prompt = LLMContextBuilder.build_crud_context(session_id, prompt)
                logger.info("🔧 Built CRUD context with code files only")
            elif context_type == "analysis" and session_id:
                base_prompt = LLMContextBuilder.build_analysis_context(session_id, prompt)
                logger.info("📊 Built analysis context with all file types")
            elif context_type == "specific_file":
                code_files = get_code_context_from_memory(memory_manager)
                base_prompt = ContentFilter.prepare_context_for_llm(code_files, prompt, "crud")
                logger.info("🎯 Built specific file context")
            else:
                base_prompt = prompt
            
            # NEW: Add mode-specific instructions
            mode_instructions = _build_mode_instructions(enable_web_search, enable_deep_research, enable_study_learn)
            return f"{base_prompt}\n\n{mode_instructions}"
            
        except Exception as e:
            logger.error(f"Error preparing enhanced context with modes: {e}")
            return prompt
    
    # EXISTING LOGIC (unchanged when no user modes)
    try:
        context_type = determine_context_type(prompt)
        session_id = getattr(memory_manager, 'session_id', None)
        
        if context_type == "crud" and session_id:
            enhanced_prompt = LLMContextBuilder.build_crud_context(session_id, prompt)
            logger.info("🔧 Built CRUD context with code files only")
            return enhanced_prompt
            
        elif context_type == "analysis" and session_id:
            enhanced_prompt = LLMContextBuilder.build_analysis_context(session_id, prompt)
            logger.info("📊 Built analysis context with all file types")
            return enhanced_prompt
            
        elif context_type == "specific_file":
            code_files = get_code_context_from_memory(memory_manager)
            enhanced_prompt = ContentFilter.prepare_context_for_llm(code_files, prompt, "crud")
            logger.info("🎯 Built specific file context")
            return enhanced_prompt
            
        else:
            return prompt
            
    except Exception as e:
        logger.error(f"Error preparing enhanced context: {e}")
        return prompt


def _build_mode_instructions(enable_web_search, enable_deep_research, enable_study_learn):
    """Build specific instructions based on enabled user modes"""
    
    instructions = []
    
    if enable_study_learn:
        instructions.append("""
🎓 STUDY/LEARN MODE ACTIVE:
- Act as an expert teacher/professor with patient, encouraging tone
- Start with learning objectives for this topic
- Break down complex concepts into digestible steps with examples
- Include practice questions when appropriate
- Structure: Learning Objectives → Core Concepts → Step-by-Step → Examples → Practice
- End with "What questions do you have?" to encourage engagement""")
    
    if enable_deep_research:
        instructions.append("""
🔬 DEEP RESEARCH MODE ACTIVE:
- Provide comprehensive research-level analysis combining web data + your knowledge
- Structure: Executive Summary → Detailed Analysis → Evidence → Multiple Perspectives → Implications
- Cross-reference sources and evaluate credibility
- Present different approaches and methodologies
- Use formal analytical tone for academic/professional research""")
    
    if enable_web_search:
        instructions.append("""
🔍 WEB SEARCH MODE ACTIVE:
- Always incorporate current, up-to-date information from web sources
- Enhance responses with recent developments even for familiar topics
- Clearly attribute information to sources and cross-reference for accuracy
- Prioritize information from last 1-3 months when available""")
    
    return "\n".join(instructions)


def prepare_enhanced_context_with_modes(prompt, memory_manager, processing_path,
                                      enable_web_search=False, enable_deep_research=False, enable_study_learn=False):
    """Enhanced context preparation that integrates user modes with your existing logic"""
    
    # For user modes, always use enhanced context but add mode-specific instructions
    if enable_web_search or enable_deep_research or enable_study_learn:
        try:
            # Use your existing enhanced context builder
            base_enhanced_prompt = prepare_enhanced_context(prompt, memory_manager, "full_pipeline")
            
            # Add mode-specific instructions
            mode_instructions = _build_mode_instructions(enable_web_search, enable_deep_research, enable_study_learn)
            
            return f"{base_enhanced_prompt}\n\n{mode_instructions}"
            
        except Exception as e:
            logger.warning(f"Enhanced context with modes failed, using fallback: {e}")
            # Fallback: original prompt + mode instructions
            mode_instructions = _build_mode_instructions(enable_web_search, enable_deep_research, enable_study_learn)
            return f"{prompt}\n\n{mode_instructions}"
    else:
        # Use your existing logic unchanged
        return prepare_enhanced_context(prompt, memory_manager, processing_path)

# ================================
# MAIN COMPLETION FUNCTION
# ================================

def get_completion_with_memory(
    prompt: str,
    user_selection_model: str,
    memory_manager,
    use_reasoning: bool = False,
    system_prompt: Optional[str] = None,
    provider: Optional[str] = None,
    has_uploads: bool = False,
    uploaded_files: Optional[List[Dict[str, Any]]] = None,
    session_id: Optional[str] = None,
    user_id: Optional[str] = None,
    # NEW: User mode parameters
    enable_web_search: bool = False,
    enable_deep_research: bool = False,
    enable_study_learn: bool = False
) -> Dict[str, Any]:
    """
    Enhanced completion function with user modes
    MAINTAINS EXACT SAME INTERFACE FOR FRONTEND COMPATIBILITY
    """
    
    try:
        start_time = time.time()
        
        # Log active user modes
        active_modes = []
        if enable_web_search: active_modes.append("Web Search")
        if enable_deep_research: active_modes.append("Deep Research")
        if enable_study_learn: active_modes.append("Study/Learn")
        
        if active_modes:
            logger.info(f"🎯 User Modes Active: {', '.join(active_modes)}")
        
        # ========================================
        # STEP 2: Check for Instant Responses (Skip for user modes)
        # ========================================
        # Skip instant responses if any user mode is enabled
        if not (enable_web_search or enable_deep_research or enable_study_learn):
            instant_response = get_instant_response(prompt)
            if instant_response:
                logger.info("✅ Instant response via pattern matching")
                memory_manager.add_ai_message(instant_response)
                
                return {
                    "text": instant_response,
                    "success": True,
                    "provider": provider or DEFAULT_PROVIDER,
                    "model": user_selection_model,
                    "elapsed_time": time.time() - start_time,
                    "input_tokens": 0,
                    "output_tokens": len(instant_response.split()),
                    "memory_info": memory_manager.get_memory_info(),
                    "session_context": {
                        "execution_path": "instant_response",
                        "optimization_enabled": True
                    }
                }
        
        # ========================================
        # STEP 3: Process Uploaded Files (Unchanged)
        # ========================================
        processed_files = ""
        if uploaded_files and has_uploads:
            processed_files = prepare_files_for_ai_enhanced(uploaded_files)
            
            code_content = extract_and_combine_code_content(processed_files)
            if code_content:
                logger.info(f"Extracted code content from {len(uploaded_files)} files")
        
        # ========================================
        # STEP 4: Get Code Context from Memory (Unchanged)
        # ========================================
        session_code_files = get_code_context_from_memory(memory_manager)
        session_has_code = len(session_code_files) > 0
        
        # ========================================
        # STEP 5: Enhanced Processing Path Determination
        # ========================================
        processing_path = determine_processing_path(
            prompt, has_uploads, session_has_code, use_reasoning,
            enable_web_search, enable_deep_research, enable_study_learn
        )
        
        logger.info(f"🎯 Enhanced processing path: {processing_path}")
        
        # ========================================
        # STEP 6: Enhanced Prompt Preparation
        # ========================================
        enhanced_prompt = prompt
        enhanced_sources = []
        agent_result = {
            "execution_path": processing_path,
            "agent_success": True,
            "task_breakdown": {"primary_intent": "general", "complexity_score": 0.5},
            "decisions": {
                "needs_web_search": enable_web_search or enable_deep_research,
                "needs_code_analysis": session_has_code,
                "force_web_search": enable_web_search,
                "force_deep_research": enable_deep_research, 
                "force_study_mode": enable_study_learn
            }
        }
        
        # Enhanced context preparation
        try:
            enhanced_prompt = prepare_enhanced_context_with_modes(
                prompt, memory_manager, processing_path,
                enable_web_search, enable_deep_research, enable_study_learn
            )
        except Exception as e:
            logger.warning(f"Enhanced context failed, using original prompt: {e}")
            enhanced_prompt = prompt
        
        # Force run agents for user modes or complex processing
        if (enable_web_search or enable_deep_research or enable_study_learn or 
            processing_path in ["full_pipeline", "code_focused", "web_search"]):
            try:
                logger.info("🚀 Running enhanced multi-agent analysis...")
                
                agent_start_time = time.time()
                agent_result = run_agents(
                    user_message=prompt,
                    use_reasoning=use_reasoning,
                    uploaded_content=processed_files,
                    session_id=session_id or "default",
                    user_id=user_id,
                    provider=provider,
                    # NEW: Pass user mode flags to agents
                    enable_web_search=enable_web_search,
                    enable_deep_research=enable_deep_research,
                    enable_study_learn=enable_study_learn
                )
                agent_end_time = time.time()
                
                # logger.info(f"Agent_decisions:====| {agent_result} |=====")

                logger.info(
                    f"Task Breakdown: {agent_result.get('task_breakdown')}, "
                    f"Decisions: {agent_result.get('decisions')}, "
                    f"Agent Success: {agent_result.get('agent_success')}, "
                    f"Execution Path: {agent_result.get('execution_path')},"
                    f"User Selected Modes : {agent_result.get('user_modes')},"
                )
                                
                logger.info(f"✅ Enhanced agents completed in {agent_end_time - agent_start_time:.4f}s")
                
                enhanced_prompt = agent_result.get("enhanced_prompt", enhanced_prompt)
                enhanced_sources = agent_result.get("enhanced_sources", [])
                
            except Exception as e:
                logger.error(f"⚠️ Enhanced agent processing failed: {e}")
                # Continue with original/enhanced prompt
        
        # ========================================
        # STEP 7: Prepare Messages for LLM (Unchanged)
        # ========================================
        messages = memory_manager.get_messages()
        messages.append({"role": "user", "content": enhanced_prompt})
        
        # ========================================
        # STEP 8: Provider Selection & LLM Call (Unchanged)
        # ========================================
        providers_to_try = []
        
        if provider and provider_enabled(provider):
            providers_to_try.append(provider)
        else:
            # Fall back to default provider
            if provider_enabled(DEFAULT_PROVIDER):
                providers_to_try.append(DEFAULT_PROVIDER)
        
        all_providers = ["groq", "google", "openai", "anthropic"]
        
        for p in all_providers:
            if p not in providers_to_try and provider_enabled(p):
                providers_to_try.append(p)
        
        if not providers_to_try:
            return {
                "text": "No AI providers are configured. Please add API keys.",
                "success": False,
                "provider": None,
                "model": None,
                "elapsed_time": time.time() - start_time,
                "error": "No providers configured"
            }
        
        # Try providers in order
        for current_provider in providers_to_try:
            try:
                logger.info(f"✅ Trying provider: {current_provider}")
                
                model_config = get_model_config(current_provider, user_selection_model)
                current_model = model_config["model"]
                
                logger.info(f"✅ Using model: {current_model}")
                
                # Call appropriate provider (existing logic)
                if current_provider == "groq":
                    result = _try_groq(messages, system_prompt or "", use_reasoning, 
                                       processed_files, has_uploads, current_model)
                elif current_provider == "google":
                    result = _try_google(messages, system_prompt or "", use_reasoning, 
                                       processed_files, has_uploads, current_model)
                elif current_provider == "openai":
                    result = _try_openai(messages, system_prompt or "", use_reasoning, 
                                          processed_files, has_uploads, current_model)
                elif current_provider == "anthropic":
                    result = _try_anthropic(messages, system_prompt or "", use_reasoning, 
                                     processed_files, has_uploads, current_model)
                else:
                    continue
                
                if result["success"]:
                    # ========================================
                    # STEP 9: Enhanced Successful Response Processing
                    # ========================================
                    
                    # Add AI response to memory
                    memory_manager.add_ai_message(result["text"])
                    
                    # Enhanced response with user mode metadata
                    result.update({
                        "memory_info": memory_manager.get_memory_info(),
                        "session_context": {
                            "uploaded_files_count": len(uploaded_files) if uploaded_files else 0,
                            "provider_used": current_provider,
                            "model_used": current_model,
                            "was_fallback": current_provider != (provider or DEFAULT_PROVIDER),
                            "execution_path": processing_path,
                            "optimization_enabled": True,
                            "has_code_context": session_has_code,
                            "code_files_count": len(session_code_files),
                            # NEW: User mode context
                            "user_modes": {
                                "web_search_active": enable_web_search,
                                "deep_research_active": enable_deep_research,
                                "study_learn_active": enable_study_learn
                            }
                        },
                        "enhanced_sources": enhanced_sources,
                        "multi_agent": {
                            "used_reasoning": use_reasoning,
                            "execution_path": agent_result.get("execution_path", processing_path),
                            "task_breakdown": agent_result.get("task_breakdown", {}),
                            "decisions": agent_result.get("decisions", {}),
                            "agent_success": agent_result.get("agent_success", True),
                            "optimization_metrics": {
                                "processing_path": processing_path,
                                "has_code_context": session_has_code,
                                "performance_optimized": True,
                                # NEW: User mode metrics
                                "user_modes_used": {
                                    "web_search": enable_web_search,
                                    "deep_research": enable_deep_research,
                                    "study_learn": enable_study_learn
                                }
                            },
                            # NEW: User mode information from agents
                            "user_modes": agent_result.get("user_modes", {})
                        }
                    })
                    
                    logger.info(f"🎯 Success with {processing_path} path and user modes: {active_modes}")
                    return result
                    
            except Exception as provider_error:
                logger.error(f"❌ Provider {current_provider} failed: {str(provider_error)}")
                continue
        
        # ========================================
        # STEP 10: All Providers Failed
        # ========================================
        return {
            "text": "All AI providers failed to respond. Please try again.",
            "success": False,
            "provider": None,
            "model": None,
            "elapsed_time": time.time() - start_time,
            "error": "All providers failed"
        }
        
    except Exception as e:
        logger.error(f"❌ Critical error in enhanced get_completion_with_memory: {str(e)}", exc_info=True)
        return {
            "text": "An error occurred while processing your request. Please try again.",
            "success": False,
            "provider": None,
            "model": None,
            "elapsed_time": 0,
            "error": str(e)
        }

# ===================================================
# Handle the Welecome Greet Message and Session Titles
# ====================================================

def generate_title(prompt: str, user_selection_model: str = None) -> str:
    """Generate title using LLM"""
    temp_memory = HybridMemoryManager()

    result = get_completion_with_memory(
        prompt=f"Create a short, descriptive title for a chat that begins with: '{prompt}'",
        memory_manager=temp_memory,
        user_selection_model=user_selection_model,
        system_prompt=TITLE_SYSTEM_PROMPT
    )
    
    if result["success"]:
        title = result["text"].strip().strip('"\'')
        return title[:50] if title else f"Chat {time.strftime('%H:%M')}"
    else:
        return f"Chat {time.strftime('%m-%d %H:%M')}"

def generate_chat_title(user_message, user_selection_model=None):
    """Generate chat title with proper error handling"""
    if not user_message or not user_message.strip():
        return f"Chat {datetime.now().strftime('%H:%M')}"

    try:
        title = generate_title(user_message, user_selection_model)
        
        if not title or len(title) > 50:
            fallback_title = f"Chat {user_message[:20]}..."
            logger.warning(f"Invalid title generated, using fallback: {fallback_title}")
            return fallback_title

        return title
        
    except Exception as e:
        logger.error(f"Error generating chat title: {str(e)}")
        return f"Chat {datetime.now().strftime('%Y-%m-%d %H:%M')}"
     
def welcomingMessage(username: str, time_greeting: str, last_login: Optional[datetime], 
                    is_returning_user: bool) -> str:
    """
    Generate a personalized welcome message using LLM with rich user context.
    Returns a short, energetic greeting or fallback message if LLM fails.
    """
    try:
        temp = HybridMemoryManager()
        
        # Format last_login for better context
        last_login_str = last_login.strftime("%B %d") if last_login else "first time"
        
        # Create context-rich prompt
        user_context = f"""
        Username: {username}
        Time greeting: {time_greeting}
        Last login: {last_login_str}
        Returning user: {'Yes' if is_returning_user else 'No, first visit'}
        """

        result = get_completion_with_memory(
            prompt=f"Create a brief, helpful welcome message for {username},{time_greeting}. Make it inviting and ready to assist with their needs.",
            memory_manager=temp,
            user_selection_model=None,
            system_prompt=WELCOME_SYSTEM_PROMPT
        )
        
        # Add debug logging
        logger.info(f"Welcome result type: {type(result)}")
        logger.info(f"Welcome result success: {result.get('success')}")

        if result["success"]:
            # Clean and limit the response
            message = result["text"].strip().strip('"\'')
            return message[:60] if message else f"{time_greeting}, {username}! Ready to chat?"
        else:
            # Fallback message
            return f"{time_greeting}, {username}! Ready to chat?"
    
    except Exception as e:
        logger.error(f"Welcome message error: {type(e).__name__}: {str(e)}")
        return f"{time_greeting}, {username}! Ready to chat?"


