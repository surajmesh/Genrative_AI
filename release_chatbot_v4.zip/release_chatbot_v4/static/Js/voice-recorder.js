/**
 * Voice recording functionality for the ABCO AI chat interface
 */
document.addEventListener('DOMContentLoaded', function() {
  let mediaRecorder;
  let audioChunks = [];
  let recordingTimer;
  let recordingSeconds = 0;
  let recordingInProgress = false;
  
  const voiceRecordBtn = document.querySelector('.voice-record-btn');
  if (!voiceRecordBtn) return;
  
  // Check if browser supports getUserMedia
  if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
    console.error('Browser does not support audio recording');
    voiceRecordBtn.style.display = 'none';
    return;
  }
  
  // Add recording timer element
  const timerElement = document.createElement('span');
  timerElement.className = 'recording-time';
  timerElement.style.display = 'none';
  voiceRecordBtn.appendChild(timerElement);
  
  // Helper to format time as mm:ss
  function formatTime(seconds) {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes.toString().padStart(2, '0')}:${remainingSeconds.toString().padStart(2, '0')}`;
  }
  
  // Request microphone permission when button is clicked
  voiceRecordBtn.addEventListener('mousedown', startRecording);
  
  // Stop recording when mouse button is released
  voiceRecordBtn.addEventListener('mouseup', stopRecording);
  
  // Also stop recording if the mouse leaves the button
  voiceRecordBtn.addEventListener('mouseleave', function() {
    if (recordingInProgress) {
      stopRecording();
    }
  });
  
  // For touch devices
  voiceRecordBtn.addEventListener('touchstart', function(e) {
    e.preventDefault(); // Prevent touch events from triggering mouse events
    startRecording();
  });
  
  voiceRecordBtn.addEventListener('touchend', function(e) {
    e.preventDefault();
    stopRecording();
  });
  
  function startRecording() {
    if (recordingInProgress) return;
    
    // Request access to the microphone
    navigator.mediaDevices.getUserMedia({ audio: true })
      .then(stream => {
        recordingInProgress = true;
        voiceRecordBtn.classList.add('recording');
        
        // Reset audio chunks
        audioChunks = [];
        
        // Create media recorder
        mediaRecorder = new MediaRecorder(stream);
        
        // Start recording and collecting data
        mediaRecorder.ondataavailable = (e) => {
          if (e.data.size > 0) {
            audioChunks.push(e.data);
          }
        };
        
        // When recording stops
        mediaRecorder.onstop = () => {
          const tracks = stream.getTracks();
          tracks.forEach(track => track.stop());
        };
        
        // Start the recording
        mediaRecorder.start();
        
        // Show and start the timer
        recordingSeconds = 0;
        timerElement.textContent = '00:00';
        timerElement.style.display = 'block';
        
        recordingTimer = setInterval(() => {
          recordingSeconds++;
          timerElement.textContent = formatTime(recordingSeconds);
          
          // Automatically stop if recording exceeds 2 minutes
          if (recordingSeconds >= 120) {
            stopRecording();
          }
        }, 1000);
      })
      .catch(error => {
        console.error('Error accessing microphone:', error);
        alert('Could not access microphone. Please check your permissions and try again.');
      });
  }
  
  function stopRecording() {
    if (!recordingInProgress || !mediaRecorder) return;
    
    recordingInProgress = false;
    voiceRecordBtn.classList.remove('recording');
    timerElement.style.display = 'none';
    
    clearInterval(recordingTimer);
    
    mediaRecorder.stop();
    
    // Create audio blob and send it
    setTimeout(() => {
      if (audioChunks.length > 0) {
        const audioBlob = new Blob(audioChunks, { type: 'audio/webm' });
        
        // Check if the recording is too short (less than 0.5 seconds)
        if (recordingSeconds < 1) {
          console.log('Recording too short, discarding');
          return;
        }
        
        sendAudioToServer(audioBlob);
      }
    }, 100);
  }
  
  function sendAudioToServer(audioBlob) {
    // Use the proper message creation in the chat-messages-container element
    const chatMessages = document.querySelector('.chat-messages');
    if (!chatMessages) {
      console.error('Chat messages container not found');
      return;
    }

    const tempMessageId = 'temp-' + Date.now();
    
    // Create a new message wrapper and message element with loading state
    const messageWrapper = document.createElement('div');
    messageWrapper.classList.add('message-wrapper', 'user-wrapper');
    messageWrapper.id = tempMessageId;
    
    // Create message element
    const messageEl = document.createElement('div');
    messageEl.classList.add('message', 'message-user');
    
    // Create avatar element
    const avatarEl = document.createElement('div');
    avatarEl.classList.add('message-avatar');
    avatarEl.innerHTML = `<div class="user-avatar">LV</div>`;
    
    // Set processing message content
    messageEl.innerHTML = `
      <div class="message-content">
        <p>Processing audio message...</p>
        <div class="loading-dots">
          <div class="loading-dot"></div>
          <div class="loading-dot"></div>
          <div class="loading-dot"></div>
        </div>
      </div>
      <div class="message-timestamp">${new Date().toLocaleTimeString()}</div>
    `;
    
    // Add message and avatar to the wrapper in correct order
    messageWrapper.appendChild(messageEl);
    messageWrapper.appendChild(avatarEl);
    
    // Add to messages container
    chatMessages.appendChild(messageWrapper);
    
    // Scroll to bottom
    chatMessages.scrollTop = chatMessages.scrollHeight;
    
    // Create form data to send the audio file
    const formData = new FormData();
    formData.append('audio', audioBlob, 'recording.webm');
    
    // Get the current session ID - try multiple ways to find it
    let currentSessionId = document.querySelector('#sessionId')?.value;
    
    // If not found, try to get it from URL parameters
    if (!currentSessionId) {
      const urlParams = new URLSearchParams(window.location.search);
      currentSessionId = urlParams.get('session_id');
    }
    
    // If still not found, check data attributes
    if (!currentSessionId) {
      currentSessionId = document.querySelector('.chat-messages-container')?.dataset?.sessionId;
    }
    
    // If still not found, try to get the active session from the sidebar
    if (!currentSessionId) {
      const activeSession = document.querySelector('.session-item.active');
      currentSessionId = activeSession?.dataset?.id;
    }
    
    // Last attempt - look for hidden session input anywhere
    if (!currentSessionId) {
      const sessionInputs = document.querySelectorAll('input[type="hidden"]');
      for (const input of sessionInputs) {
        if (input.name === 'session_id' || input.id === 'sessionId' || input.id.includes('session')) {
          currentSessionId = input.value;
          break;
        }
      }
    }
    
    // If no session ID found, create a new session
    if (!currentSessionId) {
      console.error('No session ID found, will create a new one with first message');
      
      // Create a new chat session via API
      fetch('/api/chat/sessions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          name: 'Voice Chat ' + new Date().toLocaleString()
        })
      })
      .then(response => response.json())
      .then(data => {
        if (data.success) {
          // Use the new session ID to send the audio
          const newSessionId = data.session_id;
          
          // Send to backend
          fetch('/api/send-audio', {
            method: 'POST',
            body: formData,
            headers: {
              'X-Session-ID': newSessionId
            }
          })
          .then(response => {
            if (!response.ok) {
              throw new Error(`HTTP error ${response.status}`);
            }
            return response.json();
          })
          .then(audioData => {
            // Replace the temporary message with the transcribed text
            updateTempMessage(tempMessageId, audioData.transcription);
            
            // If the server already processed AI response to the transcription
            if (audioData.response) {
              displayAIResponse(audioData.response);
            }
            
            // Refresh the page to show the new session
            window.location.href = `/chat?session_id=${newSessionId}`;
          })
          .catch(error => {
            console.error('Error sending audio:', error);
            updateTempMessage(tempMessageId, 'Error processing audio. Please try again.');
          });
        } else {
          updateTempMessage(tempMessageId, 'Error: Could not create a new chat session');
        }
      })
      .catch(error => {
        console.error('Error creating session:', error);
        updateTempMessage(tempMessageId, 'Error: Could not create a new chat session');
      });
      
      return;
    }
    
    // Use the found session ID to send the audio
    // Send to backend
    fetch('/api/send-audio', {
      method: 'POST',
      body: formData,
      headers: {
        'X-Session-ID': currentSessionId
      }
    })
    .then(response => {
      if (!response.ok) {
        throw new Error(`HTTP error ${response.status}`);
      }
      return response.json();
    })
    .then(data => {
      // Replace the temporary message with the transcribed text
      updateTempMessage(tempMessageId, data.transcription);
      
      // If the server already processed AI response to the transcription
      if (data.response) {
        displayAIResponse(data.response);
      }
    })
    .catch(error => {
      console.error('Error sending audio:', error);
      updateTempMessage(tempMessageId, 'Error processing audio. Please try again.');
    });
  }
  
  function updateTempMessage(messageId, text) {
    const tempMessageWrapper = document.getElementById(messageId);
    // alert('upadte template message')
    if (tempMessageWrapper) {
      const contentElement = tempMessageWrapper.querySelector('.message-content');
      if (contentElement) {
        contentElement.innerHTML = `<p>${text}</p>`;
      }
    }
  }
  
  function displayAIResponse(responseText) {
    // Create response message container for the new UI
    const chatMessages = document.querySelector('.chat-messages');
    if (!chatMessages) {
      console.error('Chat messages container not found');
      return;
    }
    
    // Create message wrapper
    const messageWrapper = document.createElement('div');
    messageWrapper.classList.add('message-wrapper', 'assistant-wrapper');
    messageWrapper.id = 'msg-' + Date.now();
    
    // Create avatar element
    const avatarEl = document.createElement('div');
    avatarEl.classList.add('message-avatar');
    avatarEl.innerHTML = `<div class="assistant-avatar">
      <svg viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg" class="bot-avatar-icon">
        <path d="M16 8.5C11.0366 8.5 7 12.3137 7 17C7 21.6863 11.0366 25.5 16 25.5C20.9634 25.5 25 21.6863 25 17C25 12.3137 20.9634 8.5 16 8.5Z" fill="#3498db"></path>
      </svg>
    </div>`;
    
    // Create message element
    const messageEl = document.createElement('div');
    messageEl.classList.add('message', 'message-assistant');
    messageEl.innerHTML = `
      <div class="message-content">${responseText}</div>
      <div class="message-timestamp">${new Date().toLocaleTimeString()}</div>
    `;
    
    // Add avatar and message to the wrapper
    messageWrapper.appendChild(avatarEl);
    messageWrapper.appendChild(messageEl);
    
    // Add to messages list
    chatMessages.appendChild(messageWrapper);
    
    // Scroll to bottom
    if (typeof scrollToBottom === 'function') {
      scrollToBottom();
    } else {
      chatMessages.scrollTop = chatMessages.scrollHeight;
    }
  }
});