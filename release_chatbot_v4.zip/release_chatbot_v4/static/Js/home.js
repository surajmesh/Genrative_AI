/**
 * Home page JavaScript
 * Handles cache busting and UI enhancements
 */

document.addEventListener('DOMContentLoaded', function() {
  // Log when the page loads with a timestamp
  console.log('Home page loaded with cache buster timestamp:', Date.now());
  
  // Force reload stylesheets to avoid caching issues
  const timestamp = Date.now();
  const stylesheets = document.querySelectorAll('link[rel="stylesheet"]');
  
  stylesheets.forEach(stylesheet => {
    if (stylesheet.href.includes('home.css')) {
      const newHref = stylesheet.href.split('?')[0] + '?forcereload=' + timestamp;
      stylesheet.href = newHref;
      console.log('Reloaded stylesheet:', newHref);
    }
  });
  
  // Force reload images to avoid caching issues
  const owlIcons = document.querySelectorAll('.custom-owl-icon');
  
  owlIcons.forEach(img => {
    const originalSrc = img.src.split('?')[0];
    img.src = originalSrc + '?forcereload=' + timestamp;
    console.log('Reloaded image:', img.src);
  });
  
  // Add entrance animation for feature cards
  animateFeatureCards();
});

/**
 * Add entrance animation for feature cards
 */
function animateFeatureCards() {
  const cards = document.querySelectorAll('.feature-card');
  
  cards.forEach((card, index) => {
    // Add animation with increasing delay for each card
    setTimeout(() => {
      card.classList.add('animated');
    }, 100 * index);
    
    // Add hover animations
    card.addEventListener('mouseenter', function() {
      const icon = this.querySelector('.custom-owl-icon');
      if (icon) {
        icon.style.transform = 'scale(1.05)';
        icon.style.filter = 'drop-shadow(0 0 12px rgba(30, 184, 255, 0.8))';
      }
    });
    
    card.addEventListener('mouseleave', function() {
      const icon = this.querySelector('.custom-owl-icon');
      if (icon) {
        icon.style.transform = 'scale(1)';
        icon.style.filter = 'drop-shadow(0 0 8px rgba(30, 184, 255, 0.5))';
      }
    });
  });
}