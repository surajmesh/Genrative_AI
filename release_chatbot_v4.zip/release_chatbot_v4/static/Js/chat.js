// =============================================
// COMPLETE ENHANCED CHAT SYSTEM - UPDATED WITH CONSOLIDATED CONTROLS
// commented codes for backend endpoints for improvement speech2text using whisper model
// =============================================

class ChatApplication {
    constructor() {
        // Core state
        this.currentChatSession = null;
        this.currentChatId = null;
        this.isProcessing = false;
        this.stopStreaming = false;
        this.streamingTimeout = null;
        this.uploadedFiles = [];
        this.chatHistory = JSON.parse(localStorage.getItem("chatHistory")) || {};
        this.currentThinkingMode = 'quick';
        this.isRecording = false;
        this.mediaRecorder = null;
        this.audioChunks = [];
        this.selectedModel = null;
        this.availableModels = {};
        this.modelLoading = false;
        
        // User modes state
        this.userModes = {
            webSearch: false,
            deepResearch: false,
            studyLearn: false
        };
        
        // DOM elements
        this.elements = {};
        
        // Initialize
        this.init();
    }

    // =============================================
    // INITIALIZATION
    // =============================================
    init() {
        document.addEventListener('DOMContentLoaded', () => {
            this.initElements();
            this.setupEventListeners();
            this.loadChatSessions();
            this.handleUrlParams();
            this.initSidebarToggle();
            this.initSmoothTransitions();
            this.initNewInputControls();
            this.loadWelcomeMessage();
            this.loadUserInfo();
            this.setupMessageActionButtons();
            this.initializeUserModeToggles();
            this.initializeCopyButtons();
        });
    }

    initElements() {
        this.elements = {
            messagesList: document.getElementById('messages'),
            messageInput: document.getElementById('user-input'),
            dynamicSendBtn: document.getElementById('dynamic-send-btn'),
            uploadOptionsBtn: document.getElementById('upload-options-btn'),
            uploadDropdown: document.getElementById('upload-dropdown'),
            thinkingModeBtn: document.getElementById('thinking-mode-btn'),
            thinkingDropdown: document.getElementById('thinking-dropdown'),
            fileInput: document.getElementById('file-upload'),
            chatHistory: document.getElementById('chat-history'),
            currentChatTitle: document.getElementById('current-chat-title'),
            imagePreview: document.getElementById('image-preview'),
            inputArea: document.getElementById('input-area'),
            provider: document.getElementById('provider'),
            providerDropdown: document.getElementById('provider-dropdown'),
            selectedProvider: document.getElementById('selected-provider'),
            regenerateButton: document.getElementById('regenerate-response'),
            welcomeMessage: document.getElementById('welcomeMessage')
        };
    }
    

    // =============================================
    // NEW: USER INFO & WELCOME MESSAGE METHODS
    // =============================================
    
    // NEW: Load user info immediately (fast)
    async loadUserInfo() {
        try {
            const response = await fetch('/api/chat/user-info');
            const data = await response.json();
            
            if (data.success && data.user_info) {
                this.userData = {
                    name: data.user_info.user_fullName,
                    email: data.user_info.mail,
                    avatar: null,
                    firstLetter: data.user_info.user_firstLetter
                };
                this.updateProfileDisplay();
                this.updateUserSections(data.user_info);
                console.log('User info loaded:', this.userData);
            }
        } catch (error) {
            console.error('Error loading user info:', error);
            this.setFallbackUserData();
        }
    }

    // Helper method to update user sections
    updateUserSections(userInfo) {
        // Update profile icon
        const profileIconDiv = document.querySelector('.profile-icon-img');
        if (profileIconDiv) {
            profileIconDiv.textContent = userInfo.user_firstLetter || 'U';
        }

        // Update profile name
        const profileNameDiv = document.querySelector('.user-profile-name-');
        if (profileNameDiv) {
            profileNameDiv.textContent = userInfo.user_fullName || 'Unknown User';
        }

        // Update user section
        const userNameDiv = document.querySelector('.user-section .user-name');
        if (userNameDiv) {
            userNameDiv.textContent = userInfo.user_fullName || 'Unknown User';
        }
        
        const userEmailDiv = document.querySelector('.user-section .user-email');
        if (userEmailDiv) {
            userEmailDiv.textContent = userInfo.mail || 'No Email Provided';
        }
    }

    // NEW: Set fallback user data
    setFallbackUserData() {
        this.userData = {
            name: "User",
            email: "user@example.com",
            avatar: null,
            firstLetter: "U"
        };
        this.updateProfileDisplay();
    }

    // UPDATED: Load welcome message separately (slow)
    async loadWelcomeMessage() {
        const welcomeElement = this.elements.welcomeMessage;
        
        if (!welcomeElement) {
            console.log('Welcome message element not found');
            return;
        }

        try {
            console.log('Loading dynamic welcome message...');
            welcomeElement.textContent = "What's on the agenda today?"; // Show loading state
            
            const response = await fetch('/api/chat/welcome-message');
            const data = await response.json();
            
            if (data.success && data.welcome_message) {
                welcomeElement.textContent = data.welcome_message;
                welcomeElement.classList.add('loaded');
                console.log('Welcome message loaded:', data.welcome_message);
                this.animateWelcomeMessage(welcomeElement);
            } else {
                console.warn('Failed to load welcome message:', data);
                this.setFallbackWelcomeMessage(welcomeElement);
            }
        } catch (error) {
            console.error('Error loading welcome message:', error);
            this.setFallbackWelcomeMessage(welcomeElement);
        }
    }

    // Keep existing methods...
    setFallbackWelcomeMessage(welcomeElement) {
        const fallbackMessage = `Hello! What's on your mind today?`;
        welcomeElement.textContent = fallbackMessage;
        welcomeElement.classList.add('fallback');
        console.log('Using fallback welcome message');
    }

    animateWelcomeMessage(element) {
        element.style.opacity = '0';
        element.style.transform = 'translateY(10px)';
        
        setTimeout(() => {
            element.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
            element.style.opacity = '1';
            element.style.transform = 'translateY(0)';
        }, 100);
    }

    async refreshWelcomeMessage() {
    const welcomeElement = this.elements.welcomeMessage;
    if (welcomeElement) {
        welcomeElement.textContent = 'Loading welcome message...';
        welcomeElement.classList.remove('loaded', 'fallback');
        await this.loadWelcomeMessage();
    }
    }

    updateProfileDisplay() {
        const isCollapsed = document.querySelector('.left-container.collapsed');
        const profileText = document.querySelector('.profile-text');
        const profileIcon = document.querySelector('.profile-icon-img');

        if (!profileText || !profileIcon || !this.userData) return;

        profileIcon.textContent = this.userData.firstLetter;

        if (isCollapsed) {
            profileText.style.display = 'none';
            profileText.style.opacity = '0';
        } else {
            profileText.style.display = 'flex';
            profileText.style.opacity = '1';
            profileText.querySelector('.profile-name').textContent = this.userData.name;
            profileText.querySelector('.profile-email').textContent = this.userData.email;
        }
    }

    // ================================
    // USER MODE TOGGLE METHODS
    // ================================

    initializeUserModeToggles() {
        // Get toggle elements
        this.webSearchToggle = document.getElementById('web-search-toggle');
        this.deepResearchToggle = document.getElementById('deep-research-toggle');
        this.studyLearnToggle = document.getElementById('study-learn-toggle');
        
        // Add event listeners
        if (this.webSearchToggle) {
            this.webSearchToggle.addEventListener('change', (e) => {
                this.userModes.webSearch = e.target.checked;
                this.updateToggleState('web-search', e.target.checked);
                this.logModeChange('Web Search', e.target.checked);
                this.updateActiveModeIndicator();
            });
        }
        
        if (this.deepResearchToggle) {
            this.deepResearchToggle.addEventListener('change', (e) => {
                this.userModes.deepResearch = e.target.checked;
                this.updateToggleState('deep-research', e.target.checked);
                this.logModeChange('Deep Research', e.target.checked);
                this.updateActiveModeIndicator();
            });
        }
        
        if (this.studyLearnToggle) {
            this.studyLearnToggle.addEventListener('change', (e) => {
                this.userModes.studyLearn = e.target.checked;
                this.updateToggleState('study-learn', e.target.checked);
                this.logModeChange('Study/Learn', e.target.checked);
                this.updateActiveModeIndicator();
            });
        }
    }

    updateToggleState(toggleId, isActive) {
        const toggleItem = document.querySelector(`#${toggleId}-toggle`).closest('.mode-toggle-item');
        if (toggleItem) {
            toggleItem.classList.toggle('active', isActive);
        }
    }

    logModeChange(modeName, isActive) {
        console.log(`🎯 ${modeName} mode ${isActive ? 'ENABLED' : 'DISABLED'}`);
        console.log('📊 Current modes:', this.userModes);
    }

    // Get current mode states for API calls
    getUserModeStates() {
        return {
            enable_web_search: this.userModes.webSearch,
            enable_deep_research: this.userModes.deepResearch,
            enable_study_learn: this.userModes.studyLearn
        };
    }

    // Check if any mode is active
    hasActiveModes() {
        return this.userModes.webSearch || this.userModes.deepResearch || this.userModes.studyLearn;
    }

    // Get active modes description
    getActiveModes() {
        const active = [];
        if (this.userModes.webSearch) active.push('Web Search');
        if (this.userModes.deepResearch) active.push('Deep Research');
        if (this.userModes.studyLearn) active.push('Study/Learn');
        return active;
    }

    updateActiveModeIndicator() {
        // Remove any existing indicator
        const indicator = document.querySelector('.active-modes-indicator');
        if (indicator) {
            indicator.remove();
        }
        
        // Don't create new indicators - just log to console for debugging
        const activeModes = this.getActiveModes();
        if (activeModes.length > 0) {
            console.log('🎯 Active modes:', activeModes.join(', '));
        } else {
            console.log('📴 All user modes disabled');
        }
    }

    // =============================================
    // new WELCOME MESSAGE INTEGRATION & Profile Information Display
    // =============================================


    // NEW: Initialize consolidated input controls
    initNewInputControls() {
        this.setupUploadDropdown();
        this.setupThinkingDropdown();
        this.setupDynamicSendButton();
        this.initVoiceRecording();
        this.setupModelDropdown();
    }

    setupUploadDropdown() {
    const { uploadOptionsBtn, uploadDropdown } = this.elements;
    
    if (!uploadOptionsBtn || !uploadDropdown) return;

    // Toggle dropdown on button click
    uploadOptionsBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        
        console.log('Upload button clicked'); // Debug
        
        // Close other dropdowns first
        this.closeAllDropdowns();
        
        // Toggle this dropdown
        const isVisible = uploadDropdown.classList.contains('show');
        if (isVisible) {
            uploadDropdown.classList.remove('show');
            console.log('Upload dropdown closed');
        } else {
            uploadDropdown.classList.add('show');
            console.log('Upload dropdown opened');
        }
    });

    // Handle dropdown options
    uploadDropdown.addEventListener('click', (e) => {
        e.stopPropagation();
        const option = e.target.closest('.upload-option');
        if (!option || option.hasAttribute('disabled')) return;

        const action = option.dataset.action;
        console.log('Upload option clicked:', action);
        
        switch(action) {
            case 'file-upload':
                this.elements.fileInput?.click();
                break;
            case 'screenshot':
                this.takeScreenshot();
                break;
            case 'google-drive':
                this.showNotification('Google Drive integration coming soon!', 'info');
                break;
        }
        
        // Close dropdown after action
        uploadDropdown.classList.remove('show');
    });

    // Close dropdown when clicking outside
    document.addEventListener('click', (e) => {
        if (!e.target.closest('.upload-dropdown-container')) {
            uploadDropdown.classList.remove('show');
        }
    });
    }

    setupThinkingDropdown() {
    const { thinkingModeBtn, thinkingDropdown } = this.elements;
    
    if (!thinkingModeBtn || !thinkingDropdown) return;

    // Toggle dropdown on button click
    thinkingModeBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        
        console.log('Thinking button clicked'); // Debug
        
        // Close other dropdowns first
        this.closeAllDropdowns();
        
        // Toggle this dropdown
        const isVisible = thinkingDropdown.classList.contains('show');
        if (isVisible) {
            thinkingDropdown.classList.remove('show');
            console.log('Thinking dropdown closed');
        } else {
            thinkingDropdown.classList.add('show');
            console.log('Thinking dropdown opened');
        }
    });

    // Handle mode selection
    thinkingDropdown.addEventListener('click', (e) => {
        e.stopPropagation();
        const option = e.target.closest('.thinking-option');
        if (!option) return;

        const mode = option.dataset.mode;
        console.log('Thinking mode selected:', mode);
        this.setThinkingMode(mode);
        
        // Close dropdown after selection
        thinkingDropdown.classList.remove('show');
    });

    // Close dropdown when clicking outside
    document.addEventListener('click', (e) => {
        if (!e.target.closest('.thinking-dropdown-container')) {
            thinkingDropdown.classList.remove('show');
        }
    });
    }

    // NEW: Setup dynamic send button with voice integration
    setupDynamicSendButton() {
    const { dynamicSendBtn, messageInput } = this.elements;
    
    if (!dynamicSendBtn || !messageInput) return;

    // Handle button click
    dynamicSendBtn.addEventListener('click', (e) => {
        e.preventDefault();
        
        console.log('Dynamic button clicked, processing:', this.isProcessing, 'recording:', this.isRecording);
        
        if (this.isProcessing) {
            // Stop generation
            this.stopGeneration();
        } else if (this.isRecording) {
            // Stop recording
            this.stopVoiceRecording();
        } else {
            const hasText = messageInput.value.trim().length > 0;
            const hasFiles = this.uploadedFiles.length > 0;
            
            if (hasText || hasFiles) {
                // Send message
                this.sendMessage();
            } else {
                // Start voice recording
                this.startVoiceRecording();
            }
        }
    });

    // Update button state on input change
    messageInput.addEventListener('input', () => {
        this.updateDynamicButtonState();
        this.autoResizeTextarea();
    });

    // Initial state
    this.updateDynamicButtonState();
    }

    // NEW: Initialize voice recording / commented code for backend endpoints for transcribe

    initVoiceRecording() {
    // Check for browser speech recognition support
    if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
        console.warn('Speech recognition not supported in this browser');
        return;
    }
    
    // Initialize speech recognition
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    this.recognition = new SpeechRecognition();
    
    // Configure recognition
    this.recognition.continuous = false;
    this.recognition.interimResults = false;
    this.recognition.lang = 'en-US';
    
    console.log('Browser speech recognition initialized');
    }

    // NEW: Close all dropdowns utility
    closeAllDropdowns() {
    const { uploadDropdown, thinkingDropdown, providerDropdown } = this.elements;
    const profileDropdown = document.getElementById('profile-dropdown');
    const profileToggleBtn = document.getElementById('profile-toggle-btn');
    
    // Close upload dropdown
    if (uploadDropdown) {
        uploadDropdown.classList.remove('show');
    }
    
    // Close thinking dropdown
    if (thinkingDropdown) {
        thinkingDropdown.classList.remove('show');
    }
    
    // Close provider dropdown
    if (providerDropdown) {
        providerDropdown.classList.remove('show');
    }
    
    // Close profile dropdown
    if (profileDropdown) {
        profileDropdown.classList.remove('show');
    }
    
    if (profileToggleBtn) {
        profileToggleBtn.classList.remove('active');
    }
    
    // Close session dropdowns too
    document.querySelectorAll('.session-dropdown-menu.visible').forEach(menu => {
        menu.classList.remove('visible');
    });

    const modelDropdown = document.getElementById('model-dropdown');
    const modelBtn = document.getElementById('model-selection-btn');

    if (modelDropdown) {
        modelDropdown.classList.remove('show');
    }
    
    if (modelBtn) {
        modelBtn.classList.remove('active');
    }
    
    console.log('All dropdowns closed'); // Debug


    }


    // NEW: Set thinking mode with UI updates
    setThinkingMode(mode) {
    this.currentThinkingMode = mode;
    
    // Update dropdown options
    const options = document.querySelectorAll('.thinking-option');
    options.forEach(option => {
        option.classList.remove('active');
        if (option.dataset.mode === mode) {
            option.classList.add('active');
        }
    });

    // Update button text and appearance
    const thinkingBtn = document.getElementById('thinking-mode-btn');
    const thinkingText = thinkingBtn?.querySelector('.thinking-mode-text');
    
    if (thinkingText) {
        if (mode === 'deep') {
            thinkingText.textContent = 'Think Deeper';
            thinkingBtn.setAttribute('data-mode', 'deep');
        } else {
            thinkingText.textContent = 'Quick response';
            thinkingBtn.setAttribute('data-mode', 'quick');
        }
    }

    // Save preference
    localStorage.setItem('thinkingMode', mode);
    
    // Show notification
    const modeText = mode === 'deep' ? 'Think Deeper' : 'Quick Response';
    this.showNotification(`Switched to ${modeText}`, 'success');
    
    console.log('Thinking mode set to:', mode);

    }


    // NEW: Update dynamic button state
    updateDynamicButtonState() {
    const { dynamicSendBtn, messageInput } = this.elements;
    if (!dynamicSendBtn || !messageInput) return;

    const hasText = messageInput.value.trim().length > 0;
    const hasFiles = this.uploadedFiles.length > 0;
    const hasContent = hasText || hasFiles;

    const voiceIcon = dynamicSendBtn.querySelector('.voice-icon');
    const sendIcon = dynamicSendBtn.querySelector('.send-icon');
    const stopIcon = dynamicSendBtn.querySelector('.stop-icon');

    // Remove all state classes
    dynamicSendBtn.classList.remove('has-text', 'is-processing', 'recording');

    if (this.isProcessing) {
        // Stop button state
        dynamicSendBtn.classList.add('is-processing');
        if (voiceIcon) voiceIcon.style.display = 'none';
        if (sendIcon) sendIcon.style.display = 'none';
        if (stopIcon) stopIcon.style.display = 'block';
        dynamicSendBtn.setAttribute('title', 'Stop generating');
    } else if (this.isRecording) {
        // Recording state
        dynamicSendBtn.classList.add('recording');
        if (voiceIcon) voiceIcon.style.display = 'block';
        if (sendIcon) sendIcon.style.display = 'none';
        if (stopIcon) stopIcon.style.display = 'none';
        dynamicSendBtn.setAttribute('title', 'Stop recording');
    } else if (hasContent) {
        // Send button state
        dynamicSendBtn.classList.add('has-text');
        if (voiceIcon) voiceIcon.style.display = 'none';
        if (sendIcon) sendIcon.style.display = 'block';
        if (stopIcon) stopIcon.style.display = 'none';
        dynamicSendBtn.setAttribute('title', 'Send message');
    } else {
        // Voice button state (default)
        if (voiceIcon) voiceIcon.style.display = 'block';
        if (sendIcon) sendIcon.style.display = 'none';
        if (stopIcon) stopIcon.style.display = 'none';
        dynamicSendBtn.setAttribute('title', 'Voice input');
    }

    dynamicSendBtn.disabled = false; // Always enabled for voice/stop functionality
    }
    // Replace startVoiceRecording function for real-time transcription
    async startVoiceRecording() {
    if (!this.recognition) {
        this.showNotification('Speech recognition not supported', 'error');
        return;
    }
    
    try {
        this.isRecording = true;
        this.updateDynamicButtonState();
        
        // Enable real-time results
        this.recognition.continuous = true;
        this.recognition.interimResults = true;
        this.recognition.lang = 'en-US';
        
        // Set up event handlers for real-time
        this.recognition.onstart = () => {
            console.log('Real-time speech recognition started');
            this.showNotification('Listening... Speak now (real-time)', 'info');
        };
        
        this.recognition.onresult = (event) => {
            let interimTranscript = '';
            let finalTranscript = '';
            
            // Process all results
            for (let i = event.resultIndex; i < event.results.length; i++) {
                const transcript = event.results[i][0].transcript;
                
                if (event.results[i].isFinal) {
                    finalTranscript += transcript + ' ';
                } else {
                    interimTranscript += transcript;
                }
            }
            
            // Get existing text in input
            const existingText = this.elements.messageInput.value;
            
            // Remove previous interim results and add new ones
            const baseText = existingText.replace(/\[.*?\]/g, '').trim();
            
            // Update input with final + interim text
            let displayText = baseText;
            if (finalTranscript) {
                displayText += (displayText ? ' ' : '') + finalTranscript;
            }
            if (interimTranscript) {
                displayText += (displayText ? ' ' : '') + '[' + interimTranscript + ']';
            }
            
            // Update input field in real-time
            this.elements.messageInput.value = displayText;
            this.autoResizeTextarea();
            this.updateDynamicButtonState();
            
            console.log('Real-time transcript:', displayText);
        };
        
        this.recognition.onerror = (event) => {
            console.error('Speech recognition error:', event.error);
            this.isRecording = false;
            this.updateDynamicButtonState();
            
            let errorMessage = 'Speech recognition failed';
            switch(event.error) {
                case 'no-speech':
                    errorMessage = 'No speech detected. Please try again.';
                    break;
                case 'audio-capture':
                    errorMessage = 'Microphone not accessible';
                    break;
                case 'not-allowed':
                    errorMessage = 'Microphone permission denied';
                    break;
                default:
                    errorMessage = `Speech recognition error: ${event.error}`;
            }
            this.showNotification(errorMessage, 'error');
        };
        
        this.recognition.onend = () => {
            console.log('Real-time speech recognition ended');
            
            // Clean up interim results (remove brackets)
            const finalText = this.elements.messageInput.value.replace(/\[.*?\]/g, '').trim();
            this.elements.messageInput.value = finalText;
            
            this.isRecording = false;
            this.updateDynamicButtonState();
            
            if (finalText) {
                this.showNotification('Speech recognition completed!', 'success');
                this.elements.messageInput.focus();
            }
        };
        
        // Start recognition
        this.recognition.start();
        
    } catch (error) {
        console.error('Error starting speech recognition:', error);
        this.showNotification('Failed to start speech recognition', 'error');
        this.isRecording = false;
        this.updateDynamicButtonState();
    }
    }
    
    stopVoiceRecording() {
    if (this.recognition && this.isRecording) {
        this.recognition.stop();
        this.isRecording = false;
        this.updateDynamicButtonState();
        this.showNotification('Speech recognition stopped', 'info');
        console.log('Speech recognition manually stopped');
    }
    }

    // NEW: Take screenshot functionality

    async takeScreenshot() {
    try {
        if (!navigator.mediaDevices || !navigator.mediaDevices.getDisplayMedia) {
            throw new Error('Screen capture not supported');
        }

        this.showNotification('Select screen to capture...', 'info');
        
        const stream = await navigator.mediaDevices.getDisplayMedia({
            video: { mediaSource: 'screen' }
        });

        const video = document.createElement('video');
        video.srcObject = stream;
        video.play();

        video.onloadedmetadata = () => {
            const canvas = document.createElement('canvas');
            canvas.width = video.videoWidth;
            canvas.height = video.videoHeight;
            
            const ctx = canvas.getContext('2d');
            ctx.drawImage(video, 0, 0);
            
            canvas.toBlob((blob) => {
                const file = new File([blob], `screenshot-${Date.now()}.png`, { type: 'image/png' });
                this.handleFileUpload([file]);
                this.showNotification('Screenshot captured!', 'success');
            }, 'image/png');

            // Stop stream
            stream.getTracks().forEach(track => track.stop());
        };

    } catch (error) {
        console.error('Screenshot error:', error);
        if (error.name === 'NotAllowedError') {
            this.showNotification('Screen capture permission denied', 'error');
        } else {
            this.showNotification('Screenshot failed - feature may not be supported', 'error');
        }
    }
    }

    // Enhanced sidebar toggle functionality (add to imporovement for sidebar collapse)
    initSidebarToggle() {
        const toggleBtn = document.getElementById('sidebar-toggle-btn');
        const leftContainer = document.querySelector('.left-container');
        
        if (!toggleBtn || !leftContainer) return;
        
        let lastToggle = 0;
        
        toggleBtn.addEventListener('click', (e) => {
            const now = Date.now();
            const isRapid = now - lastToggle < 350;
            lastToggle = now;
            
            // 1) Ripple effect
            const ripple = document.createElement('span');
            ripple.className = 'toggle-ripple';
            const d = Math.max(toggleBtn.clientWidth, toggleBtn.clientHeight);
            ripple.style.width = ripple.style.height = d + 'px';
            ripple.style.left = (e.offsetX - d/2) + 'px';
            ripple.style.top = (e.offsetY - d/2) + 'px';
            toggleBtn.appendChild(ripple);
            
            ripple.animate([
                { transform: 'scale(0)', opacity: 0.3 },
                { transform: 'scale(1)', opacity: 0 }
            ], { duration: 400, easing: 'ease-out' })
            .onfinish = () => ripple.remove();
            
            // 2) Inset shadow flash
            const iconBox = toggleBtn.querySelector('.toggle-icon-box');
            iconBox.classList.add('pressed');
            setTimeout(() => iconBox.classList.remove('pressed'), 200);
            
            // 3) Wiggle if toggled too fast
            if (isRapid) {
                toggleBtn.classList.add('wiggle');
                setTimeout(() => toggleBtn.classList.remove('wiggle'), 600);
            }
            
            // 4) Toggle sidebar state
            const isCollapsed = leftContainer.classList.toggle('collapsed');
            //document.body.classList.toggle('slideb', isCollapsed);
            
            // 5) Update accessibility
            toggleBtn.setAttribute('aria-expanded', String(!isCollapsed));
            toggleBtn.setAttribute('aria-label', isCollapsed ? 'Expand sidebar' : 'Collapse sidebar');
            
            // 6) Save state
            localStorage.setItem('sidebarCollapsed', isCollapsed);
            
            // 7) Smooth transition management
            const chatContainer = document.querySelector('.chat-container');
            if (chatContainer) {
                chatContainer.classList.add('transitioning');
                setTimeout(() => {
                    chatContainer.classList.remove('transitioning');
                }, 400);
            }
        });
        
        // Load saved state
        const isCollapsed = localStorage.getItem('sidebarCollapsed') === 'true';
        if (isCollapsed) {
            leftContainer.classList.add('collapsed');
            //document.body.classList.add('slideb');
            toggleBtn.setAttribute('aria-expanded', 'false');
            toggleBtn.setAttribute('aria-label', 'Expand sidebar');
        }

        // Load saved thinking mode
        const savedMode = localStorage.getItem('thinkingMode') || 'quick';
        this.setThinkingMode(savedMode);
    }

    // NEW: Initialize smooth transition behaviors
    initSmoothTransitions() {
        // Ensure initial state is properly set
        const chatContainer = document.querySelector('.chat-container');
        if (chatContainer && !chatContainer.classList.contains('chat-started')) {
            chatContainer.classList.remove('chat-started');
        }
        
        // Add transition end listeners for better UX
        chatContainer?.addEventListener('transitionend', (e) => {
            if (e.target === chatContainer && e.propertyName === 'transform') {
                chatContainer.classList.remove('transitioning');
            }
        });
        
        // Enhanced resize handler for responsive behavior
        window.addEventListener('resize', this.debounce(() => {
            this.handleResponsiveTransitions();
        }, 250));
    }

    // NEW: Handle responsive transitions
    handleResponsiveTransitions() {
        const chatContainer = document.querySelector('.chat-container');
        const isMobile = window.innerWidth <= 768;
        
        if (chatContainer && isMobile) {
            // Adjust mobile transitions
            chatContainer.style.setProperty('--mobile-transition', '0.3s');
        } else if (chatContainer) {
            chatContainer.style.removeProperty('--mobile-transition');
        }
    }

    // NEW: Debounce utility
    debounce(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    }

    // =============================================
    // EVENT LISTENERS
    // =============================================
    setupEventListeners() {
        this.setupFileInput();
        this.setupMessageInput();
        this.setupProviderDropdown();
        this.setupDragAndDrop();
        this.setupSidebarEvents();
        this.setupGlobalEvents();
        this.setupHeaderActions();
        // Add profile dropdown functionality
        this.setupProfileDropdown(); 
    }

    setupFileInput() {
        this.elements.fileInput?.addEventListener('change', (e) => {
            if (e.target.files.length > 0) {
                this.handleFileUpload(Array.from(e.target.files));
            }
        });
    }

    setupMessageInput() {
        const { messageInput } = this.elements;
        
        if (!messageInput) return;

        messageInput.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                this.sendMessage();
            }
        });

        messageInput.addEventListener('input', () => {
            this.autoResizeTextarea();
            this.updateDynamicButtonState();
        });

        messageInput.addEventListener('paste', (e) => {
            // Handle pasted files
            const items = e.clipboardData?.items;
            if (items) {
                const files = [];
                for (let i = 0; i < items.length; i++) {
                    if (items[i].kind === 'file') {
                        files.push(items[i].getAsFile());
                    }
                }
                if (files.length > 0) {
                    e.preventDefault();
                    this.handleFileUpload(files);
                }
            }
        });
    }

    setupProviderDropdown() {
        const { provider, providerDropdown } = this.elements;
        
        provider?.addEventListener('click', (e) => {
            e.stopPropagation();
            this.closeAllDropdowns();
            providerDropdown?.classList.toggle('show');
        });

        providerDropdown?.addEventListener('click', (e) => {
            e.stopPropagation();
            const option = e.target.closest('li');
            if (option) {
                this.selectProvider(option);
            }
        });

        document.addEventListener('click', () => {
            providerDropdown?.classList.remove('show');
        });
    }

    selectProvider(option) {
        const providerValue = option.dataset.provider;
        const providerLabel = option.querySelector('span')?.textContent;
        const providerIcon = option.querySelector('img')?.src;

        // Update display
        const providerTextDiv = document.querySelector('.provider-text');
        if (providerTextDiv && providerIcon) {
            providerTextDiv.innerHTML = `
                <img src="${providerIcon}" alt="${providerLabel}" class="provider-icon" />
                <span id="selected-provider">${providerLabel}</span>
            `;
        }

        window.selectedProvider = providerValue;
        this.elements.providerDropdown?.classList.remove('show');
        // this.showNotification(`Switched to ${providerLabel}`, 'success');
        this.loadModelsForProvider(providerValue);
        this.showNotification(`Switched to ${providerLabel}`, 'success');
    }

    setupDragAndDrop() {
        const { inputArea } = this.elements;
        
        ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
            inputArea?.addEventListener(eventName, (e) => {
                e.preventDefault();
                e.stopPropagation();
            });
        });
        
        ['dragenter', 'dragover'].forEach(eventName => {
            inputArea?.addEventListener(eventName, () => {
                inputArea.classList.add('drag-over');
            });
        });

        ['dragleave', 'drop'].forEach(eventName => {
            inputArea?.addEventListener(eventName, () => {
                inputArea.classList.remove('drag-over');
            });
        });
        
        inputArea?.addEventListener('drop', (e) => {
            const files = Array.from(e.dataTransfer.files);
            if (files.length > 0) {
                this.handleFileUpload(files);
            }
        });
    }

    setupSidebarEvents() {
    // New chat button
    const newChatButton = document.querySelector('.new-chat-item');
    newChatButton?.addEventListener('click', () => this.createNewChat());

    // Suggestion cards
    document.querySelectorAll('.AutoMsg_wrapper').forEach(card => {
        card.addEventListener('click', () => {
            const textElement = card.querySelector('.AutoMsg-txt');
            if (textElement && this.elements.messageInput) {
                const suggestionText = textElement.textContent.trim();
                this.elements.messageInput.value = suggestionText;
                this.elements.messageInput.focus();
                this.updateDynamicButtonState();
                
                // Auto-send after delay
                setTimeout(() => this.sendMessage(), 300);
            }
        });
    });

    // ENHANCED: Navigation items with visual feedback
    document.querySelectorAll('.SavedICon-wrapper[data-action]').forEach(item => {
        item.addEventListener('click', (e) => {
            e.preventDefault();
            const action = item.dataset.action;
            
            // Remove active from all navigation items (except home link)
            document.querySelectorAll('.SavedICon-wrapper').forEach(i => {
                if (!i.querySelector('a')) { // Don't affect home link
                    i.classList.remove('activeSidebar');
                }
            });
            
            // Add active class to clicked item
            item.classList.add('activeSidebar');
            
            // Handle different actions with enhanced functionality
            switch(action) {
                case 'starred':
                    console.log('Loading starred conversations...');
                    this.loadChatSessions('starred');
                    this.showNotification('Showing starred conversations', 'info');
                    break;
                case 'recent':
                    console.log('Loading recent conversations...');
                    this.loadChatSessions('recent');
                    this.showNotification('Showing recent conversations', 'info');
                    break;
                case 'chats':
                    console.log('Loading all conversations...');
                    this.loadChatSessions();
                    this.showNotification('Showing all conversations', 'info');
                    break;
                case 'projects':
                    this.showNot
                case 'projects':
                   this.showNotification('Projects feature coming soon!', 'info');
                   break;
               default:
                   console.log('Unknown action:', action);
           }
       });
   });
   }

   setupGlobalEvents() {
   // Global click handler for session menus
   document.addEventListener('click', (e) => {
       // Close session dropdowns
       if (!e.target.closest('.session-dropdown-menu') && !e.target.closest('.session-menu-btn')) {
           document.querySelectorAll('.session-dropdown-menu.visible').forEach(menu => {
               menu.classList.remove('visible');
           });
       }

       // ENHANCED: Session star action with immediate UI feedback
       if (e.target.closest('.star-btn')) {
           e.stopPropagation();
           const sessionId = e.target.closest('.star-btn').dataset.sessionId;
           const starBtn = e.target.closest('.star-btn');
           const starText = starBtn.querySelector('span');
           
           // Show immediate feedback
           starBtn.style.opacity = '0.6';
           starText.textContent = 'Updating...';
           
           this.toggleSessionStar(sessionId).then(() => {
               // Reset button state after update
               starBtn.style.opacity = '1';
           }).catch(() => {
               starBtn.style.opacity = '1';
               starText.textContent = 'Error';
               setTimeout(() => {
                   starText.textContent = 'Star';
               }, 2000);
           });
       }
       
       // Session rename action
       if (e.target.closest('.rename-btn')) {
           e.stopPropagation();
           const sessionId = e.target.closest('.rename-btn').dataset.sessionId;
           const sessionEl = e.target.closest('.chat-history-item');
           const titleEl = sessionEl?.querySelector('.session-title');
           this.showRenameModal(sessionId, titleEl?.textContent || 'Untitled Chat');
       }
       
       // Session delete action
       if (e.target.closest('.delete-btn')) {
           e.stopPropagation();
           const sessionId = e.target.closest('.delete-btn').dataset.sessionId;
           const sessionEl = e.target.closest('.chat-history-item');
           const titleEl = sessionEl?.querySelector('.session-title');
           this.confirmDeleteSession(sessionId, titleEl?.textContent || 'Untitled Chat');
       }
   });

   // Keyboard shortcuts
   document.addEventListener('keydown', (e) => {
       // Ctrl/Cmd + Enter to send
       if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
           e.preventDefault();
           this.sendMessage();
       }
       
       // Ctrl/Cmd + N for new chat
       if ((e.ctrlKey || e.metaKey) && e.key === 'n') {
           e.preventDefault();
           this.createNewChat();
       }
       
       // Escape to close menus and focus input
       if (e.key === 'Escape') {
           this.closeAllDropdowns();
           this.elements.messageInput?.focus();
       }

       // NEW: Ctrl/Cmd + S to toggle starred view
       if ((e.ctrlKey || e.metaKey) && e.key === 's') {
           e.preventDefault();
           const starredNav = document.querySelector('.SavedICon-wrapper[data-action="starred"]');
           if (starredNav) {
               starredNav.click();
           }
       }
   });
   }

   setupHeaderActions() {
       // Regenerate response
       this.elements.regenerateButton?.addEventListener('click', () => {
           this.regenerateLastResponse();
       });
   }

   // =============================================
   // CORE CHAT FUNCTIONALITY
   // =============================================
   async sendMessage() {
       if (this.isProcessing) return;
       
       const message = this.elements.messageInput?.value.trim() || '';
       if (!message && this.uploadedFiles.length === 0) return;
       
       // Clear input
       if (this.elements.messageInput) {
           this.elements.messageInput.value = '';
           this.autoResizeTextarea();
       }
       
       this.updateDynamicButtonState();
       
       try {
           await this.sendMessageToAPI(message);
       } catch (error) {
           console.error('Send message error:', error);
           this.showNotification('Failed to send message', 'error');
       }
   }

   async sendMessageToAPI(message) {
    if (this.isProcessing) return;
    
    this.isProcessing = true;
    this.updateDynamicButtonState();

    // ENHANCED: Trigger smooth transition to chat mode
    await this.triggerChatModeTransition();

    // Don't add user message here yet - wait for API response
    
    // Add uploaded file previews
    if (this.uploadedFiles.length > 0) {
        for (const file of this.uploadedFiles) {
            await this.displayFileInChat(file);
        }
    }
    
    // Show thinking indicator
    const thinkingIndicator = this.addThinkingIndicator();
    
    try {
        const response = await this.makeAPIRequest(message);

        // Add user message AFTER getting response with the correct ID
        if (message && response.user_message_id) {
            this.addMessage(message, 'user', false, null, { 
                user_message_id: response.user_message_id 
            });
        } else if (message) {
            // Fallback if no ID from API
            this.addMessage(message, 'user');
        }
                
        if (response.success && response.text) {
            // Remove thinking indicator
            if (thinkingIndicator) thinkingIndicator.remove();
            
            console.log('🔴 STEP 2 - Before streaming:', {
                textLength: response.text.length,
                textPreview: response.text.substring(0, 300) + '...'
            });
            
            // Format content for streaming
            let formattedContentToStream = response.text; // Fallback to original
            
            if (typeof formatLLMResponse !== 'undefined') {
                try {
                    formattedContentToStream = formatLLMResponse(response.text, {
                        enableMath: true,
                        enableTables: true,
                        enableCodeBlocks: true,
                        enableLists: true,
                        enableHeaders: true,
                        enableLinks: true,
                        sanitizeHtml: true
                    });
                    
                    console.log('📤 Formatted output length:', formattedContentToStream.length);
                    console.log('📊 Length ratio:', (formattedContentToStream.length / response.text.length * 100).toFixed(1) + '%');
                    
                    // Content analysis for debugging
                    const hasHooks = /__PROTECTED_\d+__/.test(formattedContentToStream);
                    const hasSVG = /<svg/.test(formattedContentToStream);
                    const hasCodeBlocks = /<pre/.test(formattedContentToStream);
                    const hasSpecialChars = /[\u0001\u0002]/.test(formattedContentToStream);
                    
                    console.log('🔍 Content analysis:', {
                        hasHooks,
                        hasSVG,
                        hasCodeBlocks,
                        hasSpecialChars,
                        codeBlockCount: (formattedContentToStream.match(/<div class="code-block-container">/g) || []).length,
                        svgCount: (formattedContentToStream.match(/<svg/g) || []).length
                    });
                    
                    console.log('✅ Content formatted for streaming:', {
                        originalLength: response.text.length,
                        formattedLength: formattedContentToStream.length,
                        expansionRatio: (formattedContentToStream.length / response.text.length * 100).toFixed(1) + '%'
                    });
                    
                } catch (formatError) {
                    console.error('❌ Formatting error:', formatError);
                    console.error('Error details:', formatError.message);
                    formattedContentToStream = response.text; // Use original as fallback
                }
            } else {
                console.warn('⚠️ formatLLMResponse not available, using raw text');
            }
                    
            // Add typing indicator for streaming
            const typingIndicator = this.addTypingIndicator();
            const streamingContainer = document.getElementById('streaming-content');
            
            if (!streamingContainer) {
                console.error('❌ Streaming container not found');
                if (typingIndicator) typingIndicator.remove();
                
                // Fallback: add message directly without streaming
                let responseWithMetadata = formattedContentToStream;
                if (response.model || response.provider) {
                    responseWithMetadata += `\n\n<div class="model-info-container">
                        <div class="model-info">
                            ${response.provider ? `<span class="provider-badge">${response.provider}</span>` : ''}
                            ${response.model ? `<span class="model-badge">${response.model}</span>` : ''}
                        </div>
                    </div>`;
                }
                this.addMessage(responseWithMetadata, 'assistant');
                
                // Handle session management
                if (response.session_id) {
                    this.currentChatSession = response.session_id;
                    this.updateChatTitle(response.session_name || 'New Chat');
                    this.loadChatSessions();
                }
                
                this.isProcessing = false;
                this.updateDynamicButtonState();
                return;
            }
            
            // Stream the formatted content
            console.log('🚀 Starting formatted content streaming...');
            this.streamFormattedContent(formattedContentToStream, streamingContainer, () => {
                console.log('🎯 Formatted streaming callback executed - handling completion...');
                
                // Get content from container (already formatted and streamed)
                let finalContent = '';
                try {
                    if (streamingContainer && streamingContainer.parentNode) {
                        finalContent = streamingContainer.innerHTML;
                        console.log('✅ Final content captured successfully, length:', finalContent.length);
                    } else {
                        console.error('❌ Container invalid when capturing final content');
                        finalContent = formattedContentToStream; // Fallback to formatted content
                    }
                } catch (error) {
                    console.error('❌ Error capturing final content:', error);
                    finalContent = formattedContentToStream; // Fallback to formatted content
                }
                
                // Create the final message wrapper
                const messageWrapper = document.createElement('div');
                messageWrapper.classList.add('message-wrapper', 'assistant-wrapper');
                
                // Start with hidden state for smooth animation
                messageWrapper.style.opacity = '0';
                messageWrapper.style.transform = 'translateY(20px)';
                
                const messageEl = document.createElement('div');
                messageEl.classList.add('message', 'message-assistant', 'assistant');
                
                const messageContent = document.createElement('div');
                messageContent.classList.add('message-content');
                
                // Use the final content directly (already formatted during streaming)
                messageContent.innerHTML = finalContent;
                
                // Build complete metadata and actions HTML
                let additionalHtml = '';

                // Add metadata if available
                if (response.model || response.provider) {
                    additionalHtml += `
                        <div class="model-info-container">
                            <div class="model-info">
                                ${response.provider ? `<span class="provider-badge">${response.provider}</span>` : ''}
                                ${response.model ? `<span class="model-badge">${response.model}</span>` : ''}
                            </div>
                        </div>`;
                }

                // Add response actions container
                const messageId = response.ai_message_id;
                additionalHtml += `
                    <div class="response-actions-container">
                        <button class="action-btn copy-message-btn" data-tooltip="Copy message" data-message-id="${messageId}">
                            <svg viewBox="0 0 24 24" fill="none">
                                <rect x="9" y="9" width="13" height="13" rx="2" ry="2" stroke="currentColor" stroke-width="2"/>
                                <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1" stroke="currentColor" stroke-width="2"/>
                            </svg>
                        </button>
                        
                        <button class="action-btn thumb-up-btn" data-tooltip="Good response" data-message-id="${messageId}">
                            <svg viewBox="0 0 24 24" fill="none">
                                <path d="M7 22V11M7 11L12 2L13 3L13.5 9H20.74C21.44 9 22 9.6 22 10.35V12.55C22 12.85 21.95 13.15 21.85 13.45L18.76 20.23C18.54 20.78 18.05 21.16 17.48 21.23L7 22M7 11H4C2.9 11 2 11.9 2 13V20C2 21.1 2.9 22 4 22H7" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                <circle cx="4.5" cy="18.5" r="0.5" fill="currentColor"/>
                            </svg>
                        </button>
                        
                        <button class="action-btn thumb-down-btn" data-tooltip="Bad response" data-message-id="${messageId}">
                            <svg viewBox="0 0 24 24" fill="none">
                                <path d="M17 2V13M17 13L12 22L11 21L10.5 15H3.26C2.56 15 2 14.4 2 13.65V11.45C2 11.15 2.05 10.85 2.15 10.55L5.24 3.77C5.46 3.22 5.95 2.84 6.52 2.77L17 2M17 13H20C21.1 13 22 12.1 22 11V4C22 2.9 21.1 2 20 2H17" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                <circle cx="19.5" cy="5.5" r="0.5" fill="currentColor"/>
                            </svg>
                        </button>
                        
                        <button class="action-btn regenerate-btn" data-tooltip="Regenerate response" data-message-id="${messageId}">
                          <svg viewBox="0 0 24 24" fill="none">
                                <path d="M4 12a8 8 0 0 1 12.5-6.6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                <path d="M20 12a8 8 0 0 1-12.5 6.6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                <polyline points="13 5.4 16.5 5.4 16.5 2" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                <polyline points="11 18.6 7.5 18.6 7.5 22" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                        </button>
                    </div>
                `;

                // Add all additional HTML at once
                messageContent.innerHTML += additionalHtml;

                // FIXED: Safe access to enhanced sources
                try {
                    const multiAgent = response.multi_agent || {};
                    const enhancedSources = response.enhanced_sources || [];
                    
                    if (enhancedSources && enhancedSources.length > 0) {
                        console.log('🔗 Adding enhanced sources to message:', enhancedSources.length);
                        
                        // Check if renderEnhancedSources method exists
                        if (typeof this.renderEnhancedSources === 'function') {
                            this.renderEnhancedSources(enhancedSources, messageContent);
                        } else {
                            console.warn('⚠️ renderEnhancedSources method not found, skipping sources rendering');
                            
                            // Fallback: Add simple sources list
                            const sourcesHtml = `
                                <div class="enhanced-sources">
                                    <h4>Sources:</h4>
                                    <ul>
                                        ${enhancedSources.map(source => `
                                            <li>
                                                <a href="${source.url || '#'}" target="_blank" rel="noopener">
                                                    ${source.title || 'Source'}
                                                </a>
                                                ${source.domain ? ` - ${source.domain}` : ''}
                                            </li>
                                        `).join('')}
                                    </ul>
                                </div>`;
                            messageContent.innerHTML += sourcesHtml;
                        }
                    } else {
                        console.log('ℹ️ No enhanced sources to display');
                    }
                } catch (sourcesError) {
                    console.error('❌ Error handling enhanced sources:', sourcesError);
                    // Continue without sources - don't break the entire flow
                }
                
                messageEl.appendChild(messageContent);
                messageWrapper.appendChild(messageEl);
                
                // Add to chat FIRST
                this.elements.messagesList.appendChild(messageWrapper);
                console.log('✅ Final message added to chat');
                
                // THEN remove typing indicators
                if (typingIndicator) {
                    typingIndicator.remove();
                    console.log('✅ Typing indicator removed');
                }
                
                const typingWrapper = document.getElementById('typing-indicator-wrapper');
                if (typingWrapper) {
                    typingWrapper.remove();
                    console.log('✅ Typing wrapper removed');
                }
                
                // Ensure copy buttons work on final message
                if (typeof this.attachCopyButtons === 'function') {
                    this.attachCopyButtons(messageContent);
                }
                
                // Apply syntax highlighting
                setTimeout(() => {
                    if (typeof this.highlightCodeBlocks === 'function') {
                        this.highlightCodeBlocks(messageContent);
                        console.log('🎨 Final message syntax highlighting applied');
                    }
                }, 100);

                // Trigger smooth animation
                requestAnimationFrame(() => {
                    messageWrapper.style.transition = 'all 0.4s cubic-bezier(0.4, 0, 0.2, 1)';
                    messageWrapper.style.opacity = '1';
                    messageWrapper.style.transform = 'translateY(0)';
                });
                
                this.scrollToBottom();
                
                // Reset processing state
                this.isProcessing = false;
                this.updateDynamicButtonState();
                
                console.log('🎉 Streaming completion handled successfully!');
            });
            
            // Handle session management
            if (response.session_id) {
                this.currentChatSession = response.session_id;
                this.updateChatTitle(response.session_name || 'New Chat');
                this.loadChatSessions(); // Refresh sidebar
            }
            
        } else {
            throw new Error(response.error || 'Unknown error occurred');
        }
        
    } catch (error) {
        // Clean up indicators
        if (thinkingIndicator) thinkingIndicator.remove();
        const typingIndicator = document.getElementById('typing-indicator-wrapper');
        if (typingIndicator) typingIndicator.remove();
        
        console.error('❌ API Error:', error);
        
        // ✅ Check for rate limit error
        if (error.status === 429 || error.limit_reached) {
            this.showPlanLimitWarning(error);
        } else {
            this.showNotification('Error communicating with server', 'error');
            this.addMessage('Sorry, there was an error processing your request. Please try again.', 'system');
        }
        
        this.isProcessing = false;
        this.updateDynamicButtonState();
    } finally {
        this.clearUploads();
    }
    }  
    
    // ADD this new helper function
    async regenerateWithNewUserMessage(aiMessageWrapper, userMessage) {
        const messageContent = aiMessageWrapper.querySelector('.message-content');
        
        // Disable action buttons
        const actionButtons = aiMessageWrapper.querySelectorAll('.action-btn');
        actionButtons.forEach(btn => {
            btn.disabled = true;
            btn.style.opacity = '0.5';
        });
        
        try {
            // Transform to typing state
            messageContent.innerHTML = '';
            aiMessageWrapper.querySelector('.message').classList.add('message-typing');
            
            // Create streaming container
            const streamingContainer = document.createElement('div');
            streamingContainer.id = 'streaming-content';
            messageContent.appendChild(streamingContainer);
            
            // Make API request with edited message
            const response = await this.makeAPIRequest(userMessage);
            
            if (response.success && response.text) {
                let formattedContent = response.text;
                
                if (typeof formatLLMResponse !== 'undefined') {
                    try {
                        formattedContent = formatLLMResponse(response.text, {
                            enableMath: true,
                            enableTables: true,
                            enableCodeBlocks: true,
                            enableLists: true,
                            enableHeaders: true,
                            enableLinks: true,
                            sanitizeHtml: true
                        });
                    } catch (formatError) {
                        console.error('Formatting error:', formatError);
                    }
                }
                
                // Stream content
                this.streamFormattedContent(formattedContent, streamingContainer, () => {
                    // Remove typing state
                    aiMessageWrapper.querySelector('.message').classList.remove('message-typing');
                    
                    // Get final content
                    const finalContent = streamingContainer.innerHTML;
                    
                    // Rebuild message
                    messageContent.innerHTML = finalContent;
                    
                    // Add model info
                    if (response.model || response.provider) {
                        const modelInfoHtml = `
                            <div class="model-info-container">
                                <div class="model-info">
                                    ${response.provider ? `<span class="provider-badge">${response.provider}</span>` : ''}
                                    ${response.model ? `<span class="model-badge">${response.model}</span>` : ''}
                                </div>
                            </div>`;
                        messageContent.innerHTML += modelInfoHtml;
                    }
                    
                    // Add action buttons
                    const newMessageId = response.ai_message_id || `msg-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
                    const actionsHtml = this.createResponseActionsContainer(newMessageId);
                    messageContent.innerHTML += actionsHtml;
                    
                    // Add sources if available
                    if (response.enhanced_sources && response.enhanced_sources.length > 0) {
                        this.renderEnhancedSources(response.enhanced_sources, messageContent);
                    }
                    
                    // Apply syntax highlighting
                    setTimeout(() => {
                        if (typeof this.highlightCodeBlocks === 'function') {
                            this.highlightCodeBlocks(messageContent);
                        }
                    }, 100);
                    
                    this.scrollToBottom();
                });
            }
        } catch (error) {
            console.error('Regeneration error:', error);
            this.showNotification('Failed to regenerate response', 'error');
            
            // Re-enable buttons
            actionButtons.forEach(btn => {
                btn.disabled = false;
                btn.style.opacity = '1';
            });
        }
    }

   // NEW: Enhanced smooth transition method
   async triggerChatModeTransition() {
       const chatContainer = document.querySelector('.chat-container');
       if (!chatContainer || chatContainer.classList.contains('chat-started')) {
           return; // Already in chat mode
       }
       
       // Add transitioning class to prevent interactions
       chatContainer.classList.add('transitioning');
       
       // Trigger the transition
       chatContainer.classList.add('chat-started');
       
       // Wait for the transition to complete
       return new Promise(resolve => {
           setTimeout(() => {
               chatContainer.classList.remove('transitioning');
               resolve();
           }, 1000); // Match the longest animation duration
       });
   }

    async makeAPIRequest(message) {
            // Get current provider/model/reasoning state from your existing properties
            const selectedProvider = this.currentProvider || 'groq';
            const selectedModel = this.currentModel || this.selectedModel;
            const useReasoning = this.useReasoning;
            const hasFiles = this.uploadedFiles && this.uploadedFiles.length > 0;

            // NEW: Get user mode states
            const modeStates = this.getUserModeStates();
            
            // Log active modes for debugging
            if (this.hasActiveModes()) {
                console.log('🎯 Active user modes:', this.getActiveModes().join(', '));
            }

            let requestBody;
            let requestHeaders = {};
            
            // ✅ DEBUG: Log current session state
            console.log('📤 Making API request:', {
                currentSession: this.currentChatSession,
                hasFiles: hasFiles,
                provider: selectedProvider,
                model: selectedModel,
                reasoning: useReasoning,
                userModes: modeStates // NEW: Log user modes
            });
            
            if (hasFiles) {
                const formData = new FormData();
                formData.append('message', message);
                formData.append('use_reasoning', useReasoning);
                formData.append('provider', selectedProvider);
                formData.append('has_upload', true);
                
                // NEW: Add user mode flags
                formData.append('enable_web_search', modeStates.enable_web_search);
                formData.append('enable_deep_research', modeStates.enable_deep_research);
                formData.append('enable_study_learn', modeStates.enable_study_learn);
                
                if (selectedModel) {
                    formData.append('user_selection_model', selectedModel);
                }
                
                // ✅ IMPROVED: Always send session_id, even if null
                formData.append('session_id', this.currentChatSession || '');
                
                this.uploadedFiles.forEach(file => {
                    formData.append('files', file);
                });
                
                requestBody = formData;
                
                // ✅ DEBUG: Log FormData contents
                console.log('📤 FormData contents:');
                for (let [key, value] of formData.entries()) {
                    console.log(`  ${key}:`, value);
                }
                
            } else {
                const payload = {
                    message: message,
                    use_reasoning: useReasoning,
                    provider: selectedProvider,
                    has_upload: false,
                    session_id: this.currentChatSession || null,  // ✅ IMPROVED: Always include session_id
                    
                    // NEW: Add user mode flags
                    enable_web_search: modeStates.enable_web_search,
                    enable_deep_research: modeStates.enable_deep_research,
                    enable_study_learn: modeStates.enable_study_learn
                };
                
                if (selectedModel) {
                    payload.user_selection_model = selectedModel;
                }
                
                requestBody = JSON.stringify(payload);
                requestHeaders['Content-Type'] = 'application/json';
                
                // ✅ DEBUG: Log JSON payload
                console.log('📤 JSON payload:', payload);
            }

            try {
                const response = await fetch('/api/chat/messages', {
                    method: 'POST',
                    headers: requestHeaders,
                    body: requestBody
                });

                // ✅ Handle 429 specifically
                if (response.status === 429) {
                    const errorData = await response.json();
                    throw { 
                        status: 429, 
                        limit_reached: true, 
                        error: errorData.error || 'Rate limit exceeded',
                        plan_status: errorData.plan_status,
                        upgrade_suggestion: errorData.upgrade_suggestion
                    };
                }

                if (!response.ok) {
                    throw new Error(`HTTP error! Status: ${response.status}`);
                }

                const result = await response.json();
                
                // ✅ IMPROVED: Update session state from response
                if (result.session_id && result.session_id !== this.currentChatSession) {
                    console.log('📥 Session updated:', this.currentChatSession, '->', result.session_id);
                    this.currentChatSession = result.session_id;
                    
                    // Update URL if needed
                    if (typeof this.updateUrlWithSession === 'function') {
                        this.updateUrlWithSession(result.session_id);
                    }
                }
                
                // ✅ DEBUG: Log response
                console.log('📥 API response:', {
                    success: result.success,
                    session_id: result.session_id,
                    provider: result.provider,
                    model: result.model,
                    userModesActive: result.user_modes_active // NEW: Log user modes from response
                });
                
                return result;
                
            } catch (error) {
                console.error('❌ API request failed:', error);
                throw error;
            }
    }

    // Add this right after makeAPIRequest function
    onProviderChange(newProvider) {
        console.log(`🔄 Provider changed from ${this.currentProvider} to ${newProvider}`);
        
        this.currentProvider = newProvider;
        this.selectedModel = null;
        this.currentModel = null;
        
        console.log(`📝 Model reset when switching to ${newProvider}`);
    }
     
    selectProvider(option) {
    const providerValue = option.dataset.provider;
    const providerLabel = option.querySelector('span')?.textContent;
    const providerIcon = option.querySelector('img')?.src;

    // Update display
    const providerTextDiv = document.querySelector('.provider-text');
    if (providerTextDiv && providerIcon) {
        providerTextDiv.innerHTML = `
            <img src="${providerIcon}" alt="${providerLabel}" class="provider-icon" />
            <span id="selected-provider">${providerLabel}</span>
        `;
    }

    // ✅ FIX: Reset model when provider changes
    this.currentProvider = providerValue;
    this.selectedModel = null; // ← Reset model
    this.currentModel = null;  // ← Reset current model
    
    // Update model button to show "Select Model" 
    const modelBtn = this.elements.modelBtn;
    const modelText = modelBtn?.querySelector('.model-selection-text');
    if (modelText) {
        modelText.textContent = 'Loading models...';
    }

    window.selectedProvider = providerValue;
    this.elements.providerDropdown?.classList.remove('show');
    
    // Load models and set default
    this.loadModelsForProvider(providerValue);
    this.showNotification(`Switched to ${providerLabel}`, 'success');
    }

    showPlanLimitWarning(errorResponse) {
    // ✅ Completely remove if exists
    const existingWarning = document.querySelector('.plan-limit-warning');
    if (existingWarning) {
        existingWarning.remove();
    }
    
    const inputAreaWrapper = document.querySelector('.input-areaWrapper');
    if (!inputAreaWrapper) return;
    
    // ✅ Create new div only when needed
    const warningDiv = document.createElement('div');
    warningDiv.className = 'plan-limit-warning';
    
    // Create icon
    const iconDiv = document.createElement('div');
    iconDiv.className = 'warning-icon';
    iconDiv.innerHTML = `
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z"/>
        </svg>
    `;
    
    // Create text wrapper
    const textDiv = document.createElement('div');
    textDiv.className = 'warning-text';
    
    let message = errorResponse.error || 'Rate limit exceeded';
    if (errorResponse.status === 429) {
        const subText = document.createElement('div');
        subText.className = 'warning-subtext';
        subText.textContent = 'Unlock premium model access and increase your daily limits';
        textDiv.innerHTML = `<div class="warning-main-text">${message}</div>`;
        textDiv.appendChild(subText);
    } else {
        textDiv.textContent = message;
    }
    
    // Create button wrapper
    const buttonWrapper = document.createElement('div');
    buttonWrapper.className = 'button-wrapper';
    
    const upgradeBtn = document.createElement('button');
    upgradeBtn.textContent = 'Upgrade to Pro';
    upgradeBtn.className = 'upgrade-btn';
    upgradeBtn.onclick = () => {
        window.open('/plans', '_blank');
    };
    
    // Create close button
    const closeBtn = document.createElement('button');
    closeBtn.className = 'close-btn';
    closeBtn.innerHTML = `
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <line x1="18" y1="6" x2="6" y2="18"></line>
            <line x1="6" y1="6" x2="18" y2="18"></line>
        </svg>
    `;
    closeBtn.onclick = () => {
        // Add fade out animation
        warningDiv.style.transition = 'opacity 0.3s, transform 0.3s';
        warningDiv.style.opacity = '0';
        warningDiv.style.transform = 'translateY(-10px)';
        
        // Remove from DOM after animation
        setTimeout(() => {
            if (warningDiv.parentNode) {
                warningDiv.remove();
            }
        }, 300);
    };
    
    // Assemble the warning
    warningDiv.appendChild(iconDiv);
    warningDiv.appendChild(textDiv);
    buttonWrapper.appendChild(upgradeBtn);
    buttonWrapper.appendChild(closeBtn);
    warningDiv.appendChild(buttonWrapper);
    
    // Insert into DOM
    inputAreaWrapper.insertBefore(warningDiv, inputAreaWrapper.firstChild);
    }
   
   // =============================================
   // FILE UPLOAD FUNCTIONALITY
   // =============================================

   
   async handleFileUpload(files) {
       const filesArray = Array.from(files);
       this.uploadedFiles = [];
       
       if (this.elements.imagePreview) {
           this.elements.imagePreview.innerHTML = '';
           this.elements.imagePreview.style.display = 'none';
       }
       
       this.showNotification('Validating files...', 'info');
       
       try {
           const formData = new FormData();
           filesArray.forEach(file => formData.append('files', file));
           
           const response = await fetch('/api/upload/validate', {
               method: 'POST',
               body: formData
           });
           
           const result = await response.json();
           
           // Handle error response
           if (result.error) {
               this.showNotification(result.error, 'error');
               return;
           }
           
           // Process validation results
           if (result.files && result.files.length > 0) {
               const validFiles = [];
               const invalidFiles = [];
               
               // Separate valid and invalid files
               result.files.forEach((fileResult, index) => {
                   if (fileResult.valid) {
                       validFiles.push({
                           file: filesArray[index],
                           filename: fileResult.filename,
                           type: fileResult.type
                       });
                   } else {
                       invalidFiles.push({
                           filename: fileResult.filename,
                           reason: 'Unsupported file type'
                       });
                   }
               });
               
               // Show errors for invalid files
               invalidFiles.forEach(file => {
                   this.showNotification(`Invalid: ${file.filename} - ${file.reason}`, 'error');
               });
               
               // Process valid files
               if (validFiles.length > 0) {
                   this.uploadedFiles = validFiles.map(f => f.file);
                   
                   this.displayFilePreview();
                   this.updateDynamicButtonState();
                   
                   const fileInfo = validFiles.map(f => 
                       `${f.filename} (${this.formatFileSize(f.file.size)})`
                   ).join(', ');
                   
                   this.showNotification(
                       `${validFiles.length} file(s) ready: ${fileInfo}`,
                       'success'
                   );
               }
           } else {
               this.showNotification('No files to process', 'error');
           }
           
       } catch (error) {
           console.error('File validation error:', error);
           this.showNotification('Error validating files', 'error');
       }
       
       // Clear file input
       if (this.elements.fileInput) {
           this.elements.fileInput.value = '';
       }
   }

   displayFilePreview() {
       if (!this.elements.imagePreview) return;
       
       this.uploadedFiles.forEach(file => {
           const reader = new FileReader();
           reader.onload = (e) => {
               const previewItem = document.createElement('div');
               previewItem.className = 'image-preview-item';
               
               const isImage = file.type.startsWith('image/');
               previewItem.innerHTML = isImage ? `
                   <img src="${e.target.result}" alt="Preview">
                   <button class="remove-image" onclick="chatApp.removeFilePreview(this, '${file.name}')">×</button>
               ` : `
                   <div class="document-preview">
                       <i class="fas fa-file-alt"></i>
                       <span class="document-name">${file.name}</span>
                   </div>
                   <button class="remove-image" onclick="chatApp.removeFilePreview(this, '${file.name}')">×</button>
               `;
               
               this.elements.imagePreview.appendChild(previewItem);
               this.elements.imagePreview.style.display = 'flex';
           };
           
           if (file.type.startsWith('image/')) {
               reader.readAsDataURL(file);
           } else {
               reader.onload({ target: { result: null } });
           }
       });
   }

   async displayFileInChat(file) {
       return new Promise((resolve) => {
           const reader = new FileReader();
           reader.onload = (e) => {
               const isImage = file.type.startsWith('image/');
               const content = isImage 
                   ? `<img src="${e.target.result}" alt="${file.name}" style="max-width: 300px; border-radius: 8px;">`
                   : `<div class="file-attachment"><i class="fas fa-file"></i> ${file.name}</div>`;
               this.addMessage(content, 'user');
               resolve();
           };
           reader.readAsDataURL(file);
       });
   }

   removeFilePreview(button, fileName) {
       this.uploadedFiles = this.uploadedFiles.filter(file => file.name !== fileName);
       button.parentElement.remove();
       
       if (this.uploadedFiles.length === 0) {
           if (this.elements.imagePreview) {
               this.elements.imagePreview.style.display = 'none';
           }
       }
       
       this.updateDynamicButtonState();
       this.showNotification('File removed', 'success');
   }

   clearUploads() {
       this.uploadedFiles = [];
       if (this.elements.imagePreview) {
           this.elements.imagePreview.innerHTML = '';
           this.elements.imagePreview.style.display = 'none';
       }
   }

   formatFileSize(bytes) {
       if (bytes === 0) return '0 Bytes';
       const k = 1024;
       const sizes = ['Bytes', 'KB', 'MB', 'GB'];
       const i = Math.floor(Math.log(bytes) / Math.log(k));
       return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
   }

   // =============================================
   // SESSION MANAGEMENT
   // =============================================
   async loadChatSessions(filter = null) {
       try {
           const response = await fetch('/api/chat/sessions');
           const data = await response.json();
           
           if (data.success && data.sessions) {
               this.renderChatSessions(data.sessions, filter);
               this.updateLocalChatHistory(data.sessions);
           }
       } catch (error) {
           console.error('Error loading chat sessions:', error);
       }
   }

   renderChatSessions(sessions, filter) {
  const chatHistoryElement = this.elements.chatHistory;
  if (!chatHistoryElement) return;

  chatHistoryElement.innerHTML = '';

  if (sessions.length === 0) {
    chatHistoryElement.innerHTML = '<div class="empty-state">No conversations yet</div>';
    // Remove scroll style since no sessions
    chatHistoryElement.style.maxHeight = '';
    chatHistoryElement.style.overflowY = '';
    return;
  }

  // Filter sessions as you have
  let filteredSessions = sessions;
  if (filter === 'starred') {
    filteredSessions = sessions.filter(s => s.is_starred);
  } else if (filter === 'recent') {
    filteredSessions = sessions
      .sort((a, b) => new Date(b.updated_at) - new Date(a.updated_at))
      .slice(0, 10);
  }

  const starredSessions = filteredSessions.filter(s => s.is_starred);
  const regularSessions = filteredSessions.filter(s => !s.is_starred);

  if (starredSessions.length > 0) {
    const starredHeader = document.createElement('div');
    starredHeader.className = 'session-header';
    starredHeader.innerHTML = `
      <div class="session-group-header">
        <i class="fas fa-star"></i>
        <span>Starred</span>
      </div>
    `;
    chatHistoryElement.appendChild(starredHeader);

    starredSessions.forEach(session => {
      chatHistoryElement.appendChild(this.createSessionElement(session, true));
    });
  }

  if (regularSessions.length > 0) {
    regularSessions.forEach(session => {
      chatHistoryElement.appendChild(this.createSessionElement(session, false));
    });
  }

  // Total sessions count
  const totalSessions = starredSessions.length + regularSessions.length;

  if (totalSessions > 3) {
    chatHistoryElement.style.maxHeight = '200px'; // same height as CSS or adjust
    chatHistoryElement.style.overflowY = 'auto'; // enable scroll
  } else {
    chatHistoryElement.style.maxHeight = '';
    chatHistoryElement.style.overflowY = '';
  }
}

   createSessionElement(session, isStarred) {
       const sessionEl = document.createElement('div');
       sessionEl.className = 'chat-history-item';
       sessionEl.dataset.sessionId = session.id;
       
       if (this.currentChatSession === session.id) {
           sessionEl.classList.add('active');
       }
       
       sessionEl.innerHTML = `
           <div class="session-main-content">
               <i class="fas fa-comment session-icon"></i>
               <span class="session-title" title="${session.name || 'Untitled Chat'}">${session.name || 'Untitled Chat'}</span>
               ${isStarred ? '<i class="fas fa-star star-indicator"></i>' : ''}
           </div>
           <div class="session-actions">
               <button class="session-menu-btn" title="More options">
                   <i class="fas fa-ellipsis-v"></i>
               </button>
               <div class="session-dropdown-menu">
                   <button class="session-action-btn star-btn" data-session-id="${session.id}">
                       <i class="fas fa-star"></i>
                       <span>${session.is_starred ? 'Unstar' : 'Star'}</span>
                   </button>
                   <button class="session-action-btn rename-btn" data-session-id="${session.id}">
                       <i class="fas fa-edit"></i>
                       <span>Rename</span>
                   </button>
                   <button class="session-action-btn delete-btn" data-session-id="${session.id}">
                       <i class="fas fa-trash"></i>
                       <span>Delete</span>
                   </button>
               </div>
           </div>
       `;
        
       // Add click handler for loading session
       sessionEl.querySelector('.session-main-content').addEventListener('click', () => {
           this.loadChatSession(session.id);
       });
       
       // Add menu toggle handler
       const menuBtn = sessionEl.querySelector('.session-menu-btn');
       const dropdown = sessionEl.querySelector('.session-dropdown-menu');
       
       menuBtn.addEventListener('click', (e) => {
           e.stopPropagation();
           
           // Close other dropdowns
           document.querySelectorAll('.session-dropdown-menu.visible').forEach(menu => {
               if (menu !== dropdown) menu.classList.remove('visible');
           });
           
           dropdown.classList.toggle('visible');
       });
       
       return sessionEl;
   }

   async loadChatSession(sessionId) {
    try {
        // First, get session info
        const response = await fetch(`/api/chat/sessions/${sessionId}`);
        const data = await response.json();
        
        if (data.success) {
            this.currentChatSession = sessionId;
            this.updateChatTitle(data.session.name || 'Chat');
            
            // Clear messages
            this.clearMessages();
            
            // Now get the actual message history
            const historyResponse = await fetch(`/api/chat/sessions/${sessionId}/history`);
            const historyData = await historyResponse.json();
            
            // Load messages with metadata
            if (historyData.success && historyData.messages && historyData.messages.length > 0) {
                // ENHANCED: Trigger smooth transition to chat mode
                await this.triggerChatModeTransition();
                
                // Add messages with metadata for containers
                historyData.messages.forEach((msg, index) => {
                    setTimeout(() => {
                        const metadata = {
                            ai_message_id: msg.id,
                            provider: msg.provider,
                            model: msg.model,
                            enhanced_sources: msg.enhanced_sources || []
                        };
                        this.addMessage(msg.content, msg.role, false, msg.timestamp, metadata);
                    }, index * 100);
                });
                
                this.scrollToBottom();
            } else {
                this.triggerInitialModeTransition();
            }
            
            this.highlightActiveSession(sessionId);
            this.updateUrlWithSession(sessionId);
            
            this.showNotification('Chat session loaded', 'success');
        }
    } catch (error) {
        console.error('Error loading chat session:', error);
        this.showNotification('Error loading chat session', 'error');
    }
    }

   // NEW: Add messages with staggered animation
   addMessagesWithStagger(messages) {
       messages.forEach((msg, index) => {
           setTimeout(() => {
               this.addMessage(msg.content, msg.role, false, msg.timestamp);
           }, index * 100); // 100ms delay between messages
       });
   }
    
   async toggleSessionStar(sessionId) {
   try {
       const response = await fetch(`/api/chat/sessions/${sessionId}/star`, {
           method: 'POST',
           headers: { 'Content-Type': 'application/json' }
       });
       
       const data = await response.json();
       if (data.success) {
           // Get current view to determine if we need to filter
           const activeNav = document.querySelector('.SavedICon-wrapper.activeSidebar[data-action]');
           const currentFilter = activeNav ? activeNav.dataset.action : null;
           
           // Reload sessions with current filter
           this.loadChatSessions(currentFilter);
           
           // Show appropriate notification
           const action = data.is_starred ? 'starred' : 'unstarred';
           const emoji = data.is_starred ? '⭐' : '🔄';
           this.showNotification(
               `${emoji} Conversation ${action}`, 
               'success'
           );
           
           // If we're viewing starred sessions and session was unstarred, 
           // provide helpful feedback
           if (currentFilter === 'starred' && !data.is_starred) {
               setTimeout(() => {
                   this.showNotification('Session moved to main conversations', 'info');
               }, 1000);
           }
       } else {
           throw new Error(data.error || 'Failed to update star status');
       }
   } catch (error) {
       console.error('Error toggling star:', error);
       this.showNotification('❌ Error updating star status', 'error');
   }
   }
  
   async deleteSession(sessionId) {
       try {
           const response = await fetch(`/api/chat/sessions/${sessionId}`, {
               method: 'DELETE'
           });
           
           const data = await response.json();
           if (data.success) {
               this.loadChatSessions();
               
               if (this.currentChatSession === sessionId) {
                   this.currentChatSession = null;
                   this.triggerInitialModeTransition();
                   this.updateUrlWithSession(null);
               }
               
               this.showNotification('Chat session deleted', 'success');
           }
       } catch (error) {
           console.error('Error deleting session:', error);
           this.showNotification('Error deleting session', 'error');
       }
   }

   async renameSession(sessionId, newName) {
       try {
           const response = await fetch(`/api/chat/sessions/${sessionId}/rename`, {
               method: 'POST',
               headers: { 'Content-Type': 'application/json' },
               body: JSON.stringify({ name: newName })
           });
           
           const data = await response.json();
           if (data.success) {
               this.loadChatSessions();
               
               if (this.currentChatSession === sessionId) {
                   this.updateChatTitle(newName);
               }
               
               this.showNotification('Chat session renamed', 'success');
           }
       } catch (error) {
           console.error('Error renaming session:', error);
           this.showNotification('Error renaming session', 'error');
       }
   }

   // =============================================
   // UI MANAGEMENT
   // =============================================

   showPastedContentInModal(rawText) {
    // Check if content is already HTML formatted
    const hasHtmlTags = /<[^>]+>/.test(rawText);
    const hasCodeBlocks = /```[\s\S]*?```/.test(rawText);
    const hasMarkdown = /^#{1,6}\s|^\*\s|^\d+\.\s|^\>|^\|.*\|/m.test(rawText);
    
    // If already formatted HTML, return as-is (but sanitize dangerous tags)
    if (hasHtmlTags && !hasCodeBlocks && !hasMarkdown) {
        return rawText
            .replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '')
            .replace(/<iframe\b[^<]*(?:(?!<\/iframe>)<[^<]*)*<\/iframe>/gi, '');
    }
    
    // Clean up extra whitespace while preserving structure
    let cleaned = rawText
        .replace(/\r\n/g, '\n')           // Normalize line endings
        .replace(/\n{3,}/g, '\n\n')       // Max 2 consecutive newlines
        .replace(/^\s+$/gm, '')           // Remove whitespace-only lines
        .replace(/[ \t]+$/gm, '')         // Remove trailing spaces
        .trim();                          // Remove leading/trailing whitespace
    
    // If it contains markdown or code, use formatLLMResponse
    if (hasCodeBlocks || hasMarkdown) {
        if (typeof formatLLMResponse !== 'undefined') {
            return formatLLMResponse(cleaned, {
                enableMath: true,
                enableTables: true,
                enableCodeBlocks: true,
                enableLists: true,
                enableHeaders: true,
                enableLinks: true,
                sanitizeHtml: true
            });
        }
    }
    
    // For plain text, preserve structure but sanitize
    const sanitized = cleaned
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');
    
    // Convert newlines to paragraphs for better readability
    const paragraphs = sanitized
        .split(/\n\n+/)
        .filter(p => p.trim())
        .map(p => `<p>${p.replace(/\n/g, '<br>')}</p>`)
        .join('');
    
    return `<div class="user-message-content">${paragraphs}</div>`;
    }
    
    // =============================================
    // MESSAGE COPY BUTTONS (new ) 
    // =============================================
    
    async copyMessageContent(messageElement, button) {
        try {
            const textContent = messageElement.textContent || messageElement.innerText;
            await navigator.clipboard.writeText(textContent);
            
            // Visual feedback
            const originalText = button.innerHTML;
            button.innerHTML = '<i class="fas fa-check"></i> Copied!';
            button.classList.add('copied');
            
            setTimeout(() => {
                button.innerHTML = originalText;
                button.classList.remove('copied');
            }, 2000);
            
            this.showNotification('Message copied to clipboard', 'success');
        } catch (err) {
            console.error('Failed to copy message:', err);
            this.showNotification('Failed to copy message', 'error');
            this.fallbackCopyMessage(messageElement);
        }
    }

    fallbackCopyMessage(messageElement) {
        const textArea = document.createElement('textarea');
        textArea.value = messageElement.textContent || messageElement.innerText;
        textArea.style.position = 'fixed';
        textArea.style.opacity = '0';
        document.body.appendChild(textArea);
        textArea.select();
        
        try {
            document.execCommand('copy');
            this.showNotification('Message copied to clipboard', 'success');
        } catch (err) {
            this.showNotification('Failed to copy message', 'error');
        }
        
        document.body.removeChild(textArea);
    }

    handleMessageReaction(button) {
        const reaction = button.dataset.reaction;
        const messageId = button.closest('.message').dataset.messageId;
        
        // Toggle reaction
        button.classList.toggle('active');
        
        // Update reaction count (implement as needed)
        this.showNotification(`Reacted with ${reaction}`, 'info');
    }


    addMessage(content, role, isLoading = false, timestamp = null, metadata = null) {
    const chatMessagesElement = this.elements.messagesList;
    if (!chatMessagesElement) return null;
    
    if (role === 'user' || role === 'assistant') {
        this.hideWelcomeScreen();
    }
    
    const messageWrapper = document.createElement('div');
    messageWrapper.classList.add('message-wrapper', `${role}-wrapper`);
    
    // Start with hidden state for animation
    messageWrapper.style.opacity = '0';
    messageWrapper.style.transform = 'translateY(20px)';
    
    const messageEl = document.createElement('div');
    messageEl.classList.add('message', `message-${role}`, role);
    
    const messageContent = document.createElement('div');
    messageContent.classList.add('message-content');
    
    if (role === 'user') {
        try {
            const formattedContent = this.showPastedContentInModal(content);
            messageContent.innerHTML = formattedContent;
        } catch (error) {
            console.error('Error formatting user message:', error);
            
            const escaped = content
                .replace(/&/g, '&amp;')
                .replace(/</g, '&lt;')
                .replace(/>/g, '&gt;')
                .replace(/"/g, '&quot;')
                .replace(/'/g, '&#39;');
            
            const paragraphs = escaped
                .split(/\n\n+/)
                .filter(p => p.trim())
                .map(p => `<p>${p.replace(/\n/g, '<br>')}</p>`)
                .join('');
            
            messageContent.innerHTML = `<div class="user-message-content">${paragraphs || escaped}</div>`;
        }
        
        // ADD USER ACTIONS CONTAINER
        const userMessageId = metadata?.user_message_id || `msg-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
        const userActionsHtml = this.createUserActionsContainer(userMessageId);
        messageContent.innerHTML += userActionsHtml;
        
    } else if (role === 'assistant') {
        const isAlreadyFormatted = content.includes('class="code-block-container"') || 
                                content.includes('class="formatted-');
        
        if (isAlreadyFormatted) {
            messageContent.innerHTML = content;
        } else {
            try {
                if (typeof formatLLMResponse !== 'undefined') {
                    messageContent.innerHTML = formatLLMResponse(content, {
                        enableMath: true,
                        enableTables: true,
                        enableCodeBlocks: true,
                        enableLists: true,
                        enableHeaders: true,
                        enableLinks: true,
                        sanitizeHtml: true
                    });
                } else if (typeof marked !== 'undefined') {
                    messageContent.innerHTML = marked.parse(content);
                } else {
                    messageContent.innerHTML = content;
                }
            } catch (error) {
                console.error('Error formatting assistant message:', error);
                messageContent.textContent = content;
            }
        }
        
        // ALWAYS ADD CONTAINERS FOR ASSISTANT MESSAGES
        const messageId = metadata?.ai_message_id || `msg-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
        
        // Add model info if available
        if (metadata?.provider || metadata?.model) {
            const modelInfoHtml = `
                <div class="model-info-container">
                    <div class="model-info">
                        ${metadata.provider ? `<span class="provider-badge">${metadata.provider}</span>` : ''}
                        ${metadata.model ? `<span class="model-badge">${metadata.model}</span>` : ''}
                    </div>
                </div>`;
            messageContent.innerHTML += modelInfoHtml;
        }
        
        // Add response actions container
        const actionsHtml = this.createResponseActionsContainer(messageId);
        messageContent.innerHTML += actionsHtml;
        
        // Add enhanced sources if available
        if (metadata?.enhanced_sources && metadata.enhanced_sources.length > 0) {
            this.renderEnhancedSources(metadata.enhanced_sources, messageContent);
        }
        
        // Apply syntax highlighting
        setTimeout(() => {
            if (typeof hljs !== 'undefined') {
                messageContent.querySelectorAll('pre code').forEach((block) => {
                    if (!block.classList.contains('hljs')) {
                        try {
                            hljs.highlightElement(block);
                        } catch (e) {
                            console.error('Syntax highlighting error:', e);
                        }
                    }
                });
            }
        }, 0);
    } else {
        messageContent.textContent = content;
    }
    
    if (isLoading) {
        messageEl.classList.add('message-loading');
    }
    
    messageEl.appendChild(messageContent);
    messageWrapper.appendChild(messageEl);
    chatMessagesElement.appendChild(messageWrapper);
    
    // Trigger smooth animation
    requestAnimationFrame(() => {
        messageWrapper.style.transition = 'all 0.4s cubic-bezier(0.4, 0, 0.2, 1)';
        messageWrapper.style.opacity = '1';
        messageWrapper.style.transform = 'translateY(0)';
    });
    
    this.scrollToBottom();
    return messageEl;
    }

    // Create user actions container (for edit functionality)
    
  createUserActionsContainer(messageId = null) {
    // Ensure the ID is in the correct format
    const id = messageId || `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    
    return `
        <div class="user-actions-container">
            <button class="action-btn edit-btn" data-tooltip="Edit message" data-message-id="${id}" onclick="chatApp.editUserMessage(this)">
                <svg viewBox="0 0 24 24" fill="none">
                    <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                    <path d="m18.5 2.5 3 3L12 15l-4 1 1-4 9.5-9.5z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
            </button>
        </div>
    `;
}

    // Create response actions container (for AI messages)
    createResponseActionsContainer(messageId = null) {
        const id = messageId || `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
        
        return `
            <div class="response-actions-container">
                <button class="action-btn copy-message-btn" data-tooltip="Copy message" data-message-id="${id}">
                    <svg viewBox="0 0 24 24" fill="none">
                        <rect x="9" y="9" width="13" height="13" rx="2" ry="2" stroke="currentColor" stroke-width="2"/>
                        <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1" stroke="currentColor" stroke-width="2"/>
                    </svg>
                </button>
                
                <button class="action-btn thumb-up-btn" data-tooltip="Good response" data-message-id="${id}">
                     <svg viewBox="0 0 24 24" fill="none">
                        <path d="M7 22V11M7 11L12 2L13 3L13.5 9H20.74C21.44 9 22 9.6 22 10.35V12.55C22 12.85 21.95 13.15 21.85 13.45L18.76 20.23C18.54 20.78 18.05 21.16 17.48 21.23L7 22M7 11H4C2.9 11 2 11.9 2 13V20C2 21.1 2.9 22 4 22H7" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        <circle cx="4.5" cy="18.5" r="0.5" fill="currentColor"/>
                    </svg>
                </button>
                
                <button class="action-btn thumb-down-btn" data-tooltip="Bad response" data-message-id="${id}">
                     <svg viewBox="0 0 24 24" fill="none">
                        <path d="M17 2V13M17 13L12 22L11 21L10.5 15H3.26C2.56 15 2 14.4 2 13.65V11.45C2 11.15 2.05 10.85 2.15 10.55L5.24 3.77C5.46 3.22 5.95 2.84 6.52 2.77L17 2M17 13H20C21.1 13 22 12.1 22 11V4C22 2.9 21.1 2 20 2H17" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        <circle cx="19.5" cy="5.5" r="0.5" fill="currentColor"/>
                    </svg>
                </button>
                
                <button class="action-btn regenerate-btn" data-tooltip="Regenerate response" data-message-id="${id}">
                    <svg viewBox="0 0 24 24" fill="none">
                        <path d="M4 12a8 8 0 0 1 12.5-6.6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        <path d="M20 12a8 8 0 0 1-12.5 6.6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        <polyline points="13 5.4 16.5 5.4 16.5 2" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        <polyline points="11 18.6 7.5 18.6 7.5 22" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                    </svg>
                </button>
            </div>
        `;
    }



addThinkingIndicator(isRegeneration = false) {
    const chatMessagesElement = this.elements.messagesList;
    if (!chatMessagesElement) return null;
    
    this.hideWelcomeScreen();
    
    const messageWrapper = document.createElement('div');
    messageWrapper.classList.add('message-wrapper', 'assistant-wrapper');
    messageWrapper.id = 'thinking-indicator-wrapper';
    
    const thinkingEl = document.createElement('div');
    thinkingEl.classList.add('ai-thinking-indicator');
    
    // Enhanced thinking text based on context
    let thinkingText = 'Thinking ';
    if (isRegeneration) {
        thinkingText = 'Regenerating response ';
    } else if (this.currentThinkingMode === 'deep') {
        thinkingText = 'Thinking deeply ';
    }
    
    // Add regeneration-specific styling if needed
    if (isRegeneration) {
        thinkingEl.classList.add('regenerating');
    }
    
    thinkingEl.innerHTML = `
        <div class="thinking-container">
            <span class="thinking-text">${thinkingText}</span>
            <span class="pulse-dots">
                <span class="pulse"></span>
                <span class="pulse"></span>
                <span class="pulse"></span>
                <span class="pulse"></span>
            </span>
        </div>
    `;
    
    messageWrapper.appendChild(thinkingEl);
    chatMessagesElement.appendChild(messageWrapper);
    
    this.scrollToBottom();
    return messageWrapper;
}

addTypingIndicator() {
    // Remove thinking indicator first
    const thinkingIndicator = document.getElementById('thinking-indicator-wrapper');
    if (thinkingIndicator) {
        thinkingIndicator.remove();
    }
    
    const chatMessagesElement = this.elements.messagesList;
    if (!chatMessagesElement) return null;
    
    const messageWrapper = document.createElement('div');
    messageWrapper.classList.add('message-wrapper', 'assistant-wrapper');
    messageWrapper.id = 'typing-indicator-wrapper';
    
    const typingEl = document.createElement('div');
    typingEl.classList.add('message', 'message-assistant', 'message-typing');
    
    typingEl.innerHTML = `<div class="message-content" id="streaming-content"></div>`;
    
    messageWrapper.appendChild(typingEl);
    chatMessagesElement.appendChild(messageWrapper);
    
    this.scrollToBottom();
    return messageWrapper;
}
   
// =============================================
// ENHANCED STREAMING FUNCTIONALITY
// =============================================

    // FIXED: Enhanced streaming with proper error handling and debugging
    streamTextCharByChar(text, container, callback) {
        console.log('📝 Starting stream, total length:', text.length);
        console.log('🔴 STEP 3 - streamTextCharByChar received:', {
            textLength: text.length,
            fullText: text.substring(0, 100) + '...', // Show first 100 chars only
            isString: typeof text === 'string',
            containerExists: !!container,
            callbackExists: !!callback
        });

        // Validation checks
        if (!text || typeof text !== 'string') {
            console.error('❌ Invalid text provided to streaming function');
            if (callback) callback();
            return;
        }
        
        if (!container) {
            console.error('❌ No container provided to streaming function');
            if (callback) callback();
            return;
        }

        // Reset stop flag
        this.stopStreaming = false;
        
        // Pre-process to find special blocks
        const specialBlocks = this.findSpecialBlocks(text);
        console.log('🔍 Found special blocks:', specialBlocks.length);
        
        let charIndex = 0;
        let displayedContent = '';
        let isInSpecialBlock = false;
        let lastProgressLog = 0;
        
        const addNextChar = () => {
            // Enhanced progress logging every 50 characters
            if (charIndex - lastProgressLog >= 50) {
                console.log(`🔄 Streaming progress: ${charIndex}/${text.length} (${Math.round(charIndex/text.length*100)}%) - stopFlag: ${this.stopStreaming}`);
                lastProgressLog = charIndex;
            }
            
            // Check if streaming was stopped or container is invalid
            if (this.stopStreaming) {
                console.log('⛔ STREAMING MANUALLY STOPPED at character:', charIndex);
                if (callback && !this.stopStreaming) callback();
                return;
            }
            
            if (!container || !container.parentNode) {
                console.error('⛔ CONTAINER REMOVED during streaming at character:', charIndex, {
                    containerExists: !!container,
                    parentExists: !!container?.parentNode,
                    progress: `${charIndex}/${text.length}`
                });
                if (callback) callback();
                return;
            }
            
            // Check if we've completed streaming
            if (charIndex >= text.length) {
                console.log('✅ STREAMING COMPLETED successfully!', {
                    totalChars: charIndex,
                    expectedLength: text.length,
                    finalContentLength: displayedContent.length
                });
                
                // Final update with complete content
                try {
                    this.updateStreamingContent(container, displayedContent);
                    console.log('✅ Final content update successful');
                } catch (error) {
                    console.error('❌ Final content update failed:', error);
                }
                
                // Clear streaming timeout
                this.streamingTimeout = null;
                
                // Execute callback
                if (callback && !this.stopStreaming) {
                    console.log('🎯 Executing completion callback');
                    callback();
                }
                return;
            }
            
            try {
                // Check if we're entering a special block
                const currentBlock = specialBlocks.find(block => 
                    charIndex === block.start && !block.displayed
                );
                
                if (currentBlock) {
                    console.log(`📦 Displaying special block: ${currentBlock.type} at position ${charIndex}`);
                    // Display the entire special block at once
                    displayedContent += currentBlock.content;
                    currentBlock.displayed = true;
                    charIndex = currentBlock.end;
                    isInSpecialBlock = true;
                    
                    // Update container with formatted content
                    this.updateStreamingContent(container, displayedContent);
                    
                    // Small delay after displaying block
                    this.streamingTimeout = setTimeout(addNextChar, 50);
                } else {
                    // Check if we're inside any special block
                    const insideBlock = specialBlocks.some(block => 
                        charIndex >= block.start && charIndex < block.end
                    );
                    
                    if (!insideBlock) {
                        // Stream character by character for regular text
                        displayedContent += text[charIndex];
                        charIndex++;
                        
                        // Update only if not in a special block
                        if (!isInSpecialBlock) {
                            this.updateStreamingContent(container, displayedContent);
                        }
                        
                        // Variable delay for more natural feel
                        const delay = this.getStreamingDelay(text[charIndex - 1]);
                        this.streamingTimeout = setTimeout(addNextChar, delay);
                    } else {
                        // Skip characters that are part of a special block
                        charIndex++;
                        this.streamingTimeout = setTimeout(addNextChar, 0);
                    }
                    
                    isInSpecialBlock = false;
                }
            } catch (error) {
                console.error('❌ Error during character streaming at position', charIndex, ':', error);
                
                // Attempt to continue with simple character addition
                if (charIndex < text.length) {
                    displayedContent += text[charIndex];
                    charIndex++;
                    
                    // Simple text update as fallback
                    if (container) {
                        container.textContent = displayedContent;
                    }
                    
                    this.streamingTimeout = setTimeout(addNextChar, 10);
                } else {
                    // Complete with error
                    console.log('🔚 Streaming completed with errors');
                    if (callback) callback();
                }
            }
        };
        
        // Start the streaming process
        console.log('🚀 Starting character-by-character streaming...');
        addNextChar();
    }
    
    // STEP 2: Add this NEW function after streamTextCharByChar in chat.js
    streamFormattedContent(formattedHtml, container, callback) {
        console.log('📝 Starting formatted content streaming:', formattedHtml.length, 'characters');
        
        // Reset stop flag
        this.stopStreaming = false;
        
        // Find special blocks in the formatted HTML
        const specialBlocks = this.findSpecialBlocks(formattedHtml);
        
        let charIndex = 0;
        let displayedContent = '';
        let lastProgressLog = 0;
        
        const addNextChar = () => {
            // Progress logging
            if (charIndex - lastProgressLog >= 100) {
                // console.log(`🔄 Formatted streaming progress: ${charIndex}/${formattedHtml.length} (${Math.round(charIndex/formattedHtml.length*100)}%)`);
                lastProgressLog = charIndex;
            }
            
            if (this.stopStreaming || !container || !container.parentNode) {
                console.log('⛔ Formatted streaming stopped at:', charIndex);
                
                if (callback) callback();
                return;
            }
            
            if (charIndex >= formattedHtml.length) {
                console.log('✅ Formatted streaming completed:', charIndex, 'characters');

                // IMPORTANT: Apply syntax highlighting after streaming completes
                setTimeout(() => {
                    this.highlightCodeBlocks(container);
                    console.log('🎨 Syntax highlighting applied after streaming');
                }, 100);

                if (callback) callback();
                return;
            }
            
            try {
                // Check for special blocks
                const currentBlock = specialBlocks.find(block => 
                    charIndex === block.start && !block.displayed
                );
                
                if (currentBlock) {
                    console.log(`📦 Displaying ${currentBlock.type} block instantly at position ${charIndex}`);
                    displayedContent += currentBlock.content;
                    currentBlock.displayed = true;
                    charIndex = currentBlock.end;
                    
                    // Update container directly (already formatted)
                    container.innerHTML = displayedContent;
                    this.scrollToBottom();
                    
                    // Brief pause after displaying block
                    this.streamingTimeout = setTimeout(addNextChar, 50);
                } else {
                    // Check if we're inside a block
                    const insideBlock = specialBlocks.some(block => 
                        charIndex >= block.start && charIndex < block.end
                    );
                    
                    if (!insideBlock) {
                        // Stream character by character
                        displayedContent += formattedHtml[charIndex];
                        charIndex++;
                        
                        // Update container directly (no re-formatting needed)
                        container.innerHTML = displayedContent;
                        this.scrollToBottom();
                        
                        // Variable delay for natural feel
                        const delay = this.getStreamingDelay(formattedHtml[charIndex - 1]);
                        this.streamingTimeout = setTimeout(addNextChar, delay);
                    } else {
                        // Skip characters inside blocks
                        charIndex++;
                        this.streamingTimeout = setTimeout(addNextChar, 0);
                    }
                }
            } catch (error) {
                console.error('❌ Error in formatted streaming at position', charIndex, ':', error);
                
                // Simple fallback
                if (charIndex < formattedHtml.length) {
                    displayedContent += formattedHtml[charIndex];
                    charIndex++;
                    container.innerHTML = displayedContent;
                    this.streamingTimeout = setTimeout(addNextChar, 10);
                } else {
                    if (callback) callback();
                }
            }
        };
        
        addNextChar();
    }

    // NEW: Find code blocks, tables, and other special content
    
    findSpecialBlocks(text) {
        console.log('🔍 STEP 4 - findSpecialBlocks input length:', text.length);
        const blocks = [];
        
        // 1. Find SVG elements (complete SVG tags)
        const svgRegex = /<svg[^>]*>[\s\S]*?<\/svg>/gi;
        let match;
        while ((match = svgRegex.exec(text)) !== null) {
            blocks.push({
                type: 'svg',
                start: match.index,
                end: match.index + match[0].length,
                content: match[0],
                displayed: false
            });
            console.log(`📦 Found SVG block: ${match.index}-${match.index + match[0].length}`);
        }
        
        // 2. Find complete code blocks (pre + code)
        const codeBlockRegex = /<div class="code-block-container">[\s\S]*?<\/div>/gi;
        while ((match = codeBlockRegex.exec(text)) !== null) {
            blocks.push({
                type: 'code-block',
                start: match.index,
                end: match.index + match[0].length,
                content: match[0],
                displayed: false
            });
            console.log(`📦 Found code block: ${match.index}-${match.index + match[0].length}`);
        }
        
        // 3. Find table structures
        const tableRegex = /<div class="table-wrapper">[\s\S]*?<\/div>/gi;
        while ((match = tableRegex.exec(text)) !== null) {
            blocks.push({
                type: 'table',
                start: match.index,
                end: match.index + match[0].length,
                content: match[0],
                displayed: false
            });
            console.log(`📦 Found table: ${match.index}-${match.index + match[0].length}`);
        }
        
        // 4. Find math blocks
        const mathBlockRegex = /<div class="math-display">[\s\S]*?<\/div>/gi;
        while ((match = mathBlockRegex.exec(text)) !== null) {
            blocks.push({
                type: 'math',
                start: match.index,
                end: match.index + match[0].length,
                content: match[0],
                displayed: false
            });
            console.log(`📦 Found math block: ${match.index}-${match.index + match[0].length}`);
        }
        
        // 5. Find any other complex HTML structures
        const complexElementRegex = /<(?:blockquote|ul|ol|dl)[^>]*>[\s\S]*?<\/(?:blockquote|ul|ol|dl)>/gi;
        while ((match = complexElementRegex.exec(text)) !== null) {
            blocks.push({
                type: 'complex-html',
                start: match.index,
                end: match.index + match[0].length,
                content: match[0],
                displayed: false
            });
            console.log(`📦 Found complex HTML: ${match.index}-${match.index + match[0].length}`);
        }
        
        console.log(`🔍 STEP 5 - findSpecialBlocks found ${blocks.length} blocks:`, 
            blocks.map(b => `${b.type}(${b.start}-${b.end})`));
        
        // Sort blocks by start position and remove overlaps
        const sortedBlocks = blocks.sort((a, b) => a.start - b.start);
        const cleanBlocks = [];
        
        for (let i = 0; i < sortedBlocks.length; i++) {
            const current = sortedBlocks[i];
            const hasOverlap = cleanBlocks.some(existing => 
                (current.start >= existing.start && current.start < existing.end) ||
                (current.end > existing.start && current.end <= existing.end)
            );
            
            if (!hasOverlap) {
                cleanBlocks.push(current);
            } else {
                console.log(`⚠️ Skipping overlapping block: ${current.type}(${current.start}-${current.end})`);
            }
        }
        
        console.log(`✅ Final clean blocks: ${cleanBlocks.length}`);
        return cleanBlocks;
    }
    
    // FIXED: Enhanced updateStreamingContent with better error handling
    updateStreamingContent(container, content) {
        if (!container) {
            console.error('❌ updateStreamingContent: No container provided');
            return;
        }
        
        if (!container.parentNode) {
            console.error('❌ updateStreamingContent: Container has been removed from DOM');
            return;
        }
        
        try {
            // Format the content
            if (typeof formatLLMResponse !== 'undefined') {
                const formatted = formatLLMResponse(content, {
                    enableMath: true,
                    enableTables: true,
                    enableCodeBlocks: true,
                    enableLists: true,
                    enableHeaders: true,
                    enableLinks: true,
                    sanitizeHtml: true
                });
                container.innerHTML = formatted;
            } else if (typeof marked !== 'undefined') {
                container.innerHTML = marked.parse(content);
            } else {
                // Fallback: escape HTML and preserve line breaks
                const escaped = content
                    .replace(/&/g, '&amp;')
                    .replace(/</g, '&lt;')
                    .replace(/>/g, '&gt;')
                    .replace(/\n/g, '<br>');
                container.innerHTML = escaped;
            }
            
            // Apply syntax highlighting to code blocks
            this.highlightCodeBlocks(container);
            
            // Ensure copy buttons are attached
            this.attachCopyButtons(container);
            
            // Scroll to bottom
            this.scrollToBottom();
            
        } catch (error) {
            console.error('❌ Error in updateStreamingContent:', error);
            console.error('Content that caused error (first 200 chars):', content.substring(0, 200));
            console.error('Stack trace:', error.stack);
            
            // Enhanced fallback - preserve line breaks and basic formatting
            try {
                const safeContent = content
                    .replace(/&/g, '&amp;')
                    .replace(/</g, '&lt;')
                    .replace(/>/g, '&gt;')
                    .replace(/\n\n/g, '</p><p>')
                    .replace(/\n/g, '<br>');
                
                container.innerHTML = `<p>${safeContent}</p>`;
            } catch (fallbackError) {
                console.error('❌ Even fallback failed:', fallbackError);
                // Last resort - plain text
                container.textContent = content;
            }
        }
    }

    // Enhanced syntax highlighting function
    highlightCodeBlocks(container) {
        if (typeof hljs === 'undefined') {
            console.warn('⚠️ Highlight.js not loaded - syntax highlighting disabled');
            return;
        }
        
        try {
            // Find all code blocks
            const codeBlocks = container.querySelectorAll('pre code');
            console.log(`🎨 Highlighting ${codeBlocks.length} code blocks`);
            
            codeBlocks.forEach((block, index) => {
                // Skip if already highlighted
                if (block.classList.contains('hljs')) {
                    console.log(`⏭️ Block ${index} already highlighted`);
                    return;
                }
                
                // Remove any existing hljs classes
                block.className = block.className.replace(/hljs[\w-]*/g, '').trim();
                
                try {
                    // Apply highlighting
                    hljs.highlightElement(block);
                    console.log(`✅ Block ${index} highlighted successfully`);
                    
                    // Verify highlighting was applied
                    if (block.classList.contains('hljs')) {
                        console.log(`✅ hljs class added to block ${index}`);
                    } else {
                        console.warn(`⚠️ hljs class NOT added to block ${index}`);
                    }
                    
                } catch (highlightError) {
                    console.error(`❌ Error highlighting block ${index}:`, highlightError);
                    
                    // Fallback: add basic styling
                    block.classList.add('hljs');
                    block.style.background = '#282c34';
                    block.style.color = '#abb2bf';
                }
            });
            
        } catch (error) {
            console.error('❌ Error in highlightCodeBlocks:', error);
        }
    }

    // NEW: Attach copy buttons to code blocks
    attachCopyButtons(container) {
        container.querySelectorAll('.code-block-container').forEach((blockContainer) => {
            const copyBtn = blockContainer.querySelector('.copy-button');
            const codeBlock = blockContainer.querySelector('pre');
            
            if (copyBtn && codeBlock && !copyBtn.hasAttribute('data-initialized')) {
                const blockId = codeBlock.id;
                copyBtn.setAttribute('data-code-id', blockId);
                copyBtn.setAttribute('data-initialized', 'true');
                
                // Attach click handler directly
                copyBtn.onclick = function() {
                    window.copyCodeBlock(blockId);
                };
            }
        });
    }

    // NEW: Get variable streaming delay for natural feel
    getStreamingDelay(char) {
        // Longer delays for punctuation
        if ('.!?'.includes(char)) return 50;
        if (',;:'.includes(char)) return 30;
        if (' '.includes(char)) return 10;
        
        // Very short delay for regular characters
        return Math.floor(Math.random() * 5) + 2;
    }

   // ENHANCED: createNewChat with smooth transitions
   createNewChat() {
       this.currentChatSession = null;
       this.currentChatId = null;
       
       this.clearUploads();
       
       if (this.elements.messageInput) {
           this.elements.messageInput.value = '';
           this.autoResizeTextarea();
       }
       
       this.updateDynamicButtonState();
       
       // ENHANCED: Smooth transition back to initial state
       this.triggerInitialModeTransition();
       
       if (this.elements.messageInput) {
           // Delay focus to allow transition to complete
           setTimeout(() => {
               this.elements.messageInput.focus();
           }, 600);
       }
       
       this.updateUrlWithSession(null);
       this.updateChatTitle('New Conversation');
       
       // Clear active sessions
       document.querySelectorAll('.chat-history-item').forEach(el => {
           el.classList.remove('active');
       });
       
       this.showNotification('New chat started', 'success');
   }

   // NEW: Smooth transition back to initial state
   triggerInitialModeTransition() {
       const chatContainer = document.querySelector('.chat-container');
       if (!chatContainer) return;
       
       // Add transitioning class
       chatContainer.classList.add('transitioning');
       
       // Clear messages first
       this.clearMessages();
       
       // Remove chat-started class to trigger reverse transition
       chatContainer.classList.remove('chat-started');
       
       // Show welcome content
       this.showEmptyState();
       
       // Remove transitioning class after animation
       setTimeout(() => {
           chatContainer.classList.remove('transitioning');
       }, 800);
   }

   // ENHANCED: showEmptyState with smooth transitions
   showEmptyState() {
       this.clearMessages();
       
       // Show welcome content with smooth transition
       const chatMessagesElement = this.elements.messagesList;
       if (chatMessagesElement) {
           const chatMsgContainer = chatMessagesElement.querySelector('.chat-msg-container');
           const introMessage = chatMessagesElement.querySelector('.intro-message');
           
           if (chatMsgContainer) {
               chatMsgContainer.style.display = 'block';
               chatMsgContainer.style.opacity = '0';
               
               // Fade in with delay
               setTimeout(() => {
                   chatMsgContainer.style.transition = 'opacity 0.5s ease';
                   chatMsgContainer.style.opacity = '1';
               }, 300);
           }
           
           if (introMessage) {
               introMessage.style.display = 'block';
               introMessage.style.opacity = '0';
               
               // Fade in with delay
               setTimeout(() => {
                   introMessage.style.transition = 'opacity 0.6s ease';
                   introMessage.style.opacity = '1';
               }, 400);
           }
       }
       
       this.currentChatSession = null;
       this.currentChatId = null;
   }

   // ENHANCED: hideWelcomeScreen with smooth transitions
   hideWelcomeScreen() {
       const chatMessagesElement = this.elements.messagesList;
       if (!chatMessagesElement) return;
       
       const chatMsgContainer = chatMessagesElement.querySelector('.chat-msg-container');
       const introMessage = chatMessagesElement.querySelector('.intro-message');
       
       // Smooth fade out
       if (chatMsgContainer) {
           chatMsgContainer.style.transition = 'opacity 0.3s ease';
           chatMsgContainer.style.opacity = '0';
           setTimeout(() => {
               chatMsgContainer.style.display = 'none';
           }, 300);
       }
       
       if (introMessage) {
           introMessage.style.transition = 'opacity 0.4s ease';
           introMessage.style.opacity = '0';
           setTimeout(() => {
               introMessage.style.display = 'none';
           }, 400);
       }
   }

   clearMessages() {
       const chatMessagesElement = this.elements.messagesList;
       if (!chatMessagesElement) return;
       
       const messageWrappers = chatMessagesElement.querySelectorAll('.message-wrapper, .message');
       messageWrappers.forEach(wrapper => wrapper.remove());
   }

   // Enhanced smooth scrolling
   scrollToBottom() {
       const chatMessagesElement = this.elements.messagesList;
       if (chatMessagesElement) {
           chatMessagesElement.scrollTo({
               top: chatMessagesElement.scrollHeight,
               behavior: 'smooth'
           });
       }
   }

   updateChatTitle(title) {
       if (this.elements.currentChatTitle) {
           this.elements.currentChatTitle.textContent = title;
       }
   }

   highlightActiveSession(sessionId) {
       document.querySelectorAll('.chat-history-item').forEach(el => {
           el.classList.remove('active');
           if (el.dataset.sessionId === sessionId) {
               el.classList.add('active');
           }
       });
   }

   updateUrlWithSession(sessionId) {
       const url = sessionId ? `/chat?session_id=${sessionId}` : '/chat';
       window.history.replaceState({}, document.title, url);
   }

   autoResizeTextarea() {
       const textarea = this.elements.messageInput;
       if (!textarea) return;
       
       textarea.style.height = 'auto';
       textarea.style.height = Math.min(textarea.scrollHeight, 200) + 'px';
   }

   // =============================================
   // UTILITY FUNCTIONS
   // =============================================
   showNotification(message, type = 'info') {
       // Remove existing notifications
       const existingNotifications = document.querySelectorAll('.notification');
       existingNotifications.forEach(notification => notification.remove());
       
       const notification = document.createElement('div');
       notification.className = `notification ${type}`;
       notification.textContent = message;
       
       document.body.appendChild(notification);
       
       // Auto-hide after 4 seconds
       setTimeout(() => {
           notification.classList.add('fade-out');
           setTimeout(() => notification.remove(), 300);
       }, 4000);
   }
   
/* ────────────────────────────────────────────────────────────
   Show the modal that lets the user rename a chat session
   ──────────────────────────────────────────────────────────── */
    showRenameModal(sessionId, currentName) {
    /* Grab nodes by the IDs that exist in your markup */
    const modal     = document.getElementById('rename-modal');
    const input     = document.getElementById('rename-input');
    const okBtn     = document.getElementById('rename-ok');       // <-- OK
    const cancelBtn = document.getElementById('rename-cancel');   // <-- Cancel

    /* Safety check: if any node is missing, bail out early */
    if (!modal || !input || !okBtn || !cancelBtn) {
        console.warn('Rename modal markup missing – listeners not attached');
        return;
    }

    /* ── Open the modal ──────────────────────────────────────── */
    input.value  = currentName ?? '';
    modal.hidden = false;
    input.focus();
    input.select();

    /* ── Helper functions (arrow syntax keeps correct `this`) ── */
    const close = () => {
        modal.hidden = true;
        okBtn    .removeEventListener('click', onOk);
        cancelBtn.removeEventListener('click', onCancel);
    };

    const onOk = () => {
        const newName = input.value.trim();
        if (newName && newName !== currentName) {
        /* Same class instance, so this.renameSession exists */
        this.renameSession(sessionId, newName);
        }
        close();
    };

    const onCancel = () => close();

    /* Attach listeners */
    okBtn    .addEventListener('click', onOk);
    cancelBtn.addEventListener('click', onCancel);
    }
    
/* wrapper resembling your original code */
    confirmDeleteSession(sessionId, sessionName){
    this.showDeleteModal(sessionId, sessionName);
    }
    showDeleteModal(sessionId, sessionName) {
        const modal  = document.getElementById('delete-modal');
        const msgBox = document.getElementById('delete-msg');
        const okBtn  = document.getElementById('delete-confirm');
        const cancel = document.getElementById('delete-cancel');

        msgBox.textContent =
        `Are you sure you want to delete "${sessionName}"?`;

        modal.hidden = false;

        /* keep arrow functions so that `this` stays the instance */
        const close = () => {
        modal.hidden = true;
        okBtn .removeEventListener('click', onOk);
        cancel.removeEventListener('click', close);
        };

        const onOk = () => {
        /* call the instance’s own deleteSession() */
        this.deleteSession(sessionId);
        close();
        };

        okBtn .addEventListener('click', onOk);
        cancel.addEventListener('click', close);
    }

    /* your existing delete method */
    deleteSession(id) {
        /* … */
    }

   updateLocalChatHistory(sessions) {
       sessions.forEach(session => {
           let localChatId = null;
           
           // Find existing local chat
           for (let chatId in this.chatHistory) {
               if (this.chatHistory[chatId].session_id === session.id) {
                   localChatId = chatId;
                   break;
               }
           }
           
           if (!localChatId) {
               localChatId = "chat_" + Date.now() + "_" + Math.random().toString(36).substr(2, 5);
               
               this.chatHistory[localChatId] = {
                   id: localChatId,
                   session_id: session.id,
                   title: session.name || "Untitled Chat",
                   timestamp: new Date(session.created_at).getTime() || Date.now(),
                   messages: []
               };
           } else {
               this.chatHistory[localChatId].title = session.name || "Untitled Chat";
               this.chatHistory[localChatId].timestamp = new Date(session.created_at).getTime() || this.chatHistory[localChatId].timestamp;
           }
       });
       
       this.saveChatHistory();
   }

   saveChatHistory() {
       localStorage.setItem("chatHistory", JSON.stringify(this.chatHistory));
   }

//    handling message form Ask assitance button
   handleUrlParams() {
    const urlParams = new URLSearchParams(window.location.search);
    const sessionIdParam = urlParams.get('session_id');
    const messageParam = urlParams.get('message');
    
    if (sessionIdParam) {
        this.loadChatSession(sessionIdParam);
    } else {
        this.triggerInitialModeTransition();
    }
    
    // Handle message parameter from URL
    if (messageParam) {
        // Decode the message
        const decodedMessage = decodeURIComponent(messageParam);
        
        // Wait for DOM to be ready and chat to initialize
        setTimeout(() => {
            // Put message in input field
            if (this.elements.messageInput) {
                this.elements.messageInput.value = decodedMessage;
                this.autoResizeTextarea();
                this.updateDynamicButtonState();
                
                // Auto-send the message after a brief delay
                setTimeout(() => {
                    this.sendMessage();
                    
                    // Clean up URL without reloading page
                    const cleanUrl = window.location.pathname + 
                        (sessionIdParam ? `?session_id=${sessionIdParam}` : '');
                    window.history.replaceState({}, document.title, cleanUrl);
                }, 500);
            }
        }, 1000); // Give time for chat interface to fully load
    }
    }

   // =============================================
   // ADDITIONAL FEATURES
   // =============================================
   async regenerateLastResponse() {
       // Find last user message
       const messages = this.elements.messagesList?.querySelectorAll('.message-wrapper');
       let lastUserMessage = null;
       
       for (let i = messages.length - 1; i >= 0; i--) {
           if (messages[i].classList.contains('user-wrapper')) {
               lastUserMessage = messages[i].querySelector('.message-content')?.textContent;
               break;
           }
       }
       
       if (lastUserMessage) {
           // Remove last assistant message
           const lastAssistantMsg = this.elements.messagesList?.querySelector('.assistant-wrapper:last-child');
           if (lastAssistantMsg) {
               lastAssistantMsg.remove();
           }
           
           // Resend the message
           await this.sendMessageToAPI(lastUserMessage);
       } else {
           this.showNotification('No message to regenerate', 'info');
       }
   }
   
   stopGeneration() {
       this.isProcessing = false;
       this.showNotification('Generation stopped', 'info');
       
       // Set stop flag first
       this.stopStreaming = true;
       
       // Clear timeout if exists
       if (this.streamingTimeout) {
           clearTimeout(this.streamingTimeout);
           this.streamingTimeout = null;
       }
       
       // Get current streaming content and save it
       const streamingContainer = document.getElementById('streaming-content');
       if (streamingContainer && streamingContainer.textContent.trim()) {
           // Remove typing indicator
           const typingIndicator = document.getElementById('typing-indicator-wrapper');
           if (typingIndicator) typingIndicator.remove();
           
           // Add the partial content as a message
           this.addMessage(streamingContainer.textContent.trim() + ' [Stopped]', 'assistant');
       }
       
       // Clean up any remaining indicators
       const thinkingIndicator = document.getElementById('thinking-indicator-wrapper');
       if (thinkingIndicator) thinkingIndicator.remove();
       
       // Update button state
       this.updateDynamicButtonState();
   }

   async exportChat() {
       if (!this.currentChatSession) {
           this.showNotification('No chat to export', 'info');
           return;
       }
       
       try {
           const response = await fetch(`/api/chat/sessions/${this.currentChatSession}/export`);
           const data = await response.json();
           
           if (data.success) {
               // Create download
               const blob = new Blob([JSON.stringify(data.export, null, 2)], { type: 'application/json' });
               const url = URL.createObjectURL(blob);
               const a = document.createElement('a');
               a.href = url;
               a.download = `chat-export-${new Date().toISOString().split('T')[0]}.json`;
               document.body.appendChild(a);
               a.click();
               document.body.removeChild(a);
               URL.revokeObjectURL(url);
               
               this.showNotification('Chat exported successfully', 'success');
           }
       } catch (error) {
           console.error('Export error:', error);
           this.showNotification('Failed to export chat', 'error');
       }
   }

   // =============================================
   // SEARCH FUNCTIONALITY
   // =============================================
   async searchChatHistory(query) {
       try {
           const response = await fetch('/api/user/search', {
               method: 'POST',
               headers: { 'Content-Type': 'application/json' },
               body: JSON.stringify({ query })
           });
           
           const data = await response.json();
           if (data.success) {
               return data.results;
           }
       } catch (error) {
           console.error('Search error:', error);
           this.showNotification('Search failed', 'error');
       }
       return [];
   }

   // =============================================
   // BULK OPERATIONS
   // =============================================

   async bulkDeleteSessions(sessionIds) {
       try {
           const response = await fetch('/api/chat/sessions/bulk-delete', {
               method: 'POST',
               headers: { 'Content-Type': 'application/json' },
               body: JSON.stringify({ session_ids: sessionIds })
           });
           
           const data = await response.json();
           if (data.success) {
               this.loadChatSessions();
               this.showNotification(`${sessionIds.length} sessions deleted`, 'success');
               
               // If current session was deleted, reset
               if (sessionIds.includes(this.currentChatSession)) {
                   this.currentChatSession = null;
                   this.triggerInitialModeTransition();
                   this.updateUrlWithSession(null);
               }
           }
       } catch (error) {
           console.error('Bulk delete error:', error);
           this.showNotification('Bulk delete failed', 'error');
       }
   }

   testDropdowns() {
   console.log('Testing dropdowns...');
   console.log('Upload dropdown element:', this.elements.uploadDropdown);
   console.log('Thinking dropdown element:', this.elements.thinkingDropdown);
   console.log('Upload button element:', this.elements.uploadOptionsBtn);
   console.log('Thinking button element:', this.elements.thinkingModeBtn);
   }
   
    // =============================================
    // PROFILE DROPDOWN FUNCTIONALITY
    // =============================================

    setupProfileDropdown() {
        console.log('🔧 Setting up profile dropdown (fixed version)...');
        
        const profileToggleBtn = document.getElementById('profile-toggle-btn');
        const profileDropdown = document.getElementById('profile-dropdown');
        
        console.log('Elements found:', {
            button: !!profileToggleBtn,
            dropdown: !!profileDropdown
        });
        
        if (!profileToggleBtn || !profileDropdown) {
            console.error('❌ Profile dropdown elements not found!');
            return;
        }
        
        // Store dropdown state
        let isDropdownOpen = false;
        
        // Toggle dropdown function
        const toggleDropdown = (forceClose = false) => {
            if (forceClose || isDropdownOpen) {
                // Close dropdown
                profileDropdown.classList.remove('show');
                profileToggleBtn.classList.remove('active');
                isDropdownOpen = false;
                console.log('❌ Profile dropdown closed');
            } else {
                // Close other dropdowns first
                this.closeOtherDropdowns();
                
                // Open dropdown
                profileDropdown.classList.add('show');
                profileToggleBtn.classList.add('active');
                isDropdownOpen = true;
                
                // Load stats
                this.loadUserStats();
                console.log('✅ Profile dropdown opened');
            }
        };
        
        // Profile button click handler
        profileToggleBtn.addEventListener('click', (e) => {
            e.preventDefault();
            e.stopPropagation();
            
            console.log('🖱️ Profile button clicked!');
            console.log('👁️ Dropdown currently visible:', isDropdownOpen);
            
            toggleDropdown();
        });
        
        // Close on outside click
        document.addEventListener('click', (e) => {
            // Check if click is outside both button and dropdown
            if (isDropdownOpen && 
                !profileToggleBtn.contains(e.target) && 
                !profileDropdown.contains(e.target)) {
                toggleDropdown(true);
                console.log('❌ Profile dropdown closed by outside click');
            }
        });
        
        // Close on Escape key
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape' && isDropdownOpen) {
                toggleDropdown(true);
                console.log('❌ Profile dropdown closed by Escape key');
            }
        });
        
        // Prevent dropdown from closing when clicking inside it
        profileDropdown.addEventListener('click', (e) => {
            e.stopPropagation();
        });
        
        // Setup button handlers
        this.setupProfileButtons(profileDropdown, profileToggleBtn, toggleDropdown);
        
        console.log('✅ Profile dropdown setup completed');
    }

    // Close other dropdowns (not profile)
    closeOtherDropdowns() {
        const { uploadDropdown, thinkingDropdown, providerDropdown } = this.elements;
        
        if (uploadDropdown) {
            uploadDropdown.classList.remove('show');
        }
        
        if (thinkingDropdown) {
            thinkingDropdown.classList.remove('show');
        }
        
        if (providerDropdown) {
            providerDropdown.classList.remove('show');
        }
        
        // Close session dropdowns
        document.querySelectorAll('.session-dropdown-menu.visible').forEach(menu => {
            menu.classList.remove('visible');
        });
    }
    
    // Add this method to your ChatApplication class
    async loadUserStats() {
        try {
            const response = await fetch('/api/user/stats?days=7');
            const data = await response.json();
            
            if (data.success && data.stats) {
                const totalEl = document.getElementById('total-chats-stat');
                const weekEl = document.getElementById('week-chats-stat');
                
                if (totalEl) totalEl.textContent = data.stats.total_sessions || '0';
                if (weekEl) weekEl.textContent = data.stats.sessions_last_7_days || '0';
                
                console.log('✅ Stats loaded:', data.stats);
            }
        } catch (error) {
            console.error('Stats error:', error);
            
            // Fallback values
            const totalEl = document.getElementById('total-chats-stat');
            const weekEl = document.getElementById('week-chats-stat');
            if (totalEl) totalEl.textContent = '0';
            if (weekEl) weekEl.textContent = '0';
        }
    }
    setupProfileButtons(profileDropdown, profileToggleBtn, toggleDropdown) {
        const deleteAllBtn = document.getElementById('delete-all-chats-btn');
        const settingsBtn = document.getElementById('settings-btn');
        const upgradePlanBtn = document.getElementById('upgradePlan-btn');
        
        // Delete all chats
        if (deleteAllBtn) {
            deleteAllBtn.addEventListener('click', async (e) => {
                e.stopPropagation();
                
                // Get modal elements
                const modal = document.getElementById('delete-all-modal');
                const cancelBtn = document.getElementById('delete-cancel1');
                const confirmBtn = document.getElementById('delete-confirm1');
                
                if (!modal || !cancelBtn || !confirmBtn) {
                    console.error('Modal elements not found');
                    return;
                }
                
                // Function to close modal
                const closeModal = () => {
                    modal.style.display = 'none';
                    modal.setAttribute('hidden', '');
                    // Clean up any inline event handlers
                    cancelBtn.onclick = null;
                    confirmBtn.onclick = null;
                    modal.onclick = null;
                    document.onkeydown = null;
                };
                
                // Show modal
                modal.removeAttribute('hidden');
                modal.style.display = 'flex';
                
                // Store context
                const context = this;
                
                // Set up event handlers using onclick (more direct)
                cancelBtn.onclick = () => {
                    console.log('Cancel clicked - closing modal');
                    closeModal();
                };

                confirmBtn.onclick = async () => {
                    console.log('Confirm clicked');
                    
                    // Disable buttons
                    confirmBtn.disabled = true;
                    confirmBtn.textContent = 'Deleting...';
                    cancelBtn.disabled = true;
                    
                    try {
                        const response = await fetch('/api/chat/sessions/delete-all', {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/json',
                            }
                        });
                        
                        const data = await response.json();
                        
                        if (response.ok && data.success) {
                            if (data.sessions && data.sessions.length > 0) {
                                const sessionIds = data.sessions.map(s => s.id);
                                await context.bulkDeleteSessions(sessionIds);
                                context.createNewChat();
                                context.showNotification(`Deleted ${data.deleted_count} sessions`, 'success');
                                
                                // Refresh stats after successful deletion
                                if (typeof context.loadUserStats === 'function') {
                                    await context.loadUserStats();
                                } else {
                                    // Force reload stats with cache busting
                                    const response = await fetch(`/api/user/stats?days=7&_t=${Date.now()}`);
                                    const statsData = await response.json();
                                    if (statsData.success && statsData.stats) {
                                        const totalEl = document.getElementById('total-chats-stat');
                                        const weekEl = document.getElementById('week-chats-stat');
                                        if (totalEl) totalEl.textContent = statsData.stats.total_sessions || '0';
                                        if (weekEl) weekEl.textContent = statsData.stats.sessions_last_7_days || '0';
                                    }
                                }
                            } else {
                                context.showNotification('No chats to delete', 'info');
                            }
                        } else {
                            context.showNotification(data.error || 'Failed to delete chats', 'error');
                        }
                        
                        // Close everything
                        closeModal();
                        toggleDropdown(true);
                        
                    } catch (error) {
                        console.error('Delete error:', error);
                        context.showNotification('Failed to delete chats', 'error');
                        
                        // Reset buttons but keep modal open
                        confirmBtn.disabled = false;
                        confirmBtn.textContent = 'Delete All';
                        cancelBtn.disabled = false;
                    }
                };
                
                // Click outside to close
                modal.onclick = (e) => {
                    if (e.target === modal) {
                        console.log('Backdrop clicked - closing modal');
                        closeModal();
                    }
                };
                
                // ESC to close
                document.onkeydown = (e) => {
                    if (e.key === 'Escape' && modal.style.display !== 'none') {
                        console.log('ESC pressed - closing modal');
                        closeModal();
                    }
                };
            });
        }
        
        // Rest of your code remains the same...
        if (settingsBtn) {
            settingsBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                toggleDropdown(true);
                console.log('🔄 Navigating to settings...');
                window.location.href = '/settings';
            });
        }
        
        if (upgradePlanBtn) {
            upgradePlanBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                toggleDropdown(true);
                console.log('🔄 Navigating to Upgrade plan page ...');
                window.location.href = '/plans';
            });
        }

        const logoutBtn = document.querySelector('.logout-btn');
        if (logoutBtn) {
            logoutBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                toggleDropdown(true);
            });
        }
    }

// =============================================
// DEBUGGING HELPER
// =============================================

    debugProfileDropdown() {
        console.log('🔍 Debugging profile dropdown...');
        
        const btn = document.getElementById('profile-toggle-btn');
        const dropdown = document.getElementById('profile-dropdown');
        
        console.log('Button:', btn);
        console.log('Dropdown:', dropdown);
        
        if (dropdown) {
            console.log('Dropdown classes:', dropdown.className);
            console.log('Dropdown computed style:');
            const styles = window.getComputedStyle(dropdown);
            console.log('- display:', styles.display);
            console.log('- visibility:', styles.visibility);
            console.log('- opacity:', styles.opacity);
            console.log('- pointer-events:', styles.pointerEvents);
        }
        
        if (btn) {
            console.log('Button classes:', btn.className);
            console.log('Simulating click...');
            btn.click();
            
            setTimeout(() => {
                if (dropdown) {
                    console.log('After click - Dropdown classes:', dropdown.className);
                    const styles = window.getComputedStyle(dropdown);
                    console.log('After click - visibility:', styles.visibility);
                    console.log('After click - opacity:', styles.opacity);
                }
            }, 100);
        }
    }

    // NEW: Animate number changes in stats
    animateNumber(element, start, end, duration = 500) {
        const startTime = performance.now();
        const change = end - start;
        
        const updateNumber = (currentTime) => {
            const elapsed = currentTime - startTime;
            const progress = Math.min(elapsed / duration, 1);
            
            // Ease out animation
            const easeOut = 1 - Math.pow(1 - progress, 3);
            const current = Math.round(start + (change * easeOut));
            
            element.textContent = current;
            
            if (progress < 1) {
                requestAnimationFrame(updateNumber);
            }
        };
        
        requestAnimationFrame(updateNumber);
    }

// =============================================
// Model Selection DropDown
// =============================================

setupModelDropdown() {
   const modelBtn = document.getElementById('model-selection-btn');
   const modelDropdown = document.getElementById('model-dropdown');
   
   if (!modelBtn || !modelDropdown) {
       console.warn('Model dropdown elements not found');
       return;
   }
   
   // Store references
   this.elements.modelBtn = modelBtn;
   this.elements.modelDropdown = modelDropdown;
   
   // Toggle dropdown on button click
   modelBtn.addEventListener('click', (e) => {
       e.stopPropagation();
       
       console.log('Model button clicked');
       
       // Close other dropdowns first
       this.closeAllDropdowns();
       
       // Toggle this dropdown
       const isVisible = modelDropdown.classList.contains('show');
       if (isVisible) {
           modelDropdown.classList.remove('show');
           modelBtn.classList.remove('active');
       } else {
           modelDropdown.classList.add('show');
           modelBtn.classList.add('active');
           
           // Load models if not already loaded for current provider
           const currentProvider = window.selectedProvider || 'groq';
           if (!this.availableModels[currentProvider] && !this.modelLoading) {
               this.loadModelsForProvider(currentProvider);
           }
       }
   });
   
   // Close dropdown when clicking outside
   document.addEventListener('click', (e) => {
       if (!e.target.closest('.model-dropdown-container')) {
           modelDropdown.classList.remove('show');
           modelBtn.classList.remove('active');
       }
   });
   
   // Handle model selection from dropdown
   modelDropdown.addEventListener('click', (e) => {
       e.stopPropagation();
       const modelOption = e.target.closest('.model-option');
       if (!modelOption) return;
       
       const modelName = modelOption.dataset.model;
       const isActive = modelOption.classList.contains('active');
       
       if (modelName && !isActive) {
           this.selectModel(modelName);
           modelDropdown.classList.remove('show');
           modelBtn.classList.remove('active');
       }
   });
   
   // Load initial models for default provider
   const defaultProvider = window.selectedProvider || 'groq';
   this.loadModelsForProvider(defaultProvider);
}

async loadModelsForProvider(provider) {
   if (!provider || this.modelLoading) return;
   
   this.modelLoading = true;
   console.log(`Loading models for provider: ${provider}`);
   
   try {
       // Show loading state
       this.showModelLoading();
       
       const response = await fetch(`/api/chat/models?provider=${provider}`);
       const data = await response.json();
       
       if (data.success && data.models) {
           // Store models for this provider
           this.availableModels[provider] = {
               models: data.models,
               defaultModel: data.default_model
           };
           
           // Update dropdown
           this.updateModelDropdown(data.models, data.default_model, provider);
           
           // Set default model if none selected for this provider
           if (!this.selectedModel || this.needsModelUpdate(provider)) {
               this.selectModel(data.default_model, false); // false = don't show notification
           }
           
           console.log(`✅ Loaded models for ${provider}`);
       } else {
           console.error('Failed to load models:', data.error);
           this.showModelError(data.error || 'Failed to load models');
       }
   } catch (error) {
       console.error('Error loading models:', error);
       this.showModelError('Network error loading models');
   } finally {
       this.modelLoading = false;
   }
}

updateModelDropdown(models, defaultModel, provider) {
    const dropdown = this.elements.modelDropdown;
    if (!dropdown) return;
    
    let html = '';
    
    // Standard models - no badges
    if (models.standard && models.standard.length > 0) {
        html += `
            <div class="model-group">
                <div class="model-group-header">Standard Models</div>
                ${models.standard.map(model => `
                    <div class="model-option ${model === this.selectedModel ? 'active' : ''}" data-model="${model}">
                        <span class="model-name">${this.formatModelName(model)}</span>
                    </div>
                `).join('')}
            </div>
        `;
    }
    
    // Premium models - no badges
    if (models.premium && models.premium.length > 0) {
        html += `
            <div class="model-group">
                <div class="model-group-header">Premium Models</div>
                ${models.premium.map(model => `
                    <div class="model-option ${model === this.selectedModel ? 'active' : ''}" data-model="${model}">
                        <span class="model-name">${this.formatModelName(model)}</span>
                    </div>
                `).join('')}
            </div>
        `;
    }
    
    // If no models found
    if (!html) {
        html = '<div class="model-error">No models available for this provider</div>';
    }
    
    dropdown.innerHTML = html;
}

selectModel(modelName, showNotification = true) {
   if (!modelName) return;
   
   this.selectedModel = modelName;
   
   // Update button text
   const modelBtn = this.elements.modelBtn;
   const modelText = modelBtn?.querySelector('.model-selection-text');
   if (modelText) {
       modelText.textContent = this.formatModelName(modelName);
   }
   
   // Update dropdown active state
   const dropdown = this.elements.modelDropdown;
   if (dropdown) {
       dropdown.querySelectorAll('.model-option').forEach(option => {
           option.classList.remove('active');
           if (option.dataset.model === modelName) {
               option.classList.add('active');
           }
       });
   }
   
   // Store selection in localStorage
   const provider = window.selectedProvider || 'groq';
   localStorage.setItem(`selectedModel_${provider}`, modelName);
   
   if (showNotification) {
       this.showNotification(`Selected ${this.formatModelName(modelName)}`, 'success');
   }
   
   console.log(`✅ Model selected: ${modelName}`);
}

showModelLoading() {
   const dropdown = this.elements.modelDropdown;
   if (dropdown) {
       dropdown.innerHTML = '<div class="model-loading">Loading models...</div>';
   }
}

showModelError(message) {
   const dropdown = this.elements.modelDropdown;
   if (dropdown) {
       dropdown.innerHTML = `
           <div class="model-error">
               ${message}
               <button class="model-retry-btn" onclick="chatApp.retryLoadModels()">Retry</button>
           </div>
       `;
   }
}

retryLoadModels() {
   const provider = window.selectedProvider || 'groq';
   this.loadModelsForProvider(provider);
}

formatModelName(modelName) {
   if (!modelName) return 'Select Model';
   
   // Remove common prefixes
   let formatted = modelName.replace(/^models\//, '');
   
   // Handle different model name formats
   if (formatted.includes('gpt')) {
       return formatted.toUpperCase();
   }
   
   if (formatted.includes('claude')) {
       return formatted.split('-').map(part => 
           part.charAt(0).toUpperCase() + part.slice(1)
       ).join(' ');
   }
   
   if (formatted.includes('gemini')) {
       return formatted.split('-').map(part => 
           part.charAt(0).toUpperCase() + part.slice(1)
       ).join(' ');
   }
   
   if (formatted.includes('llama')) {
       return formatted.split('-').map(part => 
           part.charAt(0).toUpperCase() + part.slice(1)
       ).join(' ');
   }
   
   // Default formatting
   return formatted.charAt(0).toUpperCase() + formatted.slice(1);
}

needsModelUpdate(provider) {
   // Check if current selected model belongs to the new provider
   if (!this.selectedModel) return true;
   
   const providerModels = this.availableModels[provider];
   if (!providerModels) return true;
   
   const allModels = [
       ...(providerModels.models.standard || []),
       ...(providerModels.models.premium || [])
   ];
   
   return !allModels.includes(this.selectedModel);
}


// Add this new method
initializeCopyButtons() {
    // Event delegation for copy buttons
    document.addEventListener('click', async (e) => {
        const copyBtn = e.target.closest('.copy-code-btn');
        if (copyBtn) {
            e.preventDefault();
            const codeId = copyBtn.getAttribute('data-code-id');
            await this.copyCodeToClipboard(codeId, copyBtn);
        }
    });
}

// Add copy functionality
async copyCodeToClipboard(codeId, button) {
    try {
        const codeBlock = document.getElementById(codeId);
        if (!codeBlock) return;
        
        const code = codeBlock.textContent;
        await navigator.clipboard.writeText(code);
        
        // Visual feedback
        const originalText = button.querySelector('.copy-btn-text').textContent;
        button.querySelector('.copy-btn-text').textContent = 'Copied!';
        button.classList.add('copied');
        
        setTimeout(() => {
            button.querySelector('.copy-btn-text').textContent = originalText;
            button.classList.remove('copied');
        }, 2000);
        
    } catch (err) {
        console.error('Failed to copy:', err);
        // Fallback for older browsers
        this.fallbackCopy(codeId);
    }
}

// Fallback copy method
fallbackCopy(codeId) {
    const codeBlock = document.getElementById(codeId);
    if (!codeBlock) return;
    
    const textArea = document.createElement('textarea');
    textArea.value = codeBlock.textContent;
    textArea.style.position = 'fixed';
    textArea.style.opacity = '0';
    document.body.appendChild(textArea);
    textArea.select();
    
    try {
        document.execCommand('copy');
        this.showNotification('Code copied!', 'success');
    } catch (err) {
        this.showNotification('Failed to copy code', 'error');
    }
    
    document.body.removeChild(textArea);
}

// Enhanced renderEnhancedSources with expandable functionality
renderEnhancedSources(sources, messageContainer) {
    if (!sources || sources.length === 0) return;
    
    console.log('🎨 Rendering enhanced sources:', sources.length);
    
    // Generate unique ID for this sources section
    const sourcesId = `sources-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    
    const sourcesHtml = `
        <div class="enhanced-sources-container">
            <div class="sources-header" onclick="this.toggleSourcesVisibility('${sourcesId}')" style="cursor: pointer;">
                <div class="sources-header-left">
                    <i class="fas fa-external-link-alt"></i>
                    <span>Sources</span>
                </div>
                <div class="sources-header-right">
                    <span class="sources-count">${sources.length} result${sources.length !== 1 ? 's' : ''}</span>
                    <i class="fas fa-chevron-down sources-toggle-arrow" id="arrow-${sourcesId}"></i>
                </div>
            </div>
            <div class="sources-grid" id="${sourcesId}" style="display: none;">
                ${sources.map((source, index) => `
                    <div class="source-card" onclick="window.open('${source.url || '#'}', '_blank')" 
                         style="cursor: ${source.url ? 'pointer' : 'default'}">
                        <div class="source-icon">
                            ${source.favicon ? 
                                `<img src="${source.favicon}" alt="${source.domain}" 
                                     onerror="this.style.display='none'; this.nextElementSibling.style.display='block';">
                                 <i class="fas fa-globe" style="display: none;"></i>` : 
                                `<i class="fas fa-globe"></i>`
                            }
                        </div>
                        <div class="source-content">
                            <div class="source-title">${this.escapeHtml(source.title || 'Untitled')}</div>
                            <div class="source-domain">${this.escapeHtml(source.domain || 'Unknown')}</div>
                            ${source.score > 0 ? `<div class="source-score">Relevance: ${Math.round(source.score * 100)}%</div>` : ''}
                        </div>
                    </div>
                `).join('')}
            </div>
        </div>
    `;
    
    messageContainer.insertAdjacentHTML('beforeend', sourcesHtml);
    console.log('✅ Enhanced sources rendered successfully');
    
    // Add the toggle functionality to the container
    this.addSourcesToggleFunctionality(messageContainer, sourcesId);
}

// Add toggle functionality method
addSourcesToggleFunctionality(container, sourcesId) {
    const header = container.querySelector('.sources-header');
    const sourcesGrid = container.querySelector(`#${sourcesId}`);
    const arrow = container.querySelector(`#arrow-${sourcesId}`);
    
    if (!header || !sourcesGrid || !arrow) return;
    
    // Add click handler to header
    header.addEventListener('click', (e) => {
        e.stopPropagation(); // Prevent event bubbling
        
        const isCurrentlyVisible = sourcesGrid.style.display !== 'none';
        
        if (isCurrentlyVisible) {
            // Close the sources
            sourcesGrid.style.display = 'none';
            arrow.style.transform = 'rotate(0deg)';
            arrow.classList.remove('expanded');
            header.classList.remove('expanded');
        } else {
            // Open the sources
            sourcesGrid.style.display = 'grid';
            arrow.style.transform = 'rotate(180deg)';
            arrow.classList.add('expanded');
            header.classList.add('expanded');
        }
    });
    
    // Optional: Add keyboard accessibility
    header.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            header.click();
        }
    });
    
    // Make header focusable for accessibility
    header.setAttribute('tabindex', '0');
    header.setAttribute('role', 'button');
    header.setAttribute('aria-expanded', 'false');
    header.setAttribute('aria-controls', sourcesId);
}

// Helper method for HTML escaping (unchanged)
escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}




    // =============================================
    // REGENERATION AND EDIT MESSAGE FUNCTIONALITY
    // =============================================
    
    async handleEditMessage(button, messageWrapper) {
        const messageContent = messageWrapper.querySelector('.message-content');
        const currentText = this.extractMessageText(messageContent);
        
        // Create edit interface
        const editUI = this.createEditInterface(currentText);
        messageContent.innerHTML = '';
        messageContent.appendChild(editUI);
        
        // Setup edit handlers
        this.setupEditHandlers(editUI, messageWrapper, messageContent);
    }
    
    // =============================================
    // MESSAGE ACTION HANDLERS - SIMPLIFIED
    // =============================================
    setupMessageActionButtons() {
        document.addEventListener('click', async (e) => {
            const button = e.target.closest('.action-btn');
            if (!button) return;
            
            e.preventDefault();
            e.stopPropagation();
            
            // Route to appropriate handler based on button class
            if (button.classList.contains('copy-message-btn')) {
                await this.handleMessageCopy(button);
            } else if (button.classList.contains('thumb-up-btn')) {
                this.handleThumbsUp(button);
            } else if (button.classList.contains('thumb-down-btn')) {
                this.handleThumbsDown(button);
            } else if (button.classList.contains('regenerate-btn')) {
                await this.handleRegenerateResponse(button);
            } else if (button.classList.contains('edit-btn')) {
                this.editUserMessage(button);
            }
        });
    }
    // =============================================
    // REGENERATION - SIMPLIFIED
    // =============================================
    
    async handleRegenerateResponse(button) {
    const messageWrapper = button.closest('.message-wrapper');
    if (!messageWrapper) {
        console.error('Could not find message wrapper');
        return;
    }
    
    const messageId = button.dataset.messageId;
    
    // Find last user message
    const allWrappers = Array.from(this.elements.messagesList.querySelectorAll('.message-wrapper'));
    const currentIndex = allWrappers.indexOf(messageWrapper);
    
    let lastUserMessage = null;
    for (let i = currentIndex - 1; i >= 0; i--) {
        if (allWrappers[i].classList.contains('user-wrapper')) {
            const userContent = allWrappers[i].querySelector('.message-content');
            const clone = userContent.cloneNode(true);
            const actionsContainer = clone.querySelector('.user-actions-container');
            if (actionsContainer) actionsContainer.remove();
            lastUserMessage = clone.textContent.trim();
            break;
        }
    }
    
    if (!lastUserMessage) {
        this.showNotification('No user message found to regenerate', 'error');
        return;
    }
    
    // Disable buttons
    const actionButtons = messageWrapper.querySelectorAll('.action-btn');
    actionButtons.forEach(btn => {
        btn.disabled = true;
        btn.style.opacity = '0.5';
    });
    
    button.classList.add('regenerating');
    
    try {
        // Transform to typing state
        const messageContent = messageWrapper.querySelector('.message-content');
        const messageElement = messageWrapper.querySelector('.message');

        // Hide the existing message temporarily
        messageWrapper.style.opacity = '0.5';

        
        messageContent.innerHTML = '';
        messageElement.classList.add('message-typing');
        
        const streamingContainer = document.createElement('div');
        streamingContainer.id = 'streaming-content';
        messageContent.appendChild(streamingContainer);

        // Add thinking indicator for regeneration
        const thinkingIndicator = this.addThinkingIndicator(true);
        
        // Call regenerate endpoint
        const response = await fetch(`/api/chat/messages/${messageId}/regenerate`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                user_message: lastUserMessage,
                provider: window.selectedProvider,
                model: this.selectedModel,
                enable_web_search: this.userModes.webSearch,
                enable_deep_research: this.userModes.deepResearch,
                enable_study_learn: this.userModes.studyLearn
            })
        });

        // Remove thinking indicator
        if (thinkingIndicator) thinkingIndicator.remove();
    
    // Show message wrapper again
    messageWrapper.style.opacity = '1';
        
        const data = await response.json();
        
        if (data.success) {
            // Stream the new content
            let formattedContent = data.text;
            
            if (typeof formatLLMResponse !== 'undefined') {
                try {
                    formattedContent = formatLLMResponse(data.text, {
                        enableMath: true,
                        enableTables: true,
                        enableCodeBlocks: true,
                        enableLists: true,
                        enableHeaders: true,
                        enableLinks: true,
                        sanitizeHtml: true
                    });
                } catch (formatError) {
                    console.error('Formatting error:', formatError);
                }
            }
            
            this.streamFormattedContent(formattedContent, streamingContainer, () => {
                messageElement.classList.remove('message-typing');
                
                const finalContent = streamingContainer.innerHTML;
                messageContent.innerHTML = finalContent;
                
                // Re-add metadata and actions
                if (data.model || data.provider) {
                    messageContent.innerHTML += `
                        <div class="model-info-container">
                            <div class="model-info">
                                ${data.provider ? `<span class="provider-badge">${data.provider}</span>` : ''}
                                ${data.model ? `<span class="model-badge">${data.model}</span>` : ''}
                            </div>
                        </div>`;
                }
                
                messageContent.innerHTML += this.createResponseActionsContainer(messageId);
                
                if (data.enhanced_sources?.length > 0) {
                    this.renderEnhancedSources(data.enhanced_sources, messageContent);
                }
                
                setTimeout(() => {
                    this.highlightCodeBlocks(messageContent);
                    this.attachCopyButtons(messageContent);
                }, 100);
                
                this.scrollToBottom();
            });
        } else {
            throw new Error(data.error || 'Failed to regenerate');
        }
        
    } catch (error) {
        console.error('Regeneration error:', error);
        this.showNotification('Failed to regenerate response', 'error');
    } finally {
        actionButtons.forEach(btn => {
            btn.disabled = false;
            btn.style.opacity = '1';
        });
        button.classList.remove('regenerating');
    }
}

    // =============================================
    // MESSAGE EDITING - SIMPLIFIED
    // =============================================
   
    editUserMessage(button) {
    const messageWrapper = button.closest('.message-wrapper');
    if (!messageWrapper) return;
    
    const messageContent = messageWrapper.querySelector('.message-content');
    const userActionsContainer = messageContent.querySelector('.user-actions-container');
    const messageId = button.dataset.messageId || messageWrapper.dataset.messageId;
    
    // Get current text
    const clone = messageContent.cloneNode(true);
    const cloneActions = clone.querySelector('.user-actions-container');
    if (cloneActions) cloneActions.remove();
    
    const currentText = clone.textContent || clone.innerText;
    
    // Create edit interface
    const editContainer = document.createElement('div');
    editContainer.className = 'edit-message-container';
    editContainer.innerHTML = `
        <textarea class="edit-message-input">${currentText}</textarea>
        <div class="edit-actions">
            <button class="cancel-edit-btn">Cancel</button>
            <button class="save-edit-btn">Save</button>
        </div>
    `;
    
    messageContent.innerHTML = '';
    messageContent.appendChild(editContainer);
    
    const textarea = editContainer.querySelector('.edit-message-input');
    const cancelBtn = editContainer.querySelector('.cancel-edit-btn');
    const saveBtn = editContainer.querySelector('.save-edit-btn');
    
    textarea.focus();
    textarea.select();
    
    const autoResize = () => {
        textarea.style.height = 'auto';
        textarea.style.height = Math.min(textarea.scrollHeight, 400) + 'px';
    };
    
    textarea.addEventListener('input', autoResize);
    autoResize();
    
    cancelBtn.addEventListener('click', () => {
        messageContent.innerHTML = `<div class="user-message-content">${currentText}</div>`;
        messageContent.appendChild(userActionsContainer);
    });
    
    saveBtn.addEventListener('click', async () => {
        const newText = textarea.value.trim();
        if (!newText || newText === currentText) return;
        
        try {
            // Update the user message via API
            const response = await fetch(`/api/chat/messages/${messageId}/update`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ content: newText })
            });
            
            const data = await response.json();
            
            if (data.success) {
                // Update UI
                messageContent.innerHTML = `<div class="user-message-content">${newText}</div>`;
                messageContent.appendChild(userActionsContainer);
                
                // Find and regenerate next AI message
                const nextWrapper = messageWrapper.nextElementSibling;
                if (nextWrapper && nextWrapper.classList.contains('assistant-wrapper')) {
                    const regenerateBtn = nextWrapper.querySelector('.regenerate-btn');
                    if (regenerateBtn) {
                        regenerateBtn.click();
                    }
                }
            } else {
                throw new Error(data.error || 'Failed to update message');
            }
        } catch (error) {
            console.error('Edit error:', error);
            this.showNotification('Failed to update message', 'error');
            // Restore original content
            messageContent.innerHTML = `<div class="user-message-content">${currentText}</div>`;
            messageContent.appendChild(userActionsContainer);
        }
    });
    
    textarea.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            saveBtn.click();
        }
    });
}

    // =============================================
    // OTHER MESSAGE ACTIONS
    // =============================================
    async handleMessageCopy(button) {
        try {
            const messageWrapper = button.closest('.message-wrapper');
            const messageContent = messageWrapper.querySelector('.message-content');
            
            // Clone and clean content
            const clone = messageContent.cloneNode(true);
            const cloneActions = clone.querySelector('.response-actions-container, .user-actions-container');
            const cloneModelInfo = clone.querySelector('.model-info-container');
            
            if (cloneActions) cloneActions.remove();
            if (cloneModelInfo) cloneModelInfo.remove();
            
            const textContent = clone.textContent || clone.innerText;
            await navigator.clipboard.writeText(textContent);
            
            // Visual feedback
            const originalSvg = button.innerHTML;
            button.innerHTML = `
                <svg viewBox="0 0 24 24" fill="none">
                    <polyline points="20,6 9,17 4,12" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
            `;
            button.classList.add('copied');
            
            setTimeout(() => {
                button.innerHTML = originalSvg;
                button.classList.remove('copied');
            }, 2000);
            
            this.showNotification('Message copied to clipboard', 'success');
        } catch (err) {
            console.error('Failed to copy message:', err);
            this.showNotification('Failed to copy message', 'error');
        }
    }

    handleThumbsUp(button) {
        const messageId = button.dataset.messageId;
        const thumbDownBtn = button.parentElement.querySelector('.thumb-down-btn');
        
        const isActive = button.classList.toggle('active');
        
        if (isActive && thumbDownBtn && thumbDownBtn.classList.contains('active')) {
            thumbDownBtn.classList.remove('active');
        }
        
        this.sendFeedback(messageId, isActive ? 'Good Response' : null);
        
        const action = isActive ? 'liked' : 'removed like from';
        this.showNotification(`You ${action} this response`, 'info');
    }

    handleThumbsDown(button) {
        const messageId = button.dataset.messageId;
        const thumbUpBtn = button.parentElement.querySelector('.thumb-up-btn');
        
        const isActive = button.classList.toggle('active');
        
        if (isActive && thumbUpBtn && thumbUpBtn.classList.contains('active')) {
            thumbUpBtn.classList.remove('active');
        }
        
        this.sendFeedback(messageId, isActive ? 'Bad Response' : null);
        
        const action = isActive ? 'disliked' : 'removed dislike from';
        this.showNotification(`You ${action} this response`, 'info');
    }

    async sendFeedback(messageId, feedback) {
        if (!feedback) return;
        
        try {
            const response = await fetch('/api/chat/feedback', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    message_id: messageId,
                    feedback: feedback,
                    session_id: this.currentChatSession
                })
            });
            
            const data = await response.json();
            console.log('Feedback sent:', data);
        } catch (error) {
            console.error('Failed to send feedback:', error);
        }
    }



}


// =============================================
// GLOBAL INITIALIZATION
// =============================================

// Initialize the chat application
const chatApp = new ChatApplication();

// Set default provider
window.selectedProvider = 'groq';

// Global functions for backward compatibility
window.chatApp = chatApp;
// Manually refresh welcome message
chatApp.refreshWelcomeMessage();
window.sendMessage = () => chatApp.sendMessage();
window.createNewChat = () => chatApp.createNewChat();
window.handleImageUpload = (files) => chatApp.handleFileUpload(files);
window.removeImagePreview = (button, fileName) => chatApp.removeFilePreview(button, fileName);

chatApp.debugProfileDropdown()

// Check if button exists and has click handler
const btn = document.getElementById('profile-toggle-btn');
console.log('Button:', btn);
console.log('Button onclick:', btn.onclick);

//for togglebutton by vk
document.getElementById('sidebar-toggle-btn').addEventListener('click', function() {
  const userNameDiv = document.querySelector('.user-profile-name-');
  if (!userNameDiv) return;

  // Toggle the 'hidden' class
  userNameDiv.classList.toggle('hidden');

  // Optionally, update aria-expanded attribute
  const expanded = this.getAttribute('aria-expanded') === 'true';
  this.setAttribute('aria-expanded', !expanded);
});


// FIXED: Code Theme switcher with proper highlight.js integration
document.getElementById('theme-toggle')?.addEventListener('click', () => {
    const body = document.body;
    const currentTheme = getCurrentCodeTheme();
    
    // Cycle through themes: monochrome → vscode → jetbrains → monochrome
    switch(currentTheme) {
        case 'monochrome':
            // Switch to VS Code
            body.classList.remove('jetbrains-dark-theme');
            body.classList.add('vscode-dark-theme');
            localStorage.setItem('codeTheme', 'vscode');
            updateHighlightJsTheme('vs2015');
            console.log('🎨 Switched to VS Code Dark theme');
            break;
            
        case 'vscode':
            // Switch to JetBrains
            body.classList.remove('vscode-dark-theme');
            body.classList.add('jetbrains-dark-theme');
            localStorage.setItem('codeTheme', 'jetbrains');
            updateHighlightJsTheme('atom-one-dark');
            console.log('🎨 Switched to JetBrains theme');
            break;
            
        case 'jetbrains':
        default:
            // Switch to Monochrome
            body.classList.remove('vscode-dark-theme', 'jetbrains-dark-theme');
            localStorage.setItem('codeTheme', 'monochrome');
            updateHighlightJsTheme('github-dark');
            console.log('🎨 Switched to Monochrome theme');
            break;
    }
    
    // Re-highlight all visible code blocks
    rehighlightAllCodeBlocks();
});

// Get current theme
function getCurrentCodeTheme() {
    const body = document.body;
    if (body.classList.contains('vscode-dark-theme')) return 'vscode';
    if (body.classList.contains('jetbrains-dark-theme')) return 'jetbrains';
    return 'monochrome';
}

// Update highlight.js theme dynamically
function updateHighlightJsTheme(themeName) {
    // Remove existing highlight.js CSS
    const existingLink = document.querySelector('link[href*="highlight.js"][href*="styles"]');
    if (existingLink) {
        existingLink.remove();
    }
    
    // Add new theme CSS
    const link = document.createElement('link');
    link.rel = 'stylesheet';
    link.href = `https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.8.0/styles/${themeName}.min.css`;
    document.head.appendChild(link);
    
    console.log(`📦 Updated highlight.js theme to: ${themeName}`);
}

// Re-highlight all code blocks after theme change
function rehighlightAllCodeBlocks() {
    if (typeof hljs === 'undefined') {
        console.warn('⚠️ hljs not available for re-highlighting');
        return;
    }
    
    // Find all code blocks
    const codeBlocks = document.querySelectorAll('pre code');
    console.log(`🔄 Re-highlighting ${codeBlocks.length} code blocks`);
    
    codeBlocks.forEach((block, index) => {
        // Remove existing hljs classes
        block.className = block.className.replace(/hljs[\w-]*/g, '').trim();
        
        // Re-apply highlighting
        try {
            hljs.highlightElement(block);
            console.log(`✅ Re-highlighted block ${index}`);
        } catch (error) {
            console.error(`❌ Error re-highlighting block ${index}:`, error);
        }
    });
}

// Load saved theme on page load
function loadSavedCodeTheme() {
    const savedTheme = localStorage.getItem('codeTheme') || 'monochrome';
    const body = document.body;
    
    // Clear all theme classes first
    body.classList.remove('vscode-dark-theme', 'jetbrains-dark-theme');
    
    switch(savedTheme) {
        case 'vscode':
            body.classList.add('vscode-dark-theme');
            updateHighlightJsTheme('vs2015');
            break;
        case 'jetbrains':
            body.classList.add('jetbrains-dark-theme');
            updateHighlightJsTheme('atom-one-dark');
            break;
        case 'monochrome':
        default:
            updateHighlightJsTheme('github-dark');
            break;
    }
    
    console.log(`🎨 Loaded saved theme: ${savedTheme}`);
}

// Initialize on page load
document.addEventListener('DOMContentLoaded', () => {
    loadSavedCodeTheme();
});

// Also call when chat app loads
if (typeof chatApp !== 'undefined') {
    loadSavedCodeTheme();
}

console.log("✅ Enhanced Chat System with Consolidated Input Controls Loaded - All Features Ready");


