// Global JavaScript functionality

document.addEventListener('DOMContentLoaded', function() {
    // Sidebar toggle functionality
    const sidebarToggle = document.getElementById('sidebarToggle');
    if (sidebarToggle) {
        sidebarToggle.addEventListener('click', function() {
            document.body.classList.toggle('sidebar-open');
        });
    }

    // Auto-hide toast messages
    const toastMessages = document.querySelectorAll('.toast-msg');
    toastMessages.forEach(toast => {
        // Auto close after 5 seconds
        setTimeout(() => {
            toast.style.animation = 'slideOut 0.3s ease';
            setTimeout(() => toast.remove(), 300);
        }, 5000);

        // Manual close button
        const closeBtn = toast.querySelector('.close-toast');
        if (closeBtn) {
            closeBtn.addEventListener('click', () => {
                toast.style.animation = 'slideOut 0.3s ease';
                setTimeout(() => toast.remove(), 300);
            });
        }
    });

    // Queue button functionality - Enhanced notification
    const queueBtn = document.getElementById('queueBtn');
    if (queueBtn) {
        queueBtn.addEventListener('click', function() {
            // Create a custom notification instead of alert
            const notification = document.createElement('div');
            notification.className = 'toast-msg toast-info';
            notification.innerHTML = `
                AI Queue feature coming soon!
                <button class="close-toast">&times;</button>
            `;
            
            // Find or create toast container
            let toastContainer = document.getElementById('toast-stack');
            if (!toastContainer) {
                toastContainer = document.querySelector('.toast-container');
            }
            if (toastContainer) {
                toastContainer.appendChild(notification);
            }
            
            // Auto remove after 3 seconds
            setTimeout(() => {
                notification.style.animation = 'slideOut 0.3s ease';
                setTimeout(() => notification.remove(), 300);
            }, 3000);
            
            // Manual close
            notification.querySelector('.close-toast').addEventListener('click', () => {
                notification.style.animation = 'slideOut 0.3s ease';
                setTimeout(() => notification.remove(), 300);
            });
        });
    }
});

// Add slideOut animation
const style = document.createElement('style');
style.textContent = `
    @keyframes slideOut {
        to {
            transform: translateX(100%);
            opacity: 0;
        }
    }
`;
document.head.appendChild(style);