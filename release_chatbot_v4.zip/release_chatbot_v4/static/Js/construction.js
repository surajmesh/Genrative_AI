/**
 * Construction Management Integration JavaScript
 * Handles cache busting and UI enhancements
 */

document.addEventListener('DOMContentLoaded', function() {
  // Log when the page loads
  console.log('Construction Management page loaded with cache buster timestamp:', Date.now());
  
  // Force reload stylesheet to avoid caching issues
  const timestamp = Date.now();
  const stylesheet = document.querySelector('link[href*="construction.css"]');
  
  if (stylesheet) {
    const newHref = stylesheet.href.split('?')[0] + '?forcereload=' + timestamp;
    stylesheet.href = newHref;
    console.log('Reloaded stylesheet:', newHref);
  }
  
  // Parse CSS variables to use consistent theme colors
  parseThemeColors();
  
  // Add subtle animations to feature items for better engagement
  addFeatureItemAnimations();
  
  // Add hover effects to integration cards
  addCardHoverEffects();
});

/**
 * Parse theme colors from CSS variables for consistent theming
 */
function parseThemeColors() {
  const root = document.documentElement;
  const computedStyle = getComputedStyle(root);
  
  // Get primary colors from CSS variables
  const primaryColor = computedStyle.getPropertyValue('--primary-color').trim() || '#3b23ff';
  const primaryLight = computedStyle.getPropertyValue('--primary-light').trim() || '#1EB8FF';
  const primaryDark = computedStyle.getPropertyValue('--primary-dark').trim() || '#0C7BD1';
  
  console.log('Using theme colors from CSS variables');
  
  // Could be used for dynamic theming if needed
  return {
    primary: primaryColor,
    light: primaryLight,
    dark: primaryDark
  };
}

/**
 * Add subtle animations to feature items for better engagement
 */
function addFeatureItemAnimations() {
  const featureItems = document.querySelectorAll('.feature-item');
  
  featureItems.forEach((item, index) => {
    // Add slight delay to each item for a cascade effect
    item.style.animationDelay = (index * 0.1) + 's';
    
    // Add animation class
    item.classList.add('feature-item-animated');
    
    // Add event listeners for hover interactions
    item.addEventListener('mouseenter', function() {
      this.style.transform = 'translateX(5px)';
      this.style.backgroundColor = 'rgba(12, 123, 209, 0.25)';
    });
    
    item.addEventListener('mouseleave', function() {
      this.style.transform = 'translateX(0)';
      this.style.backgroundColor = 'rgba(12, 123, 209, 0.15)';
    });
  });
}

/**
 * Add hover effects to integration cards
 */
function addCardHoverEffects() {
  const cards = document.querySelectorAll('.integration-card');
  
  cards.forEach(card => {
    card.addEventListener('mouseenter', function() {
      this.style.transform = 'translateY(-5px)';
      this.style.boxShadow = '0 12px 28px rgba(0, 0, 0, 0.25), 0 0 20px rgba(30, 184, 255, 0.2)';
    });
    
    card.addEventListener('mouseleave', function() {
      this.style.transform = 'translateY(0)';
      this.style.boxShadow = '0 8px 24px rgba(0, 0, 0, 0.2), 0 0 16px rgba(30, 184, 255, 0.1)';
    });
  });
}