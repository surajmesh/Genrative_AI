// AI Assistant Homepage JavaScript

document.addEventListener('DOMContentLoaded', function() {
    // Keep all existing initialization
    initializeNavigation();
    initializeSearch();
    initializeAnimations();
    initializeKeyboardShortcuts();
    initializeParallaxEffect();
    loadSidebarState();
    
    // Add new Ask Assistant initialization
    initializeAskAssistant();
});


// Navigation functionality
// Navigation functionality - UNCOMMENT THIS FUNCTION!
function initializeNavigation() {
    const navItems = document.querySelectorAll('.nav-item');
    const contentSections = document.querySelectorAll('.content-section');

    navItems.forEach(item => {
        item.addEventListener('click', function () {
            // Remove active class from all nav items
            navItems.forEach(nav => nav.classList.remove('active'));

            // Add active class to clicked item
            this.classList.add('active');

            // Hide all content sections
            contentSections.forEach(section => section.classList.remove('active'));

            // Show corresponding content section
            const targetContent = this.getAttribute('data-content');
            const targetSection = document.getElementById(targetContent);

            if (targetSection) {
                targetSection.classList.add('active');

                // Smooth scroll to top of content
                const mainContent = document.querySelector('.main-content');
                if (mainContent) {
                    mainContent.scrollTop = 0;
                }

                // Add entrance animation
                targetSection.style.animation = 'none';
                targetSection.offsetHeight; // Trigger reflow
                targetSection.style.animation = 'fadeInUp 0.5s ease';
            }
        });

        // Add hover effects
        item.addEventListener('mouseenter', function () {
            if (!this.classList.contains('active')) {
                this.style.transform = 'translateX(10px)';
            }
        });

        item.addEventListener('mouseleave', function () {
            if (!this.classList.contains('active')) {
                this.style.transform = 'translateX(0)';
            }
        });
    });
}
// Initialize Enhanced Ask Assistant Button
function initializeAskAssistant() {
    const askAssistant = document.getElementById('askAssistant');
    const assistantInput = document.getElementById('assistantInput');
    const sendButton = document.getElementById('sendButton');
    const messagePreview = document.getElementById('messagePreview');
    
    if (!askAssistant || !assistantInput || !sendButton) return;
    
    let isExpanded = false;

    // Toggle expansion
    askAssistant.addEventListener('click', function(e) {
        // Don't toggle if clicking on input or send button
        if (e.target === assistantInput || e.target === sendButton || sendButton.contains(e.target)) {
            return;
        }
        
        if (!isExpanded) {
            expandButton();
        }
    });

    // Expand function
    function expandButton() {
        isExpanded = true;
        askAssistant.classList.add('expanded');
        
        // Focus input after animation
        setTimeout(() => {
            assistantInput.focus();
        }, 300);
    }

    // Collapse function
    function collapseButton() {
        isExpanded = false;
        askAssistant.classList.remove('expanded');
        askAssistant.classList.remove('has-text');
        assistantInput.value = '';
    }

    // Input event handler
    assistantInput.addEventListener('input', function() {
        if (this.value.trim()) {
            askAssistant.classList.add('has-text');
        } else {
            askAssistant.classList.remove('has-text');
        }
    });

 
    // Send message
    function sendMessage() {
        const message = assistantInput.value.trim();
        if (message) {
            // Show loading state
            sendButton.classList.add('loading');
            
            // Show message preview
            if (messagePreview) {
                messagePreview.textContent = `Sending: "${message}"`;
                messagePreview.classList.add('show');
            }
            
            // Create a form and submit it as POST to /chat
            setTimeout(() => {
                // Create a hidden form
                const form = document.createElement('form');
                form.method = 'POST';
                form.action = '/chat';
                
                // Add the message as a hidden input
                const messageInput = document.createElement('input');
                messageInput.type = 'hidden';
                messageInput.name = 'message';
                messageInput.value = message;
                form.appendChild(messageInput);
                
                // Add the form to body and submit
                document.body.appendChild(form);
                form.submit();
            }, 1000);
        }
    }

    // Send button click
    sendButton.addEventListener('click', function(e) {
        e.stopPropagation();
        sendMessage();
    });

    // Enter key to send
    assistantInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            e.preventDefault();
            sendMessage();
        }
    });

    // Click outside to collapse
    document.addEventListener('click', function(e) {
        if (isExpanded && !askAssistant.contains(e.target)) {
            collapseButton();
        }
    });

    // Prevent input click from bubbling
    assistantInput.addEventListener('click', function(e) {
        e.stopPropagation();
    });

    // ESC key to collapse
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape' && isExpanded) {
            collapseButton();
        }
    });
}

// Main toggle function (works with whole button and main toggle)
function toggleSidebar() {
    const sidebar = document.getElementById('sidebar');
    const mainContainer = document.getElementById('mainContainer');
    
    if (sidebar && mainContainer) {
        sidebar.classList.toggle('collapsed');
        mainContainer.classList.toggle('sidebar-collapsed');
        
        updateArrowStates();
        
        const isCollapsed = sidebar.classList.contains('collapsed');
        localStorage.setItem('sidebarCollapsed', isCollapsed);
        
        console.log('Sidebar toggled:', isCollapsed ? 'collapsed' : 'expanded');
    }
}

// Collapse function (left arrow)
function collapseSidebar(event) {
    event.stopPropagation(); // Prevent double trigger
    
    const sidebar = document.getElementById('sidebar');
    const mainContainer = document.getElementById('mainContainer');
    const lbutton=document.getElementById('left-button')
    const rbutton=document.getElementById('right-button')

       
    
    if (sidebar && mainContainer && !sidebar.classList.contains('collapsed')) {
        sidebar.classList.add('collapsed');
        mainContainer.classList.add('sidebar-collapsed');
        lbutton.hidden = true;
        rbutton.hidden=false;
        updateArrowStates();
        localStorage.setItem('sidebarCollapsed', true);
        
        console.log('Sidebar collapsed via left arrow');
    }
}

// Expand function (right arrow)
function expandSidebar(event) {
    event.stopPropagation(); // Prevent double trigger
    
    const sidebar = document.getElementById('sidebar');
    const mainContainer = document.getElementById('mainContainer');
    const lbutton=document.getElementById('left-button')
    const rbutton=document.getElementById('right-button')

    
    if (sidebar && mainContainer && sidebar.classList.contains('collapsed')) {
        sidebar.classList.remove('collapsed');
        mainContainer.classList.remove('sidebar-collapsed');
        lbutton.hidden = false;
        rbutton.hidden=true;
        
        updateArrowStates();
        localStorage.setItem('sidebarCollapsed', false);
        
        console.log('Sidebar expanded via right arrow');
    }
}

// Update arrow visual states
function updateArrowStates() {
    const sidebar = document.getElementById('sidebar');
    const arrowLeft = document.querySelector('.arrow-left');
    const arrowRight = document.querySelector('.arrow-right');
    
    if (sidebar && arrowLeft && arrowRight) {
        const isCollapsed = sidebar.classList.contains('collapsed');
        
        if (isCollapsed) {
            // Collapsed - highlight right arrow (expand action)
            arrowLeft.classList.remove('active');
            arrowRight.classList.add('active');
        } else {
            // Expanded - highlight left arrow (collapse action)
            arrowLeft.classList.add('active');
            arrowRight.classList.remove('active');
        }
    }
}

// Load sidebar state on page load
function loadSidebarState() {
    const isCollapsed = localStorage.getItem('sidebarCollapsed') === 'true';
    const sidebar = document.getElementById('sidebar');
    const mainContainer = document.getElementById('mainContainer');
    
    if (isCollapsed && sidebar && mainContainer) {
        sidebar.classList.add('collapsed');
        mainContainer.classList.add('sidebar-collapsed');
    }
    
    // Set initial arrow states
    updateArrowStates();
}



function openAssistant() {
    const askAssistant = document.getElementById('askAssistant');
    if (askAssistant) {
        askAssistant.click();
    } else {
        // Fallback to direct navigation
        window.location.href = '/chat';
    }
}

// Search functionality
function initializeSearch() {
    const searchInput = document.querySelector('.search-input');
    const searchBtn = document.querySelector('.search-btn');

    if (searchInput) {
        searchInput.addEventListener('focus', function () {
            this.parentElement.style.transform = 'scale(1.02)';
            this.parentElement.style.boxShadow = '0 0 0 3px rgba(99, 102, 241, 0.1)';
        });

        searchInput.addEventListener('blur', function () {
            this.parentElement.style.transform = 'scale(1)';
            this.parentElement.style.boxShadow = 'none';
        });

        searchInput.addEventListener('input', function () {
            const query = this.value.toLowerCase();
            if (query.length > 0) {
                performSearch(query);
            }
        });
    }

    if (searchBtn) {
        searchBtn.addEventListener('click', function () {
            const query = searchInput.value.toLowerCase();
            if (query.length > 0) {
                performSearch(query);
            }
        });
    }
}

function performSearch(query) {
    const searchTerms = {
        'about': 'about-me',
        'me': 'about-me',
        'profile': 'about-me',
        'summary': 'summarization',
        'article': 'summarization',
        'articles': 'summarization',
        'summarization': 'summarization',
        'study': 'study-notes',
        'notes': 'study-notes',
        'learning': 'study-notes',
        'project': 'projects',
        'projects': 'projects',
        'portfolio': 'projects'
    };

    const targetSection = searchTerms[query];
    if (targetSection) {
        const navItem = document.querySelector(`[data-content="${targetSection}"]`);
        if (navItem) {
            navItem.click();
            if (searchInput) {
                searchInput.value = '';
            }
        }
    } else {
        const searchContainer = document.querySelector('.search-container');
        if (searchContainer) {
            searchContainer.style.animation = 'shake 0.5s ease';
            setTimeout(() => {
                searchContainer.style.animation = '';
            }, 500);
        }
    }
}

// Initialize animations
function initializeAnimations() {
    const cards = document.querySelectorAll('.feature-card, .side-card');
    cards.forEach((card, index) => {
        card.style.animationDelay = `${index * 0.1}s`;
        card.style.animation = 'floating 3s ease-in-out infinite';
    });

    const animatedElements = document.querySelectorAll('.nav-item, .feature-card, .side-card');
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.animation = 'fadeInUp 0.6s ease forwards';
                observer.unobserve(entry.target);
            }
        });
    }, { threshold: 0.1 });

    animatedElements.forEach(el => observer.observe(el));
}

// Keyboard shortcuts
function initializeKeyboardShortcuts() {
    document.addEventListener('keydown', function (e) {
        if (e.key === '/') {
            e.preventDefault();
            const searchInput = document.querySelector('.search-input');
            if (searchInput) {
                searchInput.focus();
            }
        }

        if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
            const activeNav = document.querySelector('.nav-item.active');
            const navItems = Array.from(document.querySelectorAll('.nav-item'));
            const currentIndex = navItems.indexOf(activeNav);

            let nextIndex;
            if (e.key === 'ArrowDown') {
                nextIndex = (currentIndex + 1) % navItems.length;
            } else {
                nextIndex = (currentIndex - 1 + navItems.length) % navItems.length;
            }

            navItems[nextIndex].click();
            e.preventDefault();
        }

        if (e.key === 'a' && e.ctrlKey) {
            e.preventDefault();
            openAssistant();
        }
    });
}

// Parallax effect
function initializeParallaxEffect() {
    document.addEventListener('mousemove', function (e) {
        const mouseX = e.clientX / window.innerWidth;
        const mouseY = e.clientY / window.innerHeight;

        const floatingElements = document.querySelectorAll('.logo-icon');
        floatingElements.forEach(el => {
            const speed = 3;
            el.style.transform += ` translate(${mouseX * speed}px, ${mouseY * speed}px)`;
        });
    });
}

// Utility functions
function smoothScrollTo(element) {
    element.scrollIntoView({
        behavior: 'smooth',
        block: 'start'
    });
}

function toggleTheme() {
    const body = document.body;
    body.classList.toggle('light-theme');
    localStorage.setItem('theme', body.classList.contains('light-theme') ? 'light' : 'dark');
}

function loadTheme() {
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme === 'light') {
        document.body.classList.add('light-theme');
    }
}

function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Add shake animation for search
const style = document.createElement('style');
style.textContent = `
    @keyframes shake {
        0%, 100% { transform: translateX(0); }
        25% { transform: translateX(-5px); }
        75% { transform: translateX(5px); }
    }
`;
document.head.appendChild(style);

// Export functions for potential module use
window.AIAssistant = {
    openAssistant,
    toggleTheme,
    smoothScrollTo,
    toggleSidebar,
    collapseSidebar,
    expandSidebar
};