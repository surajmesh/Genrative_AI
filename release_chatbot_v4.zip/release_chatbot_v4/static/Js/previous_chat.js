
// State management
let currentChatSession = null;
let isProcessing = false;
let chatMessages = [];

// DOM elements (will be initialized when document is loaded)
let chatContainer, messagesList, messageInput, sendButton, uploadButton, reasoningButton;
let newChatButton, chatSessionsList, sidebarToggle;

// Project view DOM elements
let viewProjectsBtn, chatView, projectsView, projectCreationView;
let newProjectBtn, projectForm, cancelCreateBtn, projectNameInput, projectDescriptionInput;
let projectsGrid, projectSearchInput, filterBtns;

/**
 * Set up global event handlers for the dropdown menu system
 */
function setupBulkSessionManagement() {
  // Set up a global click handler to close dropdowns when clicking outside
  document.addEventListener('click', function(e) {
    // If click is not inside a dropdown or menu button, close all dropdowns
    if (!e.target.closest('.session-dropdown-menu') && !e.target.closest('.session-menu-btn')) {
      document.querySelectorAll('.session-dropdown-menu.visible').forEach(menu => {
        menu.classList.remove('visible');
      });
    }
  });
  
  // Escape key handler to close dropdowns
  document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
      document.querySelectorAll('.session-dropdown-menu.visible').forEach(menu => {
        menu.classList.remove('visible');
      });
    }
  });
  
  // Delegate event listener for individual checkboxes
  document.addEventListener('change', function(e) {
    if (e.target.classList.contains('session-checkbox') && e.target.id !== 'select-all-sessions') {
      // Update select all checkbox
      updateSelectAllCheckbox();
      
      // Show/hide delete button based on selection
      updateDeleteSelectedButton();
    }
  });
}

/**
 * Update the state of the select all checkbox based on individual selections
 */
function updateSelectAllCheckbox() {
  const selectAllCheckbox = document.getElementById('select-all-sessions');
  const checkboxes = document.querySelectorAll('.session-checkbox:not(#select-all-sessions)');
  
  if (selectAllCheckbox) {
    // If all individual checkboxes are checked, check the select all checkbox
    const allChecked = Array.from(checkboxes).every(checkbox => checkbox.checked);
    selectAllCheckbox.checked = allChecked && checkboxes.length > 0;
  }
}

/**
 * Update the visibility of the delete selected button
 */
function updateDeleteSelectedButton() {
  const deleteSelectedBtn = document.getElementById('delete-selected-btn');
  const selectedCount = getSelectedSessionIds().length;
  
  if (deleteSelectedBtn) {
    deleteSelectedBtn.style.display = selectedCount > 0 ? 'flex' : 'none';
  }
}

/**
 * Get all selected session IDs
 * @returns {Array} Array of selected session IDs
 */
function getSelectedSessionIds() {
  const selectedIds = [];
  const checkboxes = document.querySelectorAll('.session-checkbox:not(#select-all-sessions):checked');
  
  checkboxes.forEach(checkbox => {
    const sessionId = checkbox.getAttribute('data-session-id');
    if (sessionId) {
      selectedIds.push(sessionId);
    }
  });
  
  return selectedIds;
}

/**
 * Show bulk delete confirmation dialog
 * @param {Array} sessionIds - Array of session IDs to delete
 */
function showBulkDeleteConfirmation(sessionIds) {
  // Show confirmation modal
  const modalOverlay = document.getElementById('bulk-delete-modal');
  const countElement = document.getElementById('bulk-delete-count');
  const confirmButton = document.getElementById('confirm-bulk-delete-btn');
  const cancelButton = document.getElementById('cancel-bulk-delete-btn');
  const closeButton = document.getElementById('close-bulk-delete-modal');
  
  if (modalOverlay && countElement) {
    // Update count text
    countElement.textContent = `You are about to delete ${sessionIds.length} conversation${sessionIds.length !== 1 ? 's' : ''}.`;
    
    // Show modal
    modalOverlay.style.display = 'flex';
    
    // Set up event listeners
    if (confirmButton) {
      confirmButton.onclick = function() {
        deleteBulkSessions(sessionIds);
        closeModal();
      };
    }
    
    if (cancelButton) {
      cancelButton.onclick = closeModal;
    }
    
    if (closeButton) {
      closeButton.onclick = closeModal;
    }
  }
  
  // Close modal function
  function closeModal() {
    modalOverlay.style.display = 'none';
  }
}

/**
 * Delete multiple chat sessions
 * @param {Array} sessionIds - Array of session IDs to delete
 */
function deleteBulkSessions(sessionIds) {
  if (!sessionIds || sessionIds.length === 0) return;
  
  fetch('/api/chat/sessions/bulk-delete', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ session_ids: sessionIds })
  })
  .then(response => response.json())
  .then(data => {
    if (data.success) {
      // Reload chat sessions
      loadChatSessions();
      
      // If current chat is deleted, show empty state
      if (currentChatSession && sessionIds.includes(currentChatSession)) {
        currentChatSession = null;
        showEmptyState();
      }
      
      // Reset select all checkbox
      const selectAllCheckbox = document.getElementById('select-all-sessions');
      if (selectAllCheckbox) {
        selectAllCheckbox.checked = false;
      }
      
      // Hide delete button
      updateDeleteSelectedButton();
    } else {
      console.error('Failed to delete sessions:', data.error);
    }
  })
  .catch(error => {
    console.error('Error deleting sessions:', error);
  });
}

document.addEventListener('DOMContentLoaded', function() {
  console.log('DOM loaded, initializing chat interface...');
  
  // Initialize DOM elements
  initElements();
  
  // Set up event listeners
  setupEventListeners();
  
  // Set up bulk session management
  setupBulkSessionManagement();
  
  // Identify key elements for debugging
  console.log('Sidebar element:', document.querySelector('.chat-sidebar'));
  console.log('Chat container element:', document.querySelector('.chat-container'));
  console.log('Chat sessions container:', document.querySelector('.chat-sidebar [style*="overflow-y: auto"]'));
  
  // Load chat sessions
  console.log('Loading chat sessions...');
  loadChatSessions();
  
  // Check URL for session ID parameter
  const urlParams = new URLSearchParams(window.location.search);
  const sessionIdParam = urlParams.get('session_id');
  console.log('URL session_id parameter:', sessionIdParam);
  
  if (sessionIdParam) {
    loadChatSession(sessionIdParam);
  } else {
    // Show empty state
    showEmptyState();
  }
});

/**
 * Initialize DOM element references
 */
function initElements() {
  chatContainer = document.querySelector('.chat-container');
  
  // For our new layout we'll find the element differently, but keep the same variable name for compatibility
  const chatContentElement = document.querySelector('.chat-content');
  if (chatContentElement) {
    messagesList = chatContentElement.querySelector('.chat-messages');
  } else {
    // Fallback
    messagesList = document.querySelector('.chat-messages');
  }
  
  messageInput = document.querySelector('.message-textarea');
  sendButton = document.querySelector('.send-btn');
  uploadButton = document.querySelector('.upload-btn');
  reasoningButton = document.querySelector('#reasoningButton');

  // document.getElementById('thinking-button').addEventListener('click', function () {
  //       console.log('thinking button hit')
  //   this.classList.toggle('active'); // Toggle active class for UI feedback
  //   });
  newChatButton = document.querySelector('.new-chat-item');
  // Use the correct selector for the restructured sidebar
  chatSessionsList = document.querySelector('.chat-sidebar .scrollable-content') || 
                     document.querySelector('.chat-sidebar [style*="overflow-y: auto"]');
  sidebarToggle = document.querySelector('.sidebar-toggle');


  // -----------------------------



  
  // Projects view elements
  viewProjectsBtn = document.getElementById('view-projects-btn');
  chatView = document.querySelector('.chat-view');
  projectsView = document.querySelector('.projects-view');
  projectCreationView = document.querySelector('.project-creation-view');
  
  // Project creation elements
  newProjectBtn = document.getElementById('new-project-btn');
  projectForm = document.getElementById('project-form');
  cancelCreateBtn = document.getElementById('cancel-create-btn');
  projectNameInput = document.getElementById('project-name');
  projectDescriptionInput = document.getElementById('project-description');
  projectsGrid = document.querySelector('.projects-grid');
  projectSearchInput = document.getElementById('project-search');
  filterBtns = document.querySelectorAll('.filter-btn');
  
  // Set up the prompt suggestions card
  suggestedPromptsCard = document.getElementById('suggested-prompts');
  if (suggestedPromptsCard) {
    const promptItems = suggestedPromptsCard.querySelectorAll('.prompt-item');
    promptItems.forEach(item => {
      item.addEventListener('click', function() {
        // Get the text content from the prompt-text span only
        const promptText = this.querySelector('.prompt-text').textContent.trim();
        
        if (messageInput) {
          messageInput.value = promptText;
          messageInput.focus();
          // Trigger input event to enable send button
          messageInput.dispatchEvent(new Event('input'));
          
          // Auto-send after a brief delay
          setTimeout(() => {
            if (!sendButton.disabled && !isProcessing) {
              sendMessage();
            }
          }, 300);
        }
      });
    });
  }
}



function setupEventListeners(messageInput) {
 
  // Projects view event listeners
  console.log('setupEventListeners')
  if (viewProjectsBtn) {
    viewProjectsBtn.addEventListener('click', function(e) {
      e.preventDefault();
      showProjectsView();
    });
  }
  
  if (newProjectBtn) {
    newProjectBtn.addEventListener('click', function() {
      showProjectCreationView();
    });
  }
  
  if (cancelCreateBtn) {
    cancelCreateBtn.addEventListener('click', function() {
      showProjectsView();
    });
  }
  
  if (projectForm) {
    projectForm.addEventListener('submit', function(e) {
      e.preventDefault();
      createProject();
    });
  }


  // ---------------------------------------

  // Image upload functionality
  const imageUploadButton = document.getElementById('image-upload-button');
  const fileUploadInput = document.getElementById('file-upload');
  const imagePreview = document.getElementById('image-preview');
  
  if (imageUploadButton && fileUploadInput) {
    imageUploadButton.addEventListener('click', function() {
      fileUploadInput.click();
    });
    
    fileUploadInput.addEventListener('change', function(e) {
      const files = Array.from(e.target.files);
      if (files.length > 0) {
        handleImageUpload(files);
      }
    });
  }
  
  // Deep thinking toggle
  const thinkingButton = document.getElementById('thinking-button');
  if (thinkingButton) {
    thinkingButton.addEventListener('click', function() {
      this.classList.toggle('active');
      console.log('this button is clicked')
      const statusIndicator = this.querySelector('.status-indicator');
      if (statusIndicator) {
        if (this.classList.contains('active')) {
          statusIndicator.style.backgroundColor = '#4CAF50';
        } else {
          statusIndicator.style.backgroundColor = '';
        }
      }
    });
  }
  
  // Provider selection
  const providerButtons = document.querySelectorAll('.provider-btn');
  providerButtons.forEach(btn => {
    btn.addEventListener('click', function() {
      // Remove active class from all provider buttons
      providerButtons.forEach(b => b.classList.remove('active'));
      // Add active class to clicked button
      this.classList.add('active');
      
      // Store selected provider
      const provider = this.getAttribute('data-provider');
      window.selectedProvider = provider;
    });
  });

  // Message input handling
  if (messageInput) {
    console.log('messageinput : ',messageInput)
    // Auto-resize textarea as user types
    messageInput.addEventListener('input', function() {
      this.style.height = 'auto';
      this.style.height = (this.scrollHeight) + 'px';
      
      // Enable/disable send button based on content
      const sendBtn = document.getElementById('send-btn');
      if (this.value.trim().length > 0) {
        sendBtn.disabled = false;
      } else {
        sendBtn.disabled = true;
      }
    });
    
    // Submit on Enter (but allow Shift+Enter for new line)
    messageInput.addEventListener('keydown', function(e) {
      if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        const sendBtn = document.getElementById('send-btn');
        if (!sendBtn.disabled && !isProcessing) {
          sendMessage();
        }
      }
    });
  }
  
  // Send button
  const sendBtn = document.getElementById('send-btn');
  if (sendBtn) {
    sendBtn.addEventListener('click', function() {
      if (!this.disabled && !isProcessing) {
        sendMessage();
      }
    });
  }
  
  // New chat button
  if (newChatButton) {
    newChatButton.addEventListener('click', createNewChat);
  }
  
  // Upload button
  if (uploadButton) {
    uploadButton.addEventListener('click', showUploadModal);
  }
  
  // Deep Thinking (Reasoning) toggle button
  if (reasoningButton) {
    reasoningButton.addEventListener('click', function() {
      // Toggle active state
      this.classList.toggle('active');
      
      // Update UI feedback (tooltip or similar)
      if (this.classList.contains('active')) {
        showNotification('Deep Thinking mode enabled. The AI will provide more detailed reasoning in its next response.', 'info');
      }
    });
  }
  
  // Sidebar toggle for mobile
  if (sidebarToggle) {
    sidebarToggle.addEventListener('click', function() {
      document.querySelector('.chat-sidebar').classList.toggle('sidebar-open');
    });
  }
  
  // Toggle sidebar button in header
  const toggleSidebarBtn = document.querySelector('.toggle-sidebar-btn');
  if (toggleSidebarBtn) {
    toggleSidebarBtn.addEventListener('click', function() {
      const sidebar = document.querySelector('.chat-sidebar');
      const chatMain = document.querySelector('.chat-main');
      const searchBar = document.querySelector('.search-bar-container');
      
      if (!sidebar || !chatMain) {
        console.error('Could not find sidebar or main elements!');
        return;
      }
      
      // Toggle the classes
      const isHidden = sidebar.classList.contains('sidebar-hidden');
      
      // Special handling to force visual update in Replit webview
      if (isHidden) {
        // If it's currently hidden, show it
        sidebar.style.transform = 'translateX(0)';
        sidebar.style.opacity = '1';
        sidebar.style.width = '280px';
        sidebar.style.minWidth = '280px';
        chatMain.style.marginLeft = '0'; 
        sidebar.classList.remove('sidebar-hidden');
        chatMain.classList.remove('full-width');
        
        // Hide search bar when sidebar is visible
        if (searchBar) {
          searchBar.classList.remove('visible');
          searchBar.classList.remove('expanded');
        }
      } else {
        // If it's currently visible, hide it
        sidebar.style.transform = 'translateX(-280px)';
        sidebar.style.opacity = '0';
        sidebar.style.width = '0';
        sidebar.style.minWidth = '0';
        chatMain.style.marginLeft = '0';
        sidebar.classList.add('sidebar-hidden');
        chatMain.classList.add('full-width');
        
        // Show search bar when sidebar is hidden
        if (searchBar) {
          // Wait for sidebar animation to complete before showing search bar
          setTimeout(() => {
            searchBar.classList.add('visible');
          }, 300);
        }
      }
      
      // Force repaint to ensure animation works on all browsers
      void sidebar.offsetHeight;
      
      // Log to console for debugging
      console.log('Sidebar toggle clicked. Hidden:', sidebar.classList.contains('sidebar-hidden'));
    });
  }
  
  // Search bar functionality
  const searchIcon = document.querySelector('.search-bar-container .search-icon');
  const searchInput = document.querySelector('.search-bar-container input');
  const searchBarContainer = document.querySelector('.search-bar-container');
  
  if (searchIcon && searchInput && searchBarContainer) {
    // Click on search icon to toggle expanded state
    searchIcon.addEventListener('click', function() {
      searchBarContainer.classList.toggle('expanded');
      
      if (searchBarContainer.classList.contains('expanded')) {
        // Focus input when expanded
        searchInput.focus();
        // Add class to main content to adjust padding
        document.querySelector('.chat-main').classList.add('search-expanded');
      } else {
        // Remove expanded class from main content
        document.querySelector('.chat-main').classList.remove('search-expanded');
      }
    });
    
    // Handle ESC key to collapse search
    searchInput.addEventListener('keydown', function(e) {
      if (e.key === 'Escape') {
        searchBarContainer.classList.remove('expanded');
        document.querySelector('.chat-main').classList.remove('search-expanded');
      }
    });
    
    // Search functionality
    searchInput.addEventListener('input', function(e) {
      const searchTerm = e.target.value.toLowerCase();
      
      // Only search if we have at least 2 characters
      if (searchTerm.length >= 2) {
        // Get all session elements
        const sessions = document.querySelectorAll('.chat-session');
        
        // Filter sessions based on search term
        sessions.forEach(session => {
          const title = session.querySelector('.chat-session-title').textContent.toLowerCase();
          
          if (title.includes(searchTerm)) {
            session.style.display = '';
          } else {
            session.style.display = 'none';
          }
        });
      } else {
        // Show all sessions if search is cleared
        document.querySelectorAll('.chat-session').forEach(session => {
          session.style.display = '';
        });
      }
    });
  }
  
  // Check toggle sidebar immediately after page load
  if (toggleSidebarBtn) {
    console.log('Sidebar toggle button found:', toggleSidebarBtn);
  } else {
    console.error('Sidebar toggle button not found!');
  }
  
  // Add event delegation for session rename buttons and other interactive elements
  document.addEventListener('click', function(e) {
    // Check if clicked element is a rename button
    if (e.target.closest('.rename-session-btn')) {
      const btn = e.target.closest('.rename-session-btn');
      const sessionId = btn.getAttribute('data-session-id');
      const sessionEl = btn.closest('.chat-session');
      const titleEl = sessionEl.querySelector('.chat-session-title');
      
      // Show rename modal
      showRenameModal(sessionId, titleEl.textContent);
    }
    
    // Check for example message clicks in welcome screen
    if (e.target.closest('.example-item')) {
      const exampleItem = e.target.closest('.example-item');
      const exampleText = exampleItem.querySelector('.example-text').textContent;
      
      // Strip the quotes from the example
      const cleanText = exampleText.replace(/^"(.+)"$/, '$1');
      
      // Set the message in the textarea
      if (messageInput) {
        messageInput.value = cleanText;
        messageInput.focus();
        
        // Trigger input event to enable the send button
        const inputEvent = new Event('input', { bubbles: true });
        messageInput.dispatchEvent(inputEvent);
        
        // Auto-send the message after a short delay
        setTimeout(() => {
          const sendBtn = document.getElementById('send-btn');
          if (!sendBtn.disabled && !isProcessing) {
            sendMessage();
          }
        }, 300);
      }
    }
    
    // Check for double-click on session title to rename
    if (e.target.closest('.chat-session-title') && e.detail === 2) {
      const titleEl = e.target.closest('.chat-session-title');
      const sessionEl = titleEl.closest('.chat-session');
      const sessionId = sessionEl.getAttribute('data-session-id');
      
      // Show rename modal
      showRenameModal(sessionId, titleEl.textContent);
    }
    
    // Check if header search button was clicked
    if (e.target.closest('.chat-header-actions button[title="Search"]')) {
      const searchBarContainer = document.querySelector('.search-bar-container');
      const toggleSidebarBtn = document.querySelector('.toggle-sidebar-btn');
      const sidebar = document.querySelector('.chat-sidebar');
      
      if (searchBarContainer && sidebar && !sidebar.classList.contains('sidebar-hidden')) {
        // If sidebar is visible, hide it first (this will show the search bar)
        if (toggleSidebarBtn) {
          toggleSidebarBtn.click();
          
          // Wait for sidebar to hide, then expand search
          setTimeout(() => {
            searchBarContainer.classList.add('expanded');
            document.querySelector('.chat-main').classList.add('search-expanded');
            document.querySelector('.search-bar-container input').focus();
          }, 300);
        }
      } else if (searchBarContainer) {
        // If sidebar is already hidden, just toggle the expanded state
        searchBarContainer.classList.toggle('expanded');
        
        if (searchBarContainer.classList.contains('expanded')) {
          document.querySelector('.chat-main').classList.add('search-expanded');
          document.querySelector('.search-bar-container input').focus();
        } else {
          document.querySelector('.chat-main').classList.remove('search-expanded');
        }
      }
    }
  });
}

// Image upload handler function
function handleImageUpload(files) {
  const imagePreview = document.getElementById('image-preview');
  const formData = new FormData();
  
  files.forEach(file => {
    formData.append('images', file);
  });
  
  // Show preview
  files.forEach(file => {
    const reader = new FileReader();
    reader.onload = function(e) {
      const imgElement = document.createElement('div');
      imgElement.className = 'image-preview-item';
      imgElement.innerHTML = `
        <img src="${e.target.result}" alt="Preview" style="max-width: 100px; max-height: 100px;">
        <button class="remove-image" onclick="removeImagePreview(this)">×</button>
      `;
      imagePreview.appendChild(imgElement);
    };
    reader.readAsDataURL(file);
  });
  
  // Store files for sending
  window.uploadedFiles = files;
}

function removeImagePreview(button) {
  button.parentElement.remove();
  if (document.getElementById('image-preview').children.length === 0) {
    window.uploadedFiles = [];
  }
}


/**
 * Show upload file modal
 */
function showUploadModal() {
  // Create modal HTML
  const modalHtml = `
    <div class="modal-overlay" id="uploadModal">
      <div class="modal-container">
        <div class="modal-header">
          <h3>Upload Image</h3>
          <button class="modal-close">&times;</button>
        </div>
        <div class="modal-body">
          <div class="file-upload-area" id="dropArea">
            <p>Drag and drop your image here or click to browse</p>
            <input type="file" id="fileUpload" class="file-upload-input" accept="image/*">
            <label for="fileUpload" class="file-upload-btn">Choose File</label>
          </div>
          <div id="uploadPreview" style="display: none; text-align: center;">
            <img id="previewImage" style="max-width: 100%; max-height: 300px; border-radius: 4px;">
            <p id="previewFilename" class="mt-2"></p>
          </div>
        </div>
        <div class="modal-footer">
          <button class="btn btn-secondary" id="cancelUpload">Cancel</button>
          <button class="btn btn-primary" id="confirmUpload" disabled>Upload</button>
        </div>
      </div>
    </div>
  `;
  
  // Add modal to body
  document.body.insertAdjacentHTML('beforeend', modalHtml);
  
  // Get modal elements
  const modal = document.getElementById('uploadModal');
  const closeButton = modal.querySelector('.modal-close');
  const cancelButton = document.getElementById('cancelUpload');
  const confirmButton = document.getElementById('confirmUpload');
  const fileInput = document.getElementById('fileUpload');
  const dropArea = document.getElementById('dropArea');
  const previewContainer = document.getElementById('uploadPreview');
  const previewImage = document.getElementById('previewImage');
  const previewFilename = document.getElementById('previewFilename');
  
  let selectedFile = null;
  
  // Setup event listeners
  closeButton.addEventListener('click', closeModal);
  cancelButton.addEventListener('click', closeModal);
  
  // File input change
  fileInput.addEventListener('change', function(e) {
    const file = e.target.files[0];
    if (file) {
      handleFileSelection(file);
    }
  });
  
  // Drag and drop
  ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
    dropArea.addEventListener(eventName, preventDefaults, false);
  });
  
  function preventDefaults(e) {
    e.preventDefault();
    e.stopPropagation();
  }
  
  // Highlight drop area when dragging file over it
  ['dragenter', 'dragover'].forEach(eventName => {
    dropArea.addEventListener(eventName, function() {
      dropArea.classList.add('drag-over');
    });
  });
  
  ['dragleave', 'drop'].forEach(eventName => {
    dropArea.addEventListener(eventName, function() {
      dropArea.classList.remove('drag-over');
    });
  });
  
  // Handle dropped files
  dropArea.addEventListener('drop', function(e) {
    const file = e.dataTransfer.files[0];
    if (file) {
      handleFileSelection(file);
    }
  });
  
  // Upload confirmation
  confirmButton.addEventListener('click', function() {
    if (selectedFile && currentChatSession) {
      uploadFile(selectedFile);
      closeModal();
    }
  });
  
  // Handle file selection
  function handleFileSelection(file) {
    if (!file.type.match('image.*')) {
      showNotification('Please select an image file (JPG, PNG, GIF)', 'error');
      return;
    }
    
    selectedFile = file;
    
    // Show preview
    const reader = new FileReader();
    reader.onload = function(e) {
      previewImage.src = e.target.result;
      previewFilename.textContent = file.name;
      dropArea.style.display = 'none';
      previewContainer.style.display = 'block';
      confirmButton.disabled = false;
    };
    reader.readAsDataURL(file);
  }
  
  // Close modal function
  function closeModal() {
    modal.remove();
  }
}

/**
 * Upload file to the server
 * @param {File} file - The file to upload
 */
function uploadFile(file) {
  if (!currentChatSession) {
    showNotification('Please start a new chat before uploading', 'warning');
    return;
  }
  
  // Show uploading message
  const uploadingMessageEl = addMessage('Uploading image...', 'user', true);
  
  const formData = new FormData();
  formData.append('file', file);
  formData.append('session_id', currentChatSession);
  
  // Display uploading state
  isProcessing = true;
  
  fetch('/api/upload', {
    method: 'POST',
    body: formData
  })
  .then(response => response.json())
  .then(data => {
    // Remove uploading placeholder
    if (uploadingMessageEl) {
      uploadingMessageEl.remove();
    }
    
    if (data.success) {
      // Add the file as a user message
      addMessage(`<p>[Image uploaded: ${file.name}]</p>`, 'user');
      
      // Add AI response with analysis
      addMessage(data.analysis, 'assistant');
      
      // Update state
      scrollToBottom();
    } else {
      showNotification('Error uploading file: ' + data.error, 'error');
      addMessage('Error uploading file: ' + data.error, 'system');
    }
  })
  .catch(error => {
    console.error('Upload error:', error);
    showNotification('Upload failed', 'error');
    
    // Remove loading placeholder
    if (uploadingMessageEl) {
      uploadingMessageEl.remove();
    }
    
    // Add error message
    addMessage('Failed to upload file. Please try again.', 'system');
  })
  .finally(() => {
    isProcessing = false;
  });
}

/**
 * Load all chat sessions for the sidebar
 */
function loadChatSessions() {
  console.log('Fetching chat sessions from API...');
  fetch('/api/chat/sessions')
    .then(response => {
      console.log('API response status:', response.status);
      return response.json();
    })
    .then(data => {
      console.log('Chat sessions API data:', data);
      if (data.success && data.sessions) {
        console.log(`Rendering ${data.sessions.length} chat sessions`);
        renderChatSessions(data.sessions);
      } else {
        console.error('Failed to load chat sessions:', data.error);
      }
    })
    .catch(error => {
      console.error('Error loading chat sessions:', error);
    });
}

/**
 * Render chat sessions in the sidebar
 * @param {Array} sessions - List of chat sessions
 */
function renderChatSessions(sessions) {
  console.log('Rendering chat sessions:', sessions);
  console.log('Chat sessions container:', chatSessionsList);
  
  if (!chatSessionsList) {
    console.error('Chat sessions container not found!');
    
    // Try to find it again with a more specific selector
    chatSessionsList = document.querySelector('.chat-sidebar [style*="overflow-y: auto"]');
    console.log('Retry finding container:', chatSessionsList);
    
    if (!chatSessionsList) {
      console.error('Still could not find chat sessions container. Check HTML structure.');
      return;
    }
  }
  
  // Clear existing sessions
  chatSessionsList.innerHTML = '';
  console.log('Cleared sessions container. Sessions count:', sessions.length);
  
  if (sessions.length === 0) {
    chatSessionsList.innerHTML = '<div style="font-size: 0.8rem; color: var(--text-light); text-align: center; padding: 12px 0; opacity: 0.7;">No chat sessions yet</div>';
    return;
  }
  
  // Add each session to the list
  sessions.forEach(session => {
    const sessionEl = document.createElement('div');
    sessionEl.classList.add('chat-session');
    sessionEl.setAttribute('data-session-id', session.id);
    
    // If this is the current session, highlight it
    if (currentChatSession && session.id === currentChatSession) {
      sessionEl.classList.add('active');
    }
    
    sessionEl.innerHTML = `
      <div class="chat-session-title" title="Click to open this conversation">${session.name}</div>
      <div class="chat-session-actions">
        <button class="session-menu-btn" data-session-id="${session.id}" title="Menu">
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <circle cx="12" cy="12" r="1"></circle>
            <circle cx="12" cy="5" r="1"></circle>
            <circle cx="12" cy="19" r="1"></circle>
          </svg>
        </button>
        <div class="session-dropdown-menu" id="dropdown-${session.id}">
          <button class="star-session-btn" data-session-id="${session.id}">
            <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon>
            </svg>
            Star
          </button>
          <button class="rename-session-btn" data-session-id="${session.id}">
            <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <path d="M12 20h9"></path>
              <path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"></path>
            </svg>
            Rename
          </button>
          <button class="delete-session-btn" data-session-id="${session.id}">
            <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <polyline points="3 6 5 6 21 6"></polyline>
              <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
            </svg>
            Delete
          </button>
        </div>
      </div>
    `;
    
    // Add click event to load this session
    sessionEl.addEventListener('click', function(e) {
      // Ignore clicks on menu button or dropdown items
      if (e.target.closest('.session-menu-btn') || 
          e.target.closest('.session-dropdown-menu') ||
          e.target.closest('.star-session-btn') ||
          e.target.closest('.rename-session-btn') ||
          e.target.closest('.delete-session-btn')) {
        return;
      }
      
      loadChatSession(session.id);
    });
    
    // Add menu button click handler to toggle dropdown
    const menuBtn = sessionEl.querySelector('.session-menu-btn');
    menuBtn.addEventListener('click', function(e) {
      e.stopPropagation();
      
      // Get the dropdown for this session
      const dropdown = document.getElementById(`dropdown-${session.id}`);
      
      // Close all other dropdowns first
      document.querySelectorAll('.session-dropdown-menu.visible').forEach(menu => {
        if (menu.id !== `dropdown-${session.id}`) {
          menu.classList.remove('visible');
        }
      });
      
      // Toggle this dropdown
      dropdown.classList.toggle('visible');
      
      // Add a one-time click handler to close the dropdown when clicking outside
      setTimeout(() => {
        const closeDropdown = function(e) {
          if (!e.target.closest(`#dropdown-${session.id}`) && 
              !e.target.closest(`.session-menu-btn[data-session-id="${session.id}"]`)) {
            dropdown.classList.remove('visible');
            document.removeEventListener('click', closeDropdown);
          }
        };
        document.addEventListener('click', closeDropdown);
      }, 0);
    });
    
    // Add star button click handler (placeholder for now)
    const starBtn = sessionEl.querySelector('.star-session-btn');
    starBtn.addEventListener('click', function(e) {
      e.stopPropagation();
      // Close the dropdown
      document.getElementById(`dropdown-${session.id}`).classList.remove('visible');
      // Show notification (just a placeholder, not implemented yet)
      showNotification('Starring conversations coming soon', 'info');
    });
    
    // Add rename button click handler
    const renameBtn = sessionEl.querySelector('.rename-session-btn');
    renameBtn.addEventListener('click', function(e) {
      e.stopPropagation();
      // Close the dropdown
      document.getElementById(`dropdown-${session.id}`).classList.remove('visible');
      // Show rename modal
      showRenameModal(session.id, session.name);
    });
    
    // Add delete button click handler
    const deleteBtn = sessionEl.querySelector('.delete-session-btn');
    deleteBtn.addEventListener('click', function(e) {
      e.stopPropagation();
      // Close the dropdown
      document.getElementById(`dropdown-${session.id}`).classList.remove('visible');
      // Show delete confirmation
      confirmDeleteSession(session.id, session.name);
    });
    
    chatSessionsList.appendChild(sessionEl);
  });
}

/**
 * Show confirmation dialog for deleting a chat session
 * @param {string} sessionId - ID of the session to delete
 * @param {string} sessionName - Name of the session to delete
 */
function confirmDeleteSession(sessionId, sessionName) {
  // Create modal HTML
  const modalHtml = `
    <div class="modal-overlay" id="deleteConfirmModal">
      <div class="modal-container">
        <div class="modal-header">
          <h3>Delete Chat Session</h3>
          <button class="modal-close">&times;</button>
        </div>
        <div class="modal-body">
          <p>Are you sure you want to delete the chat session "${sessionName}"?</p>
          <p class="text-danger">This action cannot be undone.</p>
        </div>
        <div class="modal-footer">
          <button class="btn btn-secondary" id="cancelDelete">Cancel</button>
          <button class="btn btn-danger" id="confirmDelete">Delete</button>
        </div>
      </div>
    </div>
  `;
  
  // Add modal to body
  document.body.insertAdjacentHTML('beforeend', modalHtml);
  
  // Get modal elements
  const modal = document.getElementById('deleteConfirmModal');
  const closeButton = modal.querySelector('.modal-close');
  const cancelButton = document.getElementById('cancelDelete');
  const confirmButton = document.getElementById('confirmDelete');
  
  // Setup event listeners
  closeButton.addEventListener('click', closeModal);
  cancelButton.addEventListener('click', closeModal);
  
  // Delete confirmation
  confirmButton.addEventListener('click', function() {
    deleteSession(sessionId);
    closeModal();
  });
  
  // Close modal function
  function closeModal() {
    modal.remove();
  }
}

/**
 * Delete a chat session
 * @param {string} sessionId - ID of the session to delete
 */
function deleteSession(sessionId) {
  fetch(`/api/chat/sessions/${sessionId}`, {
    method: 'DELETE'
  })
    .then(response => response.json())
    .then(data => {
      if (data.success) {
        // Reload sessions list
        loadChatSessions();
        
        // If the deleted session was the current one, show empty state
        if (currentChatSession === sessionId) {
          currentChatSession = null;
          showEmptyState();
          // Update URL
          window.history.replaceState({}, document.title, '/chat');
        }
        
        showNotification('Chat session deleted', 'success');
      } else {
        showNotification('Failed to delete session: ' + data.error, 'error');
      }
    })
    .catch(error => {
      console.error('Error deleting session:', error);
      showNotification('Error deleting session', 'error');
    });
}
let currentChatId = null;
/**
 * Create a new chat session
 * This is called when the user clicks the New Chat button
 * Rather than creating a session immediately, we'll just clear the current session
 * and let the user start typing. The session will be created with an auto-generated title
 * when they send their first message.
 */
function createNewChat() {
  // Clear current session
  currentChatSession = null;
  let currentChatId = null;

  const chatId = "chat_" + Date.now();
    
    // Generate session ID and sync it with chatId
    currentChatSession = generateSessionId();
    currentChatId = chatId;
  
  // Update URL (remove session parameter)
  window.history.replaceState({}, document.title, '/chat');
  
  // Update header
  const chatHeader = document.querySelector('.chat-header h2');
  if (chatHeader) {
    chatHeader.textContent = 'New Chat';
  }
  chatHistory[chatId] = {
        id: chatId,
        session_id: currentChatSession, // Add this line
        title: "New Conversation",
        timestamp: Date.now(),
        messages: []
    };

    currentChatTitle.textContent = "New Conversation";
  // Clear session ID in DOM elements
  document.querySelector('#sessionId')?.setAttribute('value', '');
  document.querySelector('.chat-messages-container')?.setAttribute('data-session-id', '');
  
  // Show empty state
  showEmptyState();
  
  // Focus input field
  if (messageInput) {
    messageInput.focus();
  }
  
  // Highlight active session in sidebar (none)
  const allSessions = document.querySelectorAll('.chat-session');
  allSessions.forEach(el => el.classList.remove('active'));
}

/**
 * Load a specific chat session
 * @param {string} sessionId - ID of the session to load
 */
function loadChatSession(sessionId) {
  fetch(`/api/chat/sessions/${sessionId}`)
    .then(response => response.json())
    .then(data => {
      if (data.success) {
        currentChatSession = sessionId;
        
        // Hide suggested prompts when loading a session with messages
        if (suggestedPromptsCard && data.messages && data.messages.length > 0) {
          suggestedPromptsCard.style.display = 'none';
        } else if (suggestedPromptsCard) {
          suggestedPromptsCard.style.display = 'block';
        }
        
        // Update URL with session ID
        window.history.replaceState({}, document.title, `/chat?session_id=${sessionId}`);
        
        // Update hidden inputs with session ID for voice recorder
        document.querySelector('#sessionId')?.setAttribute('value', sessionId);
        document.querySelector('.chat-messages-container')?.setAttribute('data-session-id', sessionId);
        
        // Update header with session name
        const chatHeader = document.querySelector('.chat-header h2');
        if (chatHeader) {
          chatHeader.textContent = data.session.name;
        }
        
        // Clear messages
        if (messagesList) {
          messagesList.innerHTML = '';
        }
        
        // Add messages to the chat
        if (data.messages && data.messages.length > 0) {
          // Hide suggested prompts when loading a chat with messages
          if (suggestedPromptsCard) {
            suggestedPromptsCard.style.display = 'none';
          }
          
          data.messages.forEach(msg => {
            addMessage(msg.content, msg.role, false, msg.timestamp);
          });
          
          // Scroll to bottom
          scrollToBottom();
        } else {
          // Show suggested prompts for empty chats
          if (suggestedPromptsCard) {
            suggestedPromptsCard.style.display = 'block';
          }
        }
        
        // Update active session in sidebar
        highlightActiveSession(sessionId);
        
        // Focus input field
        if (messageInput) {
          messageInput.focus();
        }
      } else {
        showNotification('Failed to load chat session: ' + data.error, 'error');
      }
    })
    .catch(error => {
      console.error('Error loading chat session:', error);
      showNotification('Error loading chat session', 'error');
    });
}

/**
 * Highlight the active session in the sidebar
 * @param {string} sessionId - ID of the active session
 */
function highlightActiveSession(sessionId) {
  if (!chatSessionsList) return;
  
  // Remove active class from all sessions
  const allSessions = chatSessionsList.querySelectorAll('.chat-session');
  allSessions.forEach(el => el.classList.remove('active'));
  
  // Add active class to current session
  const activeSession = chatSessionsList.querySelector(`.chat-session[data-session-id="${sessionId}"]`);
  if (activeSession) {
    activeSession.classList.add('active');
  }
}

/**
 * Show rename modal for chat session
 * @param {string} sessionId - ID of the session to rename
 * @param {string} currentName - Current name of the session
 */
function showRenameModal(sessionId, currentName) {
  // Create modal HTML
  const modalHtml = `
    <div class="modal-overlay" id="renameModal">
      <div class="modal-container">
        <div class="modal-header">
          <h3>Rename Chat Session</h3>
          <button class="modal-close">&times;</button>
        </div>
        <div class="modal-body">
          <div class="form-group">
            <label for="sessionName">Session Name</label>
            <input type="text" id="sessionName" class="form-control" value="${currentName}">
          </div>
        </div>
        <div class="modal-footer">
          <button class="btn btn-secondary" id="cancelRename">Cancel</button>
          <button class="btn btn-primary" id="confirmRename">Save</button>
        </div>
      </div>
    </div>
  `;
  
  // Add modal to body
  document.body.insertAdjacentHTML('beforeend', modalHtml);
  
  // Get modal elements
  const modal = document.getElementById('renameModal');
  const closeButton = modal.querySelector('.modal-close');
  const cancelButton = document.getElementById('cancelRename');
  const confirmButton = document.getElementById('confirmRename');
  const nameInput = document.getElementById('sessionName');
  
  // Focus and select the name input
  nameInput.focus();
  nameInput.select();
  
  // Setup event listeners
  closeButton.addEventListener('click', closeModal);
  cancelButton.addEventListener('click', closeModal);
  
  // Handle input enter key
  nameInput.addEventListener('keydown', function(e) {
    if (e.key === 'Enter') {
      e.preventDefault();
      confirmButton.click();
    }
  });
  
  // Rename confirmation
  confirmButton.addEventListener('click', function() {
    const newName = nameInput.value.trim();
    if (newName) {
      renameSession(sessionId, newName);
      closeModal();
    }
  });
  
  // Close modal function
  function closeModal() {
    modal.remove();
  }
}

/**
 * Rename a chat session
 * @param {string} sessionId - ID of the session to rename
 * @param {string} newName - New name for the session
 */
function renameSession(sessionId, newName) {
  fetch(`/api/chat/sessions/${sessionId}/rename`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      name: newName
    })
  })
    .then(response => response.json())
    .then(data => {
      if (data.success) {
        // Reload sessions list
        loadChatSessions();
        
        // Update header if this is the current session
        if (currentChatSession === sessionId) {
          const chatHeader = document.querySelector('.chat-header h2.header-title');
          if (chatHeader) {
            chatHeader.textContent = newName;
          }
        }
        
        showNotification('Chat session renamed', 'success');
      } else {
        showNotification('Failed to rename session: ' + data.error, 'error');
      }
    })
    .catch(error => {
      console.error('Error renaming session:', error);
      showNotification('Error renaming session', 'error');
    });
}

/**
 * Handle the case when no chat is selected - show a welcome message
 */
function showEmptyState() {
  // Clear messages
  const chatMessagesElement = document.querySelector('.chat-messages');
  if (chatMessagesElement) {
    chatMessagesElement.innerHTML = '';
  }
  
  // Prompt suggestions will be added as part of the welcome screen
  
  // Get user name
  const userName = getUserName() || 'there';
  
  // Create Claude-style welcome state with clickable examples
  const emptyStateHtml = `
    <div class="welcome-screen">
      <div class="welcome-icon">
        <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="#3498db" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <circle cx="12" cy="12" r="10"></circle>
          <line x1="12" y1="16" x2="12" y2="12"></line>
          <line x1="12" y1="8" x2="12.01" y2="8"></line>
        </svg>
      </div>
      <h2 class="welcome-heading">What's new, ${userName}?</h2>
      <div class="welcome-input-prompt">
        <p>How can I help you today with your construction or electrical project?</p>
      </div>
      <div class="welcome-examples">
        <div class="example-row">
          <div class="example-item">
            <span class="example-icon">⚡</span>
            <span class="example-text">"Explain electrical load calculations for a 2000 sq ft residential building"</span>
          </div>
          <div class="example-item">
            <span class="example-icon">🛡️</span>
            <span class="example-text">"Help me understand OSHA requirements for scaffolding on a commercial project"</span>
          </div>
        </div>
        <div class="example-row">
          <div class="example-item">
            <span class="example-icon">📋</span>
            <span class="example-text">"Draft a project plan timeline for kitchen renovation with electrical work"</span>
          </div>
          <div class="example-item">
            <span class="example-icon">♻️</span>
            <span class="example-text">"What are the best practices for managing construction waste?"</span>
          </div>
        </div>
      </div>
    </div>
  `;
  
  // Only insert the empty state if there's a chat messages element
  if (chatMessagesElement) {
    chatMessagesElement.innerHTML = emptyStateHtml;
    
    // Add click event listeners to the example items
    const exampleItems = chatMessagesElement.querySelectorAll('.example-item');
    exampleItems.forEach(item => {
      item.addEventListener('click', () => {
        const exampleText = item.querySelector('.example-text').textContent;
        // Remove quotes from the example text
        const cleanText = exampleText.replace(/^"|"$/g, '');
        if (messageInput) {
          messageInput.value = cleanText;
          messageInput.focus();
          // Trigger a send after a short delay
          setTimeout(() => sendMessage(), 100);
        }
      });
    });
  }
  
  // Update header title
  const chatHeader = document.querySelector('.chat-header h2.header-title');
  if (chatHeader) {
    chatHeader.textContent = 'New Conversation';
  }
  
  // Reset current chat session
  currentChatSession = null;
  
  // Focus input field
  if (messageInput) {
    messageInput.focus();
  }
}

/**
 * Get the user's name from local storage or from the page
 * @returns {string} The user's name or null if not found
 */
function getUserName() {
  // Try to get from element on page
  const userElement = document.querySelector('.sidebar-footer span');
  if (userElement && userElement.dataset.username) {
    return userElement.dataset.username;
  }
  
  // If not found, return null (will use "there" as fallback)
  return null;
}


function sendMessage(messageInputElement) {
  console.log('send message');
 

  // if (!messageInputElement || isProcessing) return;

  const message = messageInputElement;
  if (message.length === 0) return;

  if (!currentChatSession) {
    isProcessing = true;
    sendMessageToAPI(message);
  } else {
    sendMessageToAPI(message);
    console.log('else before send message api');
  }

  // Clear input and reset height of the input element
  messageInputElement.value = '';
}
/**
 * Send message to the API
 * @param {string} message - The message to send
 */
// ------------------------------

function  sendMessageToAPI(message) {
  console.log('sendMessageToAPI API...');
  
  // Add user message to the chat
  addMessage(message, 'user');
  
  const loadingEl = addLoadingIndicator();
  isProcessing = true;

  const reasoningBtn = document.getElementById('reasoningButton');
  const useReasoning = thinkingButton?.classList.contains('active') || false;
  if (reasoningBtn && useReasoning) {
    reasoningBtn.classList.remove('active');
  }

  return fetch('/api/chat/messages', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      message: message,
      session_id: currentChatSession,
      use_reasoning: useReasoning  // ✅ Send true/false here
    })
  })
    .then(async response => {
      if (!response.ok) {
        throw new Error(`HTTP error! Status: ${response.status}`);
      }

      const data = await response.json();

      if (loadingEl) loadingEl.remove();

      if (data.success && data.response) {
        console.log('Data Success:', data);

        let responseWithMetadata = data.response;

        if (data.provider && data.model) {
          responseWithMetadata += `
            <div class="model-info">
              Generated by: ${data.provider} | ${data.model}
            </div>`;
        }

        addMessage(responseWithMetadata, 'assistant');

        // Session updates
        if (data.session_id && data.session_id !== currentChatSession) {
          currentChatSession = data.session_id;
          window.history.replaceState({}, document.title, `/chat?session_id=${data.session_id}`);
          document.querySelector('#sessionId')?.setAttribute('value', data.session_id);
          document.querySelector('.chat-messages-container')?.setAttribute('data-session-id', data.session_id);
          const chatHeader = document.querySelector('.chat-header h2.header-title');
          if (chatHeader && data.session_name) {
            chatHeader.textContent = data.session_name;
          }
          loadChatSessions();
        }

        // ✅ Return only the plain response text (if needed)
        return data.response;

      } else {
        showNotification(`Error: ${data.error || 'Unexpected error'}`, 'error');
        addMessage('Sorry, there was an error processing your request.', 'system');
        throw new Error(data.error || 'API returned unsuccessful response');
      }
    })
    .catch(error => {
      if (loadingEl) loadingEl.remove();
      console.error('API Error:', error);
      showNotification('Error communicating with the server', 'error');
      addMessage('Sorry, there was an error communicating with the server.', 'system');
      throw error; // ❗ Important: Re-throw to catch in outer try-catch
    })
    .finally(() => {
      isProcessing = false;
      scrollToBottom();
    });
}

function generateSessionId() {
  return 'session_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
}


function sendMessageToAPI(message) {
  console.log('sendMessageToAPI API...');
  
  
  // Add user message to the chat
  addMessage(message, 'user');
  
  const loadingEl = addLoadingIndicator();
  isProcessing = true;

  // Get selected provider
  
  console.log(window.selectedProvider)
  const selectedProvider = window.selectedProvider || 'google';

  const thinkingButton = document.getElementById('thinking-button');
  const useReasoning = thinkingButton?.classList.contains('active') || false;


  // if (reasoningBtn && useReasoning) {
  //   reasoningBtn.classList.remove('active');
  // }
  
  // Ensure we have a session_id
  if (!currentChatSession) {
    currentChatSession = currentChatId;
  }
  // const formData = new FormData();
  // formData.append('message', message);
  // formData.append('session_id', currentChatSession);
  // formData.append('use_reasoning', useReasoning);
  // formData.append('provider', selectedProvider);

  // // Add uploaded files if any
  // if (window.uploadedFiles && window.uploadedFiles.length > 0) {
  //   window.uploadedFiles.forEach(file => {
  //     formData.append('images', file); // backend should accept "images"
  //   });
  // }

  // // Send using multipart/form-data (Content-Type will be auto-set)
  // return fetch('/api/chat/messages', {
  //   method: 'POST',
  //   body: formData,
  // })
    
  // Prepare form data for file upload
   const payload = {
    message: message,
    session_id: currentChatSession,
    use_reasoning: useReasoning,
    provider: selectedProvider
  };
  // Add uploaded files if any
  if (window.uploadedFiles && window.uploadedFiles.length > 0) {
    window.uploadedFiles.forEach(file => {
      formData.append('images', file);
    });
  }

  return fetch('/api/chat/messages', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(payload)
  })
    .then(async response => {
      if (!response.ok) {
        throw new Error(`HTTP error! Status: ${response.status}`);
      }

      const data = await response.json();

      if (loadingEl) loadingEl.remove();

      if (data.success && data.response) {
        console.log('Data Success:', data);

        // let responseWithMetadata = null
        let responseWithMetadata = `
          ${data.response}
          
        `;
        // let responseWithMetadata = `
        //   <p>${data.response}</p>
        //   <div style="font-size: 12px; color: gray; margin-top: 4px;">
        //     ${data.session_name ? `<div>📝 <strong>Session:</strong> ${data.session_name}</div>` : ''}
        //     ${data.provider && data.model ? `<div>⚙️ <strong>Model:</strong> ${data.provider} | ${data.model}</div>` : ''}
        //   </div>
        // `;

        // let responseWithMetadata = `
        //   <div>${data.response}</div>
        // `;

        // // Add session name and model info
        // if (data.session_name || data.model || data.provider) {
        //   responseWithMetadata += `
        //     <div class="meta-info">
        //       ${data.session_name ? `<div class="session-name">Session: ${data.session_name}</div>` : ''}
        //       ${data.provider && data.model ? `<div class="model-name">Generated by: ${data.provider} | ${data.model}</div>` : ''}
        //     </div>
        //   `;
        // }
        // console.log(responseWithMetadata)
        // let responseWithMetadata = data.response;

        // if (data.provider && data.model) {
        //   responseWithMetadata += `
        //     <div class="model-info">
        //       Generated by: ${data.provider} | ${data.model}
        //     </div>`;
        // }

        addMessage(responseWithMetadata, 'assistant');

        // Clear uploaded files after sending
        if (window.uploadedFiles) {
          window.uploadedFiles = [];
          document.getElementById('image-preview').innerHTML = '';
        }
        
        // Reset thinking button
        if (thinkingButton && thinkingButton.classList.contains('active')) {
          thinkingButton.classList.remove('active');
          const statusIndicator = thinkingButton.querySelector('.status-indicator');
          if (statusIndicator) {
            statusIndicator.style.backgroundColor = '';
          }
        }

        // Session updates
        if (data.session_id && data.session_id !== currentChatSession) {
          currentChatSession = data.session_id;
          window.history.replaceState({}, document.title, `/chat?session_id=${data.session_id}`);
          document.querySelector('#sessionId')?.setAttribute('value', data.session_id);
          document.querySelector('.chat-messages-container')?.setAttribute('data-session-id', data.session_id);
          const chatHeader = document.querySelector('.chat-header h2.header-title');
          if (chatHeader && data.session_name) {
            chatHeader.textContent = data.session_name;
          }
          loadChatSessions();
        }

        // return data.response;
        console.log(responseWithMetadata)
        return responseWithMetadata;

      } else {
        showNotification(`Error: ${data.error || 'Unexpected error'}`, 'error');
        addMessage('Sorry, there was an error processing your request.', 'system');
        throw new Error(data.error || 'API returned unsuccessful response');
      }
    })
    .catch(error => {
      if (loadingEl) loadingEl.remove();
      console.error('API Error:', error);
      showNotification('Error communicating with the server', 'error');
      addMessage('Sorry, there was an error communicating with the server.', 'system');
      throw error;
    })
    .finally(() => {
      isProcessing = false;
      scrollToBottom();
    });
}

// NOT Working

// function sendMessageToAPI(message) {
//   console.log('sendMessageToAPI API...');

//   addMessage(message, 'user');
//   const loadingEl = addLoadingIndicator();
//   isProcessing = true;

//   const selectedProvider = window.selectedProvider || 'google';
//   const thinkingButton = document.getElementById('thinking-button');
//   const useReasoning = thinkingButton?.classList.contains('active') || false;

//   if (!currentChatSession) {
//     currentChatSession = currentChatId;
//   }

//   // Check if there are uploaded files
//   const hasFiles = window.uploadedFiles && window.uploadedFiles.length > 0;

//   // Use FormData for both text and file data
//   const formData = new FormData();
//   formData.append('message', message);
//   formData.append('session_id', currentChatSession);
//   formData.append('use_reasoning', useReasoning);
//   formData.append('provider', selectedProvider);

//   // Append files if any
//   if (hasFiles) {
//     window.uploadedFiles.forEach(file => {
//       formData.append('files', file);  // Must match request.files.getlist('files') in backend
//     });
//   }

//   return fetch('/api/chat/messages', {
//     method: 'POST',
//     body: formData  // Automatically sets multipart/form-data
//   })
//     .then(async response => {
//       if (!response.ok) throw new Error(`HTTP error! Status: ${response.status}`);
//       const data = await response.json();

//       if (loadingEl) loadingEl.remove();

//       if (data.success && data.response) {
//         const responseWithMetadata = `
//           ${data.response}
//         `;

//         addMessage(responseWithMetadata, 'assistant');

//         // Clear uploaded files after sending
//         if (window.uploadedFiles) {
//           window.uploadedFiles = [];
//           document.getElementById('image-preview').innerHTML = '';
//         }

//         // Reset thinking button state
//         if (thinkingButton && thinkingButton.classList.contains('active')) {
//           thinkingButton.classList.remove('active');
//           const statusIndicator = thinkingButton.querySelector('.status-indicator');
//           if (statusIndicator) {
//             statusIndicator.style.backgroundColor = '';
//           }
//         }

//         // Update chat session
//         if (data.session_id && data.session_id !== currentChatSession) {
//           currentChatSession = data.session_id;
//           window.history.replaceState({}, document.title, `/chat?session_id=${data.session_id}`);
//           document.querySelector('#sessionId')?.setAttribute('value', data.session_id);
//           document.querySelector('.chat-messages-container')?.setAttribute('data-session-id', data.session_id);
//           const chatHeader = document.querySelector('.chat-header h2.header-title');
//           if (chatHeader && data.session_name) {
//             chatHeader.textContent = data.session_name;
//           }
//           loadChatSessions();
//         }

//         return responseWithMetadata;
//       } else {
//         showNotification(`Error: ${data.error || 'Unexpected error'}`, 'error');
//         addMessage('Sorry, there was an error processing your request.', 'system');
//         throw new Error(data.error || 'API returned unsuccessful response');
//       }
//     })
//     .catch(error => {
//       if (loadingEl) loadingEl.remove();
//       console.error('API Error:', error);
//       showNotification('Error communicating with the server', 'error');
//       addMessage('Sorry, there was an error communicating with the server.', 'system');
//       throw error;
//     })
//     .finally(() => {
//       isProcessing = false;
//       scrollToBottom();
//     });
// }

// ------------------------------


/**
 * Add a message to the chat
 * @param {string} content - Message content
 * @param {string} role - Message role ('user', 'assistant', 'system')
 * @param {boolean} isLoading - Whether this is a loading placeholder
 * @param {string} timestamp - Optional timestamp string
 * @returns {HTMLElement} The message element
 */


function addMessage(content, role, isLoading = false, timestamp = null) {
  // debugger;
  console.log('adddmesafd----',content)
  // Use new chat messages container for our fixed layout
  const chatContentElement = document.querySelector('.chat-content');
  if (!chatContentElement) return null;
  
  const chatMessagesElement = chatContentElement.querySelector('.chat-messages');
  if (!chatMessagesElement) return null;
  
  // Clear welcome screen if this is the first message
  const welcomeScreen = chatMessagesElement.querySelector('.welcome-screen');
  if (welcomeScreen) {
    welcomeScreen.remove();
  }
  
  // Welcome screen already removed, no need to do anything else
  
  // Create message wrapper (contains avatar and bubble)
  const messageWrapper = document.createElement('div');
  messageWrapper.classList.add('message-wrapper', `${role}-wrapper`);
  
  // Create message element
  const messageEl = document.createElement('div');
  console.log(messageEl,"message e1")
  messageEl.classList.add('message', `message-${role}`);
  
  // Create avatar element
  const avatarEl = document.createElement('div');
  avatarEl.classList.add('message-avatar');
  
  // Set avatar content based on role
  if (role === 'user') {
    avatarEl.innerHTML = `<div class="user-avatar">LV</div>`;
  } else if (role === 'assistant') {
    avatarEl.innerHTML = `<div class="assistant-avatar">
      <svg viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg" class="bot-avatar-icon">
        <path d="M16 8.5C11.0366 8.5 7 12.3137 7 17C7 21.6863 11.0366 25.5 16 25.5C20.9634 25.5 25 21.6863 25 17C25 12.3137 20.9634 8.5 16 8.5Z" fill="#3498db"></path>
      </svg>
    </div>`;
  }
  
  // If this is a loading indicator, add loading class
  if (isLoading) {
    messageEl.classList.add('message-loading');
  }
  
  // Parse markdown/HTML in messages from the assistant
  let messageContent = content;
  console.log('messageContent', messageContent);

  if (role === 'assistant') {
    // Actually, we're passing HTML directly for now
    // In a real app, you'd want to sanitize this or use a markdown parser
  }
  
  // Format the timestamp
  let timeDisplay = '';
  if (timestamp) {
    const date = new Date(timestamp);
    timeDisplay = `<div class="message-timestamp">${date.toLocaleTimeString()}</div>`;
  } else if (!isLoading) {
    const now = new Date();
    timeDisplay = `<div class="message-timestamp">${now.toLocaleTimeString()}</div>`;
  }
  
  // Set message content
  // messageEl.innerHTML = `
  //   <div class="message-content">${messageContent}</div>
  //   ${timeDisplay}
  // `;
//   messageEl.innerHTML = `
//   ${messageContent}
//   ${timeDisplay}
// `;

// messageEl.innerHTML = `
//   <div class="message-content">
//     ${messageContent}
//   </div>
//   ${timeDisplay}
// `;
  // Add avatar and message to the wrapper
  if (role === 'user') {
    messageWrapper.appendChild(messageEl);
    messageWrapper.appendChild(avatarEl);
  } else {
    messageWrapper.appendChild(avatarEl);
    messageWrapper.appendChild(messageEl);
  }
  
  // Add to messages list
  chatMessagesElement.appendChild(messageWrapper);
  
  // Scroll to the bottom
  scrollToBottom();
  
  return messageEl;
}

/**
 * Add a loading indicator while waiting for AI response
 * @returns {HTMLElement} The loading indicator element
 */
function addLoadingIndicator() {
  // Use the new chat message container
  const chatContentElement = document.querySelector('.chat-content');
  if (!chatContentElement) return null;
  
  const chatMessagesElement = chatContentElement.querySelector('.chat-messages');
  if (!chatMessagesElement) return null;
  
  // Clear welcome screen if this is the first message
  const welcomeScreen = chatMessagesElement.querySelector('.welcome-screen');
  if (welcomeScreen) {
    welcomeScreen.remove();
  }
  
  // Welcome screen already removed
  
  // Create message wrapper (contains avatar and bubble)
  const messageWrapper = document.createElement('div');
  messageWrapper.classList.add('message-wrapper', 'assistant-wrapper');
  
  // Create avatar element
  const avatarEl = document.createElement('div');
  avatarEl.classList.add('message-avatar');
  avatarEl.innerHTML = `<div class="assistant-avatar">
    <svg viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg" class="bot-avatar-icon">
      <path d="M16 8.5C11.0366 8.5 7 12.3137 7 17C7 21.6863 11.0366 25.5 16 25.5C20.9634 25.5 25 21.6863 25 17C25 12.3137 20.9634 8.5 16 8.5Z" fill="#3498db"></path>
    </svg>
  </div>`;
  
  // Create message element with loading indicator
  const loadingEl = document.createElement('div');
  loadingEl.classList.add('message', 'message-assistant', 'message-loading');
  
  loadingEl.innerHTML = `
    <div class="loading-dots">
      <div class="loading-dot"></div>
      <div class="loading-dot"></div>
      <div class="loading-dot"></div>
    </div>
  `;
  
  // Add avatar and loading to the wrapper
  messageWrapper.appendChild(avatarEl);
  messageWrapper.appendChild(loadingEl);
  
  // Add to messages list
  chatMessagesElement.appendChild(messageWrapper);
  scrollToBottom();
  
  return messageWrapper;
}

/**
 * Scroll the messages container to the bottom
 */
function scrollToBottom() {
  // Use the new chat message container
  const chatContentElement = document.querySelector('.chat-content');
  if (!chatContentElement) return;
  
  const chatMessagesElement = chatContentElement.querySelector('.chat-messages');
  if (chatMessagesElement) {
    chatMessagesElement.scrollTop = chatMessagesElement.scrollHeight;
  }
}

/**
 * Show projects view
 * This function hides the chat view and shows the projects view
 */
function showProjectsView() {
  // Reset any active element in the chat
  currentChatSession = null;
  
  // Hide the chat view
  if (chatView) {
    chatView.classList.add('hidden');
  }
  
  // Hide project creation view if visible
  if (projectCreationView) {
    projectCreationView.classList.add('hidden');
  }
  
  // Show the projects view
  if (projectsView) {
    projectsView.classList.remove('hidden');
  }
  
  // Highlight the active sidebar item
  document.querySelectorAll('.sidebar-item').forEach(item => {
    item.classList.remove('active');
  });
  if (viewProjectsBtn) {
    viewProjectsBtn.closest('.sidebar-item').classList.add('active');
  }
  
  // Load projects
  loadProjects();
}

/**
 * Show chat view
 * This function hides projects view and shows the chat view
 */
function showChatView() {
  // Hide the projects view
  if (projectsView) {
    projectsView.classList.add('hidden');
  }
  
  // Hide project creation view
  if (projectCreationView) {
    projectCreationView.classList.add('hidden');
  }
  
  // Show the chat view
  if (chatView) {
    chatView.classList.remove('hidden');
  }
  
  // If there's no active chat session, show empty state
  if (!currentChatSession) {
    showEmptyState();
  }
  
  // Highlight the active sidebar item
  document.querySelectorAll('.sidebar-item').forEach(item => {
    item.classList.remove('active');
  });
}

/**
 * Show project creation view
 * This function hides projects view and shows the project creation form
 */
function showProjectCreationView() {
  // Hide the projects view
  if (projectsView) {
    projectsView.classList.add('hidden');
  }
  
  // Show the project creation view
  if (projectCreationView) {
    projectCreationView.classList.remove('hidden');
  }
  
  // Focus on project name input
  if (projectNameInput) {
    projectNameInput.focus();
  }
}

/**
 * Load projects 
 * This function fetches projects from the API and renders them
 */
function loadProjects() {
  fetch('/api/projects')
    .then(response => response.json())
    .then(data => {
      if (data.success && data.projects) {
        renderProjects(data.projects);
      } else {
        console.error('Failed to load projects:', data.error);
      }
    })
    .catch(error => {
      console.error('Error loading projects:', error);
    });
}

/**
 * Render projects in the grid
 * @param {Array} projects - List of projects
 */
function renderProjects(projects) {
  if (!projectsGrid) return;
  
  // Clear existing projects
  projectsGrid.innerHTML = '';
  
  if (projects.length === 0) {
    // Show empty state
    projectsGrid.innerHTML = `
      <div class="projects-empty-state">
        <div class="empty-state-icon">📁</div>
        <h3>No projects yet</h3>
        <p>Create a project to organize your conversations</p>
      </div>
    `;
    return;
  }
  
  // Add projects to the grid
  projects.forEach(project => {
    const projectCard = document.createElement('div');
    projectCard.className = 'project-card';
    projectCard.setAttribute('data-project-id', project.id);
    
    // Format date
    const createdDate = new Date(project.created_at);
    const formattedDate = createdDate.toLocaleDateString();
    
    // Show star if starred
    const starIcon = project.is_starred ? 
      '<span class="star-icon starred">★</span>' : 
      '<span class="star-icon">☆</span>';
    
    projectCard.innerHTML = `
      <div class="project-card-header">
        <h3 class="project-title">${project.name}</h3>
        ${starIcon}
      </div>
      <p class="project-description">${project.description || 'No description'}</p>
      <div class="project-meta">
        <span class="project-date">Created: ${formattedDate}</span>
        <span class="project-chats-count">${project.chat_count || 0} chats</span>
      </div>
      <div class="project-actions">
        <button class="btn-icon project-edit-btn" title="Edit Project">
          <i class="fas fa-edit"></i>
        </button>
        <button class="btn-icon project-delete-btn" title="Delete Project">
          <i class="fas fa-trash"></i>
        </button>
      </div>
    `;
    
    // Add click event to open project
    projectCard.addEventListener('click', function(e) {
      // Don't trigger if clicking on action buttons
      if (!e.target.closest('.project-actions')) {
        openProject(project.id);
      }
    });
    
    // Add click event for star icon
    const starElement = projectCard.querySelector('.star-icon');
    if (starElement) {
      starElement.addEventListener('click', function(e) {
        e.stopPropagation(); // Prevent opening the project
        toggleProjectStar(project.id);
      });
    }
    
    // Add click event for edit button
    const editBtn = projectCard.querySelector('.project-edit-btn');
    if (editBtn) {
      editBtn.addEventListener('click', function(e) {
        e.stopPropagation(); // Prevent opening the project
        showEditProjectModal(project);
      });
    }
    
    // Add click event for delete button
    const deleteBtn = projectCard.querySelector('.project-delete-btn');
    if (deleteBtn) {
      deleteBtn.addEventListener('click', function(e) {
        e.stopPropagation(); // Prevent opening the project
        showDeleteProjectModal(project.id, project.name);
      });
    }
    
    projectsGrid.appendChild(projectCard);
  });
}

/**
 * Create a new project
 */
function createProject() {
  const name = projectNameInput ? projectNameInput.value.trim() : '';
  const description = projectDescriptionInput ? projectDescriptionInput.value.trim() : '';
  
  if (!name) {
    // Show error
    showNotification('Project name is required', 'error');
    return;
  }
  
  const projectData = {
    name: name,
    description: description
  };
  
  fetch('/api/projects', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(projectData)
  })
  .then(response => response.json())
  .then(data => {
    if (data.success) {
      // Reset form
      if (projectForm) {
        projectForm.reset();
      }
      
      // Show success message
      showNotification('Project created successfully', 'success');
      
      // Return to projects view
      showProjectsView();
    } else {
      console.error('Failed to create project:', data.error);
      showNotification('Failed to create project: ' + (data.error || 'Unknown error'), 'error');
    }
  })
  .catch(error => {
    console.error('Error creating project:', error);
    showNotification('Error creating project', 'error');
  });
}

/**
 * Open a project
 * @param {string} projectId - ID of the project to open
 */
function openProject(projectId) {
  fetch(`/api/projects/${projectId}`)
    .then(response => response.json())
    .then(data => {
      if (data.success) {
        // Show project details in a modal
        showProjectDetailsModal(data.project);
      } else {
        console.error('Failed to open project:', data.error);
      }
    })
    .catch(error => {
      console.error('Error opening project:', error);
    });
}

/**
 * Show project details modal
 * @param {Object} project - Project data
 */
function showProjectDetailsModal(project) {
  // Create modal HTML
  const modalHtml = `
    <div class="modal-overlay" id="projectDetailsModal">
      <div class="modal-container large-modal">
        <div class="modal-header">
          <h3>${project.name}</h3>
          <button class="modal-close">&times;</button>
        </div>
        <div class="modal-body">
          <div class="project-details">
            <p class="project-description">${project.description || 'No description'}</p>
            
            <h4>Conversations in this project</h4>
            <div class="project-sessions">
              ${renderProjectSessions(project.chat_sessions)}
            </div>
          </div>
        </div>
        <div class="modal-footer">
          <button class="btn btn-secondary" id="closeProjectModal">Close</button>
          <button class="btn btn-primary" id="returnToChatBtn">Return to Chat</button>
        </div>
      </div>
    </div>
  `;
  
  // Add modal to body
  document.body.insertAdjacentHTML('beforeend', modalHtml);
  
  // Get modal elements
  const modal = document.getElementById('projectDetailsModal');
  const closeButton = modal.querySelector('.modal-close');
  const closeModalButton = document.getElementById('closeProjectModal');
  const returnToChatButton = document.getElementById('returnToChatBtn');
  
  // Set up event listeners
  closeButton.addEventListener('click', closeModal);
  closeModalButton.addEventListener('click', closeModal);
  
  if (returnToChatButton) {
    returnToChatButton.addEventListener('click', function() {
      closeModal();
      showChatView();
    });
  }
  
  // Add click event for session items
  const sessionItems = modal.querySelectorAll('.project-session-item');
  sessionItems.forEach(item => {
    item.addEventListener('click', function() {
      const sessionId = this.getAttribute('data-session-id');
      if (sessionId) {
        closeModal();
        showChatView();
        loadChatSession(sessionId);
      }
    });
  });
  
  // Close modal function
  function closeModal() {
    modal.remove();
  }
}

/**
 * Render chat sessions for a project
 * @param {Array} sessions - List of chat sessions in the project
 * @returns {string} HTML for the sessions
 */
function renderProjectSessions(sessions) {
  if (!sessions || sessions.length === 0) {
    return '<p class="empty-sessions">No conversations in this project yet.</p>';
  }
  
  let sessionsHtml = '<ul class="project-sessions-list">';
  
  sessions.forEach(session => {
    sessionsHtml += `
      <li class="project-session-item" data-session-id="${session.id}">
        <span class="session-title">${session.name}</span>
        <span class="session-date">${new Date(session.timestamp).toLocaleDateString()}</span>
      </li>
    `;
  });
  
  sessionsHtml += '</ul>';
  return sessionsHtml;
}

/**
 * Toggle the starred status of a project
 * @param {string} projectId - ID of the project to toggle
 */
function toggleProjectStar(projectId) {
  fetch(`/api/projects/${projectId}/toggle-star`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    }
  })
  .then(response => response.json())
  .then(data => {
    if (data.success) {
      // Reload projects
      loadProjects();
    } else {
      console.error('Failed to toggle project star:', data.error);
    }
  })
  .catch(error => {
    console.error('Error toggling project star:', error);
  });
}

/**
 * Show edit project modal
 * @param {Object} project - Project data
 */
function showEditProjectModal(project) {
  // Create modal HTML
  const modalHtml = `
    <div class="modal-overlay" id="editProjectModal">
      <div class="modal-container">
        <div class="modal-header">
          <h3>Edit Project</h3>
          <button class="modal-close">&times;</button>
        </div>
        <div class="modal-body">
          <form id="edit-project-form">
            <div class="form-group">
              <label for="edit-project-name">Project Name</label>
              <input type="text" id="edit-project-name" value="${project.name}" required>
            </div>
            <div class="form-group">
              <label for="edit-project-description">Description (optional)</label>
              <textarea id="edit-project-description">${project.description || ''}</textarea>
            </div>
          </form>
        </div>
        <div class="modal-footer">
          <button class="btn btn-secondary" id="cancelEditProject">Cancel</button>
          <button class="btn btn-primary" id="saveEditProject">Save Changes</button>
        </div>
      </div>
    </div>
  `;
  
  // Add modal to body
  document.body.insertAdjacentHTML('beforeend', modalHtml);
  
  // Get modal elements
  const modal = document.getElementById('editProjectModal');
  const closeButton = modal.querySelector('.modal-close');
  const cancelButton = document.getElementById('cancelEditProject');
  const saveButton = document.getElementById('saveEditProject');
  const nameInput = document.getElementById('edit-project-name');
  const descriptionInput = document.getElementById('edit-project-description');
  
  // Set up event listeners
  closeButton.addEventListener('click', closeModal);
  cancelButton.addEventListener('click', closeModal);
  
  // Save button
  saveButton.addEventListener('click', function() {
    const name = nameInput.value.trim();
    
    if (!name) {
      showNotification('Project name is required', 'error');
      return;
    }
    
    const projectData = {
      name: name,
      description: descriptionInput.value.trim()
    };
    
    updateProject(project.id, projectData, closeModal);
  });
  
  // Close modal function
  function closeModal() {
    modal.remove();
  }
}

/**
 * Update a project
 * @param {string} projectId - ID of the project to update
 * @param {Object} projectData - Updated project data
 * @param {function} callback - Function to call after successful update
 */
function updateProject(projectId, projectData, callback) {
  fetch(`/api/projects/${projectId}`, {
    method: 'PUT',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(projectData)
  })
  .then(response => response.json())
  .then(data => {
    if (data.success) {
      // Show success message
      showNotification('Project updated successfully', 'success');
      
      // Reload projects
      loadProjects();
      
      // Call callback if provided
      if (typeof callback === 'function') {
        callback();
      }
    } else {
      console.error('Failed to update project:', data.error);
      showNotification('Failed to update project', 'error');
    }
  })
  .catch(error => {
    console.error('Error updating project:', error);
    showNotification('Error updating project', 'error');
  });
}

/**
 * Show delete project confirmation modal
 * @param {string} projectId - ID of the project to delete
 * @param {string} projectName - Name of the project to delete
 */
function showDeleteProjectModal(projectId, projectName) {
  // Create modal HTML
  const modalHtml = `
    <div class="modal-overlay" id="deleteProjectModal">
      <div class="modal-container">
        <div class="modal-header">
          <h3>Delete Project</h3>
          <button class="modal-close">&times;</button>
        </div>
        <div class="modal-body">
          <p>Are you sure you want to delete the project "${projectName}"?</p>
          <p class="warning-text">This will remove the project and unlink all associated conversations. The conversations themselves will not be deleted.</p>
        </div>
        <div class="modal-footer">
          <button class="btn btn-secondary" id="cancelDeleteProject">Cancel</button>
          <button class="btn btn-danger" id="confirmDeleteProject">Delete Project</button>
        </div>
      </div>
    </div>
  `;
  
  // Add modal to body
  document.body.insertAdjacentHTML('beforeend', modalHtml);
  
  // Get modal elements
  const modal = document.getElementById('deleteProjectModal');
  const closeButton = modal.querySelector('.modal-close');
  const cancelButton = document.getElementById('cancelDeleteProject');
  const confirmButton = document.getElementById('confirmDeleteProject');
  
  // Set up event listeners
  closeButton.addEventListener('click', closeModal);
  cancelButton.addEventListener('click', closeModal);
  
  // Confirm button
  confirmButton.addEventListener('click', function() {
    deleteProject(projectId, closeModal);
  });
  
  // Close modal function
  function closeModal() {
    modal.remove();
  }
}

/**
 * Delete a project
 * @param {string} projectId - ID of the project to delete
 * @param {function} callback - Function to call after successful deletion
 */
function deleteProject(projectId, callback) {
  fetch(`/api/projects/${projectId}`, {
    method: 'DELETE'
  })
  .then(response => response.json())
  .then(data => {
    if (data.success) {
      // Show success message
      showNotification('Project deleted successfully', 'success');
      
      // Reload projects
      loadProjects();
      
      // Call callback if provided
      if (typeof callback === 'function') {
        callback();
      }
    } else {
      console.error('Failed to delete project:', data.error);
      showNotification('Failed to delete project', 'error');
    }
  })
  .catch(error => {
    console.error('Error deleting project:', error);
    showNotification('Error deleting project', 'error');
  });
}

/**
 * Show notification
 * @param {string} message - Notification message
 * @param {string} type - Notification type ('success', 'error', 'warning')
 */
function showNotification(message, type = 'info') {
  const notification = document.createElement('div');
  notification.className = `notification ${type}`;
  notification.textContent = message;
  
  // Add to container or body
  const container = document.querySelector('.notification-container') || document.body;
  container.appendChild(notification);
  
  // Remove after timeout
  setTimeout(() => {
    notification.classList.add('fade-out');
    setTimeout(() => {
      notification.remove();
    }, 300);
  }, 3000);
}
