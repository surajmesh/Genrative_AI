/**
 * File upload handling for the construction/electrical AI assistant
 * 
 * This file handles the file upload functionality and image preview
 */

document.addEventListener('DOMContentLoaded', function() {
  // If we have a file upload form, initialize it
  const fileUploadForm = document.getElementById('fileUploadForm');
  if (fileUploadForm) {
    initFileUpload();
  }
});

/**
 * Initialize file upload functionality
 */
function initFileUpload() {
  const fileInput = document.getElementById('fileInput');
  const previewContainer = document.getElementById('previewContainer');
  const previewImage = document.getElementById('previewImage');
  const fileLabel = document.querySelector('.file-label');
  const uploadButton = document.getElementById('uploadButton');
  const dropArea = document.getElementById('dropArea');
  
  if (!fileInput || !previewContainer || !previewImage || !fileLabel || !uploadButton || !dropArea) {
    console.error('Missing file upload elements');
    return;
  }
  
  // File input change event
  fileInput.addEventListener('change', function(e) {
    const file = this.files[0];
    if (file) {
      handleFileSelection(file);
    }
  });
  
  // Prevent default behaviors for drag and drop events
  ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
    dropArea.addEventListener(eventName, preventDefaults, false);
  });
  
  function preventDefaults(e) {
    e.preventDefault();
    e.stopPropagation();
  }
  
  // Highlight drop area when dragging file over it
  ['dragenter', 'dragover'].forEach(eventName => {
    dropArea.addEventListener(eventName, function() {
      dropArea.classList.add('drag-over');
    });
  });
  
  ['dragleave', 'drop'].forEach(eventName => {
    dropArea.addEventListener(eventName, function() {
      dropArea.classList.remove('drag-over');
    });
  });
  
  // Handle dropped files
  dropArea.addEventListener('drop', function(e) {
    const file = e.dataTransfer.files[0];
    if (file) {
      fileInput.files = e.dataTransfer.files;
      handleFileSelection(file);
    }
  });
}

/**
 * Handle file selection for upload
 * @param {File} file - The selected file
 */
function handleFileSelection(file) {
  const fileInput = document.getElementById('fileInput');
  const previewContainer = document.getElementById('previewContainer');
  const previewImage = document.getElementById('previewImage');
  const fileLabel = document.querySelector('.file-label');
  const uploadButton = document.getElementById('uploadButton');
  const fileError = document.getElementById('fileError');
  
  if (!file.type.match('image.*')) {
    if (fileError) {
      fileError.textContent = 'Please select an image file (JPG, PNG, GIF)';
      fileError.style.display = 'block';
    }
    fileInput.value = '';
    return;
  }
  
  // Clear previous error
  if (fileError) {
    fileError.style.display = 'none';
  }
  
  // Update file label
  if (fileLabel) {
    fileLabel.textContent = file.name;
  }
  
  // Enable upload button
  if (uploadButton) {
    uploadButton.disabled = false;
  }
  
  // Show image preview
  const reader = new FileReader();
  reader.onload = function(e) {
    previewImage.src = e.target.result;
    previewContainer.style.display = 'block';
  };
  reader.readAsDataURL(file);
}

/**
 * Upload file to the server through AJAX
 * @param {string} formId - ID of the form element
 * @param {Function} callback - Callback function after upload completes
 */
function uploadFile(formId, callback) {
  const form = document.getElementById(formId);
  if (!form) return;
  
  const formData = new FormData(form);
  const uploadStatusEl = document.getElementById('uploadStatus');
  const uploadProgress = document.getElementById('uploadProgress');
  
  // Show upload status
  if (uploadStatusEl) {
    uploadStatusEl.textContent = 'Uploading...';
    uploadStatusEl.style.display = 'block';
  }
  
  // Show progress bar
  if (uploadProgress) {
    uploadProgress.style.display = 'block';
    uploadProgress.value = 0;
  }
  
  // Create AJAX request
  const xhr = new XMLHttpRequest();
  
  // Progress event
  xhr.upload.addEventListener('progress', function(e) {
    if (e.lengthComputable && uploadProgress) {
      const percentComplete = (e.loaded / e.total) * 100;
      uploadProgress.value = percentComplete;
    }
  });
  
  // Load event
  xhr.addEventListener('load', function() {
    if (uploadStatusEl) {
      if (xhr.status === 200) {
        uploadStatusEl.textContent = 'Upload complete!';
        uploadStatusEl.className = 'text-success';
        
        // Call callback with response
        if (callback) {
          try {
            const response = JSON.parse(xhr.responseText);
            callback(null, response);
          } catch (error) {
            callback(error);
          }
        }
      } else {
        uploadStatusEl.textContent = 'Upload failed: ' + xhr.statusText;
        uploadStatusEl.className = 'text-danger';
        
        if (callback) {
          callback(new Error(xhr.statusText));
        }
      }
    }
  });
  
  // Error event
  xhr.addEventListener('error', function() {
    if (uploadStatusEl) {
      uploadStatusEl.textContent = 'Upload failed: Network error';
      uploadStatusEl.className = 'text-danger';
    }
    
    if (callback) {
      callback(new Error('Network error'));
    }
  });
  
  // Open and send request
  xhr.open('POST', form.action);
  xhr.send(formData);
}
