

// Enhanced scriptv2.js - Cleaned and optimized
console.log("Loaded scriptv2.js - Enhanced version");

$(document).ready(function () {
    $(".nav-icon").click(function () {
        console.log('nav icon click');
        $("body").toggleClass("slideb");
    });
});

var MODEL = null;

document.addEventListener("DOMContentLoaded", () => {


    // DOM Elements
    const messagesContainer = document.getElementById("messages");
    const userInput = document.getElementById("user-input");
    const sendButton = document.getElementById("send-btn");
    const newChatButton = document.getElementById("new-chat");
    const clearHistoryButton = document.getElementById("clear-history");
    const chatHistoryContainer = document.getElementById("chat-history");
    const currentChatTitle = document.getElementById("current-chat-title");
    const exportChatButton = document.getElementById("export-chat");
    const regenerateResponseButton = document.getElementById("regenerate-response");
    const stopResponseButton = document.getElementById("stop-response");
    const suggestionChips = document.querySelectorAll(".suggestion-chip");

    // State variables
    let currentChatId = null;
    let isTyping = false;
    let chatHistory = JSON.parse(localStorage.getItem("chatHistory")) || {};
    let currentTheme = localStorage.getItem("theme") || "light";
    let typingSpeed = 2;
    let letterTimeout = null;
    let stopGeneration = false;

    // ENHANCED: Provider dropdown functionality
    const provider = document.getElementById('provider');
    const dropdown = document.getElementById('provider-dropdown');
    const selectedProviderText = document.getElementById('selected-provider');
    const options = dropdown.querySelectorAll('li');

  
    // Icon mapping
    const providerIcons = {
        groq: './static/icon/groq-icon.svg',
        openai: './static/icon/chatgpt-icon.svg',
        anthropic: './static/icon/claude-ai-icon.svg',
        google: './static/icon/google-gemini-icon.svg'
    };

    // Enhanced provider dropdown functionality
    provider.addEventListener('click', (e) => {
        e.stopPropagation();
        dropdown.classList.toggle('show');
        provider.classList.toggle('active');
    });

    // Close dropdown when clicking outside
    document.addEventListener('click', () => {
        dropdown.classList.remove('show');
        provider.classList.remove('active');
    });

    // Prevent dropdown from closing when clicking inside
    dropdown.addEventListener('click', (e) => {
        e.stopPropagation();
    });

    // Enhanced selection handling
    options.forEach(option => {
        option.addEventListener('click', (e) => {
            e.stopPropagation();

            // Clear previous selected class
            options.forEach(opt => opt.classList.remove('selected'));

            // Set selected class
            option.classList.add('selected');

            // Get selected provider
            const providerValue = option.dataset.provider;
            const providerLabel = option.querySelector('span').textContent;
            const providerIcon = providerIcons[providerValue];

            // Update display
            const providerTextDiv = document.querySelector('.provider-text');
            providerTextDiv.innerHTML = `
                <img src="${providerIcon}" alt="${providerLabel}" class="provider-icon" />
                <span id="selected-provider">${providerLabel}</span>
            `;

            // Set global provider
            window.selectedProvider = providerValue;

            // Close dropdown
            dropdown.classList.remove('show');
            provider.classList.remove('active');

            // Show notification
            if (typeof showNotification === 'function') {
                showNotification(`Switched to ${providerLabel}`, 'success');
            }
        });
    });

    // Helper function for stable markdown rendering
    function getStableRendering(text) {
        let parts = text.split("```");
        if (parts.length % 2 === 1) {
            return marked.parse(text);
        } else {
            let closedPart = parts.slice(0, parts.length - 1).join("```");
            let openPart = parts[parts.length - 1];
            return marked.parse(closedPart) + marked.parse("```" + openPart + "\n```");
        }
    }

    // Initialize application
    init();

    function init() {
        // Set up textarea auto-resize
        if (userInput) {
            userInput.addEventListener("input", autoResizeTextarea);
        }

        // Enhanced event listeners
        if (sendButton) {
            sendButton.addEventListener("click", handleSendMessage);
        }

        if (userInput) {
            userInput.addEventListener("keydown", (e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                    e.preventDefault();
                    handleSendMessage();
                }
            });
        }

        if (newChatButton) {
            newChatButton.addEventListener("click", createNewChat);
        }

        if (clearHistoryButton) {
            clearHistoryButton.addEventListener("click", clearAllHistory);
        }

        if (exportChatButton) {
            exportChatButton.addEventListener("click", exportCurrentChat);
        }

        if (regenerateResponseButton) {
            regenerateResponseButton.addEventListener("click", regenerateLastResponse);
        }

        if (stopResponseButton) {
            stopResponseButton.addEventListener("click", () => {
                stopGeneration = true;
                clearTimeout(letterTimeout);
                stopResponseButton.style.display = "none";
                regenerateResponseButton.style.display = "inline-block";
            });
        }

        // Enhanced suggestion chips
        suggestionChips.forEach((chip) => {
            chip.addEventListener("click", () => {
                if (userInput) {
                    userInput.value = chip.textContent;
                    handleSendMessage();
                }
            });
        });

        // Load chat history
        updateChatHistorySidebar();

        // Create new chat if none exists
        if (Object.keys(chatHistory).length === 0) {
            createNewChat();
        } else {
            const mostRecentChatId = Object.keys(chatHistory).sort((a, b) => {
                return chatHistory[b].timestamp - chatHistory[a].timestamp;
            })[0];

            loadChat(mostRecentChatId);
        }

        // Global click listener for closing menus
        window.addEventListener("click", () => {
            document.querySelectorAll(".chat-options-menu").forEach((menu) => {
                menu.style.display = "none";
            });
        });
    }

    // ENHANCED: Send message function (simplified - main logic in chat.js)
    async function handleSendMessage() {
        if (isTyping) {
            if (typeof showNotification === 'function') {
                showNotification("Please wait until the current response is completed.", 'warning');
            }
            return;
        }

        const message = userInput ? userInput.value.trim() : '';
        if (!message) return;

        // Clear input and reset height
        if (userInput) {
            userInput.value = "";
            userInput.style.height = "auto";
        }

        // Use the enhanced sendMessage from chat.js if available
        if (typeof sendMessage === 'function') {
            sendMessage();
            return;
        }

        // Fallback functionality
        addMessageToUI("user", message);

        if (!chatHistory[currentChatId]) {
            createNewChat();
        }

        chatHistory[currentChatId].messages.push({
            role: "user",
            content: message
        });

        if (chatHistory[currentChatId].messages.length === 1) {
            const title = message.split(" ").slice(0, 4).join(" ") + 
                         (message.split(" ").length > 4 ? "..." : "");
            chatHistory[currentChatId].title = title;
            if (currentChatTitle) {
                currentChatTitle.textContent = title;
            }
            updateChatHistorySidebar();
        }

        saveChatHistory();

        try {
            showTypingIndicator();
            const responseText = await getAIResponse(message);
            removeTypingIndicator();
            addMessageToUI("ai", responseText, true);

            chatHistory[currentChatId].messages.push({
                role: "assistant",
                content: responseText
            });

            saveChatHistory();
        } catch (error) {
            removeTypingIndicator();
            addMessageToUIWithTypingEffect("ai", `❌ Error: ${error.message}`);
        }
    }

    async function getAIResponse(message, chatId = null) {
        // This would integrate with your API
        // For now, return a placeholder response
        return "This is a placeholder response. The main chat functionality is handled by chat.js";
    }

    // Enhanced UI functions
    function addMessageToUI(sender, content, withTyping = false) {
        const messageDiv = document.createElement("div");
        messageDiv.className = `message ${sender}`;

        const messageContent = document.createElement("div");
        messageContent.className = "message-content";

        if (withTyping && sender === "ai") {
            addMessageToUIWithTypingEffect(sender, content);
            return;
        }

        messageContent.textContent = content;
        messageDiv.appendChild(messageContent);
        
        if (messagesContainer) {
            messagesContainer.appendChild(messageDiv);
            messagesContainer.scrollTop = messagesContainer.scrollHeight;
        }
    }

    function addMessageToUIWithTypingEffect(sender, content) {
        removeTypingIndicator();

        const messageDiv = document.createElement("div");
        messageDiv.className = `message ${sender}`;

        const messageContent = document.createElement("div");
        messageContent.className = "message-content";

        if (sender === "user") {
            messageContent.textContent = content;
            messageDiv.appendChild(messageContent);
            if (messagesContainer) {
                messagesContainer.appendChild(messageDiv);
                messagesContainer.scrollTop = messagesContainer.scrollHeight;
            }
            return;
        }

        messageDiv.appendChild(messageContent);
        if (messagesContainer) {
            messagesContainer.appendChild(messageDiv);
        }

        const processedContent = processMarkdownContent(content);

        if (sender === "ai") {
            stopGeneration = false;
            if (stopResponseButton) {
                stopResponseButton.style.display = "inline-block";
            }
        }

        startTypingEffect(messageContent, processedContent, 0);
    }

    function processMarkdownContent(content) {
        const segments = [];
        let currentPos = 0;
        const codeBlockRegex = /```([\w]*)\n([\s\S]*?)\n```/g;

        let match;
        while ((match = codeBlockRegex.exec(content)) !== null) {
            if (match.index > currentPos) {
                segments.push({
                    type: "text",
                    content: content.substring(currentPos, match.index)
                });
            }

            segments.push({
                type: "code",
                language: match[1] || "plaintext",
                content: match[2]
            });

            currentPos = match.index + match[0].length;
        }

        if (currentPos < content.length) {
            segments.push({
                type: "text",
                content: content.substring(currentPos)
            });
        }

        return segments;
    }

    function startTypingEffect(messageContent, segments, segmentIndex) {
        if (segmentIndex >= segments.length) {
            isTyping = false;
            if (stopResponseButton) {
                stopResponseButton.style.display = "none";
            }
            return;
        }

        const segment = segments[segmentIndex];

        if (segment.type === "code") {
            const preElement = document.createElement("pre");
            const codeElement = document.createElement("code");

            if (segment.language) {
                codeElement.className = `language-${segment.language}`;
            }
            codeElement.classList.add("hljs");

            const copyButtonContainer = document.createElement("div");
            copyButtonContainer.className = "code-copy-container";

            const copyButton = document.createElement("button");
            copyButton.className = "code-copy-button";
            copyButton.innerHTML = '<i class="fas fa-copy"></i>';
            copyButton.title = "Copy code";

            copyButton.addEventListener("click", () => {
                navigator.clipboard.writeText(segment.content).then(() => {
                    copyButton.innerHTML = '<i class="fas fa-check"></i>';
                    copyButton.classList.add("copied");
                    setTimeout(() => {
                        copyButton.innerHTML = '<i class="fas fa-copy"></i>';
                        copyButton.classList.remove("copied");
                    }, 2000);
                });
            });

            copyButtonContainer.appendChild(copyButton);
            preElement.appendChild(copyButtonContainer);
            preElement.appendChild(codeElement);
            messageContent.appendChild(preElement);

            typeCodeContent(codeElement, segment.content, 0, () => {
                if (typeof hljs !== 'undefined') {
                    hljs.highlightElement(codeElement);
                }
                startTypingEffect(messageContent, segments, segmentIndex + 1);
            });
        } else {
            const textDiv = document.createElement("div");
            messageContent.appendChild(textDiv);
            typeTextContent(textDiv, segment.content, 0, () => {
                startTypingEffect(messageContent, segments, segmentIndex + 1);
            });
        }
    }

    function typeCodeContent(element, content, index, callback) {
        if (stopGeneration) {
            callback();
            return;
        }
        if (index < content.length) {
            element.textContent += content[index];
            if (messagesContainer) {
                messagesContainer.scrollTop = messagesContainer.scrollHeight;
            }
            letterTimeout = setTimeout(() => {
                typeCodeContent(element, content, index + 1, callback);
            }, typingSpeed);
        } else {
            callback();
        }
    }

    function typeTextContent(element, content, index, callback) {
        if (stopGeneration) {
            callback();
            return;
        }
        if (index < content.length) {
            let currentText = content.substring(0, index + 1);
            if (typeof marked !== 'undefined') {
                element.innerHTML = marked.parse(currentText);
            } else {
                element.innerHTML = currentText;
            }
            if (messagesContainer) {
                messagesContainer.scrollTop = messagesContainer.scrollHeight;
            }
            letterTimeout = setTimeout(() => {
                typeTextContent(element, content, index + 1, callback);
            }, typingSpeed);
        } else {
            callback();
        }
    }

    function showTypingIndicator() {
        const typingDiv = document.createElement("div");
        typingDiv.className = "typing-indicator";
        typingDiv.id = "typing-indicator";

        for (let i = 0; i < 3; i++) {
            const dot = document.createElement("div");
            dot.className = "typing-dot";
            typingDiv.appendChild(dot);
        }

        if (messagesContainer) {
            messagesContainer.appendChild(typingDiv);
            messagesContainer.scrollTop = messagesContainer.scrollHeight;
        }
    }

    function removeTypingIndicator() {
        const typingIndicator = document.getElementById("typing-indicator");
        if (typingIndicator) {
            typingIndicator.remove();
        }
    }

    function createNewChat() {
        const chatId = "chat_" + Date.now();

        chatHistory[chatId] = {
            id: chatId,
            title: "New Conversation",
            timestamp: Date.now(),
            messages: []
        };

        currentChatId = chatId;
        if (currentChatTitle) {
            currentChatTitle.textContent = "New Conversation";
        }

        // Clear messages
        if (messagesContainer) {
            messagesContainer.innerHTML = "";
        }

        // Enhanced suggestion chips
        document.querySelectorAll(".suggestion-chip").forEach((chip) => {
            chip.addEventListener("click", () => {
                if (userInput) {
                    userInput.value = chip.textContent;
                    handleSendMessage();
                }
            });
        });

        saveChatHistory();
        updateChatHistorySidebar();
    }

    function loadChat(chatId) {
        if (!chatHistory[chatId]) return;

        currentChatId = chatId;
        if (currentChatTitle) {
            currentChatTitle.textContent = chatHistory[chatId].title;
        }

        if (messagesContainer) {
            messagesContainer.innerHTML = "";
        }

        chatHistory[chatId].messages.forEach((message) => {
            if (message.role === "user") {
                addMessageToUI("user", message.content);
            } else {
                addFormattedMessageToUI("ai", message.content);
            }
        });

        updateActiveChatInSidebar();
    }

    function addFormattedMessageToUI(sender, content) {
        const messageDiv = document.createElement("div");
        messageDiv.className = `message ${sender}`;

        const messageContent = document.createElement("div");
        messageContent.className = "message-content";

        const processedContent = processMarkdownContent(content);

        processedContent.forEach((segment) => {
            if (segment.type === "code") {
                const preElement = document.createElement("pre");
                const codeElement = document.createElement("code");

                if (segment.language) {
                    codeElement.className = `language-${segment.language}`;
                }
                codeElement.classList.add("hljs");

                const copyButtonContainer = document.createElement("div");
                copyButtonContainer.className = "code-copy-container";

                const copyButton = document.createElement("button");
                copyButton.className = "code-copy-button";
                copyButton.innerHTML = '<i class="fas fa-copy"></i>';
                copyButton.title = "Copy code";

                copyButton.addEventListener("click", () => {
                    navigator.clipboard.writeText(segment.content).then(() => {
                        copyButton.innerHTML = '<i class="fas fa-check"></i>';
                        copyButton.classList.add("copied");
                        setTimeout(() => {
                            copyButton.innerHTML = '<i class="fas fa-copy"></i>';
                            copyButton.classList.remove("copied");
                        }, 2000);
                    });
                });

                copyButtonContainer.appendChild(copyButton);
                preElement.appendChild(copyButtonContainer);

                codeElement.textContent = segment.content;
                preElement.appendChild(codeElement);
                messageContent.appendChild(preElement);

                if (typeof hljs !== 'undefined') {
                    hljs.highlightElement(codeElement);
                }
            } else {
                const textDiv = document.createElement("div");
                if (typeof marked !== 'undefined') {
                    textDiv.innerHTML = marked.parse(segment.content);
                } else {
                    textDiv.innerHTML = segment.content;
                }

                while (textDiv.firstChild) {
                    messageContent.appendChild(textDiv.firstChild);
                }
            }
        });

        messageDiv.appendChild(messageContent);
        if (messagesContainer) {
            messagesContainer.appendChild(messageDiv);
            messagesContainer.scrollTop = messagesContainer.scrollHeight;
        }
    }

    function saveChatHistory() {
        localStorage.setItem("chatHistory", JSON.stringify(chatHistory));
        updateChatHistorySidebar();
    }



    function updateActiveChatInSidebar() {
        document.querySelectorAll(".chat-history-item").forEach((item) => {
            item.classList.remove("active");
            if (item.dataset.chatId === currentChatId) {
                item.classList.add("active");
            }
        });
    }

    function clearAllHistory() {
        if (confirm("Are you sure you want to clear all chat history? This cannot be undone.")) {
            chatHistory = {};
            localStorage.removeItem("chatHistory");
            createNewChat();
        }
    }

    function exportCurrentChat() {
        if (!chatHistory[currentChatId]) return;

        const chat = chatHistory[currentChatId];
        let exportText = `# ${chat.title}\n\n`;

        chat.messages.forEach((message) => {
            const role = message.role === "user" ? "You" : "AI Assistant";
            exportText += `## ${role}:\n${message.content}\n\n`;
        });

        const blob = new Blob([exportText], { type: "text/markdown" });
        const url = URL.createObjectURL(blob);

        const a = document.createElement("a");
        a.href = url;
        a.download = `${chat.title.replace(/[^\w\s]/gi, "")}.md`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    }

    function regenerateLastResponse() {
        if (chatHistory[currentChatId] && chatHistory[currentChatId].messages.length > 0) {
            const lastMessage = chatHistory[currentChatId].messages[chatHistory[currentChatId].messages.length - 1];
            if (lastMessage.role === "assistant") {
                chatHistory[currentChatId].messages.pop();
                const messageElements = document.querySelectorAll(".message.ai");
                if (messageElements.length > 0) {
                    messageElements[messageElements.length - 1].remove();
                }
                saveChatHistory();
                showTypingIndicator();
                
                getAIResponse(currentChatId)
                    .then((response) => {
                        chatHistory[currentChatId].messages.push({
                            role: "assistant",
                            content: response
                        });
                        saveChatHistory();
                    })
                    .catch((error) => {
                        removeTypingIndicator();
                        addMessageToUIWithTypingEffect("ai", `Sorry, I encountered an error: ${error.message}`);
                    });
            }
        }
    }

    function autoResizeTextarea() {
        if (userInput) {
            userInput.style.height = "auto";
            userInput.style.height = userInput.scrollHeight + "px";
        }
    }
});