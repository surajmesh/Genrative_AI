// =============================================
// ENHANCED SETTINGS MANAGER WITH PLANS PAGE SUPPORT
// =============================================

class SettingsManager {
    constructor() {
        this.currentSection = 'account';
        this.currentSubSection = 'profile';
        this.isAdmin = false;
        this.charts = {};
        this.currentPage = this.detectCurrentPage();

        this.init();
    }

    detectCurrentPage() {
        // Detect if we're on settings page or plans page
        const path = window.location.pathname;
        if (path.includes('/plans')) {
            return 'plans';
        }
        return 'settings';
    }

    init() {
        console.log(`🚀 Initializing ${this.currentPage === 'plans' ? 'Plans' : 'Settings'} Manager...`);

        // Check if Razorpay is loaded
        if (typeof Razorpay === 'undefined') {
            console.error('❌ Razorpay script not loaded');
            this.showToast('Payment gateway not available', 'error');
        }

        if (this.currentPage === 'plans') {
            this.initPlansPage();
        } else {
            this.initSettingsPage();
        }
    }

    // =============================================
    // PLANS PAGE INITIALIZATION
    // =============================================
    initPlansPage() {
        this.setupPlansEventListeners();
        this.loadUserPlanStatus();
    }

    setupPlansEventListeners() {
        // Tab switching
        document.querySelectorAll('.tab-button').forEach(btn => {
            btn.addEventListener('click', () => {
                this.switchPlanTab(btn.dataset.tab);
            });
        });

        // Plan selection buttons
        document.querySelectorAll('.plan-button[data-plan]').forEach(btn => {
            btn.addEventListener('click', () => {
                const planType = btn.dataset.plan;
                this.selectPlan(planType);
            });
        });

        // Back button
        document.getElementById('back-btn')?.addEventListener('click', () => {
            window.location.href = '/chat';
        });

        // Settings button
        document.getElementById('settings-btn')?.addEventListener('click', () => {
            window.location.href = '/settings';
        });
    }

    switchPlanTab(tabName) {
        // Update tab buttons
        document.querySelectorAll('.tab-button').forEach(btn => {
            btn.classList.toggle('active', btn.dataset.tab === tabName);
        });

        // Update tab content
        document.querySelectorAll('.tab-content').forEach(content => {
            content.classList.remove('active');
        });
        document.getElementById(`${tabName}-tab`)?.classList.add('active');
    }

    async loadUserPlanStatus() {
        try {
            const response = await fetch('/api/plans/current');
            if (response.ok) {
                const data = await response.json();
                if (data.success && data.has_plan) {
                    this.updatePlanButtons(data.plan.plan_type);
                }
            }
        } catch (error) {
            console.error('Error loading user plan status:', error);
        }
    }

    updatePlanButtons(currentPlanType) {
        // Reset all buttons
        document.querySelectorAll('.plan-button').forEach(btn => {
            if (btn.dataset.plan === currentPlanType) {
                btn.textContent = 'Your current plan';
                btn.classList.add('current-plan');
                btn.disabled = true;
            }
        });

        // Update free plan if user has a paid plan
        if (currentPlanType !== 'free') {
            const freeButton = document.querySelector('.free-plan .plan-button');
            if (freeButton) {
                freeButton.textContent = 'Downgrade to Free';
                freeButton.classList.remove('current-plan');
                freeButton.disabled = false;
            }
        }
    }

    // =============================================
    // SETTINGS PAGE INITIALIZATION
    // =============================================
    initSettingsPage() {
        this.checkAdminStatus();
        this.setupEventListeners();
        this.loadInitialData();
        this.initializeCharts();
    }

    // =============================================
    // ADMIN CHECK
    // =============================================
    checkAdminStatus() {
        // Check if user is admin (you can modify this based on your auth system)
        const userRole = localStorage.getItem('userRole');
        const adminCode = localStorage.getItem('adminCode');
        
        // For now, always show admin section as requested
        this.isAdmin = true;
        
        if (this.isAdmin) {
            console.log('👑 Admin user detected');
            document.querySelector('[data-section="admin"]').style.display = 'flex';
        }
    }

    // =============================================
    // EVENT LISTENERS
    // =============================================
    setupEventListeners() {
        // Navigation
        document.querySelectorAll('.nav-item').forEach(item => {
            item.addEventListener('click', () => {
                const section = item.dataset.section;
                this.switchSection(section);
            });
        });

        // Sub-navigation
        document.querySelectorAll('.sub-nav-item').forEach(item => {
            item.addEventListener('click', () => {
                const subsection = item.dataset.subsection;
                this.switchSubSection(subsection);
            });
        });

        // Upgrade button in settings
        document.getElementById('upgrade-plan-btn')?.addEventListener('click', () => {
            window.location.href = '/plans';
        });

        // Admin tabs
        if (this.isAdmin) {
            document.querySelectorAll('.tab-btn').forEach(btn => {
                btn.addEventListener('click', () => {
                    this.switchAdminTab(btn.dataset.tab);
                });
            });
        }

        // Other buttons
        document.getElementById('back-btn')?.addEventListener('click', () => {
            window.location.href = '/chat';
        });

        document.getElementById('delete-account-btn')?.addEventListener('click', () => {
            this.showDeleteModal();
        });

        document.getElementById('export-data-btn')?.addEventListener('click', () => {
            this.exportUserData();
        });

        // Modal handlers
        this.setupModalHandlers();

        // Theme and preference handlers
        this.setupPreferenceHandlers();
    }

    setupModalHandlers() {
        // Delete modal
        const deleteModal = document.getElementById('delete-modal');
        const confirmInput = document.getElementById('delete-confirmation-input');
        const confirmBtn = document.getElementById('confirm-delete-btn');

        confirmInput?.addEventListener('input', e => {
            confirmBtn.disabled = e.target.value.trim().toUpperCase() !== 'DELETE';
        });

        confirmBtn?.addEventListener('click', () => {
            this.confirmAccountDeletion();
        });

        document.getElementById('cancel-delete-btn')?.addEventListener('click', () => {
            this.hideDeleteModal();
        });

        document.getElementById('close-delete-modal')?.addEventListener('click', () => {
            this.hideDeleteModal();
        });

        // Close modal on outside click
        deleteModal?.addEventListener('click', e => {
            if (e.target === deleteModal) {
                this.hideDeleteModal();
            }
        });
    }

    setupPreferenceHandlers() {
        // Theme selector
        document.getElementById('theme-select')?.addEventListener('change', e => {
            this.changeTheme(e.target.value);
        });

        // Language selector
        document.getElementById('language-select')?.addEventListener('change', e => {
            this.changeLanguage(e.target.value);
        });

        // Checkboxes
        const checkboxes = [
            'email-notifications',
            'usage-alerts',
            'promo-emails',
            'auto-save-chats',
            'remember-context',
            'streaming-responses'
        ];
        checkboxes.forEach(id => {
            const checkbox = document.getElementById(id);
            checkbox?.addEventListener('change', e => {
                this.updateSetting(id, e.target.checked);
            });
        });

        // Provider selector
        document.getElementById('default-provider')?.addEventListener('change', e => {
            this.updateDefaultProvider(e.target.value);
        });

        // Export buttons
        document.querySelectorAll('.export-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                this.exportChatHistory(btn.dataset.format);
            });
        });

        // Referral code copy
        document.getElementById('copy-referral')?.addEventListener('click', () => {
            this.copyReferralCode();
        });

        // Promo code apply
        document.getElementById('apply-promo')?.addEventListener('click', () => {
            this.applyPromoCode();
        });
    }

    // =============================================
    // NAVIGATION
    // =============================================
    switchSection(sectionName) {
        // Update navigation
        document.querySelectorAll('.nav-item').forEach(item => {
            item.classList.remove('active');
        });
        document.querySelector(`[data-section="${sectionName}"]`)?.classList.add('active');

        // Update content
        document.querySelectorAll('.settings-section').forEach(section => {
            section.classList.remove('active');
        });
        document.getElementById(`${sectionName}-section`)?.classList.add('active');

        this.currentSection = sectionName;

        // Load section-specific data
        this.loadSectionData(sectionName);
    }

    switchSubSection(subSectionName) {
        // Update sub-navigation
        document.querySelectorAll('.sub-nav-item').forEach(item => {
            item.classList.remove('active');
        });
        document.querySelector(`[data-subsection="${subSectionName}"]`)?.classList.add('active');

        // Update content
        document.querySelectorAll('.sub-section').forEach(section => {
            section.classList.remove('active');
        });
        document.getElementById(`${subSectionName}-subsection`)?.classList.add('active');

        this.currentSubSection = subSectionName;
    }

    switchAdminTab(tabName) {
        // Update tab navigation
        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.classList.remove('active');
        });
        document.querySelector(`[data-tab="${tabName}"]`)?.classList.add('active');

        // Update content
        document.querySelectorAll('.tab-content').forEach(content => {
            content.classList.remove('active');
        });
        document.getElementById(`${tabName}-tab`)?.classList.add('active');

        // Load tab-specific data
        this.loadAdminTabData(tabName);
    }

    // =============================================
    // DATA LOADING
    // =============================================
    async loadInitialData() {
        this.showLoading(true);
        try {
            await Promise.all([
                this.loadUserProfile(),
                this.loadCurrentPlan(),
                this.loadUserSettings()
            ]);
        } catch (error) {
            console.error('Error loading initial data:', error);
            this.showToast('Failed to load settings data', 'error');
        } finally {
            this.showLoading(false);
        }
    }

    async loadSectionData(section) {
        switch (section) {
            case 'account':
                await this.loadAccountData();
                break;
            case 'usage':
                await this.loadUsageData();
                break;
            case 'admin':
                if (this.isAdmin) {
                    await this.loadAdminData();
                }
                break;
        }
    }

    async loadUserProfile() {
        try {
            const response = await fetch('/api/user/profile');
            if (response.ok) {
                const data = await response.json();
                if (data.success && data.user) {
                    this.updateProfileDisplay(data.user);
                }
            }
        } catch (error) {
            console.error('Error loading user profile:', error);
        }
    }

    async loadCurrentPlan() {
        try {
            const response = await fetch('/api/plans/current');
            if (response.ok) {
                const data = await response.json();
                if (data.success && data.has_plan) {
                    this.updatePlanDisplay(data.plan);
                }
            }
        } catch (error) {
            console.error('Error loading current plan:', error);
        }
    }

    async loadUserSettings() {
        // Load from localStorage
        const settings = {
            theme: localStorage.getItem('theme') || 'dark',
            language: localStorage.getItem('language') || 'en',
            emailNotifications: localStorage.getItem('email-notifications') === 'true',
            usageAlerts: localStorage.getItem('usage-alerts') !== 'false',
            promoEmails: localStorage.getItem('promo-emails') === 'true',
            autoSaveChats: localStorage.getItem('auto-save-chats') !== 'false',
            rememberContext: localStorage.getItem('remember-context') !== 'false',
            streamingResponses: localStorage.getItem('streaming-responses') !== 'false',
            defaultProvider: localStorage.getItem('default-provider') || 'openai'
        };

        // Apply settings to UI
        document.getElementById('theme-select').value = settings.theme;
        document.getElementById('language-select').value = settings.language;
        document.getElementById('email-notifications').checked = settings.emailNotifications;
        document.getElementById('usage-alerts').checked = settings.usageAlerts;
        document.getElementById('promo-emails').checked = settings.promoEmails;
        document.getElementById('auto-save-chats').checked = settings.autoSaveChats;
        document.getElementById('remember-context').checked = settings.rememberContext;
        document.getElementById('streaming-responses').checked = settings.streamingResponses;
        document.getElementById('default-provider').value = settings.defaultProvider;
    }

    async loadAccountData() {
        await this.loadPaymentHistory();
    }

    async loadPaymentHistory() {
        try {
            const response = await fetch('/api/user/billing');
            if (response.ok) {
                const data = await response.json();
                if (data.success) {
                    this.updatePaymentHistory(data.billing.payment_history);
                }
            }
        } catch (error) {
            console.error('Error loading payment history:', error);
        }
    }

    async loadUsageData() {
        try {
            const response = await fetch('/api/usage/overview');
            if (response.ok) {
                const data = await response.json();
                if (data.success) {
                    this.updateUsageDisplay(data.usage);
                }
            }
        } catch (error) {
            console.error('Error loading usage data:', error);
        }
    }

    async loadAdminData() {
        try {
            this.showLoading(true);
            
            const response = await fetch('/api/admin/analytics');
            if (response.ok) {
                const data = await response.json();
                if (data.success) {
                    this.updateAdminDashboard(data.analytics);
                    this.updateProviderStats(data.analytics.providerUsage);
                } else {
                    console.error('Failed to load admin data:', data.error);
                    // Fallback to mock data
                    this.updateAdminDashboard(this.getMockAdminData());
                }
            } else {
                throw new Error('Failed to fetch admin data');
            }
        } catch (error) {
            console.error('Error loading admin data:', error);
            // Fallback to mock data on error
            this.updateAdminDashboard(this.getMockAdminData());
        } finally {
            this.showLoading(false);
        }
    }

    async loadAdminTabData(tabName) {
        switch (tabName) {
            case 'users':
                await this.loadUserAnalytics();
                break;
            case 'revenue':
                await this.loadRevenueAnalytics();
                break;
            case 'providers':
                await this.loadProviderAnalytics();
                break;
            case 'system':
                await this.loadSystemMetrics();
                break;
        }
    }

    updateProviderStats(providerData) {
        // Update OpenAI stats
        document.getElementById('openai-requests').textContent = providerData.openai?.requests || 0;
        document.getElementById('openai-cost').textContent = `$${providerData.openai?.cost || 0}`;
        document.getElementById('openai-response').textContent = `${providerData.openai?.avg_response || 0}ms`;
        
        // Update Anthropic stats  
        document.getElementById('anthropic-requests').textContent = providerData.anthropic?.requests || 0;
        document.getElementById('anthropic-cost').textContent = `$${providerData.anthropic?.cost || 0}`;
        document.getElementById('anthropic-response').textContent = `${providerData.anthropic?.avg_response || 0}ms`;
        
        // Update Google stats
        document.getElementById('google-requests').textContent = providerData.google?.requests || 0;
        document.getElementById('google-cost').textContent = `$${providerData.google?.cost || 0}`;
        document.getElementById('google-response').textContent = `${providerData.google?.avg_response || 0}ms`;
        
        // Update Groq stats
        document.getElementById('groq-requests').textContent = providerData.groq?.requests || 0;
        document.getElementById('groq-cost').textContent = `$${providerData.groq?.cost || 0}`;
        document.getElementById('groq-response').textContent = `${providerData.groq?.avg_response || 0}ms`;
    }

    // =============================================
    // UI UPDATES
    // =============================================
    updateProfileDisplay(user) {
        document.getElementById('avatar-initials').textContent = this.getInitials(user.fullname || user.username);
        document.getElementById('profile-name').textContent = user.fullname || user.username;
        document.getElementById('profile-email').textContent = user.email;
        document.getElementById('profile-fullname').textContent = user.fullname || 'Not set';
        document.getElementById('profile-username').textContent = user.username;
        document.getElementById('profile-email-detail').textContent = user.email;
        document.getElementById('profile-created').textContent = new Date(user.created_at).toLocaleDateString();
        document.getElementById('profile-last-login').textContent = new Date(user.last_login).toLocaleDateString();
    }

    updatePlanDisplay(plan) {
        const planName = this.formatPlanName(plan.plan_type);
        document.getElementById('current-plan-name').textContent = planName;

        // Update visual usage indicator
        const usagePercentage = (plan.messages_used / plan.total_messages) * 100;
        const usageProgress = document.getElementById('usage-progress');
        const circumference = 2 * Math.PI * 45;
        const offset = circumference - (usagePercentage / 100) * circumference;

        usageProgress.style.strokeDashoffset = offset;
        document.getElementById('usage-percentage').textContent = `${Math.round(usagePercentage)}%`;

        // Update days remaining
        const daysLeft = plan.days_remaining || 0;
        document.getElementById('days-left').textContent = `${daysLeft} days remaining`;

        // Update usage status
        let statusText = 'Healthy usage pattern';
        if (usagePercentage > 80) {
            statusText = 'High usage - consider upgrading';
        } else if (daysLeft < 7) {
            statusText = 'Plan expiring soon';
        }
        document.getElementById('usage-status').textContent = statusText;

        // Update plan expiry badge
        const expiryBadge = document.getElementById('plan-expiry');
        if (daysLeft < 7) {
            expiryBadge.textContent = 'Expiring Soon';
            expiryBadge.className = 'plan-expiry warning';
        } else {
            expiryBadge.textContent = 'Active';
            expiryBadge.className = 'plan-expiry active';
        }
    }

    updatePaymentHistory(payments) {
        const historyList = document.getElementById('payment-history-list');
        historyList.innerHTML = '';

        if (!payments || payments.length === 0) {
            historyList.innerHTML = '<p class="empty-state">No payment history found</p>';
            return;
        }

        payments.forEach(payment => {
            const paymentItem = document.createElement('div');
            paymentItem.className = 'payment-item';
            paymentItem.innerHTML = `
                <div class="payment-details">
                    <h4>${payment.plan_name}</h4>
                    <p class="payment-date">${new Date(payment.date).toLocaleDateString()}</p>
                </div>
                <div class="payment-amount">
                    $${payment.amount}
                </div>
            `;
            historyList.appendChild(paymentItem);
        });
    }

    updateUsageDisplay(usage) {
        // Update plan status
        const planHealth = document.getElementById('plan-health');
        if (usage.usage_percentage < 50) {
            planHealth.innerHTML = `
                <div class="status-icon good">
                    <svg width="48" height="48" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
                    </svg>
                </div>
                <p class="status-text">Your usage is healthy</p>
                <p class="status-subtext">Keep up the good pace!</p>
            `;
        } else if (usage.usage_percentage < 80) {
            planHealth.innerHTML = `
                <div class="status-icon warning">
                    <svg width="48" height="48" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M1 21h22L12 2 1 21zm12-3h-2v-2h2v2zm0-4h-2v-4h2v4z"/>
                    </svg>
                </div>
                <p class="status-text">Moderate usage</p>
                <p class="status-subtext">You're using your plan efficiently</p>
            `;
        } else {
            planHealth.innerHTML = `
                <div class="status-icon danger">
                    <svg width="48" height="48" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z"/>
                    </svg>
                </div>
                <p class="status-text">High usage detected</p>
                <p class="status-subtext">Consider upgrading your plan</p>
            `;
        }

        // Update provider distribution chart
        this.updateProviderChart(usage.provider_breakdown);

        // Update usage trend chart
        this.updateUsageTrendChart(usage.daily_usage);

        // Update alerts
        this.updateUsageAlerts(usage);
    }

    updateProviderChart(providerData) {
        const ctx = document.getElementById('provider-pie-chart').getContext('2d');

        if (this.charts.providerChart) {
            this.charts.providerChart.destroy();
        }

        const data = {
            labels: providerData.map(p => p.name),
            datasets: [{
                data: providerData.map(p => p.percentage),
                backgroundColor: [
                    '#cc0000',
                    '#ff3333',
                    '#990000',
                    '#660000'
                ],
                borderWidth: 0
            }]
        };

        this.charts.providerChart = new Chart(ctx, {
            type: 'doughnut',
            data: data,
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                }
            }
        });

        // Update legend
        const legend = document.getElementById('provider-legend');
        legend.innerHTML = providerData.map((provider, index) => `
            <div class="legend-item">
                <span class="legend-color" style="background-color: ${data.datasets[0].backgroundColor[index]}"></span>
                <span class="legend-label">${provider.name}</span>
                <span class="legend-value">${provider.percentage}%</span>
            </div>
        `).join('');
    }

    updateUsageTrendChart(dailyData) {
        const ctx = document.getElementById('usage-trend-chart').getContext('2d');

        if (this.charts.trendChart) {
            this.charts.trendChart.destroy();
        }

        const last7Days = dailyData.slice(-7);

        this.charts.trendChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: last7Days.map(d => new Date(d.date).toLocaleDateString('en', { weekday: 'short' })),
                datasets: [{
                    label: 'Daily Usage',
                    data: last7Days.map(d => d.messages),
                    borderColor: '#cc0000',
                    backgroundColor: 'rgba(204, 0, 0, 0.1)',
                    tension: 0.4,
                    fill: true
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        grid: {
                            color: 'rgba(255, 255, 255, 0.1)'
                        }
                    },
                    x: {
                        grid: {
                            display: false
                        }
                    }
                }
            }
        });

        // Update trend insights
        const avgUsage = last7Days.reduce((sum, d) => sum + d.messages, 0) / last7Days.length;
        const trend = last7Days[6].messages > avgUsage ? 'increasing' : 'stable';

        document.getElementById('trend-message').textContent =
            trend === 'increasing'
                ? 'Your usage is trending up. Monitor your limits.'
                : 'Your usage pattern is stable and sustainable.';
    }

    updateUsageAlerts(usage) {
        const alertsContainer = document.getElementById('usage-alerts-container');
        alertsContainer.innerHTML = '';

        const alerts = [];

        // Check various conditions
        if (usage.days_remaining < 7) {
            alerts.push({
                type: 'warning',
                message: `Your plan expires in ${usage.days_remaining} days`,
                action: 'Renew now'
            });
        }

        if (usage.usage_percentage > 80) {
            alerts.push({
                type: 'info',
                message: 'You\'ve used 80% of your monthly messages',
                action: 'View plans'
            });
        }

        if (usage.high_cost_provider) {
            alerts.push({
                type: 'tip',
                message: `Try using ${usage.recommended_provider} for faster responses`,
                action: 'Change default'
            });
        }

        if (alerts.length === 0) {
            alerts.push({
                type: 'success',
                message: 'All systems optimal! No alerts.',
                action: null
            });
        }

        alerts.forEach(alert => {
            const alertEl = document.createElement('div');
            alertEl.className = `usage-alert ${alert.type}`;
            alertEl.innerHTML = `
                <div class="alert-content">
                    <p>${alert.message}</p>
                    ${alert.action ? `<button class="alert-action">${alert.action}</button>` : ''}
                </div>
            `;
            alertsContainer.appendChild(alertEl);
        });
    }

    updateAdminDashboard(analytics) {
        // Update overview cards
        document.getElementById('total-users').textContent = analytics.totalUsers.toLocaleString();
        document.getElementById('monthly-revenue').textContent = `${analytics.monthlyRevenue.toLocaleString()}`;
        document.getElementById('active-users').textContent = analytics.activeUsers.toLocaleString();
        document.getElementById('conversion-rate').textContent = `${analytics.conversionRate}%`;

        // Update user growth chart
        this.updateUserGrowthChart(analytics.userGrowth);

        // Update user breakdown table
        this.updateUserBreakdownTable(analytics.usersByPlan);
    }

    // =============================================
    // CHARTS INITIALIZATION
    // =============================================
    initializeCharts() {
        Chart.defaults.color = '#e0e0e0';
        Chart.defaults.borderColor = '#2a2a2a';
        Chart.defaults.font.family = 'Space Grotesk';
    }

    // =============================================
    // ADMIN CHARTS
    // =============================================
    updateUserGrowthChart(growthData) {
        const ctx = document.getElementById('user-growth-chart')?.getContext('2d');
        if (!ctx) return;

        if (this.charts.userGrowthChart) {
            this.charts.userGrowthChart.destroy();
        }

        this.charts.userGrowthChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: growthData.map(d => d.date),
                datasets: [{
                    label: 'Total Users',
                    data: growthData.map(d => d.total),
                    borderColor: '#cc0000',
                    backgroundColor: 'rgba(204, 0, 0, 0.1)',
                    tension: 0.4
                }, {
                    label: 'Paid Users',
                    data: growthData.map(d => d.paid),
                    borderColor: '#4CAF50',
                    backgroundColor: 'rgba(76, 175, 80, 0.1)',
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom'
                    }
                }
            }
        });
    }

    updateUserBreakdownTable(usersByPlan) {
        const tbody = document.getElementById('user-breakdown-table');
        tbody.innerHTML = usersByPlan.map(plan => `
            <tr>
                <td>${plan.name}</td>
                <td>${plan.users.toLocaleString()}</td>
                <td>${plan.percentage}%</td>
                <td>${plan.avgUsage} msgs/day</td>
            </tr>
        `).join('');
    }

    // =============================================
    // ACTIONS - PAYMENT PROCESSING
    // =============================================
    async selectPlan(planType) {
        this.showLoading(true);

        try {
            // For free plan, activate directly
            if (planType === 'free') {
                const response = await fetch('/api/plans/activate', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        plan_type: planType,
                        payment_id: null,
                        amount_paid: 0
                    })
                });

                if (response.ok) {
                    const data = await response.json();
                    if (data.success) {
                        this.showToast('Free plan activated!', 'success');
                        setTimeout(() => window.location.reload(), 1500);
                    } else {
                        this.showToast(data.error || 'Failed to activate plan', 'error');
                    }
                }
                return;
            }

            // Get payment config first
            const configResponse = await fetch('/api/payment/config');
            if (!configResponse.ok) {
                throw new Error('Failed to get payment configuration');
            }
            const configData = await configResponse.json();
            
            if (!configData.success || !configData.razorpay_key_id) {
                throw new Error('Payment gateway not configured');
            }

            // For paid plans, create Razorpay order
            const orderResponse = await fetch('/api/payment/create-order', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    plan_type: planType,
                    currency: 'USD' // Always use USD for plans page
                })
            });

            if (!orderResponse.ok) {
                throw new Error('Failed to create payment order');
            }

            const orderData = await orderResponse.json();
            if (!orderData.success) {
                throw new Error(orderData.error || 'Payment order creation failed');
            }

            // Initialize Razorpay checkout with dynamic key
            const options = {
                key: configData.razorpay_key_id,
                amount: orderData.amount,
                currency: orderData.currency,
                name: "OneRoof",
                description: `Upgrade to ${orderData.plan_name}`,
                order_id: orderData.order_id,
                handler: async (response) => {
                    await this.handlePaymentSuccess(response, planType, orderData.amount);
                },
                prefill: {
                    name: this.getCurrentUserName(),
                    email: this.getCurrentUserEmail()
                },
                theme: {
                    color: "#cc0000"
                },
                modal: {
                    ondismiss: () => {
                        this.showLoading(false);
                        this.showToast('Payment cancelled', 'info');
                    }
                }
            };

            const rzp = new Razorpay(options);
            rzp.open();

        } catch (error) {
            console.error('Error selecting plan:', error);
            this.showToast(error.message || 'Failed to initiate payment', 'error');
        } finally {
            this.showLoading(false);
        }
    }

    async handlePaymentSuccess(paymentResponse, planType, amountPaid) {
        this.showLoading(true);
        
        try {
            const verifyResponse = await fetch('/api/payment/verify', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    razorpay_payment_id: paymentResponse.razorpay_payment_id,
                    razorpay_order_id: paymentResponse.razorpay_order_id,
                    razorpay_signature: paymentResponse.razorpay_signature,
                    plan_type: planType,
                    amount_paid: amountPaid
                })
            });

            // 🔍 ADD THIS DEBUG CODE
            console.log('Verify Response Status:', verifyResponse.status);
            const data = await verifyResponse.json();
            console.log('Verify Response Data:', data);

            if (verifyResponse.ok) {
                if (data.success && data.plan_activated) {
                    // Success case
                    await this.updatePlanStatusRealTime(data.plan_details);
                    this.showToast('🎉 Payment successful! Plan activated.', 'success');
                    this.updatePlanButtons(planType);
                    
                    // ✅ FIXED: Only load payment history if on settings page
                    if (this.currentPage === 'settings') {
                        await this.loadPaymentHistory();
                    }
                } else {
                    // 🚨 This is likely where it's failing
                    console.log('Plan not activated:', data);
                    this.showToast(data.error || 'Payment verification failed', 'error');
                }
            } else {
                this.showToast('Payment verification failed', 'error');
            }
        } catch (error) {
            console.error('Payment verification error:', error);
            this.showToast('Payment verification failed', 'error');
        } finally {
            this.showLoading(false);
        }
    }

    // New method to update plan status in real-time
   async updatePlanStatusRealTime(planDetails) {
    try {
        // Update current plan display
        if (planDetails) {
            const planName = this.formatPlanName(planDetails.plan_type);
            const currentPlanNameEl = document.getElementById('current-plan-name');
            
            // ✅ ADD NULL CHECK
            if (currentPlanNameEl) {
                currentPlanNameEl.textContent = planName;
            }

            // Update usage visualization
            const usagePercentage = (planDetails.messages_used / planDetails.total_messages) * 100;
            const usageProgress = document.getElementById('usage-progress');
            if (usageProgress) {
                const circumference = 2 * Math.PI * 45;
                const offset = circumference - (usagePercentage / 100) * circumference;
                usageProgress.style.strokeDashoffset = offset;
                
                const usagePercentageEl = document.getElementById('usage-percentage');
                // ✅ ADD NULL CHECK
                if (usagePercentageEl) {
                    usagePercentageEl.textContent = `${Math.round(usagePercentage)}%`;
                }
            }

            // Update days remaining
            const daysLeft = planDetails.days_remaining || 0;
            const daysLeftEl = document.getElementById('days-left');
            // ✅ ADD NULL CHECK
            if (daysLeftEl) {
                daysLeftEl.textContent = `${daysLeft} days remaining`;
            }

            // Update plan expiry badge
            const expiryBadge = document.getElementById('plan-expiry');
            if (expiryBadge) {
                expiryBadge.textContent = 'Active';
                expiryBadge.className = 'plan-expiry active';
            }
        }
        
        // Only try to reload plan data if we're on settings page
        if (this.currentPage === 'settings') {
            await this.loadCurrentPlan();
        }
        
    } catch (error) {
        console.error('Error updating plan status:', error);
    }
    }

    getCurrentUserName() {
        const profileName = document.getElementById('profile-name')?.textContent;
        return profileName || localStorage.getItem('userName') || 'User';
    }

    getCurrentUserEmail() {
        const profileEmail = document.getElementById('profile-email')?.textContent;
        return profileEmail || localStorage.getItem('userEmail') || '';
    }

    async exportUserData() {
        try {
            const response = await fetch('/api/user/export');
            if (response.ok) {
                const blob = await response.blob();
                const url = window.URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = 'user_data.json';
                a.click();
                window.URL.revokeObjectURL(url);
                this.showToast('Data exported successfully!', 'success');
            }
        } catch (error) {
            console.error('Error exporting data:', error);
            this.showToast('Failed to export data', 'error');
        }
    }

    async exportChatHistory(format) {
        try {
            const response = await fetch(`/api/chats/export?format=${format}`);
            if (response.ok) {
                const blob = await response.blob();
                const url = window.URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = `chat_history.${format}`;
                a.click();
                window.URL.revokeObjectURL(url);
                this.showToast('Chat history exported!', 'success');
            }
        } catch (error) {
            console.error('Error exporting chat history:', error);
            this.showToast('Failed to export chat history', 'error');
        }
    }

    changeTheme(theme) {
        localStorage.setItem('theme', theme);
        document.body.className = theme;
        this.showToast(`Theme changed to ${theme}`, 'success');
    }

    changeLanguage(language) {
        localStorage.setItem('language', language);
        this.showToast(`Language changed to ${language}`, 'success');
    }

    updateSetting(key, value) {
        localStorage.setItem(key, value);
        this.showToast('Setting updated', 'success');
    }

    updateDefaultProvider(provider) {
        localStorage.setItem('default-provider', provider);
        this.updateDefaultModels(provider);
    }

    updateDefaultModels(provider) {
        const modelSelect = document.getElementById('default-model');
        modelSelect.innerHTML = '<option value="auto">Auto-select best model</option>';

        const models = {
            'openai': ['GPT-4', 'GPT-3.5 Turbo'],
            'anthropic': ['Claude 3 Opus', 'Claude 3 Sonnet'],
            'google': ['Gemini Pro', 'Gemini Flash'],
            'groq': ['Llama 3 70B', 'Mixtral 8x7B']
        };

        if (models[provider]) {
            models[provider].forEach(model => {
                const option = document.createElement('option');
                option.value = model.toLowerCase().replace(/\s+/g, '-');
                option.textContent = model;
                modelSelect.appendChild(option);
            });
        }
    }

    copyReferralCode() {
        const input = document.getElementById('referral-code');
        input.select();
        document.execCommand('copy');
        this.showToast('Referral code copied!', 'success');
    }

    applyPromoCode() {
        const code = document.getElementById('promo-code-input').value.trim();
        if (!code) {
            this.showToast('Please enter a promo code', 'error');
            return;
        }
        this.showToast('Promo code applied!', 'success');
        document.getElementById('promo-code-input').value = '';
    }

    // =============================================
    // MODALS
    // =============================================
    showDeleteModal() {
        document.getElementById('delete-modal').classList.add('show');
    }

    hideDeleteModal() {
        document.getElementById('delete-modal').classList.remove('show');
        document.getElementById('delete-confirmation-input').value = '';
        document.getElementById('confirm-delete-btn').disabled = true;
    }

    async confirmAccountDeletion() {
        try {
            const response = await fetch('/api/user/delete', {
                method: 'DELETE',
                headers: {
                    'Content-Type': 'application/json'
                }
            });
            if (response.ok) {
                this.showToast('Account deleted successfully', 'success');
                setTimeout(() => {
                    window.location.href = '/';
                }, 2000);
            }
        } catch (error) {
            console.error('Error deleting account:', error);
            this.showToast('Failed to delete account', 'error');
        }
    }

// =============================================
// UTILITIES
// =============================================
    formatPlanName(planType) {
        const names = {
            'free': 'Free Plan',
            '12_day_basic': '12-Day Power Pack',
            '24_day_basic': '24-Day Pro Pack',
            '1_month_pro': '1-Month Power Pack',
            '2_month_pro': '2-Month Pro Pack'
        };
        return names[planType] || planType;
    }

    getInitials(name) {
        return name.split(' ')
            .map(word => word[0])
            .join('')
            .toUpperCase()
            .substring(0, 2);
    }

    showLoading(show) {
        const overlay = document.getElementById('loading-overlay');
        if (show) {
            overlay.classList.add('show');
        } else {
            overlay.classList.remove('show');
        }
    }

    showToast(message, type = 'info') {
        const toast = document.getElementById('toast');
        const toastMessage = document.getElementById('toast-message');

        toastMessage.textContent = message;
        toast.className = `toast ${type}`;
        toast.classList.add('show');

        setTimeout(() => {
            toast.classList.remove('show');
        }, 3000);
    }

    // =============================================
    // MOCK DATA
    // =============================================
    getMockAdminData() {
        return {
            totalUsers: 15420,
            monthlyRevenue: 48500,
            activeUsers: 3850,
            conversionRate: 12.5,
            userGrowth: [
                { date: 'Jan', total: 10000, paid: 1000 },
                { date: 'Feb', total: 11500, paid: 1300 },
                { date: 'Mar', total: 13200, paid: 1580 },
                { date: 'Apr', total: 14100, paid: 1692 },
                { date: 'May', total: 15420, paid: 1850 }
            ],
            usersByPlan: [
                { name: 'Free', users: 13570, percentage: 88, avgUsage: 25 },
                { name: 'Basic', users: 1230, percentage: 8, avgUsage: 85 },
                { name: 'Pro', users: 620, percentage: 4, avgUsage: 150 }
            ]
        };
    }





}










// =============================================
// INITIALIZATION
// =============================================

document.addEventListener('DOMContentLoaded', () => {
    console.log('🚀 Page loaded');

    // Apply saved theme
    const savedTheme = localStorage.getItem('theme') || 'dark';
    document.body.className = savedTheme;

    // Initialize settings manager (works for both settings and plans pages)
    window.settingsManager = new SettingsManager();
});