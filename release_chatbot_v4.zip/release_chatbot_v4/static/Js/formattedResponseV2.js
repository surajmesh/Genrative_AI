// js/formattedResponseV2.js
(function() {
    'use strict';
    
    // Cache for performance
    const formatterCache = new Map();
    const MAX_CACHE_SIZE = 50;
    
    // Enhanced sanitization using DOMPurify
    function sanitizeOutput(html) {
        if (window.DOMPurify) {
            return DOMPurify.sanitize(html, {
                ALLOWED_TAGS: [
                    'p', 'br', 'strong', 'em', 'code', 'pre', 
                    'blockquote', 'ul', 'ol', 'li', 'a', 'h1', 
                    'h2', 'h3', 'h4', 'h5', 'h6', 'table', 
                    'thead', 'tbody', 'tr', 'td', 'th', 'div', 
                    'span', 'button', 'svg', 'path', 'rect',
                    'hr', 'del', 'mark', 'sup', 'sub'
                ],
                ALLOWED_ATTR: [
                    'class', 'id', 'href', 'target', 'rel', 
                    'style', 'data-code-id', 'data-language',
                    'width', 'height', 'viewBox', 'fill', 
                    'stroke', 'stroke-width', 'd', 'x', 'y',
                    'rx', 'ry', 'aria-label'
                ],
                ALLOWED_URI_REGEXP: /^(?:(?:https?|mailto):|[^a-z]|[a-z+.-]+(?:[^a-z+.\-:]|$))/i
            });
        }
        
        // Fallback to original sanitization
        return sanitizeOutputOriginal(html);  // FIXED: correct function name
    }
    
    // Original sanitization as fallback
    function sanitizeOutputOriginal(html) {
        html = html.replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '');
        html = html.replace(/javascript:/gi, '');
        html = html.replace(/on\w+\s*=/gi, '');
        html = html.replace(/<iframe\b[^<]*(?:(?!<\/iframe>)<[^<]*)*<\/iframe>/gi, '');
        html = html.replace(/<object\b[^<]*(?:(?!<\/object>)<[^<]*)*<\/object>/gi, '');
        html = html.replace(/<embed\b[^>]*>/gi, '');
        return html;
    }

    function detectLanguage(specifiedLang, code) {
        if (specifiedLang && specifiedLang.trim()) {
            console.log('Language specified:', specifiedLang);
            return specifiedLang.toLowerCase().trim();
        }
        
        if (!code || typeof code !== 'string' || code.trim().length === 0) {
            console.log('No code provided, defaulting to text');
            return 'text';
        }

        const cleanCode = code.trim();
        
        const patterns = {
            'javascript': /\b(const|let|var|function|=>|console\.log|document\.|window\.|export|import|require|module\.exports|async|await|Promise|\.then|\.catch)\b/,
            'typescript': /\b(interface|type\s+\w+\s*=|:\s*\w+\[\]|\bimplements\b|enum\s+\w+|declare|namespace|readonly)\b/,
            'python': /\b(def\s+|import\s+|from\s+|print\(|if\s+__name__|self\.|class\s+\w+|elif\s|except\s|lambda|yield|with\s+.*\s+as)\b/,
            'html': /<(!DOCTYPE|html|head|body|div|span|script|style|meta|link|href|src)[^>]*>/i,
            'css': /([.#][\w-]+\s*\{|@media|@import|:root|--[\w-]+:|[a-zA-Z-]+\s*:\s*[^;]+;)/,
            'scss': /(\$[\w-]+\s*:|@mixin|@include|@extend|&\s*\{|%[\w-]+|@function)/,
            'json': /^\s*[\{\[][\s\S]*[\}\]]\s*$/m,
            'sql': /\b(SELECT|FROM|WHERE|INSERT\s+INTO|UPDATE|DELETE\s+FROM|JOIN|ON|GROUP\s+BY|ORDER\s+BY|CREATE\s+TABLE|ALTER|DROP)\b/i,
            'bash': /(^|\n)\s*(#!\/bin\/bash|#!\/bin\/sh|cd\s+|ls\s+|echo\s+|grep\s+|chmod\s+|mkdir\s+|rm\s+|cp\s+|mv\s+|sudo\s+)/,
            'shell': /(^|\n)\s*\$\s+\w+/,
            'java': /\b(public\s+class|private\s+|protected\s+|public\s+static\s+void\s+main|System\.out\.println|extends|implements|package\s+|import\s+java)\b/,
            'csharp': /\b(namespace|using\s+System|Console\.Write|public\s+class|private\s+void|protected\s+|internal\s+|async\s+Task)\b/,
            'cpp': /\b(#include\s*<.*?>|std::|cout\s*<<|cin\s*>>|namespace\s+\w+|template\s*<|nullptr|auto\s+\w+\s*=)\b/,
            'php': /(<\?php|\$[\w]+\s*=|function\s+\w+\s*\(|echo\s+|require_once|include_once|namespace\s+[\w\\]+)/,
            'ruby': /\b(def\s+\w+|end\b|puts\s+|class\s+\w+|require\s+|attr_\w+|module\s+|\.each\s*\{|\bdo\s*\|)/,
            'go': /\b(func\s+\w+\s*\(|package\s+\w+|import\s+\(|fmt\.\w+\(|var\s+\w+\s+\w+|type\s+\w+\s+struct|defer\s+)\b/,
            'rust': /\b(fn\s+\w+|let\s+mut|impl\s+\w+|pub\s+fn|use\s+std::|match\s+\w+\s*\{|Some\(|None|Ok\(|Err\()\b/,
            'swift': /\b(func\s+\w+|var\s+\w+\s*:|let\s+\w+\s*:|import\s+\w+|class\s+\w+|struct\s+\w+|enum\s+\w+|protocol\s+)\b/,
            'kotlin': /\b(fun\s+\w+|val\s+\w+|var\s+\w+|class\s+\w+|package\s+|import\s+|data\s+class|companion\s+object)\b/,
            'yaml': /^[\w-]+:\s*[\w\s]*$/m,
            'xml': /(<\?xml|<\w+[\s>].*<\/\w+>|<\w+\s+[\w:]+="[^"]*")/,
            'markdown': /(^#{1,6}\s+.+|!\[.*?\]\(.*?\)|\[.*?\]\(.*?\)|^\s*[-*+]\s+|\*\*.*?\*\*|__.*?__)/m,
            'r': /\b(library\(|require\(|function\s*\(|<-|%>%|ggplot\(|data\.frame\()\b/,
            'matlab': /\b(function\s+\w+|end\b|fprintf\(|disp\(|clear\s+all|close\s+all|figure\()\b/,
            'latex': /(\\documentclass|\\begin\{|\\end\{|\\section\{|\\usepackage\{|\\[a-zA-Z]+\{)/,
            'dockerfile': /^ *(FROM|RUN|CMD|EXPOSE|ENV|ADD|COPY|WORKDIR)\b/im,
            'makefile': /(^[\w-]+\s*:\s*[\w-]*|^\t+\w+|^\.PHONY:|^include\s+)/m
        };

        // Test each pattern
        for (const [lang, pattern] of Object.entries(patterns)) {
            if (pattern.test(cleanCode)) {
                console.log('Detected language:', lang);
                return lang;
            }
        }

        console.log('No language pattern matched, defaulting to text');
        return 'text';
    }
   
    /**
     * Format blockquotes
     */
    function formatBlockquotes(text) {
        const lines = text.split('\n');
        const result = [];
        let blockquoteLines = [];
        let inBlockquote = false;
        
        for (let i = 0; i < lines.length; i++) {
            const line = lines[i];
            const isQuoteLine = line.trim().startsWith('>');
            
            if (isQuoteLine) {
                inBlockquote = true;
                const quotedText = line.replace(/^\s*>\s?/, '');
                blockquoteLines.push(quotedText);
            } else {
                if (inBlockquote && blockquoteLines.length > 0) {
                    result.push(`<blockquote class="formatted-blockquote">${blockquoteLines.join('<br>')}</blockquote>`);
                    blockquoteLines = [];
                    inBlockquote = false;
                }
                result.push(line);
            }
        }
        
        // Handle remaining blockquote lines
        if (blockquoteLines.length > 0) {
            result.push(`<blockquote class="formatted-blockquote">${blockquoteLines.join('<br>')}</blockquote>`);
        }
        
        return result.join('\n');
    }

    /**
     * Format horizontal rules
     */
    function formatHorizontalRules(text) {
        // Match --- or *** or ___ on their own line
        return text.replace(/^[\s]*[-*_]{3,}[\s]*$/gm, '<hr class="formatted-hr">');
    }

    /**
     * Enhanced table formatting with better parsing
     */
    function formatTables(text, config) {
        const lines = text.split('\n');
        let result = [];
        let i = 0;
        
        while (i < lines.length) {
            const line = lines[i].trim();
            
            // Check if this line starts a table
            if (isTableRow(line)) {
                const tableData = parseTable(lines, i, config);
                if (tableData.isValid) {
                    result.push(generateTable(tableData));
                    i = tableData.lastIndex;
                } else {
                    result.push(lines[i]);
                }
            } else {
                result.push(lines[i]);
            }
            i++;
        }
        
        return result.join('\n');
    }

    /**
     * Check if a line could be a table row
     */
    function isTableRow(line) {
        // Must have at least 2 pipes to form a table
        const pipes = (line.match(/\|/g) || []).length;
        return pipes >= 2 && !line.startsWith('|---');
    }

    /**
     * Parse table structure with validation
     */
    function parseTable(lines, startIndex, config) {
        const tableRows = [];
        let currentIndex = startIndex;
        let headerProcessed = false;
        let alignments = [];
        
        while (currentIndex < lines.length) {
            const line = lines[currentIndex].trim();
            
            if (!line || !line.includes('|')) {
                break;
            }
            
            // Parse cells
            let cells = line.split('|').map(cell => cell.trim());
            
            // Remove empty cells at start and end if line starts/ends with |
            if (line.startsWith('|')) cells.shift();
            if (line.endsWith('|')) cells.pop();
            
            // Check for separator row (like |---|---|)
            if (cells.every(cell => /^:?-+:?$/.test(cell))) {
                // Parse alignments from separator row
                alignments = cells.map(cell => {
                    if (cell.startsWith(':') && cell.endsWith(':')) return 'center';
                    if (cell.endsWith(':')) return 'right';
                    return 'left';
                });
                headerProcessed = true;
                currentIndex++;
                continue;
            }
            
            // Validate column count consistency
            if (tableRows.length > 0 && cells.length !== tableRows[0].cells.length) {
                // Allow slight variations but break on major inconsistencies
                if (Math.abs(cells.length - tableRows[0].cells.length) > 1) {
                    break;
                }
            }
            
            // Check maximum columns limit
            if (cells.length > config.maxTableColumns) {
                break;
            }
            
            tableRows.push({
                cells: cells,
                isHeader: tableRows.length === 0 && !headerProcessed
            });
            
            currentIndex++;
        }
        
        return {
            rows: tableRows,
            alignments: alignments,
            isValid: tableRows.length >= 2, // At least header + one data row
            lastIndex: currentIndex - 1
        };
    }

    /**
     * Generate HTML table from parsed data
     */
    function generateTable(tableData) {
        let html = '<div class="table-wrapper"><table class="formatted-table">';
        
        // Process rows
        let hasHeader = false;
        tableData.rows.forEach((row, index) => {
            if (index === 0 && row.isHeader) {
                // First row with content - treat as header
                html += '<thead><tr>';
                row.cells.forEach((cell, cellIndex) => {
                    const align = tableData.alignments[cellIndex] || 'left';
                    html += `<th style="text-align: ${align}">${formatTableCell(cell)}</th>`;
                });
                html += '</tr></thead><tbody>';
                hasHeader = true;
            } else {
                if (!hasHeader && index === 0) {
                    html += '<tbody>';
                }
                html += '<tr>';
                row.cells.forEach((cell, cellIndex) => {
                    const align = tableData.alignments[cellIndex] || 'left';
                    html += `<td style="text-align: ${align}">${formatTableCell(cell || '')}</td>`;
                });
                html += '</tr>';
            }
        });
        
        html += '</tbody></table></div>';
        
        return html;
    }

    /**
     * Format table cell content (allow inline formatting)
     */
    function formatTableCell(content) {
        let formatted = escapeHtml(content);
        
        // Allow basic inline formatting in table cells
        formatted = formatted.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');
        formatted = formatted.replace(/\*([^*]+)\*/g, '<em>$1</em>');
        formatted = formatted.replace(/`([^`]+)`/g, '<code>$1</code>');
        
        return formatted;
    }

    /**
     * Enhanced list formatting with nested support
     */
    function formatLists(text, config) {
        const lines = text.split('\n');
        const result = [];
        let i = 0;
        
        while (i < lines.length) {
            const listData = parseList(lines, i, config);
            if (listData.isValid) {
                result.push(generateList(listData));
                i = listData.lastIndex;
            } else {
                result.push(lines[i]);
            }
            i++;
        }
        
        return result.join('\n');
    }

    /**
     * Parse list structure with nesting support
     */
    function parseList(lines, startIndex, config) {
        const items = [];
        let currentIndex = startIndex;
        let listType = null;
        let previousIndent = -1;
        
        while (currentIndex < lines.length) {
            const line = lines[currentIndex];
            const trimmed = line.trim();
            
            if (!trimmed) {
                // Empty line might end the list or be within it
                if (items.length > 0 && currentIndex + 1 < lines.length) {
                    const nextLine = lines[currentIndex + 1];
                    if (!isListItem(nextLine)) {
                        break; // End of list
                    }
                }
                currentIndex++;
                continue;
            }
            
            const listMatch = parseListItem(line);
            if (!listMatch) {
                // Check if it's a continuation of the previous item
                if (items.length > 0 && line.startsWith('  ')) {
                    // Continuation line
                    items[items.length - 1].text += '\n' + trimmed;
                    currentIndex++;
                    continue;
                }
                break; // Not a list item
            }
            
            // Determine list type from first item
            if (listType === null) {
                listType = listMatch.type;
            }
            
            // Check nesting depth
            if (listMatch.level > config.maxListDepth) {
                break;
            }
            
            items.push({
                text: listMatch.text,
                level: listMatch.level,
                type: listMatch.type,
                marker: listMatch.marker
            });
            
            previousIndent = listMatch.level;
            currentIndex++;
        }
        
        return {
            items: items,
            type: listType,
            isValid: items.length > 0,
            lastIndex: currentIndex - 1
        };
    }

    /**
     * Parse individual list item with nesting level
     */
    function parseListItem(line) {
        const indentMatch = line.match(/^(\s*)/);
        const indent = indentMatch ? indentMatch[1].length : 0;
        const level = Math.floor(indent / 2); // 2 spaces per level
        
        const trimmed = line.trim();
        
        // Bullet points (-, *, +)
        const bulletMatch = trimmed.match(/^([-*+])\s+(.*)$/);
        if (bulletMatch) {
            return {
                text: bulletMatch[2],
                level: level,
                type: 'ul',
                marker: bulletMatch[1]
            };
        }
        
        // Numbered lists (1., 2., etc.)
        const numberedMatch = trimmed.match(/^(\d+)\.\s+(.*)$/);
        if (numberedMatch) {
            return {
                text: numberedMatch[2],
                level: level,
                type: 'ol',
                marker: numberedMatch[1]
            };
        }
        
        // Letter lists (a., b., etc.)
        const letterMatch = trimmed.match(/^([a-z])\.\s+(.*)$/i);
        if (letterMatch) {
            return {
                text: letterMatch[2],
                level: level,
                type: 'ol',
                marker: letterMatch[1]
            };
        }
        
        return null;
    }

    /**
     * Check if line is a list item
     */
    function isListItem(line) {
        const trimmed = line.trim();
        return /^[-*+]\s/.test(trimmed) || /^\d+\.\s/.test(trimmed) || /^[a-z]\.\s/i.test(trimmed);
    }

    /**
     * Generate nested HTML list
     */
    function generateList(listData) {
        if (listData.items.length === 0) return '';
        
        let html = '';
        let currentLevel = 0;
        const openTags = [];
        
        listData.items.forEach((item, index) => {
            // Handle level changes
            while (currentLevel < item.level) {
                const tag = item.type;
                const listClass = currentLevel === 0 ? 'formatted-list' : 'nested-list';
                html += `<${tag} class="${listClass}">`;
                openTags.push(tag);
                currentLevel++;
            }
            
            while (currentLevel > item.level) {
                const tag = openTags.pop();
                html += `</${tag}>`;
                currentLevel--;
            }
            
            // Add list item with proper formatting
            const formattedText = formatListItemText(item.text);
            html += `<li>${formattedText}</li>`;
        });
        
        // Close remaining open tags
        while (openTags.length > 0) {
            const tag = openTags.pop();
            html += `</${tag}>`;
        }
        
        return html;
    }

    /**
     * Format text within list items
     */
    function formatListItemText(text) {
        let formatted = escapeHtml(text);
        
        // Allow inline formatting in list items
        formatted = formatted.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');
        formatted = formatted.replace(/\*([^*]+)\*/g, '<em>$1</em>');
        formatted = formatted.replace(/`([^`]+)`/g, '<code class="inline-code">$1</code>');
        
        // Handle line breaks within list items
        formatted = formatted.replace(/\n/g, '<br>');
        
        return formatted;
    }

    /**
     * Enhanced mathematical formula formatting
     */
    function formatFormulas(text) {
        // Display math blocks ($$...$$)
        text = text.replace(/\$\$\n?([\s\S]*?)\n?\$\$/g, (match, formula) => {
            return `<div class="math-display">${escapeHtml(formula.trim())}</div>`;
        });
        
        // Inline math ($...$) - but not currency
        text = text.replace(/(?<![\\$])\$(?!\d)([^$\n]+?)\$(?!\d)/g, (match, formula) => {
            // Check if it looks like currency
            if (/^\d+\.?\d*$/.test(formula.trim())) {
                return match; // Keep as is if it's just a number
            }
            return `<span class="math-inline">${escapeHtml(formula)}</span>`;
        });
        
        // LaTeX-style math blocks
        text = text.replace(/\\\[([\s\S]*?)\\\]/g, (match, formula) => {
            return `<div class="math-display">${escapeHtml(formula.trim())}</div>`;
        });
        
        // LaTeX-style inline math
        text = text.replace(/\\\((.*?)\\\)/g, (match, formula) => {
            return `<span class="math-inline">${escapeHtml(formula)}</span>`;
        });
        
        return text;
    }

    /**
     * Enhanced header formatting with ID generation
     */
    function formatHeaders(text) {
        const lines = text.split('\n');
        const result = [];
        
        lines.forEach(line => {
            let headerMatch = null;
            let headerLevel = 0;
            
            // Check for hash-style headers
            for (let level = 6; level >= 1; level--) {
                const regex = new RegExp(`^${'#'.repeat(level)}\\s+(.+)$`);
                const match = line.match(regex);
                if (match) {
                    headerMatch = match;
                    headerLevel = level;
                    break;
                }
            }
            
            if (headerMatch) {
                const title = headerMatch[1].trim();
                const id = generateHeaderId(title);
                result.push(`<h${headerLevel} class="header-${headerLevel}" id="${id}">${escapeHtml(title)}</h${headerLevel}>`);
            } else {
                result.push(line);
            }
        });
        
        return result.join('\n');
    }

    /**
     * Generate URL-friendly header ID
     */
    function generateHeaderId(title) {
        return title.toLowerCase()
            .replace(/[^\w\s-]/g, '')
            .replace(/\s+/g, '-')
            .replace(/-+/g, '-')
            .trim()
            .substring(0, 50); // Limit length
    }

    /**
     * Enhanced text style formatting
     */
    function formatTextStyles(text) {
        // Bold text (** or __)
        text = text.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');
        text = text.replace(/__([^_]+)__/g, '<strong>$1</strong>');
        
        // Italic text (* or _) - more careful matching
        text = text.replace(/(?<!\*)\*([^*\s][^*]*[^*\s]|\S)\*(?!\*)/g, '<em>$1</em>');
        text = text.replace(/(?<!_)_([^_\s][^_]*[^_\s]|\S)_(?!_)/g, '<em>$1</em>');
        
        // Strikethrough
        text = text.replace(/~~([^~]+)~~/g, '<del>$1</del>');
        
        // Highlight
        text = text.replace(/==([^=]+)==/g, '<mark>$1</mark>');
        
        // Superscript
        text = text.replace(/\^([^\s^]+)\^/g, '<sup>$1</sup>');
        
        // Subscript
        text = text.replace(/~([^\s~]+)~/g, '<sub>$1</sub>');
        
        return text;
    }

    /**
     * Enhanced link formatting
     */
    function formatLinks(text) {
        // Markdown links [text](url)
        text = text.replace(/\[([^\]]+)\]\(([^)]+)\)/g, (match, linkText, url) => {
            const cleanUrl = url.trim();
            const isExternal = /^https?:\/\//.test(cleanUrl);
            const target = isExternal ? ' target="_blank" rel="noopener noreferrer"' : '';
            return `<a href="${escapeHtml(cleanUrl)}"${target} class="formatted-link">${escapeHtml(linkText)}</a>`;
        });
        
        // Reference-style links [text][ref]
        text = text.replace(/\[([^\]]+)\]\[([^\]]+)\]/g, (match, linkText, ref) => {
            return `<a href="#${escapeHtml(ref)}" class="reference-link">${escapeHtml(linkText)}</a>`;
        });
        
        // Auto-link URLs (but not inside existing tags)
        text = text.replace(/(?<!["'>])(https?:\/\/[^\s<>"']+)/g, (url) => {
            // Truncate long URLs for display
            const displayUrl = url.length > 50 ? url.substring(0, 47) + '...' : url;
            return `<a href="${escapeHtml(url)}" target="_blank" rel="noopener noreferrer" class="auto-link">${escapeHtml(displayUrl)}</a>`;
        });
        
        // Email addresses
        text = text.replace(/([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})/g, (email) => {
            return `<a href="mailto:${escapeHtml(email)}" class="email-link">${escapeHtml(email)}</a>`;
        });
        
        return text;
    }

    /**
     * Enhanced special character formatting
     */
    function formatSpecialCharacters(text) {
        const replacements = {
            '(c)': '©', '(C)': '©',
            '(r)': '®', '(R)': '®',
            '(tm)': '™', '(TM)': '™',
            '...': '…',
            '--': '–',
            '---': '—',
            '->': '→',
            '<-': '←',
            '<->': '↔',
            '=>': '⇒',
            '<=': '⇐',
            '<=>': '⇔',
            '!=': '≠',
            '>=': '≥',
            '<=': '≤',
            '+-': '±',
            '1/2': '½',
            '1/3': '⅓',
            '2/3': '⅔',
            '1/4': '¼',
            '3/4': '¾',
            '1/8': '⅛',
            '3/8': '⅜',
            '5/8': '⅝',
            '7/8': '⅞'
        };
        
        for (const [pattern, replacement] of Object.entries(replacements)) {
            const regex = new RegExp(escapeRegExp(pattern), 'g');
            text = text.replace(regex, replacement);
        }
        
        return text;
    }

    /**
     * Enhanced paragraph formatting
     */

    function formatParagraphs(text, config) {
        // Split by double line breaks for paragraphs
        const blocks = text.split(/\n\s*\n/);
        
        return blocks.map(block => {
            const trimmed = block.trim();
            if (!trimmed) return '';
            
            // Don't wrap if it's already an HTML block element
            if (isBlockElement(trimmed)) {
                return trimmed;
            }
            
            // IMPORTANT: Don't wrap protected placeholders
            if (/^__PROTECTED_\d+__$/.test(trimmed)) {
                return trimmed;
            }
            
            // Check if block contains ONLY a protected placeholder
            if (/^\s*__PROTECTED_\d+__\s*$/.test(trimmed)) {
                return trimmed;
            }
            
            // Check if it's a single line that might be a heading
            if (trimmed.split('\n').length === 1 && trimmed.length < 100 && !trimmed.includes('.')) {
                // Might be a title, don't wrap
                return trimmed;
            }
            
            // Handle single line breaks within paragraphs
            const withBreaks = config.preserveWhitespace 
                ? trimmed.replace(/\n/g, '<br>')
                : trimmed.replace(/\n/g, ' ');
                
            // Don't wrap if it contains protected blocks
            if (/__PROTECTED_\d+__/.test(withBreaks)) {
                return withBreaks;
            }
                
            return `<p class="formatted-paragraph">${withBreaks}</p>`;
        }).filter(p => p).join('\n\n');
    }

    /**
     * Check if content is already a block-level HTML element
     */
    function isBlockElement(text) {
        const blockTags = /^<(?:div|p|h[1-6]|table|ul|ol|pre|blockquote|section|article|aside|header|footer|nav|main|hr)/i;
        return blockTags.test(text.trim());
    }

    /**
     * Escape HTML characters
     */
    function escapeHtml(text) {
        if (typeof text !== 'string') return '';
        
        const htmlEscapes = {
            '&': '&amp;',
            '<': '&lt;',
            '>': '&gt;',
            '"': '&quot;',
            "'": '&#x27;',
            '/': '&#x2F;'
        };
        
        return text.replace(/[&<>"'/]/g, (match) => htmlEscapes[match]);
    }

    /**
     * Escape regex special characters
     */
    function escapeRegExp(string) {
        return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    }
    
   // Enhanced main function with caching
    function formatLLMResponse(rawResponse, options = {}) {
        if (!rawResponse || typeof rawResponse !== 'string') {
            return '';
        }
        
        const MAX_LENGTH = 1000000; // 1MB
        if (rawResponse.length > MAX_LENGTH) {
            console.warn('Input too large for formatting');
            return escapeHtml(rawResponse);
        }
        
        const cacheKey = rawResponse.substring(0, 100) + JSON.stringify(options);
        if (formatterCache.has(cacheKey)) {
            return formatterCache.get(cacheKey);
        }
        
        try {
            const config = {
                preserveWhitespace: false,
                enableMath: true,
                enableTables: true,
                enableCodeBlocks: true,
                enableLists: true,
                enableHeaders: true,
                enableLinks: true,
                sanitizeHtml: true,
                maxTableColumns: 20,
                maxListDepth: 5,
                enableCopyButton: true,
                enableSyntaxHighlight: true,
                enableBlockquotes: true,
                enableHorizontalRules: true,
                ...options
            };
            
            let formatted = rawResponse.trim();

            // Step 1: Extract code blocks and inline code with SAFE markers
            const codeBlocks = [];
            const inlineCode = [];
            let codeIndex = 0;
            let inlineIndex = 0;
            
            // Use unique base64-like markers that won't be touched by formatters
            const generateSafeMarker = (type, index) => {
                return `\u0001${type}${index}\u0002`;
            };
            
            // Extract code blocks first
            formatted = formatted.replace(/```(\w*)\n?([\s\S]*?)```/g, (match, lang, code) => {
                const marker = generateSafeMarker('CODEBLOCK', codeIndex);
                codeBlocks.push({ lang, code, marker });
                codeIndex++;
                return marker;
            });
            
            // Extract inline code
            formatted = formatted.replace(/`([^`\n]+)`/g, (match, code) => {
                const marker = generateSafeMarker('INLINE', inlineIndex);
                inlineCode.push({ code, marker });
                inlineIndex++;
                return marker;
            });

            // Step 2: Process all other formatting
            if (config.enableTables) {
                formatted = formatTables(formatted, config);
            }
            
            if (config.enableMath) {
                formatted = formatFormulas(formatted);
            }
            
            if (config.enableLists) {
                formatted = formatLists(formatted, config);
            }
            
            if (config.enableBlockquotes) {
                formatted = formatBlockquotes(formatted);
            }
            
            if (config.enableHeaders) {
                formatted = formatHeaders(formatted);
            }
            
            if (config.enableHorizontalRules) {
                formatted = formatHorizontalRules(formatted);
            }
            
            // Text styles will no longer affect our markers
            formatted = formatTextStyles(formatted);
            
            if (config.enableLinks) {
                formatted = formatLinks(formatted);
            }
            
            formatted = formatSpecialCharacters(formatted);
            formatted = formatParagraphs(formatted, config);

            // Step 3: Restore inline code FIRST
            inlineCode.forEach(({ code, marker }) => {
                const inlineHtml = `<code class="inline-code">${escapeHtml(code)}</code>`;
                // Simple string replacement since our markers are unique
                while (formatted.includes(marker)) {
                    formatted = formatted.replace(marker, inlineHtml);
                }
            });

            // Step 4: Restore code blocks LAST
            if (config.enableCodeBlocks) {
                let codeBlockId = 0;
                codeBlocks.forEach(({ lang, code, marker }) => {
                    const language = detectLanguage(lang, code) || 'text';
                    const formattedCode = escapeHtml(code.trim());
                    const blockId = `code-block-${Date.now()}-${codeBlockId++}`;
                    
                    let codeHtml = `<div class="code-block-container">`;
                    codeHtml += `<div class="code-block-header">
                        <span class="code-language">${escapeHtml(language)}</span>`;
                    
                    if (config.enableCopyButton) {
                        // SECURE VERSION - no onclick
                        codeHtml += `<button class="copy-code-btn" 
                            data-code-id="${escapeHtml(blockId)}"
                            aria-label="Copy code to clipboard">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect>
                                <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path>
                            </svg>
                            <span class="copy-btn-text">Copy</span>
                        </button>`;
                    }
                    
                    codeHtml += `</div>`;
                    codeHtml += `<pre class="code-block language-${escapeHtml(language)}" id="${escapeHtml(blockId)}"><code>${formattedCode}</code></pre>`;
                    codeHtml += `</div>`;
                    
                    // Simple string replacement since our markers are unique
                    while (formatted.includes(marker)) {
                        formatted = formatted.replace(marker, codeHtml);
                    }
                });
            }
            
            // Final sanitization
            if (config.sanitizeHtml) {
                formatted = sanitizeOutput(formatted);
            }
            
            // Cache management
            if (formatterCache.size >= MAX_CACHE_SIZE) {
                const firstKey = formatterCache.keys().next().value;
                formatterCache.delete(firstKey);
            }
            formatterCache.set(cacheKey, formatted);
            
            return formatted;
            
        } catch (error) {
            console.error('Formatting error:', error);
            return escapeHtml(rawResponse);
        }
    }
    // Export to window
    window.formatLLMResponse = formatLLMResponse;


    console.log("Enhanced formatLLMResponse V2 loaded");
})();