"""
1. Database Tables Structure:

User Management: Registration, login, session tracking
Chat Organization: Sessions grouped by user with optional projects
Message Storage: Complete chat history with AI provider metadata
Analytics: Track usage patterns, provider preferences, response times

"""
from datetime import datetime
from uuid import uuid4
import secrets
from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash
from itsdangerous import URLSafeTimedSerializer
import os

db = SQLAlchemy()

class User(UserMixin, db.Model):
    # User authentication and profile management
    __tablename__ = 'user'
    
    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid4()))
    email = db.Column(db.String(120), unique=True, nullable=False, index=True)
    username = db.Column(db.String(64), unique=True, nullable=False)
    fullname = db.Column(db.String(100), nullable=True)
    password_hash = db.Column(db.String(256), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    last_login = db.Column(db.DateTime, nullable=True)
    is_active = db.Column(db.Boolean, default=True)
    
    # Password reset functionality
    reset_token = db.Column(db.String(100), nullable=True)
    reset_token_expires = db.Column(db.DateTime, nullable=True)
    
    # Microsoft integration fields for future use
    ms_identity_id = db.Column(db.String(255), unique=True, nullable=True)
    ms_tenant_id = db.Column(db.String(255), nullable=True)
    
    # Relationships
    chat_sessions = db.relationship('ChatSession', back_populates='user', lazy='dynamic')
    projects = db.relationship('Project', back_populates='user', lazy='dynamic')
    user_sessions = db.relationship('UserSession', back_populates='user', lazy='dynamic')
    
    # Google Outh 
    google_id = db.Column(db.String(100), unique=True, nullable=True)
    is_google_user = db.Column(db.Boolean, default=False)
    
    def set_password(self, password):
        # Hash and store password
        self.password_hash = generate_password_hash(password)
    
    def check_password(self, password):
        # Verify password against hash
        if self.password_hash:
            return check_password_hash(self.password_hash, password)
        return False
    
    def generate_reset_token(self):
        # Generate secure reset token
        self.reset_token = secrets.token_urlsafe(32)
        self.reset_token_expires = datetime.utcnow() + datetime.timedelta(hours=1)
        return self.reset_token
    
    def verify_reset_token(self, token):
        # Verify reset token is valid and not expired
        if not self.reset_token or not self.reset_token_expires:
            return False
        if datetime.utcnow() > self.reset_token_expires:
            return False
        return self.reset_token == token
    
    def clear_reset_token(self):
        # Clear reset token after use
        self.reset_token = None
        self.reset_token_expires = None
    
    @staticmethod
    def find_by_reset_token(token):
        # Find user by reset token
        return User.query.filter_by(reset_token=token).first()
    
    def to_dict(self):
        # Convert user to dictionary
        return {
            'id': self.id,
            'google_id': self.google_id,
            'email': self.email,
            'username': self.username,
            'fullname': self.fullname,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'last_login': self.last_login.isoformat() if self.last_login else None,
            'is_active': self.is_active,
            'has_microsoft_auth': bool(self.ms_identity_id),
            'is_google_user':self.is_google_user,

        }
    
    def __repr__(self):
        return f'<User {self.username}>'

class ChatMessage(db.Model):
    # Individual chat messages with AI provider tracking
    __tablename__ = 'chat_message'
    
    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid4()))
    session_id = db.Column(db.String(36), db.ForeignKey('chat_session.id'), nullable=False)
    role = db.Column(db.String(20), nullable=False)  # user, assistant, system
    content = db.Column(db.Text, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # AI provider tracking
    provider = db.Column(db.String(50), nullable=True)  # openai, anthropic, google, groq
    model = db.Column(db.String(100), nullable=True)  # gpt-4o, claude-3-5-sonnet, etc
    reasoning_used = db.Column(db.Boolean, default=False)
    response_time = db.Column(db.Float, nullable=True)  # seconds
    
    # Token and cost tracking
    input_tokens = db.Column(db.Integer, nullable=True)
    output_tokens = db.Column(db.Integer, nullable=True)
    total_tokens = db.Column(db.Integer, nullable=True)
    estimated_cost = db.Column(db.Float, nullable=True)
    
    # File handling
    file_path = db.Column(db.Text, nullable=True)  
    file_type = db.Column(db.String(50), nullable=True)
    has_uploads = db.Column(db.Boolean, default=False)
    file_names = db.Column(db.Text, nullable=True)
    
    # Enhanced mode flags
    enable_web_search = db.Column(db.Boolean, default=False)
    enable_deep_research = db.Column(db.Boolean, default=False)
    enable_study_learn = db.Column(db.Boolean, default=False)
    
    # NEW: AI Response Feedback
    user_feedback = db.Column(db.String(50), nullable=True)  # 'Good Response', 'Bad Response', null
    feedback_timestamp = db.Column(db.DateTime, nullable=True)
    feedback_comment = db.Column(db.Text, nullable=True)  # Optional detailed feedback
    
    # Message metadata
    message_index = db.Column(db.Integer, nullable=True)  # Order in conversation
    parent_message_id = db.Column(db.String(36), nullable=True)  # For threaded conversations
    
    # Relationships
    session = db.relationship('ChatSession', back_populates='messages')
    enhanced_sources = db.relationship('EnhancedSource', back_populates='message', cascade='all, delete-orphan')
    
    def to_dict(self):
        # Convert message to dictionary
        return {
            'id': self.id,
            'session_id': self.session_id,
            'role': self.role,
            'content': self.content,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'provider': self.provider,
            'model': self.model,
            'reasoning_used': self.reasoning_used,
            'response_time': self.response_time,
            'input_tokens': self.input_tokens,
            'output_tokens': self.output_tokens,
            'total_tokens': self.total_tokens,
            'estimated_cost': self.estimated_cost,
            'file_path': self.file_path,
            'file_type': self.file_type,
            'has_uploads': self.has_uploads,
            'file_names': self.file_names,
            'enable_web_search': self.enable_web_search,
            'enable_deep_research': self.enable_deep_research,
            'enable_study_learn': self.enable_study_learn,
            'user_feedback': self.user_feedback,
            'feedback_timestamp': self.feedback_timestamp.isoformat() if self.feedback_timestamp else None,
            'feedback_comment': self.feedback_comment,
            'message_index': self.message_index,
            'parent_message_id': self.parent_message_id,
            'enhanced_sources': [source.to_dict() for source in self.enhanced_sources]
        }
    
    def __repr__(self):
        return f'<ChatMessage {self.role} in {self.session_id}>'

class UserSession(db.Model):
    # Track user login sessions for analytics
    __tablename__ = 'user_session'
    
    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid4()))
    user_id = db.Column(db.String(36), db.ForeignKey('user.id'), nullable=False)
    login_time = db.Column(db.DateTime, default=datetime.utcnow)
    logout_time = db.Column(db.DateTime, nullable=True)
    ip_address = db.Column(db.String(45), nullable=True)  # IPv6 compatible
    user_agent = db.Column(db.String(500), nullable=True)
    is_active = db.Column(db.Boolean, default=True)
    
    # Session statistics
    messages_sent = db.Column(db.Integer, default=0)
    sessions_created = db.Column(db.Integer, default=0)
    total_time_spent = db.Column(db.Integer, default=0)  # seconds
    
    # Relationships
    user = db.relationship('User', back_populates='user_sessions')
    
    def to_dict(self):
        # Convert session to dictionary
        return {
            'id': self.id,
            'user_id': self.user_id,
            'login_time': self.login_time.isoformat() if self.login_time else None,
            'logout_time': self.logout_time.isoformat() if self.logout_time else None,
            'ip_address': self.ip_address,
            'is_active': self.is_active,
            'messages_sent': self.messages_sent,
            'sessions_created': self.sessions_created,
            'total_time_spent': self.total_time_spent
        }
    
    def __repr__(self):
        return f'<UserSession {self.user_id} at {self.login_time}>'

class EnhancedSource(db.Model):
    # Store web search and research sources for messages
    __tablename__ = 'enhanced_source'
    
    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid4()))
    message_id = db.Column(db.String(36), db.ForeignKey('chat_message.id'), nullable=False)
    user_id = db.Column(db.String(36), db.ForeignKey('user.id'), nullable=False)
    session_id = db.Column(db.String(36), db.ForeignKey('chat_session.id'), nullable=False)
    
    # Source information
    title = db.Column(db.String(500), nullable=True)
    url = db.Column(db.Text, nullable=True)
    content = db.Column(db.Text, nullable=True)
    summary = db.Column(db.Text, nullable=True)
    
    # Source metadata
    source_type = db.Column(db.String(50), default='web_search')  # web_search, research, document
    relevance_score = db.Column(db.Float, nullable=True)  # 0.0 to 1.0
    search_query = db.Column(db.String(500), nullable=True)  # Original query used
    
    # Timestamps
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    fetched_at = db.Column(db.DateTime, nullable=True)  # When source was fetched
    
    # Mode context
    triggered_by_web_search = db.Column(db.Boolean, default=False)
    triggered_by_deep_research = db.Column(db.Boolean, default=False)
    triggered_by_study_learn = db.Column(db.Boolean, default=False)
    
    # Source quality metrics
    word_count = db.Column(db.Integer, nullable=True)
    domain = db.Column(db.String(255), nullable=True)  # website domain
    is_primary_source = db.Column(db.Boolean, default=False)
    
    # FIXED: Relationships with proper back_populates
    message = db.relationship('ChatMessage', back_populates='enhanced_sources')
    user = db.relationship('User', backref='user_enhanced_sources')
    session = db.relationship('ChatSession', backref='session_enhanced_sources')
    
    def to_dict(self):
        return {
            'id': self.id,
            'message_id': self.message_id,
            'user_id': self.user_id,
            'session_id': self.session_id,
            'title': self.title,
            'url': self.url,
            'content': self.content,
            'summary': self.summary,
            'source_type': self.source_type,
            'relevance_score': self.relevance_score,
            'search_query': self.search_query,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'fetched_at': self.fetched_at.isoformat() if self.fetched_at else None,
            'triggered_by_web_search': self.triggered_by_web_search,
            'triggered_by_deep_research': self.triggered_by_deep_research,
            'triggered_by_study_learn': self.triggered_by_study_learn,
            'word_count': self.word_count,
            'domain': self.domain,
            'is_primary_source': self.is_primary_source
        }
    
    def __repr__(self):
        return f'<EnhancedSource {self.title[:50] if self.title else "Untitled"} for {self.message_id}>'

class ChatSession(db.Model):
    # Chat session container for organizing messages
    __tablename__ = 'chat_session'
    
    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid4()))
    name = db.Column(db.String(255), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    last_message = db.Column(db.Text, nullable=True)
    message_count = db.Column(db.Integer, default=0)
    user_id = db.Column(db.String(36), db.ForeignKey('user.id'), nullable=False)
    project_id = db.Column(db.String(36), db.ForeignKey('project.id'), nullable=True)
    is_active = db.Column(db.Boolean, default=True)
    is_starred = db.Column(db.Boolean, default=False)

    # Session metadata
    total_tokens_used = db.Column(db.Integer, default=0)
    total_cost = db.Column(db.Float, default=0.0)
    primary_provider = db.Column(db.String(50), nullable=True)
    
    # Enhanced features usage tracking
    total_web_searches = db.Column(db.Integer, default=0)
    total_deep_research = db.Column(db.Integer, default=0)
    total_study_sessions = db.Column(db.Integer, default=0)
    total_sources_gathered = db.Column(db.Integer, default=0)
    
    # FIXED: Relationships - removed duplicate enhanced_sources
    user = db.relationship('User', back_populates='chat_sessions')
    project = db.relationship('Project', back_populates='chat_sessions')
    messages = db.relationship('ChatMessage', back_populates='session', cascade='all, delete-orphan')
    # Enhanced sources are accessed via backref from EnhancedSource model
    
    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None,
            'last_message': self.last_message,
            'message_count': self.message_count,
            'user_id': self.user_id,
            'project_id': self.project_id,
            'is_active': self.is_active,
            'is_starred': self.is_starred,
            'total_tokens_used': self.total_tokens_used,
            'total_cost': self.total_cost,
            'primary_provider': self.primary_provider,
            'total_web_searches': self.total_web_searches,
            'total_deep_research': self.total_deep_research,
            'total_study_sessions': self.total_study_sessions,
            'total_sources_gathered': self.total_sources_gathered
        }
    
    def __repr__(self):
        return f'<ChatSession {self.name}>'


# User Plans tables
class UserPlan(db.Model):
    """User subscription plan management"""
    __tablename__ = 'user_plan'
    
    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid4()))
    user_id = db.Column(db.String(36), db.ForeignKey('user.id'), nullable=False)
    plan_type = db.Column(db.String(20), nullable=False)  # 'free', '12_day', '24_day', '1_month', '3_month'
    
    # Plan details
    total_messages = db.Column(db.Integer, nullable=False)
    messages_used = db.Column(db.Integer, default=0)
    total_web_searches = db.Column(db.Integer, nullable=False)
    web_searches_used = db.Column(db.Integer, default=0)
    
    # Validity period
    activated_at = db.Column(db.DateTime, default=datetime.utcnow)
    expires_at = db.Column(db.DateTime, nullable=False)
    is_active = db.Column(db.Boolean, default=True)
    
    # Payment tracking
    payment_id = db.Column(db.String(100), nullable=True)  # Razorpay/Stripe payment ID
    amount_paid = db.Column(db.Float, nullable=False)
    currency = db.Column(db.String(3), default='INR')
    
    # Usage limits
    max_input_tokens = db.Column(db.Integer, default=4000)
    can_use_premium_models = db.Column(db.Boolean, default=False)
    can_upload_files = db.Column(db.Boolean, default=True)
    daily_message_limit = db.Column(db.Integer, nullable=True)  # For free plans
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    user = db.relationship('User', backref='user_plans')
    
# In database/model.py - UPDATE the UserPlan.to_dict() method:

    def to_dict(self):
        # Calculate days remaining more accurately
        if self.expires_at:
            time_diff = self.expires_at - datetime.utcnow()
            days_remaining = max(0, time_diff.days)
            hours_remaining = max(0, time_diff.seconds // 3600)
            
            # If less than 1 day but more than 0 hours, show as partial day
            if days_remaining == 0 and hours_remaining > 0:
                days_remaining = 1  # Show as 1 day if there are still hours left
        else:
            days_remaining = 0
        
        return {
            'id': self.id,
            'user_id': self.user_id,
            'plan_type': self.plan_type,
            'total_messages': self.total_messages,
            'messages_used': self.messages_used,
            'messages_remaining': self.total_messages - self.messages_used,
            'total_web_searches': self.total_web_searches,
            'web_searches_used': self.web_searches_used,
            'web_searches_remaining': self.total_web_searches - self.web_searches_used,
            'activated_at': self.activated_at.isoformat() if self.activated_at else None,
            'expires_at': self.expires_at.isoformat() if self.expires_at else None,
            'is_active': self.is_active,
            'amount_paid': self.amount_paid,
            'currency': self.currency,
            'max_input_tokens': self.max_input_tokens,
            'can_use_premium_models': self.can_use_premium_models,
            'can_upload_files': self.can_upload_files,
            'daily_message_limit': self.daily_message_limit,
            'days_remaining': days_remaining,  # Fixed calculation
            'hours_remaining': hours_remaining if days_remaining == 1 else 0  # Add hours info
        }

class UsageTracking(db.Model):
    """Track detailed usage for billing and analytics"""
    __tablename__ = 'usage_tracking'
    
    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid4()))
    user_id = db.Column(db.String(36), db.ForeignKey('user.id'), nullable=False)
    session_id = db.Column(db.String(36), db.ForeignKey('chat_session.id'), nullable=True)
    message_id = db.Column(db.String(36), db.ForeignKey('chat_message.id'), nullable=True)
    
    # Usage details
    action_type = db.Column(db.String(20), nullable=False)  # 'message', 'web_search', 'file_upload'
    provider = db.Column(db.String(50), nullable=True)
    model = db.Column(db.String(100), nullable=True)
    model_tier = db.Column(db.String(20), nullable=True)  # 'standard', 'premium'
    
    # Token usage
    input_tokens = db.Column(db.Integer, default=0)
    output_tokens = db.Column(db.Integer, default=0)
    total_tokens = db.Column(db.Integer, default=0)
    
    # Cost tracking
    estimated_cost_usd = db.Column(db.Float, default=0.0)
    
    # Additional metadata
    has_web_search = db.Column(db.Boolean, default=False)
    has_file_upload = db.Column(db.Boolean, default=False)
    response_time_ms = db.Column(db.Integer, nullable=True)
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    user = db.relationship('User', backref='usage_tracking')
    session = db.relationship('ChatSession', backref='usage_tracking')
    message = db.relationship('ChatMessage', backref='usage_tracking')
    
    def to_dict(self):
        return {
            'id': self.id,
            'user_id': self.user_id,
            'session_id': self.session_id,
            'message_id': self.message_id,
            'action_type': self.action_type,
            'provider': self.provider,
            'model': self.model,
            'model_tier': self.model_tier,
            'input_tokens': self.input_tokens,
            'output_tokens': self.output_tokens,
            'total_tokens': self.total_tokens,
            'estimated_cost_usd': self.estimated_cost_usd,
            'has_web_search': self.has_web_search,
            'has_file_upload': self.has_file_upload,
            'response_time_ms': self.response_time_ms,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }
    
    def __repr__(self):
        return f'<UsageTracking {self.action_type} for {self.user_id}>'

class DailyUsageSummary(db.Model):
    """Daily usage summary for enforcing daily limits"""
    __tablename__ = 'daily_usage_summary'
    
    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid4()))
    user_id = db.Column(db.String(36), db.ForeignKey('user.id'), nullable=False)
    date = db.Column(db.Date, nullable=False)
    
    # Daily usage counts
    messages_sent = db.Column(db.Integer, default=0, nullable=False)
    web_searches_made = db.Column(db.Integer, default=0, nullable=False)
    files_uploaded = db.Column(db.Integer, default=0, nullable=False)
    total_tokens = db.Column(db.Integer, default=0, nullable=False)
    estimated_cost_usd = db.Column(db.Float, default=0.0, nullable=False)
    
    # Token usage
    total_input_tokens = db.Column(db.Integer, default=0)
    total_output_tokens = db.Column(db.Integer, default=0)
    total_tokens = db.Column(db.Integer, default=0)
    
    # Cost tracking
    estimated_cost_usd = db.Column(db.Float, default=0.0)
    
    # Provider usage
    openai_messages = db.Column(db.Integer, default=0)
    google_messages = db.Column(db.Integer, default=0)
    anthropic_messages = db.Column(db.Integer, default=0)
    groq_messages = db.Column(db.Integer, default=0)
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    user = db.relationship('User', backref='daily_usage')
    
    # Unique constraint for user + date
    __table_args__ = (db.UniqueConstraint('user_id', 'date', name='unique_user_date'),)
    
    def to_dict(self):
        return {
            'id': self.id,
            'user_id': self.user_id,
            'date': self.date.isoformat() if self.date else None,
            'messages_sent': self.messages_sent,
            'web_searches_made': self.web_searches_made,
            'files_uploaded': self.files_uploaded,
            'total_input_tokens': self.total_input_tokens,
            'total_output_tokens': self.total_output_tokens,
            'total_tokens': self.total_tokens,
            'estimated_cost_usd': self.estimated_cost_usd,
            'openai_messages': self.openai_messages,
            'google_messages': self.google_messages,
            'anthropic_messages': self.anthropic_messages,
            'groq_messages': self.groq_messages,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }
    
    def __repr__(self):
        return f'<DailyUsage {self.user_id} on {self.date}>'

class PlanTemplate(db.Model):
    """Plan templates with pricing and limits"""
    __tablename__ = 'plan_template'
    
    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid4()))
    plan_type = db.Column(db.String(20), unique=True, nullable=False)
    plan_name = db.Column(db.String(100), nullable=False)
    plan_category = db.Column(db.String(20), default='basic')  # 'free', 'basic', 'pro'
    description = db.Column(db.Text, nullable=True)
    
    # Pricing - FIXED: Added missing fields
    price_inr = db.Column(db.Float, nullable=False)
    price_usd = db.Column(db.Float, nullable=False, default=0.0)  # Added missing field
    validity_days = db.Column(db.Integer, nullable=False)
    
    # Limits
    total_messages = db.Column(db.Integer, nullable=False)
    total_web_searches = db.Column(db.Integer, nullable=False)
    max_input_tokens = db.Column(db.Integer, default=4000)
    daily_message_limit = db.Column(db.Integer, nullable=True)
    
    # Features - FIXED: Added missing fields
    can_use_premium_models = db.Column(db.Boolean, default=False)
    can_upload_files = db.Column(db.Boolean, default=True)
    max_file_uploads = db.Column(db.Integer, nullable=True)  # Added missing field
    priority_support = db.Column(db.Boolean, default=False)
    phone_support = db.Column(db.Boolean, default=False)  # Added missing field
    
    # Display - FIXED: Added missing fields
    features = db.Column(db.Text, nullable=True)  # Added missing field
    savings_text = db.Column(db.String(100), nullable=True)  # Added missing field
    is_popular = db.Column(db.Boolean, default=False)  # Added missing field
    is_active = db.Column(db.Boolean, default=True)
    display_order = db.Column(db.Integer, default=0)
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def to_dict(self):
        """Convert plan template to dictionary with dual currency display"""
        return {
            'id': self.id,
            'plan_type': self.plan_type,
            'plan_name': self.plan_name,
            'plan_category': self.plan_category,
            'description': self.description,
            'price_inr': self.price_inr,
            'price_usd': self.price_usd,
            'validity_days': self.validity_days,
            'total_messages': self.total_messages,
            'total_web_searches': self.total_web_searches,
            'max_input_tokens': self.max_input_tokens,
            'daily_message_limit': self.daily_message_limit,
            'can_use_premium_models': self.can_use_premium_models,
            'can_upload_files': self.can_upload_files,
            'max_file_uploads': self.max_file_uploads,
            'priority_support': self.priority_support,
            'phone_support': self.phone_support,
            'features': self.features,
            'savings_text': self.savings_text,
            'is_popular': self.is_popular,
            'display_order': self.display_order,
            'is_active': self.is_active,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }
    
    def __repr__(self):
        return f'<PlanTemplate {self.plan_name}>'

class SystemSettings(db.Model):
    # System-wide configuration settings
    __tablename__ = 'system_settings'
    
    id = db.Column(db.Integer, primary_key=True)
    key = db.Column(db.String(100), unique=True, nullable=False)
    value = db.Column(db.Text, nullable=True)
    description = db.Column(db.String(255), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    @staticmethod
    def get_setting(key, default=None):
        # Get system setting value
        setting = SystemSettings.query.filter_by(key=key).first()
        return setting.value if setting else default
    
    @staticmethod
    def set_setting(key, value, description=None):
        # Set system setting value
        setting = SystemSettings.query.filter_by(key=key).first()
        if setting:
            setting.value = value
            setting.updated_at = datetime.utcnow()
            if description:
                setting.description = description
        else:
            setting = SystemSettings(key=key, value=value, description=description)
            db.session.add(setting)
        db.session.commit()
        return setting
    
    def to_dict(self):
        # Convert setting to dictionary
        return {
            'id': self.id,
            'key': self.key,
            'value': self.value,
            'description': self.description,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }
    
    def __repr__(self):
        return f'<SystemSettings {self.key}>'
      
class Project(db.Model):
    # Project management for organizing chats
    __tablename__ = 'project'

    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid4()))
    name = db.Column(db.String(255), nullable=False)
    description = db.Column(db.Text, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    user_id = db.Column(db.String(36), db.ForeignKey('user.id'), nullable=False)
    is_active = db.Column(db.Boolean, default=True)

    # Relationships
    user = db.relationship('User', back_populates='projects')
    chat_sessions = db.relationship('ChatSession', back_populates='project', lazy='dynamic')

    def to_dict(self):
        # Convert project to dictionary
        return {
            'id': self.id,
            'name': self.name,
            'description': self.description,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None,
            'user_id': self.user_id,
            'is_active': self.is_active,
            'chat_count': self.chat_sessions.count()
        }

    def __repr__(self):
        return f'<Project {self.name}>'
