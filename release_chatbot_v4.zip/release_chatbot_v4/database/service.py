from datetime import datetime, timedelta
import json
from flask import request
from flask_login import current_user
from sqlalchemy import func, desc
from database.model import (
    db, User, ChatSession, ChatMessage, UserSession, Project, SystemSettings,
    UserPlan, PlanTemplate, UsageTracking, DailyUsageSummary ,EnhancedSource # ADD THESE
)


from services.analytics_service import AnalyticsService

import logging
import re
from typing import Dict, List, Any, Optional

import logging

logger = logging.getLogger(__name__)


class ContentFilter:
    """Filter and extract specific content types for LLM processing"""
    
    @staticmethod
    def extract_all_files_from_content(content: str) -> Dict[str, Dict]:
        """Extract all uploaded files from message content"""
        files = {}
        
        if not content or '=== UPLOADED FILE:' not in content:
            return files
        
        lines = content.split('\n')
        current_file = None
        current_content = []
        current_type = "unknown"
        
        for line in lines:
            if line.startswith('=== UPLOADED FILE:') or line.startswith('=== UPLOADED IMAGE:') or line.startswith('=== UPLOADED AUDIO:'):
                # Save previous file
                if current_file and current_content:
                    files[current_file] = {
                        'content': '\n'.join(current_content),
                        'type': current_type,
                        'line_count': len(current_content)
                    }
                
                # Start new file
                current_file = line.split(':', 1)[1].strip().replace(' ===', '')
                current_content = []
                
                if 'IMAGE:' in line:
                    current_type = 'image'
                elif 'AUDIO:' in line:
                    current_type = 'audio'
                else:
                    current_type = ContentFilter._detect_file_type(current_file)
                    
            elif line == '=== END FILE ===':
                # Save current file
                if current_file and current_content:
                    files[current_file] = {
                        'content': '\n'.join(current_content),
                        'type': current_type,
                        'line_count': len(current_content)
                    }
                current_file = None
                current_content = []
                current_type = "unknown"
            elif current_file:
                current_content.append(line)
        
        logger.info(f"🔍 Extracted {len(files)} files from content")
        return files
    
    @staticmethod
    def _detect_file_type(filename: str) -> str:
        """Detect file type based on extension"""
        if not filename:
            return "unknown"
            
        filename_lower = filename.lower()
        
        # Code files
        code_extensions = ['.py', '.js', '.java', '.cpp', '.c', '.html', '.css', '.php', '.rb', '.go', '.ts', '.jsx', '.vue', '.swift', '.kt']
        if any(filename_lower.endswith(ext) for ext in code_extensions):
            return "code"
        
        # Document files
        doc_extensions = ['.txt', '.md', '.rst', '.doc', '.docx', '.pdf']
        if any(filename_lower.endswith(ext) for ext in doc_extensions):
            return "document"
        
        # Data files
        data_extensions = ['.json', '.xml', '.yaml', '.yml', '.csv', '.sql', '.config', '.ini', '.env']
        if any(filename_lower.endswith(ext) for ext in data_extensions):
            return "data"
        
        return "document"  # Default to document
    
    @staticmethod
    def filter_by_file_type(files: Dict[str, Dict], file_types: List[str]) -> Dict[str, Dict]:
        """Filter files by specific types"""
        filtered = {}
        
        for filename, file_info in files.items():
            if file_info['type'] in file_types:
                filtered[filename] = file_info
        
        logger.info(f"📂 Filtered to {len(filtered)} files of types: {file_types}")
        return filtered
    
    @staticmethod
    def get_code_files_only(content: str) -> Dict[str, str]:
        """Extract only code files for CRUD operations"""
        all_files = ContentFilter.extract_all_files_from_content(content)
        code_files = ContentFilter.filter_by_file_type(all_files, ['code'])
        
        # Return simplified format for CRUD operations
        result = {}
        for filename, file_info in code_files.items():
            result[filename] = file_info['content']
        
        return result
    
    @staticmethod
    def get_specific_file(content: str, target_filename: str) -> Optional[str]:
        """Get content of a specific file"""
        all_files = ContentFilter.extract_all_files_from_content(content)
        
        for filename, file_info in all_files.items():
            if filename == target_filename or filename.endswith(target_filename):
                return file_info['content']
        
        return None
    
    @staticmethod
    def prepare_context_for_llm(session_code_files: Dict[str, str], user_query: str, 
                               context_type: str = "crud") -> str:
        """Prepare filtered content for LLM based on operation type"""
        
        if context_type == "crud" and session_code_files:
            # For CRUD operations, include all code files
            context_parts = []
            context_parts.append("=== CURRENT SESSION CODE FILES ===")
            
            for filename, content in session_code_files.items():
                context_parts.append(f"\n--- FILE: {filename} ---")
                context_parts.append(content)
                context_parts.append(f"--- END {filename} ---")
            
            context_parts.append("\n=== END SESSION CODE FILES ===")
            context_parts.append(f"\nUser Request: {user_query}")
            
            return "\n".join(context_parts)
        
        elif context_type == "analysis" and session_code_files:
            # For analysis, provide summary + full code
            context_parts = []
            context_parts.append("=== CODE ANALYSIS CONTEXT ===")
            context_parts.append(f"Files available: {', '.join(session_code_files.keys())}")
            
            for filename, content in session_code_files.items():
                lines = content.split('\n')
                context_parts.append(f"\nFile: {filename} ({len(lines)} lines)")
                context_parts.append(content)
            
            context_parts.append("\n=== END ANALYSIS CONTEXT ===")
            context_parts.append(f"\nUser Request: {user_query}")
            
            return "\n".join(context_parts)
        
        else:
            # Default: just the user query
            return user_query

class DatabaseService:
    """Service class for all database operations"""
    
    # =============================================
    # USER MANAGEMENT
    # =============================================
    
    @staticmethod
    def create_user(email, username, fullname, password=None, google_id=None, is_google_user=False):
        # Create new user account
        try:
            user = User(
                email=email.lower().strip(),
                username=username.strip(),
                fullname=fullname.strip(),
                google_id=google_id,
                is_google_user=is_google_user
            )
            
            # Only set password if provided (not for Google users)
            if password is not None:
                user.set_password(password)
            
            db.session.add(user)
            db.session.commit()
            
            logger.info(f"Created new user: {username} ({email})")
            return user
            
        except Exception as e:
            db.session.rollback()
            logger.error(f"Error creating user: {str(e)}")
            raise

    @staticmethod
    def get_user_by_email(email):
        # Find user by email address
        try:
            return User.query.filter_by(email=email.lower().strip()).first()
        except Exception as e:
            logger.error(f"Error getting user by email: {str(e)}")
            return None
    
    @staticmethod
    def get_user_by_username(username):
        # Find user by username
        try:
            return User.query.filter_by(username=username.strip()).first()
        except Exception as e:
            logger.error(f"Error getting user by username: {str(e)}")
            return None
    
    @staticmethod
    def get_user_by_id(user_id):
        # Find user by ID
        try:
            return User.query.get(user_id)
        except Exception as e:
            logger.error(f"Error getting user by ID: {str(e)}")
            return None
    
    @staticmethod
    def update_last_login(user_id):
        # Update user's last login timestamp
        try:
            user = User.query.get(user_id)
            if user:
                user.last_login = datetime.utcnow()
                db.session.commit()
                return True
            return False
        except Exception as e:
            db.session.rollback()
            logger.error(f"Error updating last login: {str(e)}")
            return False
    
    @staticmethod
    def update_user_profile(user_id, **kwargs):
        # Update user profile information
        try:
            user = User.query.get(user_id)
            if not user:
                return False
            
            for key, value in kwargs.items():
                if hasattr(user, key) and value is not None:
                    setattr(user, key, value)
            
            db.session.commit()
            logger.info(f"Updated user profile: {user_id}")
            return True
            
        except Exception as e:
            db.session.rollback()
            logger.error(f"Error updating user profile: {str(e)}")
            return False
    
    # =============================================
    # USER SESSION TRACKING
    # =============================================
    
    @staticmethod
    def create_user_session(user_id, ip_address=None, user_agent=None):
        # Track user login session
        try:
            session = UserSession(
                user_id=user_id,
                ip_address=ip_address,
                user_agent=user_agent[:500] if user_agent else None  # Truncate long user agents
            )
            db.session.add(session)
            db.session.commit()
            
            logger.info(f"Created user session for user {user_id}")
            return session.id
            
        except Exception as e:
            db.session.rollback()
            logger.error(f"Error creating user session: {str(e)}")
            return None
    
    @staticmethod
    def end_user_session(session_id, messages_sent=0, sessions_created=0):
        # Mark user session as ended with statistics
        try:
            session = UserSession.query.get(session_id)
            if session:
                session.logout_time = datetime.utcnow()
                session.is_active = False
                session.messages_sent = messages_sent
                session.sessions_created = sessions_created
                
                # Calculate total time spent
                if session.login_time:
                    time_diff = session.logout_time - session.login_time
                    session.total_time_spent = int(time_diff.total_seconds())
                
                db.session.commit()
                logger.info(f"Ended user session: {session_id}")
                return True
            return False
            
        except Exception as e:
            db.session.rollback()
            logger.error(f"Error ending user session: {str(e)}")
            return False
    
    @staticmethod
    def get_active_user_sessions(user_id):
        # Get active sessions for user
        try:
            sessions = UserSession.query.filter_by(
                user_id=user_id,
                is_active=True
            ).order_by(desc(UserSession.login_time)).all()
            
            return [session.to_dict() for session in sessions]
            
        except Exception as e:
            logger.error(f"Error getting active user sessions: {str(e)}")
            return []
    
    # =============================================
    # PROJECT MANAGEMENT
    # =============================================
    
    @staticmethod
    def create_project(name, description=None, user_id=None):
        # Create new project
        try:
            if user_id is None and current_user.is_authenticated:
                user_id = current_user.id
            
            if not user_id:
                raise ValueError("User ID is required for project creation")
            
            project = Project(
                name=name.strip(),
                description=description.strip() if description else None,
                user_id=user_id
            )
            db.session.add(project)
            db.session.commit()
            
            logger.info(f"Created project: {name} for user {user_id}")
            return project.id
            
        except Exception as e:
            db.session.rollback()
            logger.error(f"Error creating project: {str(e)}")
            raise
    
    @staticmethod
    def get_user_projects(user_id=None, limit=100):
        # Get user's projects
        try:
            if user_id is None and current_user.is_authenticated:
                user_id = current_user.id
            
            if not user_id:
                return []
            
            projects = Project.query.filter_by(user_id=user_id, is_active=True)\
                                  .order_by(desc(Project.updated_at))\
                                  .limit(limit).all()
            
            return [project.to_dict() for project in projects]
            
        except Exception as e:
            logger.error(f"Error getting user projects: {str(e)}")
            return []
    
    # =============================================
    # CHAT SESSION MANAGEMENT
    # =============================================
    
    @staticmethod
    def get_session_files_by_type(session_id, file_types: List[str], user_id=None):
        """Get specific file types from session history"""
        try:
            if user_id is None and current_user.is_authenticated:
                user_id = current_user.id
            
            # Get all messages with uploads
            messages = ChatMessage.query.filter_by(
                session_id=session_id,
                role='user',
                has_uploads=True
            ).order_by(ChatMessage.created_at).all()
            
            filtered_files = {}
            
            for message in messages:
                content = message.content or ""
                all_files = ContentFilter.extract_all_files_from_content(content)
                filtered = ContentFilter.filter_by_file_type(all_files, file_types)
                
                # Update with latest versions
                for filename, file_info in filtered.items():
                    filtered_files[filename] = file_info['content']
            
            logger.info(f"📁 Retrieved {len(filtered_files)} files of types {file_types}")
            return filtered_files
            
        except Exception as e:
            logger.error(f"Error getting session files by type: {str(e)}")
            return {}
    
    @staticmethod
    def get_session_code_files_for_crud(session_id, user_id=None):
        """Optimized method to get only code files for CRUD operations"""
        return DatabaseService.get_session_files_by_type(session_id, ['code'], user_id)
    
    @staticmethod
    def search_in_code_files(session_id, search_term, user_id=None):
        """Search specifically within code files"""
        try:
            code_files = DatabaseService.get_session_code_files_for_crud(session_id, user_id)
            
            matching_results = {}
            
            for filename, content in code_files.items():
                if search_term.lower() in content.lower():
                    lines = content.split('\n')
                    matching_lines = []
                    
                    for i, line in enumerate(lines, 1):
                        if search_term.lower() in line.lower():
                            matching_lines.append({
                                'line_number': i,
                                'content': line.strip(),
                                'context': {
                                    'before': lines[max(0, i-2):i-1] if i > 1 else [],
                                    'after': lines[i:min(len(lines), i+2)] if i < len(lines) else []
                                }
                            })
                    
                    if matching_lines:
                        matching_results[filename] = {
                            'full_content': content,
                            'matches': matching_lines,
                            'match_count': len(matching_lines)
                        }
            
            logger.info(f"🔎 Found '{search_term}' in {len(matching_results)} code files")
            return matching_results
            
        except Exception as e:
            logger.error(f"Error searching in code files: {str(e)}")
            return {}
    
    
    @staticmethod
    def create_chat_session(name,user_id=None, project_id=None):
        # Create new chat session
        try:
            if user_id is None and current_user.is_authenticated:
                user_id = current_user.id
            
            if not user_id:
                raise ValueError("User ID is required for chat session")
            
            session = ChatSession(
                name=name.strip(),
                user_id=user_id,
                project_id=project_id
            )
            db.session.add(session)
            db.session.commit()
            
            logger.info(f"Created chat session: {name} for user {user_id}")
            return session.id
            
        except Exception as e:
            db.session.rollback()
            logger.error(f"Error creating chat session: {str(e)}")
            raise
    
    @staticmethod
    def get_chat_sessions(user_id=None, project_id=None, limit=50, starred_only=False):
        try:
            if user_id is None and current_user.is_authenticated:
                user_id = current_user.id
            
            if not user_id:
                return []
            
            query = ChatSession.query.filter_by(user_id=user_id, is_active=True)

            if project_id:
                query = query.filter_by(project_id=project_id)

            if starred_only:
                query = query.filter_by(is_starred=True)

            sessions = query.order_by(desc(ChatSession.updated_at)).limit(limit).all()
            
            return [session.to_dict() for session in sessions]
            
        except Exception as e:
            logger.error(f"Error getting chat sessions: {str(e)}")
            return []

    
    @staticmethod
    def get_chat_session(session_id, user_id=None):
        # Get specific chat session with permission check
        try:
            if user_id is None and current_user.is_authenticated:
                user_id = current_user.id
            
            session = ChatSession.query.filter_by(
                id=session_id,
                user_id=user_id,
                is_active=True
            ).first()
            
            return session.to_dict() if session else None
            
        except Exception as e:
            logger.error(f"Error getting chat session: {str(e)}")
            return None
    
    @staticmethod
    def update_chat_session(session_id, user_id=None, **kwargs):
        # Update chat session properties
        try:
            if user_id is None and current_user.is_authenticated:
                user_id = current_user.id
            
            session = ChatSession.query.filter_by(
                id=session_id,
                user_id=user_id
            ).first()
            
            if not session:
                return False
            
            for key, value in kwargs.items():
                if hasattr(session, key) and value is not None:
                    setattr(session, key, value)
            
            session.updated_at = datetime.utcnow()
            db.session.commit()
            
            logger.info(f"Updated chat session: {session_id}")
            return True
            
        except Exception as e:
            db.session.rollback()
            logger.error(f"Error updating chat session: {str(e)}")
            return False
    
    @staticmethod
    def delete_chat_session(session_id, user_id=None):
        # Soft delete chat session with permission check
        try:
            if user_id is None and current_user.is_authenticated:
                user_id = current_user.id
            
            session = ChatSession.query.filter_by(
                id=session_id,
                user_id=user_id
            ).first()
            
            if not session:
                return False
            
            # Soft delete by marking as inactive
            session.is_active = False
            session.updated_at = datetime.utcnow()
            db.session.commit()
            
            logger.info(f"Deleted chat session: {session_id}")
            return True
            
        except Exception as e:
            db.session.rollback()
            logger.error(f"Error deleting chat session: {str(e)}")
            return False
    
    @staticmethod
    def bulk_delete_chat_sessions(session_ids, user_id=None):
        # Bulk delete multiple chat sessions
        try:
            if user_id is None and current_user.is_authenticated:
                user_id = current_user.id
            
            if not session_ids:
                return 0
            
            updated_count = ChatSession.query.filter(
                ChatSession.id.in_(session_ids),
                ChatSession.user_id == user_id
            ).update(
                {
                    ChatSession.is_active: False,
                    ChatSession.updated_at: datetime.utcnow()
                },
                synchronize_session=False
            )
            
            db.session.commit()
            
            logger.info(f"Bulk deleted {updated_count} chat sessions for user {user_id}")
            return updated_count
            
        except Exception as e:
            db.session.rollback()
            logger.error(f"Error bulk deleting chat sessions: {str(e)}")
            return 0
    
    
    
    # =============================================
    # NEW: EDIT/REGENERATE SUPPORT METHODS
    # =============================================
    
    @staticmethod
    def get_message_by_id(message_id: str, user_id: str) -> Optional[Dict]:
        """Get a specific message by ID with user permission check"""
        try:
            message = db.session.query(ChatMessage).filter(
                ChatMessage.id == message_id,
                ChatMessage.session.has(ChatSession.user_id == user_id)
            ).first()
            
            if message:
                return message.to_dict()
            return None
            
        except Exception as e:
            logger.error(f"Error getting message by ID {message_id}: {str(e)}")
            return None
    
    @staticmethod
    def update_message_content(message_id: str, new_content: str, user_id: str) -> bool:
        """Update message content by ID with user permission check"""
        try:
            message = db.session.query(ChatMessage).filter(
                ChatMessage.id == message_id,
                ChatMessage.session.has(ChatSession.user_id == user_id)
            ).first()
            
            if message:
                message.content = new_content
                db.session.commit()
                logger.info(f"Updated message {message_id} content")
                return True
            
            logger.warning(f"Message {message_id} not found for user {user_id}")
            return False
            
        except Exception as e:
            logger.error(f"Error updating message {message_id}: {str(e)}")
            db.session.rollback()
            return False
    
    @staticmethod
    def update_ai_message_complete(message_id: str, new_content: str, provider: str, 
                                 model: str, response_time: float, input_tokens: int, 
                                 output_tokens: int, estimated_cost: float, user_id: str) -> bool:
        """Update AI message with complete metadata and user permission check"""
        try:
            message = db.session.query(ChatMessage).filter(
                ChatMessage.id == message_id,
                ChatMessage.role == 'assistant',
                ChatMessage.session.has(ChatSession.user_id == user_id)
            ).first()
            
            if message:
                message.content = new_content
                message.provider = provider
                message.model = model
                message.response_time = response_time
                message.input_tokens = input_tokens
                message.output_tokens = output_tokens
                message.total_tokens = input_tokens + output_tokens if input_tokens and output_tokens else None
                message.estimated_cost = estimated_cost
                message.created_at = datetime.utcnow()  # Update timestamp for regenerated content
                
                db.session.commit()
                logger.info(f"Updated AI message {message_id} completely")
                return True
            
            logger.warning(f"AI message {message_id} not found for user {user_id}")
            return False
            
        except Exception as e:
            logger.error(f"Error updating AI message {message_id}: {str(e)}")
            db.session.rollback()
            return False
    # =============================================
    # STARRED MESSAGES MANAGEMENT
    # =============================================
    
    @staticmethod
    def toggle_message_star(message_id, user_id=None):
        # Toggle starred status of a message
        try:
            if user_id is None and current_user.is_authenticated:
                user_id = current_user.id
            
            # Verify message belongs to user's session
            message = db.session.query(ChatMessage)\
                               .join(ChatSession)\
                               .filter(ChatMessage.id == message_id)\
                               .filter(ChatSession.user_id == user_id)\
                               .first()
            
            if not message:
                return {"success": False, "error": "Message not found"}
            
            # Toggle starred status
            message.is_starred = not message.is_starred
            db.session.commit()
            
            logger.info(f"Toggled star for message {message_id}: {message.is_starred}")
            return {
                "success": True, 
                "is_starred": message.is_starred,
                "message_id": message_id
            }
            
        except Exception as e:
            db.session.rollback()
            logger.error(f"Error toggling message star: {str(e)}")
            return {"success": False, "error": "Failed to toggle star"}
    
    @staticmethod
    def get_starred_messages(user_id=None, limit=50):
        # Get all starred messages for user
        try:
            if user_id is None and current_user.is_authenticated:
                user_id = current_user.id
            
            if not user_id:
                return []
            
            starred_messages = db.session.query(ChatMessage)\
                                        .join(ChatSession)\
                                        .filter(ChatSession.user_id == user_id)\
                                        .filter(ChatMessage.is_starred == True)\
                                        .order_by(desc(ChatMessage.created_at))\
                                        .limit(limit).all()
            
            # Include session info for context
            result = []
            for message in starred_messages:
                message_dict = message.to_dict()
                message_dict['session_name'] = message.session.name
                result.append(message_dict)
            
            return result
            
        except Exception as e:
            logger.error(f"Error getting starred messages: {str(e)}")
            return []
    
    @staticmethod
    def get_starred_messages_count(user_id=None):
        # Get count of starred messages
        try:
            if user_id is None and current_user.is_authenticated:
                user_id = current_user.id
            
            if not user_id:
                return 0
            
            count = db.session.query(ChatMessage)\
                             .join(ChatSession)\
                             .filter(ChatSession.user_id == user_id)\
                             .filter(ChatMessage.is_starred == True)\
                             .count()
            
            return count
            
        except Exception as e:
            logger.error(f"Error getting starred messages count: {str(e)}")
            return 0
    
    ##------------------new ----------------------------
    
    # =============================================
    #  CHAT MESSAGE MANAGEMENT
    # =============================================
    
    @staticmethod
    def save_chat_message_with_code(session_id, role, content, provider=None, model=None, 
                     reasoning_used=False, response_time=None, file_path=None, 
                     file_type=None, has_uploads=False, file_names=None,
                     input_tokens=None, output_tokens=None, estimated_cost=None,
                     uploaded_files=None,
                     # NEW: Mode flags and enhanced sources
                     enable_web_search=False, enable_deep_research=False, 
                     enable_study_learn=False, enhanced_sources=None):
        """Enhanced save method that extracts code content AND saves mode flags/sources"""
        try:
            # Extract code content from uploaded files (existing logic)
            enhanced_content = content
            
            if uploaded_files and has_uploads:
                code_content_parts = [content]
                
                for file_info in uploaded_files:
                    try:
                        filename = file_info.get("name", "unknown_file")
                        file_content = file_info.get("content", "")
                        file_type_info = file_info.get("file_type", "unknown")
                        
                        if file_type_info == "code" and file_content:
                            code_content_parts.append(f"\n=== UPLOADED FILE: {filename} ===")
                            code_content_parts.append(file_content)
                            code_content_parts.append("=== END FILE ===")
                            logger.info(f"📁 Stored code content for file: {filename}")
                    except Exception as file_error:
                        logger.error(f"❌ Error processing file {filename}: {str(file_error)}")
                        continue
                
                enhanced_content = "\n".join(code_content_parts)
            
            # Use the updated save_chat_message with mode flags
            return DatabaseService.save_chat_message(
                session_id=session_id,
                role=role,
                content=enhanced_content,
                provider=provider,
                model=model,
                reasoning_used=reasoning_used,
                response_time=response_time,
                file_path=file_path,
                file_type=file_type,
                has_uploads=has_uploads,
                file_names=file_names,
                input_tokens=input_tokens,
                output_tokens=output_tokens,
                estimated_cost=estimated_cost,
                enable_web_search=enable_web_search,
                enable_deep_research=enable_deep_research,
                enable_study_learn=enable_study_learn,
                enhanced_sources=enhanced_sources
            )
            
        except Exception as e:
            logger.error(f"Error saving enhanced chat message with code: {str(e)}")
            raise
                         
    @staticmethod
    def save_chat_message(session_id, role, content, provider=None, model=None, 
                     reasoning_used=False, response_time=None, file_path=None, 
                     file_type=None, has_uploads=False, file_names=None,
                     input_tokens=None, output_tokens=None, estimated_cost=None,
                     # NEW: Mode flags and enhanced sources
                     enable_web_search=False, enable_deep_research=False, 
                     enable_study_learn=False, enhanced_sources=None):
        """Enhanced save method with mode flags and enhanced sources"""
        try:
            # Calculate total tokens
            total_tokens = None
            if input_tokens is not None and output_tokens is not None:
                total_tokens = input_tokens + output_tokens
            
            # Get next message index
            last_message = ChatMessage.query.filter_by(session_id=session_id)\
                                        .order_by(desc(ChatMessage.message_index))\
                                        .first()
            message_index = (last_message.message_index + 1) if last_message and last_message.message_index else 1
            
            # Create message with mode flags
            message = ChatMessage(
                session_id=session_id,
                role=role,
                content=content,
                provider=provider,
                model=model,
                reasoning_used=reasoning_used,
                response_time=response_time,
                file_path=file_path,
                file_type=file_type,
                has_uploads=has_uploads,
                file_names=json.dumps(file_names) if file_names else None,
                input_tokens=input_tokens,
                output_tokens=output_tokens,
                total_tokens=total_tokens,
                estimated_cost=estimated_cost,
                message_index=message_index,
                # NEW: Mode flags
                enable_web_search=enable_web_search,
                enable_deep_research=enable_deep_research,
                enable_study_learn=enable_study_learn
            )
            db.session.add(message)
            db.session.flush()  # Get message ID before commit
            
            # Save enhanced sources if provided (only for assistant messages)
            if role == 'assistant' and enhanced_sources:
                DatabaseService._save_enhanced_sources(
                    message.id, session_id, enhanced_sources,
                    enable_web_search, enable_deep_research, enable_study_learn
                )
            
            # Update session metadata
            session = ChatSession.query.get(session_id)
            if session:
                if role == 'user':
                    preview = content[:100] + "..." if len(content) > 100 else content
                    session.last_message = preview
                elif role == 'assistant':
                    preview = content[:100] + "..." if len(content) > 100 else content
                    session.last_message = f"AI: {preview}"
                
                session.updated_at = datetime.utcnow()
                session.message_count += 1
                
                # Update session mode tracking
                if enable_web_search:
                    session.total_web_searches = (session.total_web_searches or 0) + 1
                if enable_deep_research:
                    session.total_deep_research = (session.total_deep_research or 0) + 1
                if enable_study_learn:
                    session.total_study_sessions = (session.total_study_sessions or 0) + 1
                if enhanced_sources:
                    session.total_sources_gathered = (session.total_sources_gathered or 0) + len(enhanced_sources)
                
                if total_tokens:
                    session.total_tokens_used = (session.total_tokens_used or 0) + total_tokens
                if estimated_cost:
                    session.total_cost = (session.total_cost or 0) + estimated_cost
                if provider and not session.primary_provider:
                    session.primary_provider = provider
            
            db.session.commit()
            
            logger.info(f"💾 Saved {role} message with mode flags and {len(enhanced_sources) if enhanced_sources else 0} sources")
            return message.id
            
        except Exception as e:
            db.session.rollback()
            logger.error(f"Error saving enhanced chat message: {str(e)}")
            raise

    # ================================
    # NEW: Helper function to save enhanced sources
    # ================================
    
    @staticmethod
    def _save_enhanced_sources(message_id, session_id, enhanced_sources, 
                            enable_web_search=False, enable_deep_research=False, 
                            enable_study_learn=False):
        """Save enhanced sources to database"""
        try:
            if not enhanced_sources:
                return
            
            # Get user_id from session
            session = ChatSession.query.get(session_id)
            if not session:
                logger.error(f"Session {session_id} not found for enhanced sources")
                return
            
            user_id = session.user_id
            
            for source in enhanced_sources:
                # Extract domain from URL
                domain = None
                url = source.get('url', '')
                if url:
                    try:
                        from urllib.parse import urlparse
                        domain = urlparse(url).netloc
                    except:
                        domain = None
                
                enhanced_source = EnhancedSource(
                    message_id=message_id,
                    user_id=user_id,
                    session_id=session_id,
                    title=source.get('title', '')[:500] if source.get('title') else None,
                    url=url,
                    content=source.get('content', ''),
                    summary=source.get('summary', ''),
                    source_type='web_search',  # Default type
                    relevance_score=source.get('score', 0.0),
                    search_query=source.get('query', ''),
                    fetched_at=datetime.utcnow(),
                    triggered_by_web_search=enable_web_search,
                    triggered_by_deep_research=enable_deep_research,
                    triggered_by_study_learn=enable_study_learn,
                    word_count=len(source.get('content', '').split()) if source.get('content') else 0,
                    domain=domain,
                    is_primary_source=source.get('is_primary', False)
                )
                db.session.add(enhanced_source)
            
            logger.info(f"💾 Saved {len(enhanced_sources)} enhanced sources for message {message_id}")
            
        except Exception as e:
            logger.error(f"Error saving enhanced sources: {str(e)}")
            raise
  
    # @staticmethod
    # def get_chat_history_enhanced(session_id, user_id=None, limit=None):
    #     """Enhanced chat history retrieval with code content"""
    #     try:
    #         if user_id is None and current_user.is_authenticated:
    #             user_id = current_user.id
            
    #         # Verify session belongs to user
    #         session = ChatSession.query.filter_by(
    #             id=session_id,
    #             user_id=user_id
    #         ).first()
            
    #         if not session:
    #             return []
            
    #         query = ChatMessage.query.filter_by(session_id=session_id)\
    #                                .order_by(ChatMessage.created_at)
            
    #         if limit:
    #             query = query.limit(limit)
            
    #         messages = query.all()
            
    #         # Format for enhanced memory with code extraction capability
    #         formatted_messages = []
    #         for message in messages:
    #             if message.role in ["user", "assistant"]:
    #                 formatted_messages.append({
    #                     "id": message.id,
    #                     "role": message.role,
    #                     "content": message.content,  # This now includes extracted code content
    #                     "created_at": message.created_at,
    #                     "has_uploads": message.has_uploads,
    #                     "file_names": json.loads(message.file_names) if message.file_names else None,
    #                     "message_index": message.message_index
    #                 })
            
    #         logger.info(f"📚 Retrieved {len(formatted_messages)} messages with enhanced content for session {session_id}")
    #         return formatted_messages
            
    #     except Exception as e:
    #         logger.error(f"Error getting enhanced chat history: {str(e)}")
    #         return []
     
    @staticmethod
    def get_chat_history_enhanced(session_id, user_id=None, limit=None):
        """Enhanced chat history retrieval with metadata"""
        try:
            if user_id is None and current_user.is_authenticated:
                user_id = current_user.id
            
            # Verify session belongs to user
            session = ChatSession.query.filter_by(
                id=session_id,
                user_id=user_id
            ).first()
            
            if not session:
                return []
            
            query = ChatMessage.query.filter_by(session_id=session_id)\
                                .order_by(ChatMessage.created_at)
            
            if limit:
                query = query.limit(limit)
            
            messages = query.all()
            
            # Format with enhanced metadata
            formatted_messages = []
            for message in messages:
                if message.role in ["user", "assistant"]:
                    msg_data = {
                        "id": message.id,
                        "role": message.role,
                        "content": message.content,
                        "created_at": message.created_at,
                        "has_uploads": message.has_uploads,
                        "file_names": json.loads(message.file_names) if message.file_names else None,
                        "message_index": message.message_index,
                        "provider": message.provider,
                        "model": message.model,
                        "enhanced_sources": [source.to_dict() for source in message.enhanced_sources] if hasattr(message, 'enhanced_sources') else []
                    }
                    formatted_messages.append(msg_data)
            
            logger.info(f"📚 Retrieved {len(formatted_messages)} messages with metadata for session {session_id}")
            return formatted_messages
            
        except Exception as e:
            logger.error(f"Error getting enhanced chat history: {str(e)}")
            return []

    @staticmethod
    def get_chat_history(session_id, user_id=None, limit=None):
        """UPDATED: Now calls enhanced version for backward compatibility"""
        return DatabaseService.get_chat_history_enhanced(session_id, user_id, limit)
     
    @staticmethod
    def get_chat_history_since(session_id, last_message_id, user_id=None):
        """Get incremental chat messages since a specific message ID"""
        try:
            if user_id is None and current_user.is_authenticated:
                user_id = current_user.id
            
            # Verify session belongs to user
            session = ChatSession.query.filter_by(
                id=session_id,
                user_id=user_id
            ).first()
            
            if not session:
                return []
            
            # Get messages after the specified message ID
            messages = ChatMessage.query.filter_by(session_id=session_id)\
                                       .filter(ChatMessage.id > last_message_id)\
                                       .order_by(ChatMessage.created_at)\
                                       .all()
            
            # Format for enhanced memory
            formatted_messages = []
            for message in messages:
                if message.role in ["user", "assistant"]:
                    formatted_messages.append({
                        "id": message.id,
                        "role": message.role,
                        "content": message.content,  # Enhanced content with code
                        "created_at": message.created_at,
                        "has_uploads": message.has_uploads,
                        "file_names": json.loads(message.file_names) if message.file_names else None
                    })
            
            logger.info(f"📈 Retrieved {len(formatted_messages)} incremental messages since ID {last_message_id}")
            return formatted_messages
            
        except Exception as e:
            logger.error(f"Error getting incremental chat history: {str(e)}")
            return []
    
    # =============================================
    # CODE CONTEXT EXTRACTION METHODS  
    # =============================================
    
    @staticmethod
    def get_session_code_files(session_id, user_id=None):
        """Extract all code files from a session's conversation history"""
        try:
            if user_id is None and current_user.is_authenticated:
                user_id = current_user.id
            
            # Verify session belongs to user
            session = ChatSession.query.filter_by(
                id=session_id,
                user_id=user_id
            ).first()
            
            if not session:
                return {}
            
            # Get all user messages with uploads
            messages = ChatMessage.query.filter_by(
                session_id=session_id,
                role='user',
                has_uploads=True
            ).order_by(ChatMessage.created_at).all()
            
            code_files = {}
            
            for message in messages:
                content = message.content or ""
                
                # Extract code files from content
                if '=== UPLOADED FILE:' in content and '=== END FILE ===' in content:
                    lines = content.split('\n')
                    current_file = None
                    current_content = []
                    
                    for line in lines:
                        if line.startswith('=== UPLOADED FILE:'):
                            current_file = line.replace('=== UPLOADED FILE:', '').strip()
                            current_content = []
                        elif line == '=== END FILE ===':
                            if current_file and current_content:
                                code_files[current_file] = '\n'.join(current_content)
                            current_file = None
                            current_content = []
                        elif current_file:
                            current_content.append(line)
            
            logger.info(f"🔍 Extracted {len(code_files)} code files from session {session_id}")
            return code_files
            
        except Exception as e:
            logger.error(f"Error extracting session code files: {str(e)}")
            return {}
    
    @staticmethod
    def get_latest_code_version(session_id, filename, user_id=None):
        """Get the latest version of a specific code file from session history"""
        try:
            code_files = DatabaseService.get_session_code_files(session_id, user_id)
            return code_files.get(filename)
            
        except Exception as e:
            logger.error(f"Error getting latest code version: {str(e)}")
            return None
    
    @staticmethod
    def search_code_files(session_id, search_term, user_id=None):
        """Search for specific terms within code files in a session"""
        try:
            code_files = DatabaseService.get_session_code_files(session_id, user_id)
            
            matching_files = {}
            
            for filename, content in code_files.items():
                if search_term.lower() in content.lower():
                    # Find lines containing the search term
                    lines = content.split('\n')
                    matching_lines = []
                    
                    for i, line in enumerate(lines, 1):
                        if search_term.lower() in line.lower():
                            matching_lines.append({
                                'line_number': i,
                                'content': line.strip()
                            })
                    
                    if matching_lines:
                        matching_files[filename] = {
                            'full_content': content,
                            'matching_lines': matching_lines
                        }
            
            logger.info(f"🔎 Found '{search_term}' in {len(matching_files)} files")
            return matching_files
            
        except Exception as e:
            logger.error(f"Error searching code files: {str(e)}")
            return {}
    
    # =============================================
    # SESSION MANAGEMENT
    # =============================================
    
    @staticmethod
    def create_chat_session(name, user_id):
        """Create a new chat session"""
        try:
            from uuid import uuid4
            
            session = ChatSession(
                id=str(uuid4()),
                name=name,
                user_id=user_id,
                created_at=datetime.utcnow(),
                updated_at=datetime.utcnow(),
                message_count=0,
                is_active=True
            )
            
            db.session.add(session)
            db.session.commit()
            
            logger.info(f"Created new chat session: {session.id}")
            return session.id
            
        except Exception as e:
            db.session.rollback()
            logger.error(f"Error creating chat session: {str(e)}")
            raise
    
    @staticmethod
    def get_chat_session(session_id, user_id):
        """Get chat session details"""
        try:
            session = ChatSession.query.filter_by(
                id=session_id,
                user_id=user_id
            ).first()
            
            if session:
                return {
                    'id': session.id,
                    'name': session.name,
                    'created_at': session.created_at,
                    'updated_at': session.updated_at,
                    'message_count': session.message_count,
                    'is_active': session.is_active
                }
            
            return None
            
        except Exception as e:
            logger.error(f"Error getting chat session: {str(e)}")
            return None
    
    @staticmethod
    def get_user_chat_sessions(user_id, limit=50):
        """Get all chat sessions for a user"""
        try:
            sessions = ChatSession.query.filter_by(
                user_id=user_id,
                is_active=True
            ).order_by(desc(ChatSession.updated_at)).limit(limit).all()
            
            return [{
                'id': session.id,
                'name': session.name,
                'created_at': session.created_at,
                'updated_at': session.updated_at,
                'message_count': session.message_count,
                'last_message': session.last_message
            } for session in sessions]
            
        except Exception as e:
            logger.error(f"Error getting user chat sessions: {str(e)}")
            return []
    
    # =============================================
    # ADDITIONAL EXISTING METHODS (if you have them)
    # =============================================
    
    @staticmethod
    def get_detailed_chat_history(session_id, user_id=None, limit=None):
        """Get detailed chat history with all metadata"""
        try:
            if user_id is None and current_user.is_authenticated:
                user_id = current_user.id
            
            # Verify session belongs to user
            session = ChatSession.query.filter_by(
                id=session_id,
                user_id=user_id
            ).first()
            
            if not session:
                return []
            
            query = ChatMessage.query.filter_by(session_id=session_id)\
                                   .order_by(ChatMessage.created_at)
            
            if limit:
                query = query.limit(limit)
            
            messages = query.all()
            return [message.to_dict() for message in messages]
            
        except Exception as e:
            logger.error(f"Error getting detailed chat history: {str(e)}")
            return []
    
    @staticmethod
    def search_messages(user_id=None, query_text=None, provider=None, 
                       start_date=None, end_date=None, limit=50):
        """Search through user's messages"""
        try:
            if user_id is None and current_user.is_authenticated:
                user_id = current_user.id
            
            if not user_id:
                return []
            
            # Build query
            query = db.session.query(ChatMessage)\
                             .join(ChatSession)\
                             .filter(ChatSession.user_id == user_id)
            
            if query_text:
                query = query.filter(ChatMessage.content.contains(query_text))
            
            if provider:
                query = query.filter(ChatMessage.provider == provider)
            
            if start_date:
                query = query.filter(ChatMessage.created_at >= start_date)
            
            if end_date:
                query = query.filter(ChatMessage.created_at <= end_date)
            
            messages = query.order_by(desc(ChatMessage.created_at))\
                          .limit(limit).all()
            
            return [message.to_dict() for message in messages]
            
        except Exception as e:
            logger.error(f"Error searching messages: {str(e)}")
            return []
        
    ##------------------new ----------------------------
    # =============================================
    # ANALYTICS AND STATISTICS
    # =============================================
    @staticmethod
    def get_user_stats(user_id=None, days=30):
        # Get comprehensive user usage statistics
        try:
            if user_id is None and current_user.is_authenticated:
                user_id = current_user.id
            
            if not user_id:
                return {}
            
            # Date range for recent activity
            since_date = datetime.utcnow() - timedelta(days=days)
            
            # Basic counts
            total_sessions = ChatSession.query.filter_by(user_id=user_id).count()
            active_sessions = ChatSession.query.filter_by(user_id=user_id, is_active=True).count()
            
            total_messages = db.session.query(ChatMessage)\
                                     .join(ChatSession)\
                                     .filter(ChatSession.user_id == user_id)\
                                     .count()
            
            recent_messages = db.session.query(ChatMessage)\
                                      .join(ChatSession)\
                                      .filter(ChatSession.user_id == user_id)\
                                      .filter(ChatMessage.created_at >= since_date)\
                                      .count()
            
            # Provider usage stats
            provider_stats = db.session.query(
                ChatMessage.provider,
                func.count(ChatMessage.id).label('count'),
                func.avg(ChatMessage.response_time).label('avg_response_time'),
                func.sum(ChatMessage.total_tokens).label('total_tokens'),
                func.sum(ChatMessage.estimated_cost).label('total_cost')
            ).join(ChatSession)\
             .filter(ChatSession.user_id == user_id)\
             .filter(ChatMessage.role == 'assistant')\
             .filter(ChatMessage.provider.isnot(None))\
             .group_by(ChatMessage.provider)\
             .all()
            
            # Recent activity by day
            daily_activity = db.session.query(
                func.date(ChatMessage.created_at).label('date'),
                func.count(ChatMessage.id).label('message_count')
            ).join(ChatSession)\
             .filter(ChatSession.user_id == user_id)\
             .filter(ChatMessage.created_at >= since_date)\
             .group_by(func.date(ChatMessage.created_at))\
             .order_by(func.date(ChatMessage.created_at))\
             .all()
            
            # Most used models
            model_stats = db.session.query(
                ChatMessage.model,
                func.count(ChatMessage.id).label('count')
            ).join(ChatSession)\
             .filter(ChatSession.user_id == user_id)\
             .filter(ChatMessage.role == 'assistant')\
             .filter(ChatMessage.model.isnot(None))\
             .group_by(ChatMessage.model)\
             .order_by(desc(func.count(ChatMessage.id)))\
             .limit(10).all()
            
            # File usage stats
            file_usage = db.session.query(
                func.count(ChatMessage.id).label('messages_with_files'),
                func.count(func.distinct(ChatMessage.file_type)).label('unique_file_types')
            ).join(ChatSession)\
             .filter(ChatSession.user_id == user_id)\
             .filter(ChatMessage.has_uploads == True)\
             .first()
            
            return {
                'total_sessions': total_sessions,
                'active_sessions': active_sessions,
                'total_messages': total_messages,
                'recent_messages': recent_messages,
                'days_analyzed': days,
                'provider_usage': [
                    {
                        'provider': stat.provider,
                        'message_count': stat.count,
                        'avg_response_time': float(stat.avg_response_time) if stat.avg_response_time else None,
                        'total_tokens': stat.total_tokens or 0,
                        'total_cost': float(stat.total_cost) if stat.total_cost else 0.0
                    } for stat in provider_stats
                ],
                'daily_activity': [
                    {
                        'date': activity.date.isoformat() if activity.date else None,
                        'message_count': activity.message_count
                    } for activity in daily_activity
                ],
                'top_models': [
                    {
                        'model': model.model,
                        'count': model.count
                    } for model in model_stats
                ],
                'file_usage': {
                    'messages_with_files': file_usage.messages_with_files if file_usage else 0,
                    'unique_file_types': file_usage.unique_file_types if file_usage else 0
                }
            }
            
        except Exception as e:
            logger.error(f"Error getting user stats: {str(e)}")
            return {}
    
    @staticmethod
    def get_system_stats():
        # Get system-wide statistics (admin only)
        try:
            # User stats
            total_users = User.query.count()
            active_users_today = User.query.filter(
                User.last_login >= datetime.utcnow().date()
            ).count()
            
            # Session stats
            total_sessions = ChatSession.query.count()
            active_sessions = ChatSession.query.filter_by(is_active=True).count()
            
            # Message stats
            total_messages = ChatMessage.query.count()
            messages_today = ChatMessage.query.filter(
                ChatMessage.created_at >= datetime.utcnow().date()
            ).count()
            
            # Provider distribution
            provider_distribution = db.session.query(
                ChatMessage.provider,
                func.count(ChatMessage.id).label('count')
            ).filter(ChatMessage.role == 'assistant')\
             .filter(ChatMessage.provider.isnot(None))\
             .group_by(ChatMessage.provider)\
             .all()
            
            return {
                'total_users': total_users,
                'active_users_today': active_users_today,
                'total_sessions': total_sessions,
                'active_sessions': active_sessions,
                'total_messages': total_messages,
                'messages_today': messages_today,
                'provider_distribution': [
                    {
                        'provider': stat.provider,
                        'count': stat.count
                    } for stat in provider_distribution
                ]
            }
            
        except Exception as e:
            logger.error(f"Error getting system stats: {str(e)}")
            return {}
    
    # =============================================
    # SYSTEM SETTINGS
    # =============================================
    
    @staticmethod
    def get_system_setting(key, default=None):
        # Get system setting value
        try:
            return SystemSettings.get_setting(key, default)
        except Exception as e:
            logger.error(f"Error getting system setting: {str(e)}")
            return default
    
    @staticmethod
    def set_system_setting(key, value, description=None):
        # Set system setting value
        try:
            return SystemSettings.set_setting(key, value, description)
        except Exception as e:
            logger.error(f"Error setting system setting: {str(e)}")
            return None
        
        
    @staticmethod
    def get_user_sessions_count(user_id, days=None):
        """Get count of user chat sessions"""
        try:
            query = ChatSession.query.filter_by(user_id=user_id, is_active=True)
            
            if days:
                since_date = datetime.utcnow() - timedelta(days=days)
                query = query.filter(ChatSession.created_at >= since_date)
            
            return query.count()
            
        except Exception as e:
            logger.error(f"Error getting user sessions count: {str(e)}")
            return 0
        
    @staticmethod
    def get_user_usage_analytics(user_id, days=30):
        """Get comprehensive usage analytics for a user"""
        try:
            since_date = datetime.utcnow() - timedelta(days=days)
            
            # Current plan info
            from services.plan_manager import PlanManager
            current_plan = PlanManager.get_current_user_plan(user_id)
            
            # Usage summary from UsageTracking table
            total_usage = db.session.query(
                func.sum(UsageTracking.total_tokens).label('total_tokens'),
                func.sum(UsageTracking.estimated_cost_usd).label('total_cost'),
                func.count(UsageTracking.id).label('total_actions')
            ).filter(
                UsageTracking.user_id == user_id,
                UsageTracking.created_at >= since_date
            ).first()
            
            # Provider breakdown
            provider_usage = db.session.query(
                UsageTracking.provider,
                func.count(UsageTracking.id).label('count'),
                func.sum(UsageTracking.total_tokens).label('tokens'),
                func.sum(UsageTracking.estimated_cost_usd).label('cost_usd')
            ).filter(
                UsageTracking.user_id == user_id,
                UsageTracking.created_at >= since_date,
                UsageTracking.provider.isnot(None)
            ).group_by(UsageTracking.provider).all()
            
            # Daily usage trend from DailyUsageSummary
            daily_trend = db.session.query(
                func.date(DailyUsageSummary.date).label('date'),
                DailyUsageSummary.messages_sent,
                DailyUsageSummary.total_tokens,
                DailyUsageSummary.estimated_cost_usd
            ).filter(
                DailyUsageSummary.user_id == user_id,
                DailyUsageSummary.date >= since_date.date()
            ).order_by(DailyUsageSummary.date).all()
            
            # Most used models
            model_stats = db.session.query(
                UsageTracking.model,
                func.count(UsageTracking.id).label('count')
            ).filter(
                UsageTracking.user_id == user_id,
                UsageTracking.created_at >= since_date,
                UsageTracking.model.isnot(None)
            ).group_by(UsageTracking.model)\
            .order_by(desc(func.count(UsageTracking.id)))\
            .limit(10).all()
            
            # Get today's usage for summary
            today = datetime.utcnow().date()
            today_usage = DailyUsageSummary.query.filter_by(
                user_id=user_id,
                date=today
            ).first()
            
            # Web searches count
            web_searches = db.session.query(
                func.count(UsageTracking.id)
            ).filter(
                UsageTracking.user_id == user_id,
                UsageTracking.has_web_search == True,
                UsageTracking.created_at >= since_date
            ).scalar() or 0
            
            return {
                'current_plan': current_plan,
                'summary': {
                    'total_tokens': int(total_usage.total_tokens or 0),
                    'total_cost_usd': float(total_usage.total_cost or 0),
                    'total_actions': int(total_usage.total_actions or 0),
                    'messages_today': today_usage.messages_sent if today_usage else 0,
                    'web_searches': web_searches,
                    'days_analyzed': days
                },
                'provider_breakdown': [
                    {
                        'provider': usage.provider,
                        'count': usage.count,
                        'tokens': int(usage.tokens or 0),
                        'cost_usd': float(usage.cost_usd or 0)
                    } for usage in provider_usage
                ],
                'daily_trend': [
                    {
                        'date': trend.date.isoformat() if trend.date else None,
                        'messages': trend.messages_sent or 0,
                        'tokens': int(trend.total_tokens or 0),
                        'cost_usd': float(trend.estimated_cost_usd or 0)
                    } for trend in daily_trend
                ],
                'top_models': [
                    {
                        'model': model.model,
                        'count': model.count
                    } for model in model_stats
                ]
            }
            
        except Exception as e:
            logger.error(f"Error getting user usage analytics: {str(e)}")
            return {
                'current_plan': None,
                'summary': {
                    'total_tokens': 0,
                    'total_cost_usd': 0.0,
                    'total_actions': 0,
                    'messages_today': 0,
                    'web_searches': 0,
                    'days_analyzed': days
                },
                'provider_breakdown': [],
                'daily_trend': [],
                'top_models': []
            }
        
    # =============================================
    # UTILITY METHODS
    # =============================================
    
    @staticmethod
    def cleanup_old_data(days_to_keep=90):
        # Clean up old inactive sessions and user sessions
        try:
            cutoff_date = datetime.utcnow() - timedelta(days=days_to_keep)
            
            # Delete old inactive chat sessions
            old_sessions = ChatSession.query.filter(
                ChatSession.is_active == False,
                ChatSession.updated_at < cutoff_date
            ).all()
            
            deleted_sessions = 0
            for session in old_sessions:
                db.session.delete(session)
                deleted_sessions += 1
            
            # Delete old user sessions
            old_user_sessions = UserSession.query.filter(
                UserSession.is_active == False,
                UserSession.logout_time < cutoff_date
            ).all()
            
            deleted_user_sessions = 0
            for session in old_user_sessions:
                db.session.delete(session)
                deleted_user_sessions += 1
            
            db.session.commit()
            
            logger.info(f"Cleaned up {deleted_sessions} chat sessions and {deleted_user_sessions} user sessions")
            return {
                'deleted_chat_sessions': deleted_sessions,
                'deleted_user_sessions': deleted_user_sessions
            }
            
        except Exception as e:
            db.session.rollback()
            logger.error(f"Error during cleanup: {str(e)}")
            return {'error': str(e)}
    
    @staticmethod
    def export_user_data(user_id, format='json'):
        # Export all user data for GDPR compliance
        try:
            user = User.query.get(user_id)
            if not user:
                return None
            
            # Get all user data
            sessions = ChatSession.query.filter_by(user_id=user_id).all()
            projects = Project.query.filter_by(user_id=user_id).all()
            user_sessions = UserSession.query.filter_by(user_id=user_id).all()
            
            # Get all messages
            messages = db.session.query(ChatMessage)\
                                .join(ChatSession)\
                                .filter(ChatSession.user_id == user_id)\
                                .all()
            
            export_data = {
                'user': user.to_dict(),
                'projects': [project.to_dict() for project in projects],
                'chat_sessions': [session.to_dict() for session in sessions],
                'chat_messages': [message.to_dict() for message in messages],
                'user_sessions': [session.to_dict() for session in user_sessions],
                'export_date': datetime.utcnow().isoformat()
            }
            
            if format == 'json':
                return json.dumps(export_data, indent=2, default=str)
            else:
                return export_data
            
        except Exception as e:
            logger.error(f"Error exporting user data: {str(e)}")
            return None  
        
    @staticmethod
    def cleanup_session_memory_db(session_id, user_id=None):
        """
        ✅ NEW METHOD: Clean up session data when session is deleted
        This can be called when user deletes a session to ensure cleanup
        """
        try:
            if user_id is None and current_user.is_authenticated:
                user_id = current_user.id
            
            # Verify session belongs to user before cleanup
            session = ChatSession.query.filter_by(
                id=session_id,
                user_id=user_id
            ).first()
            
            if not session:
                logger.warning(f"Cannot cleanup session {session_id} - not found or no access")
                return False
            
            # You can add any additional DB cleanup here if needed
            # For now, just log the cleanup request
            logger.info(f"Database cleanup requested for session {session_id}")
            
            # This will be called from your app.py when session is deleted
            # to trigger memory manager cleanup as well
            return True
            
        except Exception as e:
            logger.error(f"Error in session cleanup: {str(e)}")
            return False 
     
    
    # =============================================
    # LLM CONTEXT PREPARATION
    # =============================================
        
    # Admin Analytics Methods
    @staticmethod
    def get_total_users():
        return AnalyticsService.get_total_users()
    
    @staticmethod 
    def get_monthly_revenue():
        return AnalyticsService.get_monthly_revenue()
    
    @staticmethod
    def get_active_users_24h():
        return AnalyticsService.get_active_users_24h()
    
    @staticmethod
    def get_conversion_rate():
        return AnalyticsService.get_conversion_rate()
    
    @staticmethod
    def get_user_growth_data(days=30):
        return AnalyticsService.get_user_growth_data(days)
    
    @staticmethod
    def get_users_by_plan():
        return AnalyticsService.get_users_by_plan()
    
    @staticmethod
    def get_provider_detailed_stats(days=30):
        return AnalyticsService.get_provider_detailed_stats(days)
    
    @staticmethod
    def get_revenue_trends(days=30):
        return AnalyticsService.get_revenue_trends(days)
    
    @staticmethod
    def get_average_revenue_per_user():
        return AnalyticsService.get_average_revenue_per_user()
    
    @staticmethod
    def get_lifetime_value():
        return AnalyticsService.get_lifetime_value()
    
    @staticmethod
    def get_churn_rate():
        return AnalyticsService.get_churn_rate()
    
    @staticmethod
    def get_provider_usage_stats():
        return AnalyticsService.get_provider_detailed_stats()
    
    @staticmethod
    def get_system_metrics():
        # Return basic system health metrics
        return {
            "uptime": "99.9%",
            "response_time": "124ms", 
            "error_rate": "0.1%",
            "queue_size": 12
        }
    
    @staticmethod
    def get_user_activity_stats(days=30):
        return AnalyticsService.get_user_growth_data(days)
    
    @staticmethod
    def get_user_retention_stats():
        return {
            "week1": 85,
            "week2": 72,
            "month1": 45,
            "month3": 28
        }
     
# =============================================
# LLM CONTEXT PREPARATION
# =============================================

class LLMContextBuilder:
    """Build optimized context for different LLM operations"""
    
    @staticmethod
    def build_crud_context(session_id, user_query, user_id=None):
        """Build context specifically for CRUD operations"""
        try:
            # Get only code files for CRUD
            code_files = DatabaseService.get_session_code_files_for_crud(session_id, user_id)
            
            if not code_files:
                return user_query
            
            # Determine if user is asking about specific file
            mentioned_files = []
            for filename in code_files.keys():
                if filename.lower() in user_query.lower():
                    mentioned_files.append(filename)
            
            if mentioned_files:
                # Focus on mentioned files
                focused_context = ContentFilter.prepare_context_for_llm(
                    {f: code_files[f] for f in mentioned_files}, 
                    user_query, 
                    "crud"
                )
                logger.info(f"🎯 Built focused CRUD context for: {mentioned_files}")
                return focused_context
            else:
                # Include all code files
                full_context = ContentFilter.prepare_context_for_llm(
                    code_files, 
                    user_query, 
                    "crud"
                )
                logger.info(f"📋 Built full CRUD context for {len(code_files)} files")
                return full_context
                
        except Exception as e:
            logger.error(f"Error building CRUD context: {str(e)}")
            return user_query
    
    @staticmethod
    def build_analysis_context(session_id, user_query, user_id=None):
        """Build context for code analysis operations"""
        try:
            # Get all relevant files (code + data)
            all_files = DatabaseService.get_session_files_by_type(
                session_id, ['code', 'data', 'document'], user_id
            )
            
            if not all_files:
                return user_query
            
            # Build comprehensive analysis context
            context_parts = []
            context_parts.append("=== SESSION FILES FOR ANALYSIS ===")
            
            # Categorize files
            code_files = {f: c for f, c in all_files.items() if ContentFilter._detect_file_type(f) == 'code'}
            data_files = {f: c for f, c in all_files.items() if ContentFilter._detect_file_type(f) == 'data'}
            doc_files = {f: c for f, c in all_files.items() if ContentFilter._detect_file_type(f) == 'document'}
            
            if code_files:
                context_parts.append("\n--- CODE FILES ---")
                for filename, content in code_files.items():
                    context_parts.append(f"File: {filename}")
                    context_parts.append(content)
                    context_parts.append("")
            
            if data_files:
                context_parts.append("\n--- DATA/CONFIG FILES ---")
                for filename, content in data_files.items():
                    context_parts.append(f"File: {filename}")
                    context_parts.append(content)
                    context_parts.append("")
            
            if doc_files:
                context_parts.append("\n--- DOCUMENTATION ---")
                for filename, content in doc_files.items():
                    context_parts.append(f"File: {filename}")
                    context_parts.append(content[:500] + "..." if len(content) > 500 else content)
                    context_parts.append("")
            
            context_parts.append("=== END SESSION FILES ===")
            context_parts.append(f"\nUser Request: {user_query}")
            
            result = "\n".join(context_parts)
            logger.info(f"📊 Built analysis context: {len(code_files)} code, {len(data_files)} data, {len(doc_files)} docs")
            
            return result
            
        except Exception as e:
            logger.error(f"Error building analysis context: {str(e)}")
            return user_query

