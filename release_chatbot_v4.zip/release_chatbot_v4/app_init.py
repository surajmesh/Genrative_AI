import os
import re 
import json
import logging
import time
import glob
from datetime import datetime
from urllib.parse import urlparse
from werkzeug.utils import secure_filename
from werkzeug.middleware.proxy_fix import ProxyFix
import flask
from flask import Flask, render_template, request, jsonify, session, redirect, url_for, current_app, flash
from flask_login import LoginManager, login_user, logout_user, login_required, current_user
from flask_cors import CORS
from datetime import datetime
import pytz

#Google Auth 
from google_auth_oauthlib.flow import Flow
from google.auth.transport.requests import Request
from googleapiclient.discovery import build
import google.auth.exceptions

import razorpay
import razorpay.errors

from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()


RAZORPAY_KEY_ID = os.getenv("RAZORPAY_KEY_ID","")
RAZORPAY_KEY_SECRET =  os.getenv("RAZORPAY_KEY_SECRET","")

# razorpay client initilisation
razorpay_client = razorpay.Client(auth=(RAZORPAY_KEY_ID, RAZORPAY_KEY_SECRET ))

# Google OAuth Configuration

os.environ['OAUTHLIB_INSECURE_TRANSPORT'] = '1'


from config import BASE_PATH

CLIENT_SECRET_FILE = os.path.join(
    BASE_PATH,
    "GOOGLE_CLIENT_SECRET_FILE.json"
)


SCOPES = [
    'openid',
    'https://www.googleapis.com/auth/userinfo.profile',
    'https://www.googleapis.com/auth/userinfo.email'
    
]

# 'https://www.googleapis.com/auth/drive'

def credentials_to_dict(credentials):
    return {
        'token': credentials.token,
        'refresh_token': credentials.refresh_token,
        'token_uri': credentials.token_uri,
        'client_id': credentials.client_id,
        'client_secret': credentials.client_secret,
        'scopes': credentials.scopes
    }

from dotenv import load_dotenv


# Load environment variables from .env file
load_dotenv()

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Set logging level to WARNING or ERROR to hide INFO/DEBUG messages
logging.getLogger().setLevel(logging.INFO)
logging.getLogger('integrations.llm_provider').setLevel(logging.WARNING)
logging.getLogger('anthropic._base_client').setLevel(logging.WARNING)

# Or disable specific loggers completely
logging.getLogger('integrations.llm_provider').disabled = True
logging.getLogger('anthropic._base_client').disabled = True

# Create the Flask application
app = Flask(__name__)

from collections import defaultdict
app.memory_managers = {}

# Cache-busting system
APP_VERSION = "1.3.0"
CACHE_BUSTER = f"{APP_VERSION}.{int(datetime.utcnow().timestamp())}"
logger.info(f"Cache buster initialized: {CACHE_BUSTER}")

def get_cache_buster():
    # Return cache buster string for static files
    return CACHE_BUSTER

# Enable CORS and add ProxyFix middleware
app.wsgi_app = ProxyFix(app.wsgi_app, x_proto=1, x_host=1)
CORS(app)

# Import configuration
from config import UPLOAD_FOLDER
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Configuration variables
COMPANY_NAME = os.getenv('COMPANY_NAME', 'AI Assistant Platform')
app.config['COMPANY_ACCESS_CODE'] = os.getenv('COMPANY_ACCESS_CODE', 'demo_access_2024')
app.secret_key = os.getenv('SECRET_KEY', 'your-secret-key-change-in-production')

# Configure SQLAlchemy database
database_url = os.environ.get("DATABASE_URL")

if database_url:
    logger.info(f"Using database URL from environment: {database_url}")
    # Fix potential Heroku postgres:// vs postgresql:// URLs
    if database_url.startswith("postgres://"):
        database_url = database_url.replace("postgres://", "postgresql://", 1)
else:
    # Development fallback
    logger.warning("DATABASE_URL environment variable not set. Using SQLite as fallback.")
    database_url = "sqlite:///ai_assistant.db"

app.config["SQLALCHEMY_DATABASE_URI"] = database_url
app.config["SQLALCHEMY_ENGINE_OPTIONS"] = {
    "pool_recycle": 300,
    "pool_pre_ping": True,
}
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False


# Import database models and service
from database import db, User, ChatSession, DatabaseService
from services.plan_manager import PlanManager
from services.analytics_service import AnalyticsService
from database.model import  ChatMessage
    


# Initialize database
db.init_app(app)

# Initialize login manager
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'
login_manager.login_message = 'Please log in to access this page.'

@login_manager.user_loader
def load_user(user_id):
    # Load user for Flask-Login
    return User.query.get(user_id)

# Make cache_buster available to templates
@app.context_processor
def inject_cache_buster():
    return {'cache_buster': get_cache_buster}

# Create database tables and initialize data
with app.app_context():
    try:
        db.create_all()
        logger.info("Database tables created successfully")
        
        # ADDED: Initialize plan templates if empty
        from services.plan_manager import PlanManager
        from database.model import PlanTemplate
        
        if PlanTemplate.query.count() == 0:
            logger.info("Initializing plan templates...")
            success = PlanManager.initialize_plan_templates()
            if success:
                logger.info("✅ Plan templates initialized successfully")
            else:
                logger.error("❌ Failed to initialize plan templates")
        else:
            logger.info(f"Plan templates already exist: {PlanTemplate.query.count()} plans")
            
    except Exception as e:
        logger.error(f"Error setting up database: {str(e)}")

# Import integration modules
from integration.Settings_llm import  MODEL_CATALOG, DEFAULT_MODELS, get_models_by_provider ,provider_enabled,get_system_prompt
from integration.Get_Completion_Function import get_completion_with_memory, generate_chat_title , welcomingMessage



try:
    from integration.advanced_memory_manager import HybridMemoryManager
except ImportError as e:
    print(f"❌ Import failed: {e}")

# Import forms
from database.forms import LoginForm, RegistrationForm, PasswordResetRequestForm, PasswordResetForm

# =============================================
# UTILITY FUNCTIONS
# =============================================


# Create Google OAuth flow
def create_flow():
    flow = Flow.from_client_secrets_file(
        CLIENT_SECRET_FILE,
        scopes=SCOPES,
        redirect_uri=url_for('google_callback', _external=True)
    )
    return flow

def get_google_user_info(credentials_dict):
    """Get user info from Google using stored credentials"""
    try:
        from google.oauth2.credentials import Credentials
        
        credentials = Credentials(**credentials_dict)
        service = build('oauth2', 'v2', credentials=credentials)
        return service.userinfo().get().execute()
    except Exception as e:
        logger.error(f"Error getting Google user info: {str(e)}")
        return None

def delete_files_in_uploads(uploads_path):
    # Delete all files in uploads directory
    try:
        files = glob.glob(os.path.join(uploads_path, "*"))
        files = [f for f in files if os.path.isfile(f)]
        
        for file in files:
            os.remove(file)
            logger.info(f"Deleted: {file}")
        
        logger.info(f"Successfully deleted {len(files)} files from uploads directory")
        
    except Exception as e:
        logger.error(f"Error deleting files: {str(e)}")

def cleanup_uploaded_files(uploaded_files):
    # Remove uploaded files after processing
    for file_info in uploaded_files:
        try:
            if os.path.exists(file_info["filepath"]):
                os.remove(file_info["filepath"])
        except Exception as e:
            logger.error(f"❌ Error cleaning up file {file_info['filepath']}: {e}")

def validate_file_type(filename):
    # Validate allowed file extensions
    allowed_extensions = {'.txt', '.pdf', '.docx', '.xlsx', '.csv', '.json', '.py', '.js', '.html', '.css', 
                         '.jpg', '.jpeg', '.png', '.gif', '.bmp', '.webp', '.mp3', '.wav', '.m4a', '.ogg'}
    return any(filename.lower().endswith(ext) for ext in allowed_extensions)

def process_uploaded_files(files):
    """Process and validate uploaded files"""
    uploaded_files = []
    for file in files:
        if file.filename and validate_file_type(file.filename):
            filename = secure_filename(file.filename)
            filepath = os.path.join(UPLOAD_FOLDER, filename)
            file.save(filepath)
            
            file_type = determine_file_type(filename)
            
            # Read content for code files immediately
            content = None
            if file_type == 'code':
                try:
                    with open(filepath, 'r', encoding='utf-8') as f:
                        content = f.read()
                    logger.info(f"✅ Read code content from {filename}: {len(content)} chars")
                except Exception as e:
                    logger.error(f"❌ Error reading {filename}: {e}")
                    try:
                        # Try different encoding
                        with open(filepath, 'r', encoding='latin-1') as f:
                            content = f.read()
                    except:
                        content = None
            
            uploaded_file_info = {
                "filename": filename,
                "filepath": filepath,
                "type": file_type,  # This will be 'code' for .py files
                "size": os.path.getsize(filepath),
                "content": content  # Add content here for code files
            }
            
            # Add file_type to match what CodebaseAnalyzer expects
            if file_type == 'code':
                uploaded_file_info["file_type"] = 'code'
            
            uploaded_files.append(uploaded_file_info)
            
            logger.info(f"📁 Processed file: {filename} - type: {file_type}, has_content: {bool(content)}")
    
    return uploaded_files

def determine_file_type(filename):
    # Determine file type based on extension
    extension = filename.lower().split('.')[-1]
    if extension in ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp']:
        return 'image'
    elif extension in ['mp3', 'wav', 'm4a', 'ogg']:
        return 'audio'
    elif extension in ['pdf', 'docx', 'txt']:
        return 'document'
    elif extension in ['xlsx', 'csv']:
        return 'data'
    elif extension in ['py', 'js', 'html', 'css', 'json']:
        return 'code'
    else:
        return 'unknown'

def prepare_file_path_for_db(uploaded_files, max_length=490):
    """Prepare file paths to fit in String(500) column"""
    if not uploaded_files:
        return None
    
    # Option A: Store only filenames (not full paths)
    filenames = [f['filename'] for f in uploaded_files]
    
    # Option B: Truncate if too long
    if len(filenames) <= 3:
        # For few files, join normally
        file_path = ','.join(filenames)
    else:
        # For many files, show first 2 + count
        file_path = f"{filenames[0]},{filenames[1]}...+{len(filenames)-2} more"
    
    # Ensure it fits in 500 chars
    if len(file_path) > max_length:
        file_path = file_path[:max_length-3] + "..."
    
    return file_path

# =============================================
# AUTHENTICATION ROUTES
# =============================================

@app.route('/', methods=['GET', 'POST'])
def index():
    # Landing page with login form
    if current_user.is_authenticated:
        return redirect(url_for('chat'))
        
    form = LoginForm()
    if form.validate_on_submit():
        print(f"DEBUG: Login attempt for email: {form.email.data}")
        user = DatabaseService.get_user_by_email(form.email.data)
        print(f"DEBUG: User found: {user}")
        
        if user is None or not user.check_password(form.password.data):
            flash('Invalid email or password', 'error')
            return redirect(url_for('index'))
        
        login_user(user, remember=form.remember_me.data)
        
        # Update last login and create session tracking
        DatabaseService.update_last_login(user.id)
        DatabaseService.create_user_session(
            user.id,
            ip_address=request.remote_addr,
            user_agent=request.headers.get('User-Agent')
        )
        
        next_page = request.args.get('next')
        if not next_page or urlparse(next_page).netloc != '':
            next_page = url_for('chat')
            
        flash('You have been logged in successfully!', 'success')
        return redirect(next_page)
        
    return render_template('index.html', form=form, page_class="login-page")

@app.route('/home')
@login_required
def dev_home():
    # Render the Ohmni Oracle home page
    return render_template('dev_home.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    # User login page (alternative route)
    if current_user.is_authenticated:
        return redirect(url_for('chat'))
    
    form = LoginForm()
    if form.validate_on_submit():
        user = DatabaseService.get_user_by_email(form.email.data)
        
        if user is None or not user.check_password(form.password.data):
            flash('Invalid email or password')
            return redirect(url_for('login'))
        
        login_user(user, remember=form.remember_me.data)
        
        # Update last login and create session tracking
        DatabaseService.update_last_login(user.id)
        DatabaseService.create_user_session(
            user.id,
            ip_address=request.remote_addr,
            user_agent=request.headers.get('User-Agent')
        )
        
        next_page = request.args.get('next')
        if not next_page or urlparse(next_page).netloc != '':
            next_page = url_for('chat')
            
        flash('You have been logged in successfully!')
        return redirect(next_page)
        
    return render_template("login.html", page_class="login-page", form=form)

@app.route('/logout')
def logout():
    # Log out current user and clear Google credentials
    if 'google_credentials' in session:
        session.pop('google_credentials', None)
    
    logout_user()
    flash('You have been logged out.', 'info')
    return redirect(url_for('index'))

@app.route('/reset_password_request', methods=['GET', 'POST'])
def reset_password_request():
    # Handle password reset request
    if current_user.is_authenticated:
        return redirect(url_for('index'))
        
    form = PasswordResetRequestForm()
    if form.validate_on_submit():
        user = DatabaseService.get_user_by_email(form.email.data)
        
        if user:
            # Check if user is Google-only user
            if hasattr(user, 'is_google_user') and user.is_google_user and not user.password_hash:
                flash('This account uses Google authentication. Please sign in with Google.', 'info')
                return redirect(url_for('index'))
            
            # Generate reset token
            token = user.generate_reset_token()
            db.session.commit()
            
            # Development: show reset link directly
            reset_url = url_for('reset_password', token=token, _external=True)
            flash(f'For development only - Password reset link: {reset_url}', 'info')
            flash('In production, this link would be emailed to you.', 'info')
            flash('A password reset link has been sent to your email address.', 'success')
        else:
            # Don't reveal if user exists for security
            flash('If an account with that email exists, a password reset link has been sent.', 'info')
            
        return render_template('reset_request.html', title='Reset Password', form=form)
        
    return render_template('reset_request.html', title='Reset Password', form=form)
    
@app.route('/reset_password/<token>', methods=['GET', 'POST'])
def reset_password(token):
    # Handle password reset with token
    if current_user.is_authenticated:
        return redirect(url_for('index'))
        
    # Find user by token
    user = User.find_by_reset_token(token)
    if not user:
        flash('Invalid or expired reset link.', 'error')
        return redirect(url_for('reset_password_request'))
    
    # Check if user is Google-only user
    if hasattr(user, 'is_google_user') and user.is_google_user:
        flash('This account uses Google authentication. Please sign in with Google.', 'info')
        return redirect(url_for('index'))
        
    form = PasswordResetForm()
    if form.validate_on_submit():
        # Set new password and clear token
        user.set_password(form.password.data)
        user.clear_reset_token()
        db.session.commit()
        
        flash('Your password has been reset successfully.', 'success')
        return redirect(url_for('index'))
        
    return render_template('reset_password.html', title='Reset Password', form=form, token=token)

@app.route('/register', methods=['GET', 'POST'])
def register():
    # New user registration
    if current_user.is_authenticated:
        return redirect(url_for('dev_home'))
    
    form = RegistrationForm()
    if form.validate_on_submit():
        # Check company access code if provided
        company_code = form.company_access_code.data
        if company_code and company_code != app.config.get('COMPANY_ACCESS_CODE'):
            flash('Invalid company access code. Please contact your administrator.', 'error')
            return redirect(url_for('register'))
        
        try:
            print(f"DEBUG: Creating user with email: {form.email.data}")
            # Create new user using DatabaseService
            user = DatabaseService.create_user(
                email=form.email.data,
                username=form.username.data,
                fullname=form.fullname.data,
                password=form.password.data,
                is_google_user=False
            )

            print(f"DEBUG: User created: {user}")
            db.session.commit()
            
            flash('Registration successful! You can now log in.', 'success')
            return redirect(url_for('index'))
            
        except Exception as e:
            logger.error(f"Error registering user: {str(e)}")
            flash('An error occurred during registration. Please try again.', 'error')
    
    return render_template('register.html', title='Register', form=form, 
                         company_name=app.config.get('COMPANY_NAME', 'OneRoof'))

# =============================================
# GOOGLE OAUTH ROUTES
# =============================================

@app.route('/auth/google')
def google_auth():
    """Initiate Google OAuth flow"""
    if current_user.is_authenticated:
        return redirect(url_for('chat'))
    
    try:
        flow = create_flow()
        authorization_url, state = flow.authorization_url(
            access_type='offline',
            include_granted_scopes='true',
            prompt='select_account'  # Force account selection
        )
        
        # Store the state in session for security
        session['oauth_state'] = state
        return redirect(authorization_url)
        
    except Exception as e:
        logger.error(f"Error initiating Google OAuth: {str(e)}")
        flash('Unable to connect to Google. Please try again or use email login.', 'error')
        return redirect(url_for('index'))


@app.route('/auth/google/callback')
def google_callback():
    """Handle Google OAuth callback"""
    try:
        # Verify state parameter for security
        if 'oauth_state' not in session or request.args.get('state') != session['oauth_state']:
            flash('Invalid authentication state. Please try again.', 'error')
            return redirect(url_for('index'))
        
        # Handle authorization errors
        if 'error' in request.args:
            error = request.args.get('error')
            if error == 'access_denied':
                flash('Google authentication was cancelled.', 'info')
            else:
                flash('Google authentication failed. Please try again.', 'error')
            return redirect(url_for('index'))
        
        # Exchange authorization code for credentials
        flow = create_flow()
        flow.fetch_token(authorization_response=request.url)
        
        # Store credentials in session
        credentials = flow.credentials
        session['google_credentials'] = credentials_to_dict(credentials)
        
        # Get user info from Google
        service = build('oauth2', 'v2', credentials=credentials)
        user_info = service.userinfo().get().execute()
        
        if not user_info.get('email'):
            flash('Unable to get email from Google account. Please try again.', 'error')
            return redirect(url_for('index'))
        
        # Check if user exists
        user = DatabaseService.get_user_by_email(user_info['email'])
        
        if user is None:
            # Create new user from Google info
            try:
                
                # Generate username from first name only
                full_name = user_info.get('name', '')
                first_name = full_name.split(' ')[0] if full_name else ''
                username = first_name.replace(' ', '').lower()
                
                if not username or DatabaseService.get_user_by_username(username):
                    username = user_info['email'].split('@')[0]
                    # Add number if username exists
                    counter = 1
                    original_username = username
                    while DatabaseService.get_user_by_username(username):
                        username = f"{original_username}{counter}"
                        counter += 1

                print(f"DEBUG: Creating Google user: {user_info}")
                user = DatabaseService.create_user(
                    email=user_info['email'],
                    username=username,
                    fullname=user_info.get('name', ''),
                    password=None,  # No password for Google users
                    google_id=user_info.get('id'),
                    is_google_user=True
                )

                print(f"DEBUG: Google user created: {user}")  # ADD THIS
                db.session.commit()  #
                flash(f'Welcome! Your account has been created using Google.', 'success')
                
            except Exception as e:
                logger.error(f"Error creating Google user: {str(e)}")
                flash('Error creating your account. Please try again or use email registration.', 'error')
                return redirect(url_for('index'))
        else:
            # Update existing user with Google ID if not set
            if not hasattr(user, 'google_id') or not user.google_id:
                try:
                    user.google_id = user_info.get('id')
                    user.is_google_user = True
                    db.session.commit()
                except Exception as e:
                    logger.error(f"Error updating user Google info: {str(e)}")
        
        # Log the user in
        login_user(user, remember=True)
        
        # Update last login and create session tracking
        DatabaseService.update_last_login(user.id)
        DatabaseService.create_user_session(
            user.id,
            ip_address=request.remote_addr,
            user_agent=request.headers.get('User-Agent')
        )
        
        # Clean up session
        session.pop('oauth_state', None)
        
        flash('You have been logged in successfully with Google!', 'success')
        return redirect(url_for('chat'))
        
    except google.auth.exceptions.RefreshError:
        flash('Google authentication expired. Please try again.', 'error')
        return redirect(url_for('index'))
    except Exception as e:
        logger.error(f"Error in Google OAuth callback: {str(e)}")
        flash('Authentication failed. Please try again.', 'error')
        return redirect(url_for('index'))

# =============================================
# PLAN MANAGEMENT ROUTES
# =============================================

@app.route('/api/plans/available', methods=['GET'])
@login_required
def get_available_plans():
    """Get all available subscription plans"""
    try:
        plans = PlanManager.get_available_plans()
        return jsonify({
            "success": True,
            "plans": plans
        })
    except Exception as e:
        logger.error(f"❌ Error getting plans: {str(e)}")
        return jsonify({
            "success": False,
            "error": "Failed to retrieve plans"
        }), 500

@app.route('/api/plans/current', methods=['GET'])
@login_required
def get_current_plan():
    """Get user's current plan and usage status"""
    try:
        status = PlanManager.get_plan_usage_status(current_user.id)
        return jsonify({
            "success": True,
            **status
        })
    except Exception as e:
        logger.error(f"❌ Error getting current plan: {str(e)}")
        return jsonify({
            "success": False,
            "error": "Failed to retrieve plan status"
        }), 500

@app.route('/api/plans/activate', methods=['POST'])
@login_required
def activate_plan():
    """Activate a new plan for user"""
    try:
        data = request.get_json()
        plan_type = data.get('plan_type')
        payment_id = data.get('payment_id')  # From payment gateway
        amount_paid = data.get('amount_paid', 0)
        
        if not plan_type:
            return jsonify({
                "success": False,
                "error": "Plan type is required"
            }), 400
        
        # For free plans, no payment required
        if plan_type == 'free':
            plan = DatabaseService.create_free_plan(current_user.id)
        else:
            # TODO: Verify payment with payment gateway here
            plan = PlanManager.activate_plan(
                user_id=current_user.id,
                plan_type=plan_type,
                payment_id=payment_id,
                amount_paid=amount_paid
            )
        
        return jsonify({
            "success": True,
            "plan": plan,
            "message": f"Successfully activated {plan_type} plan"
        })
        
    except Exception as e:
        logger.error(f"❌ Error activating plan: {str(e)}")
        return jsonify({
            "success": False,
            "error": "Failed to activate plan"
        }), 500

@app.route('/api/usage/analytics', methods=['GET'])
@login_required
def get_usage_analytics():
    """Get user usage analytics"""
    try:
        days = request.args.get('days', 30, type=int)
        analytics = DatabaseService.get_user_usage_analytics(current_user.id, days)
        
        return jsonify({
            "success": True,
            "analytics": analytics
        })
        
    except Exception as e:
        logger.error(f"❌ Error getting usage analytics: {str(e)}")
        return jsonify({
            "success": False,
            "error": "Failed to retrieve analytics"
        }), 500
              
# =============================================
# CHAT INTERFACE ROUTES
# =============================================

@app.route('/chat')
@login_required
def chat():
    # Main chat interface
    try:
        chat_sessions = DatabaseService.get_chat_sessions(current_user.id)
        return render_template('chatv2.html', chat_sessions=chat_sessions, user=current_user)
    except Exception as e:
        logger.error(f"❌ Error loading chat page: {str(e)}")
        return render_template('chatv2.html', chat_sessions=[], user=current_user)

# =============================================
# CHAT API ROUTES
# =============================================

@app.route('/api/chat/user-info', methods=['GET'])
@login_required
def get_user_info():
    """Get user information immediately (fast response)"""
    try:
        # Build user_info dictionary
        user_fullName = current_user.fullname or current_user.username or 'User'
        user_firstName = user_fullName.split()[0] if user_fullName else 'User'
        user_firstLetter = user_fullName[0].upper() if user_fullName else 'U'
        mail = getattr(current_user, 'email', None)

        return jsonify({
            "success": True,
            "user_info": {
                "user_fullName": user_fullName,
                "user_firstLetter": user_firstLetter,
                "mail": mail
            }
        })
        
    except Exception as e:
        logger.error(f"❌ Error getting user info: {str(e)}")
        return jsonify({
            "success": False,
            "error": "Failed to retrieve user information"
        }), 500

@app.route('/api/chat/welcome-message', methods=['GET'])
@login_required
def get_welcome_message_only():
    """Generate personalized welcome message using LLM (slow response)"""
    try:
        # Get user info for welcome message
        user_fullName = current_user.fullname or current_user.username or 'User'
        user_firstName = user_fullName.split()[0] if user_fullName else 'User'

        # Get current IST time using timezone
        ist_timezone = pytz.timezone('Asia/Kolkata')
        current_time = datetime.now(ist_timezone)

        # Determine time of day greeting based on IST
        hour = current_time.hour
        if 5 <= hour < 12:
            time_greeting = "Good morning"
        elif 12 <= hour < 17:
            time_greeting = "Good afternoon"
        elif 17 <= hour < 21:
            time_greeting = "Good evening"
        else:
            time_greeting = "Good night"
        
        logger.info(f"IST Time: {current_time}, Hour: {hour}, Greeting: {time_greeting}")
        
        # Prepare additional parameters
        last_login = current_user.last_login
        is_returning_user = bool(current_user.last_login)
        
        # Call your LLM function
        welcome_message = welcomingMessage(
            username=user_firstName,
            time_greeting=time_greeting,
            last_login=last_login,
            is_returning_user=is_returning_user
        )
        
        logger.info(f"Generated welcome message: {welcome_message}")

        return jsonify({
            "success": True,
            "welcome_message": welcome_message
        })
        
    except Exception as e:
        logger.error(f"❌ Error generating welcome message: {str(e)}")
        return jsonify({
            "success": False,
            "welcome_message": f"Welcome back! 👋",
            "error": "Failed to generate personalized welcome message"
        }), 500

# Add this route after your existing chat routes
@app.route('/api/chat/models', methods=['GET'])
@login_required
def get_models_catalog():
    """Get available models for a specific provider"""
    try:
        provider = request.args.get('provider')
        
        if not provider:
            # Return all providers and their models
            available_models = {}
            for provider_name in MODEL_CATALOG.keys():
                if provider_enabled(provider_name):
                    available_models[provider_name] = get_models_by_provider(provider_name)
            
            return jsonify({
                "success": True,
                "providers": available_models,
                "default_models": DEFAULT_MODELS
            })
        
        # Return models for specific provider
        if provider.lower() not in MODEL_CATALOG:
            return jsonify({
                "success": False,
                "error": f"Provider '{provider}' not supported"
            }), 400
        
        if not provider_enabled(provider.lower()):
            return jsonify({
                "success": False,
                "error": f"Provider '{provider}' not configured (missing API key)"
            }), 400
        
        models_data = get_models_by_provider(provider.lower())
        
        return jsonify({
            "success": True,
            "provider": provider.lower(),
            "models": models_data["models"],
            "default_model": DEFAULT_MODELS.get(provider.lower())
        })
        
    except Exception as e:
        logger.error(f"❌ Error getting models catalog: {str(e)}")
        return jsonify({
            "success": False,
            "error": "Failed to retrieve models catalog"
        }), 500

# =============================================
# REGULAR MESSAGE FUNCTIONALITY
# =============================================

@app.route('/api/chat/messages', methods=['POST'])
@login_required
def api_send_message():
    """Enhanced API endpoint with new user modes"""
    session_id = None 
    uploaded_files = []
    user_message = ''
    use_reasoning = False
    provider = None
    has_uploads = False
    user_selection_model = None
    processed_files = []
    
    # NEW: User mode flags with defaults
    enable_web_search = False
    enable_deep_research = False
    enable_study_learn = False

    os.makedirs(UPLOAD_FOLDER, exist_ok=True)
    
    try:
        # ========================================
        # STEP 1: Process Request Data (Enhanced)
        # ========================================
        if request.files:
            user_message = request.form.get('message', '')
            use_reasoning = request.form.get('use_reasoning', 'false').lower() == 'true'
            provider = request.form.get('provider')
            user_selection_model = request.form.get('user_selection_model')
            session_id = request.form.get('session_id')
            
            # NEW: Extract user mode flags from form
            enable_web_search = request.form.get('enable_web_search', 'false').lower() == 'true'
            enable_deep_research = request.form.get('enable_deep_research', 'false').lower() == 'true'
            enable_study_learn = request.form.get('enable_study_learn', 'false').lower() == 'true'
            
            has_uploads = True
            files = request.files.getlist('files')
            uploaded_files = process_uploaded_files(files)
            processed_files = prepare_files_for_ai_enhanced(uploaded_files)
            
        else:
            data = request.get_json()
            if not data:
                return jsonify({"error": "No data provided"}), 400
                
            user_message = data.get('message', '')
            use_reasoning = bool(data.get("use_reasoning", False))
            provider = data.get("provider")
            user_selection_model = data.get("user_selection_model")
            session_id = data.get('session_id')
            has_uploads = bool(data.get("has_uploads", False))
            
            # NEW: Extract user mode flags from JSON
            enable_web_search = bool(data.get("enable_web_search", False))
            enable_deep_research = bool(data.get("enable_deep_research", False))
            enable_study_learn = bool(data.get("enable_study_learn", False))
        
        # Log user modes for debugging
        logger.info(f"🎯 User Modes - Web Search: {enable_web_search}, Deep Research: {enable_deep_research}, Study/Learn: {enable_study_learn}")
        
        # Validate user message
        if not user_message.strip():
            return jsonify({"error": "Message is required"}), 400
        
        # ========================================
        # STEP 2: Plan Limit Checks (Enhanced for user modes)
        # ========================================
        estimated_tokens = len(user_message.split()) * 1.3
        
        # Increase token estimate for enhanced modes
        if enable_deep_research:
            estimated_tokens *= 2  # Deep research uses more tokens
        elif enable_web_search or enable_study_learn:
            estimated_tokens *= 1.5  # Moderate increase
        
        permission_check = PlanManager.check_message_permission(
            user_id=current_user.id,
            provider=provider,
            model=user_selection_model,
            input_tokens=int(estimated_tokens)
        )
        
        if not permission_check['allowed']:
            return jsonify({
                "success": False,
                "error": permission_check['reason'],
                "limit_reached": True,
                "upgrade_suggestion": permission_check.get('upgrade_suggestion'),
                "suggested_model": permission_check.get('suggested_model'),
                "plan_status": PlanManager.get_plan_usage_status(current_user.id)
            }), 429
        
        # Enhanced plan checks for user modes
        if enable_web_search or enable_deep_research:
            web_search_check = PlanManager.check_web_search_permission(current_user.id)
            if not web_search_check['allowed']:
                return jsonify({
                    "success": False,
                    "error": f"Web search required but {web_search_check['reason']}",
                    "limit_reached": True,
                    "upgrade_suggestion": "12_day"
                }), 429
        
        if uploaded_files:
            upload_check = PlanManager.check_file_upload_permission(current_user.id)
            if not upload_check['allowed']:
                return jsonify({
                    "success": False,
                    "error": upload_check['reason'],
                    "limit_reached": True,
                    "upgrade_suggestion": "12_day"
                }), 429
        
        # ========================================
        # STEP 3: Session Management (Unchanged)
        # ========================================
        session_title = None
        if session_id:
            session_data = DatabaseService.get_chat_session(session_id, current_user.id)
            if not session_data:
                logger.warning(f"Session {session_id} not found for user {current_user.id}")
                session_id = None
            else:
                session_title = session_data.get('name', 'Chat Session')
        
        if not session_id:
            session_title = generate_chat_title(user_message, user_selection_model)
            session_id = DatabaseService.create_chat_session(
                name=session_title,
                user_id=current_user.id
            )
            logger.info(f"Created new chat session: {session_id}")
        else:
            logger.info(f"Using existing chat session: {session_id}")
        
        # ========================================
        # STEP 4: Enhanced Memory Manager (Unchanged)
        # ========================================
        memory_manager = None
        is_new_memory = False
        
        if session_id not in app.memory_managers:
            memory_manager = HybridMemoryManager(
                buffer_limit=20,
                summary_threshold=0.8
            )
            memory_manager.session_id = session_id
            memory_manager.history_loaded = False
            memory_manager.last_message_id = None
            memory_manager.session_code_files = {}
            app.memory_managers[session_id] = memory_manager
            is_new_memory = True
            logger.info(f"Created NEW memory manager for session: {session_id}")
        else:
            memory_manager = app.memory_managers[session_id]
            logger.info(f"♻️ Reusing EXISTING memory manager for session: {session_id}")

        # Load history (existing logic)
        if not getattr(memory_manager, 'history_loaded', False):
            try:
                chat_history = DatabaseService.get_chat_history_enhanced(session_id, current_user.id)
                
                for msg in chat_history:
                    if msg['role'] == 'user':
                        memory_manager.add_user_message(msg['content'])
                        
                        if msg.get('has_uploads') and '=== UPLOADED FILE:' in msg['content']:
                            code_files = extract_code_files_from_content(msg['content'])
                            if hasattr(memory_manager, 'session_code_files'):
                                memory_manager.session_code_files.update(code_files)
                            else:
                                memory_manager.session_code_files = code_files
                                
                    elif msg['role'] == 'assistant':
                        memory_manager.add_ai_message(msg['content'])
                
                memory_manager.history_loaded = True
                if chat_history:
                    memory_manager.last_message_id = chat_history[-1].get('id')
                
                code_count = len(getattr(memory_manager, 'session_code_files', {}))
                logger.info(f"Loaded {len(chat_history)} messages and {code_count} code files into memory")
                
            except Exception as e:
                logger.error(f"❌ Error loading enhanced chat history: {str(e)}")
        else:
            try:
                last_msg_id = getattr(memory_manager, 'last_message_id', None)
                if last_msg_id:
                    new_messages = DatabaseService.get_chat_history_since(session_id, last_msg_id, current_user.id)
                    
                    for msg in new_messages:
                        if msg['role'] == 'user':
                            memory_manager.add_user_message(msg['content'])
                        elif msg['role'] == 'assistant':
                            memory_manager.add_ai_message(msg['content'])
                    
                    if new_messages:
                        memory_manager.last_message_id = new_messages[-1].get('id')
                        logger.info(f"Added {len(new_messages)} incremental messages")
                        
            except Exception as e:
                logger.error(f"❌ Error loading incremental messages: {str(e)}")

        # ========================================
        # STEP 5: Add Current Code Files (Unchanged)
        # ========================================
        if processed_files:
            if not hasattr(memory_manager, 'session_code_files'):
                memory_manager.session_code_files = {}
                
            for file_info in processed_files:
                if file_info.get('file_type') == 'code' and file_info.get('content'):
                    filename = file_info.get('name', 'unknown_file')
                    memory_manager.session_code_files[filename] = file_info['content']
                    logger.info(f"📁 Added {filename} to session code context")

        memory_info = memory_manager.get_memory_info()
        logger.info(f"Memory Info: {memory_info}")
        
        # ========================================
        # STEP 6: Duplicate Prevention & Message Addition (Unchanged)
        # ========================================
        current_messages = memory_manager.get_messages()
        if current_messages and len(current_messages) > 0:
            last_user_msg = None
            for msg in reversed(current_messages):
                if msg.get('role') == 'user':
                    last_user_msg = msg.get('content', '')
                    break
            
            if last_user_msg == user_message.strip():
                logger.warning(f"⚠️ Duplicate message detected: {user_message[:50]}...")
            else:
                memory_manager.add_user_message(user_message)
        else:
            memory_manager.add_user_message(user_message)

        # ========================================
        # STEP 7: Enhanced Database Storage (Unchanged)
        # ========================================
        user_message_id = DatabaseService.save_chat_message_with_code(
            session_id=session_id,
            role='user',
            content=user_message,
            has_uploads=len(uploaded_files) > 0,
            file_path=prepare_file_path_for_db(uploaded_files),
            file_names=[f['filename'] for f in uploaded_files] if uploaded_files else None,
            uploaded_files=processed_files
        )
        
        memory_manager.last_message_id = user_message_id
        
        # ========================================
        # STEP 8: Enhanced System Prompt & AI Processing
        # ========================================
        system_prompt = get_system_prompt(
            use_reasoning=use_reasoning, 
            uploaded_files=processed_files,
            has_uploads=has_uploads
        )
        
        logger.info("About to call get_completion_with_memory")
        
        start_time = time.time()
        
        # Enhanced AI response with user modes
        ai_response = get_completion_with_memory(
            prompt=user_message,
            memory_manager=memory_manager,
            use_reasoning=use_reasoning,
            system_prompt=system_prompt,
            provider=provider,
            has_uploads=len(uploaded_files) > 0,
            uploaded_files=processed_files,
            user_selection_model=user_selection_model,
            session_id=session_id,
            user_id=current_user.id,
            # NEW: Pass user mode flags
            enable_web_search=enable_web_search,
            enable_deep_research=enable_deep_research,
            enable_study_learn=enable_study_learn
        )
        
        end_time = time.time()
        execution_time = end_time - start_time
        logger.info(f"✅ Enhanced LLM processing completed in {execution_time:.4f}s")
        
        # ========================================
        # STEP 9: Enhanced Success Response Processing
        # ========================================
        if ai_response["success"]:
            # Save AI response to database
            ai_message_id = DatabaseService.save_chat_message(
                session_id=session_id,
                role='assistant',
                content=ai_response["text"],
                provider=ai_response.get("provider"),
                model=ai_response.get("model"),
                reasoning_used=use_reasoning,
                response_time=ai_response.get("elapsed_time"),
                input_tokens=ai_response.get("input_tokens"),
                output_tokens=ai_response.get("output_tokens"),
                estimated_cost=ai_response.get("estimated_cost"),
                enable_web_search=enable_web_search,
                enable_deep_research=enable_deep_research,
                enable_study_learn=enable_study_learn,
                enhanced_sources=ai_response.get("enhanced_sources", [])
            )
            
            # Enhanced usage recording with user modes
            PlanManager.record_message_usage(
                user_id=current_user.id,
                provider=ai_response.get("provider"),
                model=ai_response.get("model"),
                input_tokens=ai_response.get("input_tokens", 0),
                output_tokens=ai_response.get("output_tokens", 0),
                session_id=session_id,
                message_id=ai_message_id,
                response_time_ms=int((ai_response.get("elapsed_time", 0) * 1000)),
                has_web_search=ai_response.get("multi_agent", {}).get("decisions", {}).get("needs_web_search", False) or enable_web_search or enable_deep_research,
                has_file_upload=len(uploaded_files) > 0
            )
            
            # Enhanced response with user mode information
            ai_response.update({
                "session_id": session_id,
                "session_name": session_title if is_new_memory else None,
                "user_message_id": user_message_id,
                "ai_message_id": ai_message_id,
                "memory_info": memory_manager.get_memory_info(),
                "plan_status": PlanManager.get_plan_usage_status(current_user.id),
                "code_context": {
                    "has_code_files": len(getattr(memory_manager, 'session_code_files', {})) > 0,
                    "code_files_count": len(getattr(memory_manager, 'session_code_files', {})),
                    "code_files_list": list(getattr(memory_manager, 'session_code_files', {}).keys())
                },
                # NEW: User mode status in response
                "user_modes_active": {
                    "web_search": enable_web_search,
                    "deep_research": enable_deep_research,
                    "study_learn": enable_study_learn,
                    "mode_description": _get_active_modes_description(enable_web_search, enable_deep_research, enable_study_learn)
                }
            })
        
        # Cleanup uploaded files
        if uploaded_files:
            cleanup_uploaded_files(uploaded_files)
        
        return jsonify(ai_response)
        
    except Exception as e:
        logger.error(f"❌ Error in enhanced api_send_message: {str(e)}", exc_info=True)
        
        if uploaded_files:
            cleanup_uploaded_files(uploaded_files)
            
        return jsonify({
            "error": "Internal server error",
            "success": False,
            "text": "Sorry, there was an error processing your request."
        }), 500

def _get_active_modes_description(web_search, deep_research, study_learn):
    """Generate description of active user modes"""
    active_modes = []
    if study_learn: active_modes.append("Study/Learn Mode")
    if deep_research: active_modes.append("Deep Research Mode")  
    if web_search: active_modes.append("Web Search Mode")
    
    if active_modes:
        return f"Active: {', '.join(active_modes)}"
    return "Standard Mode"


# =============================================
# REGENERATION AND EDIT MESSAGE FUNCTIONALITY
# =============================================

@app.route('/api/chat/messages/<message_id>/update', methods=['PUT'])
@login_required
def update_message_content(message_id):
    """Update an existing message (for edits)"""
    try:
        data = request.get_json()
        new_content = data.get('content')
        
        if not new_content:
            return jsonify({"error": "Content is required"}), 400
        
        # Get the message and verify ownership
        message = ChatMessage.query.filter_by(
            id=message_id
        ).join(ChatSession).filter(
            ChatSession.user_id == current_user.id
        ).first()
        
        if not message:
            return jsonify({"error": "Message not found"}), 404
        
        # Update the message
        message.content = new_content
        db.session.commit()
        
        return jsonify({
            "success": True,
            "message_id": message_id,
            "updated_content": new_content
        })
        
    except Exception as e:
        logger.error(f"Error updating message: {str(e)}")
        return jsonify({"error": "Failed to update message"}), 500

@app.route('/api/chat/messages/<message_id>/regenerate', methods=['POST'])
@login_required
def regenerate_assistant_message(message_id):
    """Regenerate an assistant message"""
    try:
        data = request.get_json()
        user_message = data.get('user_message')
        
        if not user_message:
            return jsonify({"error": "User message is required"}), 400
        
        # Get the assistant message to update
        assistant_msg = ChatMessage.query.filter_by(
            id=message_id,
            role='assistant'
        ).join(ChatSession).filter(
            ChatSession.user_id == current_user.id
        ).first()
        
        if not assistant_msg:
            return jsonify({"error": "Message not found"}), 404
        
        # Get memory manager
        session_id = assistant_msg.session_id
        if session_id not in app.memory_managers:
            memory_manager = HybridMemoryManager(buffer_limit=20, summary_threshold=0.8)
            app.memory_managers[session_id] = memory_manager
        else:
            memory_manager = app.memory_managers[session_id]
        
        # Generate new response
        ai_response = get_completion_with_memory(
            prompt=user_message,
            memory_manager=memory_manager,
            provider=data.get('provider', assistant_msg.provider),
            user_selection_model=data.get('model', assistant_msg.model),
            session_id=session_id,
            user_id=current_user.id,
            enable_web_search=data.get('enable_web_search', False),
            enable_deep_research=data.get('enable_deep_research', False),
            enable_study_learn=data.get('enable_study_learn', False)
        )
        
        if ai_response["success"]:
            # Update the existing message
            assistant_msg.content = ai_response["text"]
            assistant_msg.provider = ai_response.get("provider")
            assistant_msg.model = ai_response.get("model")
            assistant_msg.input_tokens = ai_response.get("input_tokens")
            assistant_msg.output_tokens = ai_response.get("output_tokens")
            assistant_msg.response_time = ai_response.get("elapsed_time")
            
            db.session.commit()
            
            # Return the updated message ID
            ai_response["ai_message_id"] = message_id
            ai_response["updated_existing"] = True
            
            return jsonify(ai_response)
        else:
            return jsonify(ai_response), 500
            
    except Exception as e:
        logger.error(f"Error regenerating message: {str(e)}")
        return jsonify({"error": "Failed to regenerate message"}), 500
        
# ========================================
# HELPER FUNCTIONS FOR CODE EXTRACTION
# ========================================

def extract_code_files_from_content(content):
    """Extract code files from message content"""
    code_files = {}
    
    if '=== UPLOADED FILE:' in content and '=== END FILE ===' in content:
        lines = content.split('\n')
        current_file = None
        current_content = []
        
        for line in lines:
            if line.startswith('=== UPLOADED FILE:'):
                current_file = line.replace('=== UPLOADED FILE:', '').strip()
                current_content = []
            elif line == '=== END FILE ===':
                if current_file and current_content:
                    code_files[current_file] = '\n'.join(current_content)
                current_file = None
                current_content = []
            elif current_file:
                current_content.append(line)
    
    return code_files

def prepare_files_for_ai_enhanced(uploaded_files):
    """Enhanced file processing with better code content handling"""
    processed_files = []
    
    for file_info in uploaded_files:
        try:
            file_type = file_info.get("type", "unknown")
            filepath = file_info["filepath"]
            
            if file_type == "image":
                with open(filepath, "rb") as image_file:
                    import base64
                    image_data = base64.b64encode(image_file.read()).decode('utf-8')
                
                processed_files.append({
                    "type": "image",
                    "name": file_info["filename"],
                    "data": image_data
                })
            
            elif file_type in ["document", "data", "code", "json"]:
                # Enhanced code processing
                if file_type == "code" and file_info.get("content"):
                    content = file_info["content"]
                else:
                    from integration.File_Processor import process_file_content
                    content = process_file_content(filepath, file_type)
                
                processed_files.append({
                    "type": "document",
                    "name": file_info["filename"],
                    "content": content,
                    "file_type": file_type,
                })
                
                logger.info(f"📄 Processed {file_type} file: {file_info['filename']}")
            
            elif file_type == "audio":
                with open(filepath, "rb") as audio_file:
                    import base64
                    audio_data = base64.b64encode(audio_file.read()).decode('utf-8')
                
                processed_files.append({
                    "type": "audio",
                    "name": file_info["filename"],
                    "data": audio_data
                })

        except Exception as e:
            logger.error(f"❌ Error processing file {file_info['filename']}: {str(e)}")
            processed_files.append({
                "type": "error",
                "name": file_info["filename"],
                "error": str(e)
            })

    return processed_files

# ========================================
# ENHANCED MEMORY MANAGEMENT
# ========================================

def get_session_memory_enhanced(session_id):
    """Enhanced memory loading with code context"""
    if session_id in app.memory_managers:
        return app.memory_managers[session_id]
    
    memory_manager = HybridMemoryManager(buffer_limit=20, summary_threshold=0.8)
    memory_manager.session_id = session_id
    memory_manager.history_loaded = False
    memory_manager.last_message_id = None
    memory_manager.session_code_files = {}
    
    try:
        chat_history = DatabaseService.get_chat_history_enhanced(session_id, current_user.id)
        
        for msg in chat_history:
            if msg['role'] == 'user':
                memory_manager.add_user_message(msg['content'])
                
                # Extract any code files
                if msg.get('has_uploads') and '=== UPLOADED FILE:' in msg['content']:
                    code_files = extract_code_files_from_content(msg['content'])
                    memory_manager.session_code_files.update(code_files)
                    
            elif msg['role'] == 'assistant':
                memory_manager.add_ai_message(msg['content'])
        
        memory_manager.history_loaded = True
        if chat_history:
            memory_manager.last_message_id = chat_history[-1].get('id')
            
        logger.info(f"🧠 Enhanced memory loaded: {len(chat_history)} messages, {len(memory_manager.session_code_files)} code files")
            
    except Exception as e:
        logger.error(f"Error in enhanced memory loading: {str(e)}")
    
    app.memory_managers[session_id] = memory_manager
    return memory_manager

def cleanup_session_memory_enhanced(session_id):
    """Enhanced cleanup with code context"""
    if session_id in app.memory_managers:
        try:
            del app.memory_managers[session_id]
            logger.info(f"🧹 Cleaned up enhanced memory for session: {session_id}")
        except Exception as e:
            logger.error(f"Error cleaning up enhanced memory for session {session_id}: {str(e)}")


@app.route('/api/chat/sessions', methods=['GET'])
@login_required
def get_chat_sessions_api():
    # Get user's chat sessions
    try:
        sessions = DatabaseService.get_chat_sessions(current_user.id)
        return jsonify({
            "sessions": sessions,
            "success": True
        })
    except Exception as e:
        logger.error(f"Error getting chat sessions: {str(e)}")
        return jsonify({
            "error": "Failed to get chat sessions",
            "success": False
        }), 500

@app.route('/api/chat/sessions/<session_id>', methods=['GET'])
@login_required
def get_chat_session_api(session_id):
    # Get specific chat session
    try:
        session = DatabaseService.get_chat_session(session_id, current_user.id)
        if not session:
            return jsonify({"error": "Session not found"}), 404
        
        return jsonify({
            "session": session,
            "success": True
        })
    except Exception as e:
        logger.error(f"Error getting chat session: {str(e)}")
        return jsonify({
            "error": "Failed to get chat session",
            "success": False
        }), 500

@app.route('/api/chat/sessions/<session_id>/history', methods=['GET'])
@login_required
def get_chat_history_api(session_id):
    # Get chat message history
    try:
        messages = DatabaseService.get_detailed_chat_history(session_id, current_user.id)
        return jsonify({
            "messages": messages,
            "success": True
        })
    except Exception as e:
        logger.error(f"Error getting chat history: {str(e)}")
        return jsonify({
            "error": "Failed to get chat history",
            "success": False
        }), 500

@app.route('/api/chat/sessions/<session_id>', methods=['DELETE'])
@login_required
def delete_chat_session_api(session_id):
    # Delete chat session
    try:
        success = DatabaseService.delete_chat_session(session_id, current_user.id)
        if success:
            return jsonify({"message": "Session deleted", "success": True})
        else:
            return jsonify({"error": "Session not found"}), 404
    except Exception as e:
        logger.error(f"Error deleting chat session: {str(e)}")
        return jsonify({
            "error": "Failed to delete chat session",
            "success": False
        }), 500

@app.route('/api/chat/sessions/<session_id>/rename', methods=['POST'])
@login_required
def api_rename_chat_session(session_id):
    # Rename chat session
    try:
        data = request.get_json()
        if not data or 'name' not in data:
            return jsonify({"success": False, "error": "Name is required"}), 400
            
        new_name = data['name'].strip()
        if not new_name:
            return jsonify({"success": False, "error": "Name cannot be empty"}), 400
        
        # Verify session belongs to user and update
        success = DatabaseService.update_chat_session(
            session_id, 
            current_user.id,
            name=new_name
        )
        
        if success:
            return jsonify({
                "success": True,
                "session_id": session_id,
                "name": new_name
            })
        else:
            return jsonify({"success": False, "error": "Session not found"}), 404
            
    except Exception as e:
        logger.error(f"Error renaming chat session: {str(e)}")
        return jsonify({"success": False, "error": "Failed to rename session"}), 500

@app.route('/api/chat/sessions/bulk-delete', methods=['POST'])
@login_required
def api_bulk_delete_chat_sessions():
    # Bulk delete chat sessions
    try:
        data = request.get_json()
        if not data or 'session_ids' not in data or not isinstance(data['session_ids'], list):
            return jsonify({"success": False, "error": "Session IDs array is required"}), 400
        
        session_ids = data['session_ids']
        if not session_ids:
            return jsonify({"success": False, "error": "No session IDs provided"}), 400
        
        deleted_count = DatabaseService.bulk_delete_chat_sessions(session_ids, current_user.id)
        
        return jsonify({
            "success": True, 
            "deleted_count": deleted_count,
            "message": f"Successfully deleted {deleted_count} of {len(session_ids)} sessions"
        })
        
    except Exception as e:
        logger.error(f"Error bulk deleting sessions: {str(e)}")
        return jsonify({"success": False, "error": "Failed to delete sessions"}), 500


# Add this new route for deleting all sessions
@app.route('/api/chat/sessions/delete-all', methods=['POST'])
@login_required
def api_delete_all_chat_sessions():
    """Delete all chat sessions for the current user"""
    try:
        # Get all session IDs for the current user
        sessions = DatabaseService.get_chat_sessions(current_user.id)
        
        if not sessions:
            return jsonify({
                "success": True, 
                "deleted_count": 0,
                "message": "No sessions to delete"
            })
        
        # Handle both dict and object formats
        session_ids = []
        for session in sessions:
            if hasattr(session, 'id'):
                # Object with .id attribute
                session_ids.append(session.id)
            elif isinstance(session, dict) and 'id' in session:
                # Dictionary with 'id' key
                session_ids.append(session['id'])
            else:
                logger.warning(f"Unexpected session format: {session}")
                continue
        deleted_count = DatabaseService.bulk_delete_chat_sessions(session_ids, current_user.id)
        
        return jsonify({
            "success": True, 
            "deleted_count": deleted_count,
            "sessions": [{"id": sid} for sid in session_ids],  # Return for frontend cleanup
            "message": f"Successfully deleted {deleted_count} sessions"
        })
        
    except Exception as e:
        logger.error(f"Error deleting all sessions: {str(e)}")
        return jsonify({"success": False, "error": "Failed to delete sessions"}), 500 

# =============================================
# STARRED MESSAGES API ROUTES
# =============================================

# Add this route to your app.py file, after your existing session routes

@app.route('/api/chat/sessions/<session_id>/star', methods=['POST'])
@login_required
def toggle_session_star(session_id):
    # Toggle starred status of a chat session
    try:
        # Get the session and verify it belongs to current user
        session = ChatSession.query.filter_by(
            id=session_id,
            user_id=current_user.id
        ).first()
        
        if not session:
            return jsonify({
                "success": False,
                "error": "Session not found or access denied"
            }), 404
        
        # Toggle the starred status
        session.is_starred = not session.is_starred
        db.session.commit()
        
        logger.info(f"Toggled star for session {session_id}: {session.is_starred}")
        
        return jsonify({
            "success": True,
            "is_starred": session.is_starred,
            "session_id": session_id
        })
        
    except Exception as e:
        db.session.rollback()
        logger.error(f"Error toggling session star: {str(e)}")
        return jsonify({
            "success": False,
            "error": "Failed to toggle star status"
        }), 500
        
@app.route('/api/chat/messages/starred', methods=['GET'])
@login_required
def get_starred_messages():
    # Get all starred messages for current user
    try:
        limit = request.args.get('limit', 50, type=int)
        starred_messages = DatabaseService.get_starred_messages(current_user.id, limit)
        starred_count = DatabaseService.get_starred_messages_count(current_user.id)
        
        return jsonify({
            "success": True,
            "starred_messages": starred_messages,
            "total_count": starred_count,
            "returned_count": len(starred_messages)
        })
        
    except Exception as e:
        logger.error(f"Error getting starred messages: {str(e)}")
        return jsonify({
            "success": False,
            "error": "Failed to get starred messages"
        }), 500

#  ================================
# Feedback API Route
# ================================

@app.route('/api/chat/feedback', methods=['POST'])
@login_required
def api_submit_feedback():
    """Submit feedback for AI response"""
    try:
        data = request.get_json()
        if not data:
            return jsonify({"error": "No data provided"}), 400
        
        message_id = data.get('message_id')
        feedback = data.get('feedback')  # 'Good Response' or 'Bad Response'
        session_id = data.get('session_id')
        comment = data.get('comment', '')  # Optional detailed feedback
        
        # Validate required fields
        if not message_id or not feedback:
            return jsonify({"error": "message_id and feedback are required"}), 400
        
        # Validate feedback value
        if feedback not in ['Good Response', 'Bad Response']:
            return jsonify({"error": "feedback must be 'Good Response' or 'Bad Response'"}), 400
        
        # Find the message
        message = ChatMessage.query.filter_by(
            id=message_id,
            session_id=session_id
        ).first()
        
        if not message:
            return jsonify({"error": "Message not found"}), 404
        
        # Verify message belongs to current user's session
        chat_session = ChatSession.query.filter_by(
            id=session_id,
            user_id=current_user.id
        ).first()
        
        if not chat_session:
            return jsonify({"error": "Session not found or access denied"}), 403
        
        # Only allow feedback on AI responses
        if message.role != 'assistant':
            return jsonify({"error": "Feedback can only be submitted for AI responses"}), 400
        
        # Update message with feedback
        message.user_feedback = feedback
        message.feedback_timestamp = datetime.utcnow()
        message.feedback_comment = comment if comment else None
        
        # Save to database
        try:
            db.session.commit()
            logger.info(f"✅ Feedback saved: {feedback} for message {message_id}")
            
            return jsonify({
                "success": True,
                "message": "Feedback submitted successfully",
                "feedback": {
                    "message_id": message_id,
                    "feedback": feedback,
                    "timestamp": message.feedback_timestamp.isoformat(),
                    "comment": comment
                }
            })
            
        except Exception as db_error:
            db.session.rollback()
            logger.error(f"❌ Database error saving feedback: {str(db_error)}")
            return jsonify({"error": "Failed to save feedback"}), 500
        
    except Exception as e:
        logger.error(f"❌ Error in feedback API: {str(e)}")
        return jsonify({"error": "Internal server error"}), 500

# =============================================
# USER AND ANALYTICS API ROUTES
# =============================================

@app.route('/api/user/stats', methods=['GET'])
@login_required
def get_user_stats_api():
    # Get user usage statistics
    try:
        days = request.args.get('days', 30, type=int)
        stats = DatabaseService.get_user_stats(current_user.id, days)
        return jsonify({
            "stats": stats,
            "success": True
        })
    except Exception as e:
        logger.error(f"Error getting user stats: {str(e)}")
        return jsonify({
            "error": "Failed to get user stats",
            "success": False
        }), 500

@app.route('/api/user/profile', methods=['GET'])
@login_required
def get_user_profile_api():
    # Get user profile information
    try:
        return jsonify({
            "user": current_user.to_dict(),
            "success": True
        })
    except Exception as e:
        logger.error(f"Error getting user profile: {str(e)}")
        return jsonify({
            "error": "Failed to get user profile",
            "success": False
        }), 500

@app.route('/api/user/search', methods=['GET'])
@login_required
def search_user_messages_api():
    # Search through user's messages
    try:
        query_text = request.args.get('q')
        provider = request.args.get('provider')
        limit = request.args.get('limit', 50, type=int)
        
        messages = DatabaseService.search_messages(
            user_id=current_user.id,
            query_text=query_text,
            provider=provider,
            limit=limit
        )
        
        return jsonify({
            "messages": messages,
            "query": query_text,
            "success": True
        })
        
    except Exception as e:
        logger.error(f"Error searching messages: {str(e)}")
        return jsonify({
            "error": "Failed to search messages",
            "success": False
        }), 500

@app.route('/api/user/export', methods=['GET'])
@login_required
def export_user_data_api():
    # Export user data for GDPR compliance
    try:
        export_data = DatabaseService.export_user_data(current_user.id)
        if export_data:
            return jsonify({
                "data": export_data,
                "success": True
            })
        else:
            return jsonify({
                "error": "Failed to export user data",
                "success": False
            }), 500
            
    except Exception as e:
        logger.error(f"Error exporting user data: {str(e)}")
        return jsonify({
            "error": "Failed to export user data",
            "success": False
        }), 500

# =============================================
# PROJECT MANAGEMENT API ROUTES
# =============================================

@app.route('/api/upload/validate', methods=['POST'])
@login_required
def validate_upload():
    # Validate uploaded files before processing
    if not request.files:
        return jsonify({"error": "No files provided"}), 400
    
    files = request.files.getlist('files')
    validation_results = []
    
    for file in files:
        is_valid = validate_file_type(file.filename) if file.filename else False
        validation_results.append({
            "filename": file.filename,
            "valid": is_valid,
            "type": determine_file_type(file.filename) if is_valid else "unsupported"
        })
    
    return jsonify({"files": validation_results})

# =============================================
# PAYMENT GETWAY ROUTES
# =============================================

@app.route('/api/payment/config', methods=['GET'])
@login_required
def get_payment_config():
    """Get payment gateway configuration"""
    try:
        return jsonify({
            "success": True,
            "razorpay_key_id": RAZORPAY_KEY_ID,
            "currency": "USD"  # or "INR" based on your plans
        })
    except Exception as e:
        logger.error(f"❌ Error getting payment config: {str(e)}")
        return jsonify({
            "success": False,
            "error": "Payment gateway configuration error"
        }), 500

@app.route('/api/payment/create-order', methods=['POST'])
@login_required
def create_payment_order():
    """Create Razorpay order for plan purchase"""
    try:
        data = request.get_json()
        plan_type = data.get('plan_type')
        currency = data.get('currency', 'USD')
        
        # Define plan prices
        plan_prices = {
            '12_day_basic': 800,   # $8 = 800 cents
            '24_day_basic': 1500,  # $15 = 1500 cents  
            '1_month_pro': 2000,   # $20 = 2000 cents
            '2_month_pro': 3800    # $38 = 3800 cents
        }
        
        if plan_type not in plan_prices:
            return jsonify({
                "success": False,
                "error": "Invalid plan type"
            }), 400
            
        amount = plan_prices[plan_type]
        
        # Create Razorpay order
        order_data = {
            "amount": amount,
            "currency": currency,
            "receipt": f"{plan_type}_{current_user.id}"[:40]
        }
        
        razor_order = razorpay_client.order.create(data=order_data)
        
        # Format plan name for display
        plan_names = {
            '12_day_basic': '12-Day Power Pack',
            '24_day_basic': '24-Day Pro Pack',
            '1_month_pro': '1-Month Power Pack', 
            '2_month_pro': '2-Month Pro Pack'
        }
        
        return jsonify({
            "success": True,
            "order_id": razor_order['id'],
            "amount": amount,
            "currency": currency,
            "plan_name": plan_names.get(plan_type, plan_type)
        })
        
    except Exception as e:
        logger.error(f"❌ Error creating payment order: {str(e)}")
        return jsonify({
            "success": False,
            "error": "Failed to create payment order"
        }), 500

@app.route('/api/payment/verify', methods=['POST'])
@login_required  
def verify_payment():
    try:
        data = request.get_json()
        payment_id = data.get('razorpay_payment_id')
        order_id = data.get('razorpay_order_id')
        signature = data.get('razorpay_signature')
        plan_type = data.get('plan_type')
        amount_paid = data.get('amount_paid')
        
        # Verify payment signature
        razorpay_client.utility.verify_payment_signature({
            "razorpay_payment_id": payment_id,
            "razorpay_order_id": order_id,
            "razorpay_signature": signature
        })
        
        # ✅ Actually activate the plan
        activated_plan = PlanManager.activate_plan(
            user_id=current_user.id,
            plan_type=plan_type,
            payment_id=payment_id,
            amount_paid=amount_paid/100
        )
        
        return jsonify({
            "success": True,
            "message": "Payment verified and plan activated successfully",
            "plan_type": plan_type,
            "plan_activated": True,      # ← ADD THIS
            "plan_details": activated_plan  # ← ADD THIS
        })
        
    except Exception as e:
        logger.error(f"❌ Error verifying payment: {str(e)}")
        return jsonify({
            "success": False,
            "error": "Payment verification error"
        }), 500

# =============================================
# SETTINGS PAGE ROUTES
# =============================================

@app.route('/settings')
@login_required
def settings():
    """Settings page"""
    return render_template('settings.html', user=current_user)

@app.route('/plans')
@login_required
def plans():
    """Settings page"""
    return render_template('plans.html', user=current_user)

@app.route('/api/user/profile', methods=['GET'])
@login_required
def get_user_profile():
    """Get current user profile information"""
    try:
        user_data = {
            'id': current_user.id,
            'username': current_user.username,
            'fullname': current_user.fullname,
            'email': current_user.email,
            'created_at': current_user.created_at.isoformat() if current_user.created_at else None,
            'last_login': current_user.last_login.isoformat() if current_user.last_login else None,
            'is_active': current_user.is_active
        }
        
        return jsonify({
            "success": True,
            "user": user_data
        })
        
    except Exception as e:
        logger.error(f"❌ Error getting user profile: {str(e)}")
        return jsonify({
            "success": False,
            "error": "Failed to retrieve user profile"
        }), 500 
              
@app.route('/api/user/settings', methods=['GET'])
@login_required
def get_user_settings():
    """Get user preferences and settings"""
    try:
        # For now, return default settings
        # TODO: Store user settings in database
        settings = {
            'theme': 'dark',
            'default_provider': 'groq',
            'default_model': 'auto',
            'auto_save_chats': True,
            'remember_context': True,
            'analytics_opt_out': False,
            'language': 'en'
        }
        
        return jsonify({
            "success": True,
            "settings": settings
        })
        
    except Exception as e:
        logger.error(f"❌ Error getting user settings: {str(e)}")
        return jsonify({
            "success": False,
            "error": "Failed to retrieve user settings"
        }), 500

@app.route('/api/user/settings', methods=['POST'])
@login_required
def update_user_settings():
    """Update user preferences and settings"""
    try:
        data = request.get_json()
        if not data:
            return jsonify({"error": "No data provided"}), 400
        
        # TODO: Store settings in database
        # For now, just validate and return success
        valid_settings = ['theme', 'default_provider', 'default_model', 
                         'auto_save_chats', 'remember_context', 'analytics_opt_out', 'language']
        
        updated_settings = {}
        for key, value in data.items():
            if key in valid_settings:
                updated_settings[key] = value
        
        logger.info(f"Updated settings for user {current_user.id}: {updated_settings}")
        
        return jsonify({
            "success": True,
            "message": "Settings updated successfully",
            "updated_settings": updated_settings
        })
        
    except Exception as e:
        logger.error(f"❌ Error updating user settings: {str(e)}")
        return jsonify({
            "success": False,
            "error": "Failed to update settings"
        }), 500

@app.route('/api/user/billing', methods=['GET'])
@login_required
def get_billing_info():
    """Get user billing information and payment history"""
    try:
        # Get user's payment history from plans
        from database.model import UserPlan
        
        user_plans = UserPlan.query.filter_by(user_id=current_user.id)\
                                  .order_by(UserPlan.created_at.desc())\
                                  .limit(10).all()
        
        total_spent = sum(plan.amount_paid for plan in user_plans)
        
        # Get current month spending
        current_month_start = datetime.now().replace(day=1, hour=0, minute=0, second=0, microsecond=0)
        current_month_plans = UserPlan.query.filter_by(user_id=current_user.id)\
                                           .filter(UserPlan.created_at >= current_month_start)\
                                           .all()
        current_month_spent = sum(plan.amount_paid for plan in current_month_plans)
        
        # Get next billing date (from active plan)
        active_plan = PlanManager.get_current_user_plan(current_user.id)
        next_billing = "No active subscription"
        if active_plan and active_plan['plan_type'] != 'free':
            expires_at = datetime.fromisoformat(active_plan['expires_at'].replace('Z', '+00:00')).replace(tzinfo=None)
            next_billing = expires_at.strftime('%b %d, %Y')
        
        # Format payment history
        payment_history = []
        for plan in user_plans:
            if plan.amount_paid > 0:  # Only include paid plans
                payment_history.append({
                    'date': plan.created_at.strftime('%Y-%m-%d'),
                    'amount': plan.amount_paid,
                    'plan': PlanManager.format_plan_name(plan.plan_type),
                    'payment_id': plan.payment_id
                })
        
        return jsonify({
            "success": True,
            "billing": {
                "total_spent": total_spent,
                "current_month_spent": current_month_spent,
                "next_billing": next_billing,
                "payment_history": payment_history
            }
        })
        
    except Exception as e:
        logger.error(f"❌ Error getting billing info: {str(e)}")
        return jsonify({
            "success": False,
            "error": "Failed to retrieve billing information"
        }), 500

@app.route('/api/user/export', methods=['GET'])
@login_required
def export_user_data():
    """Export user data for GDPR compliance"""
    try:
        # Use existing export functionality from DatabaseService
        exported_data = DatabaseService.export_user_data(current_user.id, format='dict')
        
        if not exported_data:
            return jsonify({
                "success": False,
                "error": "Failed to export user data"
            }), 500
        
        # Create response with proper headers for download
        response = jsonify(exported_data)
        response.headers['Content-Disposition'] = f'attachment; filename=user_data_{current_user.id}.json'
        response.headers['Content-Type'] = 'application/json'
        
        return response
        
    except Exception as e:
        logger.error(f"❌ Error exporting user data: {str(e)}")
        return jsonify({
            "success": False,
            "error": "Failed to export user data"
        }), 500

@app.route('/api/user/delete', methods=['DELETE'])
@login_required
def delete_user_account():
    """Delete user account (DANGEROUS - implement with caution)"""
    try:
        data = request.get_json()
        if not data or data.get('confirmation') != 'DELETE':
            return jsonify({
                "success": False,
                "error": "Invalid confirmation"
            }), 400
        
        # TODO: Implement account deletion with proper safeguards
        # This should:
        # 1. Cancel active subscriptions
        # 2. Delete all user data (chats, sessions, etc.)
        # 3. Mark user as deleted (soft delete) or hard delete
        # 4. Send confirmation email
        # 5. Log the deletion for audit
        
        logger.warning(f"⚠️ Account deletion requested for user {current_user.id}")
        
        # For now, just return a message
        return jsonify({
            "success": False,
            "error": "Account deletion is not yet implemented for safety reasons"
        }), 501  # Not implemented
        
    except Exception as e:
        logger.error(f"❌ Error deleting user account: {str(e)}")
        return jsonify({
            "success": False,
            "error": "Failed to delete account"
        }), 500

@app.route('/api/support/contact', methods=['POST'])
@login_required
def submit_support_request():
    """Submit a support request"""
    try:
        data = request.get_json()
        if not data:
            return jsonify({"error": "No data provided"}), 400
        
        subject = data.get('subject', '')
        message = data.get('message', '')
        category = data.get('category', 'general')
        
        if not subject or not message:
            return jsonify({
                "success": False,
                "error": "Subject and message are required"
            }), 400
        
        # TODO: Implement actual support ticket creation
        # This could:
        # 1. Store in database
        # 2. Send email to support team
        # 3. Integrate with support system (Intercom, Zendesk, etc.)
        
        logger.info(f"Support request from user {current_user.id}: {subject}")
        
        return jsonify({
            "success": True,
            "message": "Support request submitted successfully",
            "ticket_id": f"TICKET-{int(time.time())}"
        })
        
    except Exception as e:
        logger.error(f"❌ Error submitting support request: {str(e)}")
        return jsonify({
            "success": False,
            "error": "Failed to submit support request"
        }), 500

@app.route('/api/models/available', methods=['GET'])
@login_required
def get_available_models():
    """Get available models based on user's plan"""
    try:
        # Get user's current plan to determine model access
        plan_status = PlanManager.get_plan_usage_status(current_user.id)
        can_use_premium = plan_status.get('limits', {}).get('can_use_premium', False) if plan_status.get('has_plan') else False
        
        # Your existing MODEL_CATALOG
        MODEL_CATALOG = {
            "google": {
                "standard": ["models/gemini-2.0-flash"],
                "premium": ["models/gemini-2.5-flash", "models/gemini-2.0-flash-thinking-exp"]
            },
            "openai": {
                "standard": ["gpt-4o-mini", "gpt-3.5-turbo"],
                "premium": ["o3", "gpt-4o", "gpt-4-turbo"]
            },
            "anthropic": {
                "standard": ["claude-3-5-haiku-20241022"],
                "premium": ["claude-opus-4-20250514", "claude-sonnet-4-20250514", "claude-3-5-sonnet-20241022"]
            },
            "groq": {
                "standard": ["llama-3.1-8b-instant", "meta-llama/llama-4-scout-17b-16e-instruct"],
                "premium": ["meta-llama/llama-4-maverick-17b-128e-instruct", "llama-3.3-70b-versatile"]
            }
        }
        
        # Filter models based on plan
        available_models = {}
        for provider, tiers in MODEL_CATALOG.items():
            available_models[provider] = {
                "standard": tiers.get("standard", []),
                "premium": tiers.get("premium", []) if can_use_premium else []
            }
        
        return jsonify({
            "success": True,
            "models": available_models,
            "can_use_premium": can_use_premium,
            "plan_type": plan_status.get('plan', {}).get('plan_type') if plan_status.get('has_plan') else 'free'
        })
        
    except Exception as e:
        logger.error(f"❌ Error getting available models: {str(e)}")
        return jsonify({
            "success": False,
            "error": "Failed to retrieve available models"
        }), 500

# =============================================
# ADMIN ANALYTICS API ENDPOINT  
# =============================================

@app.route('/api/admin/analytics', methods=['GET'])
@login_required
def get_admin_analytics():
    """Get comprehensive admin analytics dashboard data"""
    try:
        
        
        # Basic overview metrics
        analytics_data = {
            "totalUsers": AnalyticsService.get_total_users(),
            "monthlyRevenue": AnalyticsService.get_monthly_revenue(),
            "activeUsers": AnalyticsService.get_active_users_24h(),
            "conversionRate": AnalyticsService.get_conversion_rate(),
            
            # Chart data
            "userGrowth": AnalyticsService.get_user_growth_data(30),
            "usersByPlan": AnalyticsService.get_users_by_plan(),
            "revenueHistory": AnalyticsService.get_revenue_trends(30),
            
            # Provider usage
            "providerUsage": AnalyticsService.get_provider_detailed_stats(30),
            
            # Additional metrics
            "businessMetrics": {
                "arpu": AnalyticsService.get_average_revenue_per_user(),
                "ltv": AnalyticsService.get_lifetime_value(),
                "churnRate": AnalyticsService.get_churn_rate()
            }
        }
        
        logger.info("✅ Admin analytics data retrieved successfully")
        
        return jsonify({
            "success": True,
            "analytics": analytics_data
        })
        
    except Exception as e:
        logger.error(f"❌ Error getting admin analytics: {str(e)}")
        return jsonify({
            "success": False,
            "error": "Failed to retrieve analytics data",
            "analytics": {
                "totalUsers": 0,
                "monthlyRevenue": 0,
                "activeUsers": 0,
                "conversionRate": 0,
                "userGrowth": [],
                "usersByPlan": [],
                "providerUsage": {
                    "openai": {"requests": 0, "cost": 0, "avg_response": 0},
                    "anthropic": {"requests": 0, "cost": 0, "avg_response": 0},
                    "google": {"requests": 0, "cost": 0, "avg_response": 0},
                    "groq": {"requests": 0, "cost": 0, "avg_response": 0}
                }
            }
        }), 500

# =============================================
# 3. USAGE OVERVIEW API ENDPOINT
# =============================================

@app.route('/api/usage/overview', methods=['GET'])
@login_required
def get_usage_overview():
    """Get user usage overview for settings dashboard"""
    try:
        days = request.args.get('days', 30, type=int)
        
        # Get current plan status
        plan_status = PlanManager.get_plan_usage_status(current_user.id)
        
        if not plan_status.get('has_plan'):
            return jsonify({
                "success": True,
                "usage": {
                    "usage_percentage": 0,
                    "days_remaining": 0,
                    "provider_breakdown": [],
                    "daily_usage": [],
                    "high_cost_provider": False,
                    "recommended_provider": "groq"
                }
            })
        
        plan = plan_status['plan']
        usage_percentage = plan_status['usage']['message_percent']
        days_remaining = plan_status['usage']['days_remaining']
        
        # Get provider usage breakdown
        from database.analytics_service import AnalyticsService
        from database.model import DailyUsageSummary
        from datetime import datetime, timedelta
        
        # Get daily usage for trend chart
        start_date = datetime.now().date() - timedelta(days=days)
        daily_usage_query = DailyUsageSummary.query.filter(
            DailyUsageSummary.user_id == current_user.id,
            DailyUsageSummary.date >= start_date
        ).order_by(DailyUsageSummary.date).all()
        
        daily_usage = [
            {
                "date": usage.date.isoformat(),
                "messages": usage.messages_sent
            }
            for usage in daily_usage_query
        ]
        
        # Get provider breakdown
        provider_breakdown = []
        if daily_usage_query:
            total_messages = sum([u.messages_sent for u in daily_usage_query])
            if total_messages > 0:
                openai_pct = sum([u.openai_messages or 0 for u in daily_usage_query]) / total_messages * 100
                google_pct = sum([u.google_messages or 0 for u in daily_usage_query]) / total_messages * 100
                anthropic_pct = sum([u.anthropic_messages or 0 for u in daily_usage_query]) / total_messages * 100
                groq_pct = sum([u.groq_messages or 0 for u in daily_usage_query]) / total_messages * 100
                
                if openai_pct > 0:
                    provider_breakdown.append({"name": "OpenAI", "percentage": round(openai_pct, 1)})
                if google_pct > 0:
                    provider_breakdown.append({"name": "Google", "percentage": round(google_pct, 1)})
                if anthropic_pct > 0:
                    provider_breakdown.append({"name": "Anthropic", "percentage": round(anthropic_pct, 1)})
                if groq_pct > 0:
                    provider_breakdown.append({"name": "Groq", "percentage": round(groq_pct, 1)})
        
        # Default provider breakdown if no data
        if not provider_breakdown:
            provider_breakdown = [
                {"name": "Groq", "percentage": 45},
                {"name": "Google", "percentage": 25},
                {"name": "OpenAI", "percentage": 20},
                {"name": "Anthropic", "percentage": 10}
            ]
        
        return jsonify({
            "success": True,
            "usage": {
                "usage_percentage": usage_percentage,
                "days_remaining": days_remaining,
                "provider_breakdown": provider_breakdown,
                "daily_usage": daily_usage,
                "high_cost_provider": usage_percentage > 70,
                "recommended_provider": "groq"
            }
        })
        
    except Exception as e:
        logger.error(f"❌ Error getting usage overview: {str(e)}")
        return jsonify({
            "success": False,
            "error": "Failed to retrieve usage overview"
        }), 500

# =============================================
# MAIN APPLICATION ENTRY POINT
# =============================================

if __name__ == "__main__":
    app.run(host="0.0.0.0",debug=True)