import os
from pathlib import Path

# Get the directory where config.py is located (project root)
BASE_PATH = Path(__file__).parent.absolute()



# Create dynamic paths for uploads and prompts
UPLOAD_FOLDER = os.path.join(BASE_PATH, 'uploads')
PROMPTS_FOLDER = os.path.join(BASE_PATH, 'prompts')


print("Upload folder path:", UPLOAD_FOLDER)
print("Prompt directory path:", PROMPTS_FOLDER)

# Subdirectory names
prompt_dir = 'prompts'
upload_dir = 'uploads'

# Ensure directories exist
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(PROMPTS_FOLDER, exist_ok=True)





# Configuration settings
MAX_UPLOAD_SIZE = 16 * 1024 * 1024  # 16MB max file size
ALLOWED_EXTENSIONS = {
    'txt', 'pdf', 'docx', 'xlsx', 'csv', 'json', 
    'py', 'js', 'html', 'css', 'jpg', 'jpeg', 
    'png', 'gif', 'bmp', 'webp', 'mp3', 'wav', 
    'm4a', 'ogg'
}

# Database configuration
DATABASE_CONFIG = {
    'SQLALCHEMY_TRACK_MODIFICATIONS': False,
    'SQLALCHEMY_ENGINE_OPTIONS': {
        'pool_recycle': 300,
        'pool_pre_ping': True,
    }
}

# Application settings
APP_CONFIG = {
    'SECRET_KEY': os.getenv('SECRET_KEY', 'dev-secret-key-change-in-production'),
    'COMPANY_NAME': os.getenv('COMPANY_NAME', 'AI Assistant Platform'),
    'COMPANY_ACCESS_CODE': os.getenv('COMPANY_ACCESS_CODE', 'demo_access_2024'),
    'DEBUG': os.getenv('FLASK_DEBUG', 'False').lower() == 'true',
    'HOST': os.getenv('FLASK_HOST', '0.0.0.0'),
    'PORT': int(os.getenv('FLASK_PORT', '8000'))
}

# Logging configuration
LOGGING_CONFIG = {
    'LOG_LEVEL': os.getenv('LOG_LEVEL', 'INFO'),
    'LOG_FILE': os.path.join(BASE_PATH, 'logs', 'app.log'),
    'LOG_MAX_BYTES': 10 * 1024 * 1024,  # 10MB
    'LOG_BACKUP_COUNT': 5
}

# Create logs directory
os.makedirs(os.path.dirname(LOGGING_CONFIG['LOG_FILE']), exist_ok=True)

# Print configuration for debugging
if __name__ == "__main__":
    print("Configuration Summary:")
    print(f"BASE_PATH: {BASE_PATH}")
    print(f"UPLOAD_FOLDER: {UPLOAD_FOLDER}")
    print(f"PROMPTS_FOLDER: {PROMPTS_FOLDER}")
    print(f"Upload folder exists: {os.path.exists(UPLOAD_FOLDER)}")
    print(f"Prompts folder exists: {os.path.exists(PROMPTS_FOLDER)}")
    
    # List contents
    if os.path.exists(PROMPTS_FOLDER):
        prompts = os.listdir(PROMPTS_FOLDER)
        print(f"Prompt files: {prompts}")
    
    if os.path.exists(UPLOAD_FOLDER):
        uploads = os.listdir(UPLOAD_FOLDER)
        print(f"Upload files: {uploads[:5]}...")  # Show first 5 files
