# services/plan_manager.py - REPLACE ENTIRE FILE WITH THIS:

from datetime import datetime, timedelta
import logging
from flask_login import current_user
from sqlalchemy import func, desc

logger = logging.getLogger(__name__)

class PlanManager:
    """Centralized plan management and enforcement"""
    
    # =============================================
    # PLAN MANAGEMENT
    # =============================================
    
    @staticmethod
    def get_current_user_plan(user_id=None):
        """Get user's current active plan"""
        try:
            # Import inside function to avoid circular import
            from database.model import UserPlan
            
            if user_id is None and current_user.is_authenticated:
                user_id = current_user.id
            
            if not user_id:
                return None
            
            # Get active plan that hasn't expired
            plan = UserPlan.query.filter_by(
                user_id=user_id,
                is_active=True
            ).filter(
                UserPlan.expires_at > datetime.utcnow()
            ).order_by(desc(UserPlan.created_at)).first()
            
            return plan.to_dict() if plan else None
            
        except Exception as e:
            logger.error(f"Error getting user plan: {str(e)}")
            return None
    
    @staticmethod
    def create_user_plan(user_id, plan_type, payment_id=None, amount_paid=0):
        """Create new user plan"""
        try:
            from database.model import db, UserPlan, PlanTemplate
            
            # Get plan template
            template = PlanTemplate.query.filter_by(plan_type=plan_type, is_active=True).first()
            if not template:
                raise ValueError(f"Plan template {plan_type} not found")
            
            # Calculate expiry date
            expires_at = datetime.utcnow() + timedelta(days=template.validity_days)
            
            # Deactivate existing plans for this user
            UserPlan.query.filter_by(user_id=user_id, is_active=True).update(
                {'is_active': False}, synchronize_session=False
            )
            
            # Create new plan
            plan = UserPlan(
                user_id=user_id,
                plan_type=plan_type,
                total_messages=template.total_messages,
                total_web_searches=template.total_web_searches,
                expires_at=expires_at,
                payment_id=payment_id,
                amount_paid=amount_paid,
                max_input_tokens=template.max_input_tokens,
                can_use_premium_models=template.can_use_premium_models,
                can_upload_files=template.can_upload_files,
                daily_message_limit=template.daily_message_limit
            )
            
            db.session.add(plan)
            db.session.commit()
            
            logger.info(f"Created plan {plan_type} for user {user_id}")
            return plan.to_dict()
            
        except Exception as e:
            from database.model import db
            db.session.rollback()
            logger.error(f"Error creating user plan: {str(e)}")
            raise
    
    @staticmethod
    def check_user_limits(user_id=None, action_type='message'):
        """Check if user can perform action based on their plan"""
        try:
            if user_id is None and current_user.is_authenticated:
                user_id = current_user.id
            
            if not user_id:
                return {"allowed": False, "reason": "User not authenticated"}
            
            # Get current plan
            plan = PlanManager.get_current_user_plan(user_id)
            
            # If no plan, create free plan
            if not plan:
                PlanManager.create_free_plan(user_id)
                plan = PlanManager.get_current_user_plan(user_id)
            
            if not plan:
                return {"allowed": False, "reason": "Unable to create free plan"}
            
            # Check if plan is expired
            if datetime.fromisoformat(plan['expires_at'].replace('Z', '+00:00')).replace(tzinfo=None) <= datetime.utcnow():
                return {"allowed": False, "reason": "Plan expired", "upgrade_suggestion": "12_day"}
            
            # Check specific limits based on action
            if action_type == 'message':
                if plan['messages_used'] >= plan['total_messages']:
                    return {"allowed": False, "reason": "Message limit reached", "upgrade_suggestion": "12_day"}
                
                # Check daily limit for free plans
                if plan['daily_message_limit']:
                    daily_usage = PlanManager.get_daily_usage(user_id)
                    if daily_usage['messages_sent'] >= plan['daily_message_limit']:
                        return {"allowed": False, "reason": "Daily message limit reached", "reset_time": "24 hours"}
            
            elif action_type == 'web_search':
                if plan['web_searches_used'] >= plan['total_web_searches']:
                    return {"allowed": False, "reason": "Web search limit reached", "upgrade_suggestion": "12_day"}
            
            return {"allowed": True, "plan": plan}
            
        except Exception as e:
            logger.error(f"Error checking user limits: {str(e)}")
            return {"allowed": False, "reason": "System error"}
    
    @staticmethod
    def create_free_plan(user_id):
        """Create free plan for new users"""
        try:
            from database.model import db, UserPlan
            
            # Check if user already has a free plan today
            existing_plan = UserPlan.query.filter_by(
                user_id=user_id,
                plan_type='free',
                is_active=True
            ).filter(
                UserPlan.expires_at > datetime.utcnow()
            ).first()
            
            if existing_plan:
                return existing_plan.to_dict()
            
            # Create 24-hour free plan
            expires_at = datetime.utcnow() + timedelta(days=1)
            
            plan = UserPlan(
                user_id=user_id,
                plan_type='free',
                total_messages=200,  # 10 messages per day
                messages_used=0,
                total_web_searches=50,  # 3 web searches per day
                web_searches_used=0,
                expires_at=expires_at,
                amount_paid=0.0,
                max_input_tokens=4000,
                can_use_premium_models=False,
                can_upload_files=True,
                daily_message_limit=50
            )
            
            db.session.add(plan)
            db.session.commit()
            
            logger.info(f"Created free plan for user {user_id}")
            return plan.to_dict()
            
        except Exception as e:
            from database.model import db
            db.session.rollback()
            logger.error(f"Error creating free plan: {str(e)}")
            raise
    
    @staticmethod
    def update_plan_usage(user_id, action_type='message', tokens_used=0, web_search=False):
        """Update plan usage counters"""
        try:
            from database.model import db, UserPlan
            
            plan = UserPlan.query.filter_by(
                user_id=user_id,
                is_active=True
            ).filter(
                UserPlan.expires_at > datetime.utcnow()
            ).first()
            
            if not plan:
                return False
            
            # Update plan counters
            if action_type == 'message':
                plan.messages_used += 1
            
            if web_search:
                plan.web_searches_used += 1
            
            plan.updated_at = datetime.utcnow()
            
            # Also update daily usage
            PlanManager.update_daily_usage(user_id, action_type, tokens_used, web_search)
            
            db.session.commit()
            return True
            
        except Exception as e:
            from database.model import db
            db.session.rollback()
            logger.error(f"Error updating plan usage: {str(e)}")
            return False
    
    # =============================================
    # USAGE TRACKING
    # =============================================
    
    @staticmethod
    def track_usage(user_id, action_type, provider=None, model=None, 
                   input_tokens=0, output_tokens=0, estimated_cost=0,
                   session_id=None, message_id=None, response_time_ms=None,
                   has_web_search=False, has_file_upload=False):
        """Track detailed usage for analytics and billing"""
        try:
            from database.model import db, UsageTracking
            
            # Determine model tier
            model_tier = 'standard'
            if model and PlanManager.is_premium_model(provider, model):
                model_tier = 'premium'
            
            usage = UsageTracking(
                user_id=user_id,
                session_id=session_id,
                message_id=message_id,
                action_type=action_type,
                provider=provider,
                model=model,
                model_tier=model_tier,
                input_tokens=input_tokens,
                output_tokens=output_tokens,
                total_tokens=input_tokens + output_tokens,
                estimated_cost_usd=estimated_cost,
                has_web_search=has_web_search,
                has_file_upload=has_file_upload,
                response_time_ms=response_time_ms
            )
            
            db.session.add(usage)
            db.session.commit()
            
            return usage.id
            
        except Exception as e:
            from database.model import db
            db.session.rollback()
            logger.error(f"Error tracking usage: {str(e)}")
            return None
    
    @staticmethod
    def get_daily_usage(user_id, date=None):
        """Get daily usage summary for a user"""
        try:
            from database.model import DailyUsageSummary
            
            if date is None:
                date = datetime.utcnow().date()
            
            usage = DailyUsageSummary.query.filter_by(
                user_id=user_id,
                date=date
            ).first()
            
            if usage:
                return usage.to_dict()
            else:
                # Return empty usage
                return {
                    'user_id': user_id,
                    'date': date.isoformat(),
                    'messages_sent': 0,
                    'web_searches_made': 0,
                    'files_uploaded': 0,
                    'total_tokens': 0,
                    'estimated_cost_usd': 0.0
                }
                
        except Exception as e:
            logger.error(f"Error getting daily usage: {str(e)}")
            return {}
    
    @staticmethod
    def update_daily_usage(user_id, action_type='message', tokens_used=0, web_search=False, file_upload=False, provider=None):
        """Update daily usage summary"""
        try:
            from database.model import db, DailyUsageSummary
            
            today = datetime.utcnow().date()
            
            # Get or create daily usage record
            usage = DailyUsageSummary.query.filter_by(
                user_id=user_id,
                date=today
            ).first()
            
            if not usage:
                usage = DailyUsageSummary(
                    user_id=user_id,
                    date=today,
                    messages_sent=0,
                    web_searches_made=0,
                    files_uploaded=0,
                    total_tokens=0,
                    estimated_cost_usd=0.0,
                    openai_messages=0,
                    google_messages=0,
                    anthropic_messages=0,
                    groq_messages=0
                )
                db.session.add(usage)
            
            # FIXED: Handle None values safely
            if action_type == 'message':
                usage.messages_sent = (usage.messages_sent or 0) + 1
                usage.total_tokens = (usage.total_tokens or 0) + tokens_used
                
                # Update provider-specific counters safely
                if provider == 'openai':
                    usage.openai_messages = (usage.openai_messages or 0) + 1
                elif provider == 'google':
                    usage.google_messages = (usage.google_messages or 0) + 1
                elif provider == 'anthropic':
                    usage.anthropic_messages = (usage.anthropic_messages or 0) + 1
                elif provider == 'groq':
                    usage.groq_messages = (usage.groq_messages or 0) + 1
            
            if web_search:
                usage.web_searches_made = (usage.web_searches_made or 0) + 1
            
            if file_upload:
                usage.files_uploaded = (usage.files_uploaded or 0) + 1
            
            usage.updated_at = datetime.utcnow()
            db.session.commit()
            
            return True
            
        except Exception as e:
            from database.model import db
            db.session.rollback()
            logger.error(f"Error updating daily usage: {str(e)}")
            return False
    # =============================================
    # PLAN TEMPLATES
    # =============================================
    
    @staticmethod
    def get_all_plan_templates():
        """Get all available plan templates"""
        try:
            from database.model import PlanTemplate
            
            templates = PlanTemplate.query.filter_by(is_active=True)\
                                        .order_by(PlanTemplate.display_order)\
                                        .all()
            
            return [template.to_dict() for template in templates]
            
        except Exception as e:
            logger.error(f"Error getting plan templates: {str(e)}")
            return []
    
    # Updated PlanManager.initialize_plan_templates() with optimized pricing

    @staticmethod
    def initialize_plan_templates():
        """Initialize optimized plan templates with USD/INR dual pricing"""
        try:
            from database.model import db, PlanTemplate
            
            # Check if templates already exist
            if PlanTemplate.query.count() > 0:
                return True
            
            templates = [
                # FREE TIER 🆓
                {
                    'plan_type': 'free',
                    'plan_name': 'Free Tier',
                    'plan_category': 'free',
                    'description': '🆓 Discovery & Exploration - Perfect for trying out AI features',
                    'price_inr': 0.0,
                    'price_usd': 0.0,
                    'validity_days': 1,  # Keep same for all
                    'total_messages': 200,  # Increased for acquisition
                    'total_web_searches': 50,  # Increased
                    'max_input_tokens': 4000,
                    'daily_message_limit': 20,
                    'can_use_premium_models': False,
                    'can_upload_files': True,
                    'max_file_uploads': 20,  # Increased
                    'features': '200 messages/day, Standard models, 50 web searches, 20 file uploads',
                    'display_order': 1,
                    'is_popular': False,
                    'savings_text': 'Try for Free'
                },
                
                # BASIC PLANS 💰 (Pay-Per-Use)
                {
                    'plan_type': '12_day_basic',
                    'plan_name': '12-Day Power Pack',
                    'plan_category': 'basic',
                    'description': '💰 Flexibility Plan - Perfect for short-term projects',
                    'price_inr': 660.0,  # $8 * 82.5 INR
                    'price_usd': 8.0,
                    'validity_days': 12,
                    'total_messages': 300,  # Generous for 12 days
                    'total_web_searches': 90,
                    'max_input_tokens': 8000,
                    'daily_message_limit': None,
                    'can_use_premium_models': True,
                    'can_upload_files': True,
                    'max_file_uploads': None,  # Unlimited
                    'features': '300 messages, Standard + Premium models, 90 web searches, Unlimited uploads',
                    'display_order': 2,
                    'is_popular': False,
                    'savings_text': '$8 for 12 days'
                },
                {
                    'plan_type': '24_day_basic',
                    'plan_name': '24-Day Pro Pack',
                    'plan_category': 'basic',
                    'description': '💰 Best Basic Value - Save $2 on double duration!',
                    'price_inr': 1155.0,  # $14 * 82.5 INR  
                    'price_usd': 14.0,  # Save $2 from $16
                    'validity_days': 24,
                    'total_messages': 700,  # More than double
                    'total_web_searches': 210,  # More than double
                    'max_input_tokens': 12000,
                    'daily_message_limit': None,
                    'can_use_premium_models': True,
                    'can_upload_files': True,
                    'max_file_uploads': None,
                    'features': '700 messages, All models, 210 web searches, Priority processing',
                    'display_order': 3,
                    'is_popular': True,  # Mark as popular
                    'savings_text': 'Save $2 - Best Basic Value!'
                },
                
                # PRO PLANS 🚀 (Monthly Subscription)
                {
                    'plan_type': '1_month_pro',
                    'plan_name': '1-Month Power Pack',
                    'plan_category': 'pro',
                    'description': '🚀 Pro Monthly - All premium features unlocked',
                    'price_inr': 1320.0,  # $16 * 82.5 INR
                    'price_usd': 16.0,
                    'validity_days': 30,
                    'total_messages': 1200,  # 40 messages/day
                    'total_web_searches': 360,  # 12 searches/day
                    'max_input_tokens': 16000,
                    'daily_message_limit': None,
                    'can_use_premium_models': True,
                    'can_upload_files': True,
                    'max_file_uploads': None,
                    'priority_support': True,
                    'features': '1200 messages, All premium models, 360 web searches, Email support',
                    'display_order': 4,
                    'is_popular': False,
                    'savings_text': 'Pro Monthly'
                },
                {
                    'plan_type': '2_month_pro',
                    'plan_name': '2-Month Pro Pack',
                    'plan_category': 'pro', 
                    'description': '🚀 Maximum Value - Save $2 on double duration!',
                    'price_inr': 2475.0,  # $30 * 82.5 INR
                    'price_usd': 30.0,  # Save $2 from $32
                    'validity_days': 60,
                    'total_messages': 2800,  # More than double
                    'total_web_searches': 840,  # More than double  
                    'max_input_tokens': 32000,
                    'daily_message_limit': None,
                    'can_use_premium_models': True,
                    'can_upload_files': True,
                    'max_file_uploads': None,
                    'priority_support': True,
                    'phone_support': True,
                    'features': '2800 messages, Premium priority access, 840 web searches, Phone support',
                    'display_order': 5,
                    'is_popular': True,  # Mark as popular
                    'savings_text': 'Save $2 - Maximum Value!'
                }
            ]
            
            for template_data in templates:
                template = PlanTemplate(**template_data)
                db.session.add(template)
            
            db.session.commit()
            logger.info("Initialized optimized plan templates with USD/INR pricing")
            return True
            
        except Exception as e:
            from database.model import db
            db.session.rollback()
            logger.error(f"Error initializing plan templates: {str(e)}")
            return False

    # =============================================
    # PERMISSION CHECKS
    # =============================================
    
    @staticmethod
    def check_message_permission(user_id, provider=None, model=None, input_tokens=0):
        """Check if user can send a message with given parameters"""
        try:
            # Check basic limits
            limit_check = PlanManager.check_user_limits(user_id, 'message')
            
            if not limit_check['allowed']:
                return limit_check
            
            plan = limit_check['plan']
            
            # Check token limits
            if input_tokens > plan['max_input_tokens']:
                return {
                    "allowed": False,
                    "reason": f"Input too long. Maximum {plan['max_input_tokens']} tokens allowed.",
                    "upgrade_suggestion": "12_day" if plan['plan_type'] == 'free' else None
                }
            
            # Check premium model access
            if PlanManager.is_premium_model(provider, model) and not plan['can_use_premium_models']:
                return {
                    "allowed": False,
                    "reason": "Premium models not available in your plan",
                    "upgrade_suggestion": "12_day",
                    "suggested_model": PlanManager.get_alternative_model(provider)
                }
            
            return {"allowed": True, "plan": plan}
            
        except Exception as e:
            logger.error(f"Error checking message permission: {str(e)}")
            return {"allowed": False, "reason": "System error"}
    
    @staticmethod
    def check_web_search_permission(user_id):
        """Check if user can perform web search"""
        try:
            return PlanManager.check_user_limits(user_id, 'web_search')
        except Exception as e:
            logger.error(f"Error checking web search permission: {str(e)}")
            return {"allowed": False, "reason": "System error"}
    
    @staticmethod
    def check_file_upload_permission(user_id):
        """Check if user can upload files"""
        try:
            plan = PlanManager.get_current_user_plan(user_id)
            
            if not plan:
                return {"allowed": False, "reason": "No active plan"}
            
            if not plan['can_upload_files']:
                return {"allowed": False, "reason": "File uploads not available in your plan"}
            
            return {"allowed": True, "plan": plan}
            
        except Exception as e:
            logger.error(f"Error checking file upload permission: {str(e)}")
            return {"allowed": False, "reason": "System error"}
    
    @staticmethod
    def record_message_usage(user_id, provider, model, input_tokens, output_tokens, 
                           session_id=None, message_id=None, response_time_ms=None,
                           has_web_search=False, has_file_upload=False):
        """Record usage and update counters"""
        try:
            # Calculate cost
            estimated_cost = PlanManager.calculate_token_cost(
                provider, model, input_tokens, output_tokens
            )
            
            # Track detailed usage
            PlanManager.track_usage(
                user_id=user_id,
                action_type='message',
                provider=provider,
                model=model,
                input_tokens=input_tokens,
                output_tokens=output_tokens,
                estimated_cost=estimated_cost,
                session_id=session_id,
                message_id=message_id,
                response_time_ms=response_time_ms,
                has_web_search=has_web_search,
                has_file_upload=has_file_upload
            )
            
            # Update plan usage
            PlanManager.update_plan_usage(
                user_id=user_id,
                action_type='message',
                tokens_used=input_tokens + output_tokens,
                web_search=has_web_search
            )
            
            return True
            
        except Exception as e:
            logger.error(f"Error recording usage: {str(e)}")
            return False
    
    # =============================================
    # UTILITY METHODS
    # =============================================
    
    @staticmethod
    def get_alternative_model(provider):
        """Get alternative standard model for a provider"""
        alternatives = {
            "openai": "gpt-4o-mini",
            "google": "models/gemini-2.0-flash",
            "anthropic": "claude-3-5-haiku-20241022",
            "groq": "llama-3.1-8b-instant"
        }
        return alternatives.get(provider)
    
    @staticmethod
    def is_premium_model(provider, model):
        """Check if model is premium tier"""
        PREMIUM_MODELS = {
            "google": ["models/gemini-2.5-flash", "models/gemini-2.0-flash-thinking-exp"],
            "openai": ["o3", "gpt-4o", "gpt-4-turbo"],
            "anthropic": ["claude-opus-4-20250514", "claude-sonnet-4-20250514", "claude-3-5-sonnet-20241022", "claude-3-7-sonnet-20250219"],
            "groq": ["meta-llama/llama-4-maverick-17b-128e-instruct", "llama-3.3-70b-versatile", "deepseek-r1-distill-llama-70b"]
        }
        
        return model in PREMIUM_MODELS.get(provider, [])
    
    @staticmethod
    def calculate_token_cost(provider, model, input_tokens, output_tokens):
        """Calculate estimated cost for token usage"""
        # Cost per 1K tokens in USD
        PRICING = {
            "openai": {
                "gpt-4o-mini": {"input": 0.00015, "output": 0.0006},
                "gpt-4o": {"input": 0.0025, "output": 0.01},
                "gpt-4-turbo": {"input": 0.001, "output": 0.003},
                "o3": {"input": 0.01, "output": 0.04}
            },
            "google": {
                "models/gemini-2.0-flash": {"input": 0.000075, "output": 0.0003},
                "models/gemini-2.5-flash": {"input": 0.0001, "output": 0.0004}
            },
            "anthropic": {
                "claude-3-5-haiku-20241022": {"input": 0.0001, "output": 0.0005},
                "claude-3-5-sonnet-20241022": {"input": 0.003, "output": 0.015},
                "claude-opus-4-20250514": {"input": 0.015, "output": 0.075},
                "claude-sonnet-4-20250514": {"input": 0.003, "output": 0.015}
            },
            "groq": {
                "llama-3.1-8b-instant": {"input": 0.000075, "output": 0.00015},
                "llama-3.3-70b-versatile": {"input": 0.0005, "output": 0.0008},
                "deepseek-r1-distill-llama-70b": {"input": 0.0002, "output": 0.0004}
            }
        }
        
        provider_pricing = PRICING.get(provider, {})
        model_pricing = provider_pricing.get(model, {"input": 0.001, "output": 0.002})  # Default pricing
        
        input_cost = (input_tokens / 1000) * model_pricing["input"]
        output_cost = (output_tokens / 1000) * model_pricing["output"]
        
        return input_cost + output_cost
    
    @staticmethod
    def get_plan_usage_status(user_id):
        """Get current plan usage status for UI display"""
        try:
            plan = PlanManager.get_current_user_plan(user_id)
            
            if not plan:
                return {
                    "has_plan": False,
                    "plan_type": "none",
                    "suggestion": "Create free account to get started"
                }
            
            # Calculate percentages
            message_percent = (plan['messages_used'] / plan['total_messages']) * 100 if plan['total_messages'] > 0 else 0
            search_percent = (plan['web_searches_used'] / plan['total_web_searches']) * 100 if plan['total_web_searches'] > 0 else 0
            
            # Calculate days remaining
            days_remaining = plan['days_remaining']
            
            # Determine status
            status = "active"
            if message_percent >= 90 or search_percent >= 90:
                status = "low"
            elif days_remaining <= 1:
                status = "expiring"
            
            return {
                "has_plan": True,
                "plan": plan,
                "usage": {
                    "message_percent": round(message_percent, 1),
                    "search_percent": round(search_percent, 1),
                    "days_remaining": days_remaining,
                    "status": status
                },
                "limits": {
                    "can_use_premium": plan['can_use_premium_models'],
                    "can_upload_files": plan['can_upload_files'],
                    "max_input_tokens": plan['max_input_tokens']
                }
            }
            
        except Exception as e:
            logger.error(f"Error getting plan usage status: {str(e)}")
            return {"has_plan": False, "error": str(e)}
    
    @staticmethod
    def activate_plan(user_id, plan_type, payment_id=None, amount_paid=0):
        """Activate a new plan for user"""
        try:
            return PlanManager.create_user_plan(
                user_id=user_id,
                plan_type=plan_type,
                payment_id=payment_id,
                amount_paid=amount_paid
            )
        except Exception as e:
            logger.error(f"Error activating plan: {str(e)}")
            raise
    
    @staticmethod
    def suggest_upgrade(current_plan_type, reason):
        """Suggest appropriate upgrade based on current plan and usage"""
        upgrade_path = {
            "free": "12_day",
            "12_day": "24_day", 
            "24_day": "1_month",
            "1_month": "3_month",
            "3_month": "3_month"  # Already at top tier
        }
        
        suggestions = {
            "message_limit": {
                "title": "Need more messages?",
                "description": "Upgrade to continue chatting with AI",
                "benefits": ["More messages", "Premium models", "Faster responses"]
            },
            "token_limit": {
                "title": "Input too long?", 
                "description": "Upgrade for longer context windows",
                "benefits": ["Longer inputs", "Better context handling", "Complex conversations"]
            },
            "premium_model": {
                "title": "Want better AI?",
                "description": "Access premium models for better responses", 
                "benefits": ["GPT-4o, Claude Opus", "Better reasoning", "Higher accuracy"]
            },
            "web_search": {
                "title": "Need web search?",
                "description": "Get current information from the web",
                "benefits": ["Real-time data", "Latest information", "Research capabilities"]
            }
        }
        
        suggested_plan = upgrade_path.get(current_plan_type, "12_day")
        suggestion_details = suggestions.get(reason, suggestions["message_limit"])
        
        return {
            "suggested_plan": suggested_plan,
            "current_plan": current_plan_type,
            "reason": reason,
            **suggestion_details
        }
    
    @staticmethod
    def get_available_plans():
        """Get all available plans for purchase"""
        try:
            return PlanManager.get_all_plan_templates()
        except Exception as e:
            logger.error(f"Error getting available plans: {str(e)}")
            return []
        
    @staticmethod
    def format_plan_name(plan_type):
        """Format plan type to display name"""
        names = {
            'free': 'Free Plan',
            '12_day_basic': '12-Day Power Pack',
            '24_day_basic': '24-Day Pro Pack', 
            '1_month_pro': '1-Month Power Pack',
            '2_month_pro': '2-Month Pro Pack'
        }
        return names.get(plan_type, plan_type.replace('_', ' ').title())