# import os
# from flask import Flask, redirect, url_for, session, request
# from google_auth_oauthlib.flow import InstalledAppFlow
# import google.auth.transport.requests
# from googleapiclient.discovery import build
# from google.oauth2.credentials import Credentials

# # Allow HTTP for local development only
# if os.environ.get("FLASK_ENV") != "production":
#     os.environ['OAUTHLIB_INSECURE_TRANSPORT'] = '1'

# app = Flask(__name__)
# app.secret_key = 'your_secret_key'  # Required for sessions

# CLIENT_SECRET_FILE = r"D:\02_My_Learning_Resources\01_Learning_Projects\chat_application\release_chatbot_v3\GOOGLE_CLIENT_SECRET_FILE.json"
# SCOPES = [
#     'openid',
#     'https://www.googleapis.com/auth/userinfo.profile',
#     'https://www.googleapis.com/auth/userinfo.email',
#     'https://www.googleapis.com/auth/drive'
# ]

# def credentials_to_dict(credentials):
#     return {
#         'token': credentials.token,
#         'refresh_token': credentials.refresh_token,
#         'token_uri': credentials.token_uri,
#         'client_id': credentials.client_id,
#         'client_secret': credentials.client_secret,
#         'scopes': credentials.scopes
#     }

# @app.route('/')
# def index():
#     if 'user_info' in session:
#         user = session['user_info']
#         return f"Hello, {user.get('name')} ({user.get('email')})<br><a href='/drive-files'>View Drive Files</a><br><a href='/logout'>Logout</a>"
#     else:
#         return '<a href="/login">Login with Google</a>'

# @app.route('/login')
# def login():
#     flow = InstalledAppFlow.from_client_secrets_file(
#         CLIENT_SECRET_FILE, scopes=SCOPES)
#     flow.redirect_uri = url_for('callback', _external=True)
#     authorization_url, state = flow.authorization_url(
#         access_type='offline',
#         prompt='consent'  # Force user to re-consent and grant all scopes
#     )
#     session['state'] = state
#     return redirect(authorization_url)

# @app.route('/callback')
# def callback():
#     if request.args.get('state') != session.get('state'):
#         raise Exception('Invalid state parameter')

#     flow = InstalledAppFlow.from_client_secrets_file(
#         CLIENT_SECRET_FILE, scopes=SCOPES, state=session['state'])
#     flow.redirect_uri = url_for('callback', _external=True)
#     flow.fetch_token(authorization_response=request.url)

#     credentials = flow.credentials
#     print("Granted scopes:", credentials.scopes)  # Confirm scopes include Drive

#     authed_session = google.auth.transport.requests.AuthorizedSession(credentials)
#     userinfo_response = authed_session.get('https://openidconnect.googleapis.com/v1/userinfo')
#     user_info = userinfo_response.json()

#     session['credentials'] = credentials_to_dict(credentials)
#     session['user_info'] = user_info

#     return redirect(url_for('index'))

# @app.route('/drive-files')
# def drive_files():
#     if 'credentials' not in session:
#         return redirect(url_for('login'))

#     # Redirect user to Google Drive main page
#     return redirect('https://drive.google.com/drive/my-drive')

# @app.route('/logout')
# def logout():
#     session.clear()  # Properly clear session on logout
#     return redirect(url_for('index'))

# if __name__ == '__main__':
#     app.run(debug=True)



import razorpay


app = Flask(__name__)
app.secret_key = 'your_secret_key'  # Required for sessions


@app.route('/orders')
def orders():
        client = razorpay.Client(auth=(TEST_KEY_ID, TEST_KEY_SECRET))

        DATA = {
            "amount": 50000,
            "currency": "INR",
            "receipt": "receipt#1",
            "notes": {
                "key1": "value3",
                "key2": "value2"
            }
        }
        order = client.order.create(data=DATA)
    retrun order

if __name__ == '__main__':
    app.run(debug=True)